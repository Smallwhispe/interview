#!/bin/bash
RUN_NAME="ad.advertiser.bff"

mkdir -p output/bin output/conf
cp script/bootstrap.sh output 2>/dev/null
chmod +x output/bootstrap.sh
cp script/bootstrap.sh output/bootstrap_staging.sh
chmod +x output/bootstrap_staging.sh
find conf/ -type f ! -name "*_local.*" | xargs -I{} cp {} output/conf/

if [ "$BUILD_TYPE" = "offline" -o "$BUILD_TYPE" = "test" ]; then # 也可以自定义条件
#offline 表示线下版本编译
#test    表示测试版本编译
    echo "{\"branch_name\":\"$BUILD_BRANCH\",
    \"commit_id\":\"$BUILD_BASE_COMMIT_HASH\",
    \"scm_version\":\"$BUILD_VERSION($BUILD_REPO_NAME)\"}" > output/revision_file.txt
    # go1.17以上版本请用 go install code.byted.org/bet/go_coverage@tiktok_sg
    go install code.byted.org/bet/go_coverage@tiktok_sg
    go_coverage annotate -skip-files=vendor,test*,main.go,router.go,router_gen.go,common,biz/model,biz/router
    # -skip-files 过滤无需插桩的仓库目录, e.g. -skip-files=test*,example.go,pkg/
    # ≈ 默认过滤internal目录，需要internal目录插桩时添加-extra-info=include:internal
    # -main-folder=xxx 指定main文件的路径(main文件不在根目录时使用)
fi

if [ "x${TASK_FROM}" == "xSCM" -o "x${BUILD_TYPE}" == "xtest" ]; then
	wget https:code.byted.org/ad/common_tool/blob/auxiliary/toolkit/auxiliary/thrift && mv thrift /usr/local/bin/

	go install code.byted.org/middleware/hertztool/v3@v3.1.2
	go install code.byted.org/kite/kitex/tool/cmd/kitex@v1.10.4
fi

make -f Makefile idl

go build -o output/bin/${RUN_NAME}
