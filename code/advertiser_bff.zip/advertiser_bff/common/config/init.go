package config

import (
	"fmt"
	"os"
	"strings"

	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
	"github.com/spf13/viper"
)

const (
	defaultConfigFileName string = "default"
)

func Init() {
	region := env.Region()
	if len(region) <= 0 {
		region = "BOE"
	}

	appRootDir := os.Getenv("APP_ROOT_DIR")
	if len(appRootDir) == 0 {
		appRootDir, _ = os.Getwd()
		if strings.HasSuffix(appRootDir, "/test") {
			appRootDir = appRootDir[:len(appRootDir)-len("/test")] // test代码启动位置带test后缀，需要移除
		}
	}

	defaultConfigFileFullPath := fmt.Sprintf("%s/conf/%s.yaml", appRootDir, defaultConfigFileName)
	envConfigFileFullPath := fmt.Sprintf("%s/conf/%s.yaml", appRootDir, region)

	logs.Info("default config path: %v", defaultConfigFileFullPath)
	logs.Info("env config path: %v", envConfigFileFullPath)

	// 读取默认配置文件
	viper.SetConfigFile(defaultConfigFileFullPath)
	err := viper.ReadInConfig()
	if err != nil {
		logs.Fatalf("Read default config=%v, fail: %v", defaultConfigFileFullPath, err)
	}

	/*
	   使用环境配置覆盖默认配置
	   环境相关的配置文件不存在时将忽略并使用默认配置
	*/
	if _, err = os.Stat(envConfigFileFullPath); err == nil {
		viper.SetConfigFile(envConfigFileFullPath)
		err = viper.MergeInConfig()
		if err != nil {
			logs.Fatalf("Read env config=%v, failed:%v", envConfigFileFullPath, err)
		}
	} else {
		logs.Info("Can not find the env config file: %v", envConfigFileFullPath)
		logs.Info("Using default config to set up...")
	}
}
