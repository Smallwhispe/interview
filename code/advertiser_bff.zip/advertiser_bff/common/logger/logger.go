package logger

import (
	"strings"

	"code.byted.org/gopkg/logs"
	"github.com/spf13/viper"
)

var lvlmap = map[string]int{
	"trace":  logs.LevelTrace,
	"debug":  logs.LevelDebug,
	"info":   logs.LevelInfo,
	"notice": logs.LevelNotice,
	"warn":   logs.LevelWarn,
	"error":  logs.LevelError,
	"fatal":  logs.LevelFatal,
}

func Init() {
	var defaultLevel = logs.LevelInfo
	var level = viper.GetString("log.level")
	if lvl, ok := lvlmap[strings.ToLower(level)]; ok {
		defaultLevel = lvl
	}
	logs.SetLevel(defaultLevel)
}
