package tcc

import (
	"os"

	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/tccclient"
	"github.com/spf13/viper"
)

var (
	nsAccount *tccclient.ClientV2
)

func GetAccount() *tccclient.ClientV2 { return nsAccount }

func Init() {
	initAccountClient()
}

func initAccountClient() {
	nsAccount = initClient(viper.GetString("tcc.namespace.adv_account_i18n"))
}

func initClient(namespace string) *tccclient.ClientV2 {
	config := tccclient.NewConfigV2()
	cln, err := tccclient.NewClientV2(namespace, config)
	if err != nil {
		logs.Error("init tcc %v failed, errmsg=%v", namespace, err)
		os.Exit(1)
	}
	return cln
}
