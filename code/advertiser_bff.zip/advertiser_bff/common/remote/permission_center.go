package remote

import (
	"os"

	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/tt4b/permission_center/permissioncenterservice"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client"
	"github.com/spf13/viper"
)

var PermissionCenterClient permissioncenterservice.Client

func GetPermissionCenterClient() permissioncenterservice.Client {
	return PermissionCenterClient
}

func initPermissionCenterClient() {
	var err error
	var psm = viper.GetString("service.permission_center.name")

	PermissionCenterClient, err = permissioncenterservice.NewClient(psm, client.WithSuite(NewDefaultKXClientSuite()))
	if err != nil {
		logs.Fatal("init %v client failed, errmsg=%v", psm, err)
		os.Exit(1)
	}
}
