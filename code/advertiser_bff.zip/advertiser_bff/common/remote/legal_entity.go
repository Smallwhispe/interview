package remote

import (
	"os"

	"code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service/legalentityservice"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client"
	"github.com/spf13/viper"
)

var LegalEntityClient legalentityservice.Client

func GetLegalEntityClient() legalentityservice.Client {
	return LegalEntityClient
}

func initLegalEntityClient() {
	var err error
	psm := viper.GetString("service.legal_entity.name")

	LegalEntityClient, err = legalentityservice.NewClient(psm, client.WithSuite(NewDefaultKXClientSuite()))
	if err != nil {
		logs.Fatal("init %v client failed, err msg=%v", psm, err)
		os.Exit(1)
	}
}
