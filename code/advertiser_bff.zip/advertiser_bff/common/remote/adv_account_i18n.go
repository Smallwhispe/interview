package remote

import (
	"os"

	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n/accountservice"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client"
	"github.com/spf13/viper"
)

var AdvAccountClient accountservice.Client

func GetAdvAccountClient() accountservice.Client {
	return AdvAccountClient
}

func initAdvAccountClient() {
	var err error
	var psm = viper.GetString("service.adv_account_i18n.name")

	AdvAccountClient, err = accountservice.NewClient(psm, client.WithSuite(NewDefaultKXClientSuite()))
	if err != nil {
		logs.Fatal("init %v client failed, errmsg=%v", psm, err)
		os.Exit(1)
	}
}
