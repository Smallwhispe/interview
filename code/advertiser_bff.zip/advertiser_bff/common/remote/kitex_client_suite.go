package remote

import (
	"context"
	"time"

	"code.byted.org/ad/advertiser_bff/toolkit/encoding"
	"code.byted.org/ad/advertiser_bff/toolkit/metrics"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client"
	"code.byted.org/kite/kitex/pkg/connpool"
	"code.byted.org/kite/kitex/pkg/endpoint"
	"code.byted.org/kite/kitex/pkg/rpcinfo"
)

type KiteXClientSuite struct {
	ConnectTimeOut        time.Duration
	RPCTimeout            time.Duration
	LongConnection        connpool.IdleConfig
	RPCWarningTime        map[string]time.Duration
	DefaultRPCWarningTime time.Duration
}

func NewDefaultPool() connpool.IdleConfig {
	return connpool.IdleConfig{
		MaxIdlePerAddress: 100,
		MaxIdleGlobal:     500,
		MaxIdleTimeout:    60 * time.Second,
	}
}

func NewDefaultKXClientSuite() *KiteXClientSuite {
	return &KiteXClientSuite{
		ConnectTimeOut:        2 * time.Second,
		RPCTimeout:            5 * time.Second,
		LongConnection:        NewDefaultPool(),
		DefaultRPCWarningTime: 2 * time.Second,
	}
}

func (slf *KiteXClientSuite) Options() []client.Option {
	return []client.Option{
		client.WithLongConnection(NewDefaultPool()),
		client.WithMiddleware(slf.CommonKiteXMetricsMW()),
		client.WithMiddleware(slf.CommonKiteClientLogging()),
	}
}

func (slf *KiteXClientSuite) CommonKiteXMetricsMW() endpoint.Middleware {
	return func(point endpoint.Endpoint) endpoint.Endpoint {
		return func(ctx context.Context, req, resp interface{}) error {
			begin := time.Now()
			err := point(ctx, req, resp)
			cost := elapsed(begin)
			rpcInfo := rpcinfo.GetRPCInfo(ctx)
			method := "unknow"
			if rpcInfo.To() != nil {
				method = rpcInfo.To().Method()
			}
			warningTime := slf.DefaultRPCWarningTime
			if WTime, exits := slf.RPCWarningTime[method]; exits {
				warningTime = WTime
			}
			fromMethod := "unknow"
			if rpcInfo.From() != nil {
				fromMethod = rpcInfo.From().Method()
			}

			baseTag := map[string]string{metrics.TagThirdMethod: method, metrics.TagMethodName: fromMethod,
				metrics.TagWarnTimeout: string(metrics.TagTTLFalse)}

			if cost > warningTime.Milliseconds() {
				logs.CtxWarn(ctx, "Method = %v RPC-Call cost[%v] >[%v] Milliseconds ",
					method, cost, warningTime.Milliseconds())
				baseTag[metrics.TagWarnTimeout] = metrics.TagTTLTrue
			}
			metrics.EmitTimer(metrics.ThirdRpc, cost, baseTag)
			if err != nil {
				logs.CtxWarn(ctx, "Method = %v Call-error=%v ", method, err)
				metrics.EmitFail(metrics.ThirdRpc, baseTag)
			} else {
				metrics.EmitCounter(metrics.ThirdRpc, baseTag)
			}
			return err
		}
	}
}

func (slf *KiteXClientSuite) CommonKiteClientLogging() endpoint.Middleware {
	return func(point endpoint.Endpoint) endpoint.Endpoint {
		return func(ctx context.Context, request, response interface{}) error {
			begin := time.Now()
			err := point(ctx, request, response)
			cost := elapsed(begin)
			rpcInfo := rpcinfo.GetRPCInfo(ctx)
			method := "unknown"
			if rpcInfo != nil {
				method = rpcInfo.To().Method()
			}

			if err != nil {
				logs.CtxWarn(ctx, "invoke %v failed=%v, cost=%v",
					method, err, cost)
			} else {
				logs.CtxInfo(ctx, "invoke %v success, cost=%v, response=%v",
					method, cost, encoding.UnsafeEncode(response))
			}
			return err
		}
	}
}

func elapsed(t1 time.Time) int64 {
	return time.Now().Sub(t1).Milliseconds()
}
