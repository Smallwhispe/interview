package remote

import (
	"os"

	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/region/regionservice"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client"
	"github.com/spf13/viper"
)

var RegionClient regionservice.Client

func GetRegionClient() regionservice.Client {
	return RegionClient
}

func initRegionClient() {
	var err error
	var psm = viper.GetString("service.region.name")

	RegionClient, err = regionservice.NewClient(psm, client.WithSuite(NewDefaultKXClientSuite()))
	if err != nil {
		logs.Fatal("init %v client failed, errmsg=%v", psm, err)
		os.Exit(1)
	}
}
