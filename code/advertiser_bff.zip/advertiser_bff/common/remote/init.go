package remote

func Init() {
	initRegionClient()
	initToolboxClient()
	initAdvAccountClient()
	initPermissionCenterClient()
	initLegalEntityClient()
	initFGClient()
}
