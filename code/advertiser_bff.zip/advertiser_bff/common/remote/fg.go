package remote

import (
	"os"

	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/feature_gating_srv/adfeaturegatingservice"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client"
	"github.com/spf13/viper"
)

var FGClient adfeaturegatingservice.Client

func GetFGClient() adfeaturegatingservice.Client {
	return FGClient
}

func initFGClient() {
	var err error
	psm := viper.GetString("service.fg.name")

	FGClient, err = adfeaturegatingservice.NewClient(psm, client.WithSuite(NewDefaultKXClientSuite()))
	if err != nil {
		logs.Fatal("init %v client failed, errmsg=%v", psm, err)
		os.Exit(1)
	}
}
