package remote

import (
	"os"

	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/toolbox_i18n/toolboxi18nservice"
	"code.byted.org/gopkg/logs"
	"code.byted.org/kite/kitex/client"
	"github.com/spf13/viper"
)

var ToolboxClient toolboxi18nservice.Client

func GetToolboxClient() toolboxi18nservice.Client {
	return ToolboxClient
}

func initToolboxClient() {
	var err error
	var psm = viper.GetString("service.toolbox_i18n.name")

	ToolboxClient, err = toolboxi18nservice.NewClient(psm, client.WithSuite(NewDefaultKXClientSuite()))
	if err != nil {
		logs.Fatal("init %v client failed, errmsg=%v", psm, err)
		os.Exit(1)
	}
}
