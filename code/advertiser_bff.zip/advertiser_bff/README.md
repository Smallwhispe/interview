# ad.advertiser.bff
广告主账户中心的 BFF


## 注意📢
- ***代码仓库不保存 kitex 生成的代码,需要在本地编译***
- 修改了本项目的 IDL
- 依赖服务的 IDL 文件需要拷贝到本仓库 idl 目录下
- 需要及时到 BAM 平台生成新的接口文档


## IDL生成代码
### 生成服务自身代码
```shell
make self
```

### 生成所有服务代码
```shell
make all
```

### 生成 adv_account_i18n 代码
```
make adv_account
```

### 生成 region 代码
```
make region
```

### 生成 permission 代码
```
make permission
```

### 生成 toolbox 代码
```
make toolbox
```

### 检查代码规范
```
make vet
```

### 删除临时文件
```
make clean
```

### 本地运行单元测试
```
make test
```
