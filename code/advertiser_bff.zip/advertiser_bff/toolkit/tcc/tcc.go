package tcc

import (
	"context"
	"encoding/json"
	"strconv"

	"code.byted.org/ad/advertiser_bff/common/tcc"
	"code.byted.org/gopkg/logs"
	"code.byted.org/gopkg/tccclient"
)

func Get(ctx context.Context, cln *tccclient.ClientV2, key string) (string, error) {
	retval, err := cln.Get(ctx, key)
	if err != nil {
		logs.CtxWarn(ctx, "get tcc config [%v] failed, errmsg=%v", key, err)
	}
	return retval, err
}

func GetString(ctx context.Context, cln *tccclient.ClientV2, key string) (string, error) {
	return Get(ctx, cln, key)
}

func GetBoolean(ctx context.Context, cln *tccclient.ClientV2, key string) (bool, error) {
	retval, err := GetString(ctx, cln, key)
	if err != nil {
		return false, err
	}
	return strconv.ParseBool(retval)
}

func GetBooleanWithDefault(ctx context.Context, cln *tccclient.ClientV2, key string, def bool) bool {
	retval, err := GetBoolean(ctx, cln, key)
	if err != nil {
		return def
	}
	return retval
}

func GetAndParse(ctx context.Context, cln *tccclient.ClientV2, key string, value interface{}) error {
	retval, err := GetString(ctx, cln, key)
	if err != nil {
		return err
	}
	return json.Unmarshal([]byte(retval), &value)
}

func GetOpen2SVSwitch(ctx context.Context) bool {
	return GetBooleanWithDefault(ctx, tcc.GetAccount(), SwitchOpen2SV, false)
}
