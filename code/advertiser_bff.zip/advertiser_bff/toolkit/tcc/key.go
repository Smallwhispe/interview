package tcc

const (
	SwitchOpen2SV = "open_2sv_switch"
)
