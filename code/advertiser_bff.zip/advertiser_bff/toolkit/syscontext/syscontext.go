package syscontext

import (
	"code.byted.org/ad/common_mw_lib/constants"
	"code.byted.org/ad/mwlib/basic/model"
	"code.byted.org/ad/mwlib/mwhertz"
	"code.byted.org/middleware/hertz/pkg/app"
)

func IsShopifyRequest(ctx *app.RequestContext) bool {
	return mwhertz.IsShopifyRequest(ctx)
}

func GetAccessAdvID(ctx *app.RequestContext) int64 {
	return ctx.GetInt64(constants.ADVERTISER_ID)
}

func GetCoreUserID(ctx *app.RequestContext) int64 {
	return ctx.GetInt64(constants.CORE_USER_ID)
}

func GetStaffID(ctx *app.RequestContext) int64 {
	return ctx.GetInt64(constants.STAFF_ID)
}

func GetAdvLoginInfo(ctx *app.RequestContext) (*model.AdvLoginInfo, error) {
	return mwhertz.GetAdvLogInfo(ctx)
}
