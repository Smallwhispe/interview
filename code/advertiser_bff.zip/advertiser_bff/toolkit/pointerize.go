package toolkit

func NewPtr[T any](v T) *T { return &v }
