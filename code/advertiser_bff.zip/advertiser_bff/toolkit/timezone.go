package toolkit

import (
	"time"
)

const (
	TimeFormat         = "2006-01-02 15:04:05"
	TimeFormatNoSecond = "2006-01-02 15:04"
)

func UTC2LocalTime(utcTime string, timezone string) string {
	loc, err := time.LoadLocation(timezone)
	if err != nil {
		return utcTime
	}

	t, err := time.Parse(TimeFormat, utcTime)
	if err != nil {
		return utcTime
	}

	return t.In(loc).Format(TimeFormat)
}

func TimeRemoveSecond(input string) string {
	t, err := time.Parse(TimeFormat, input)
	if err != nil {
		return input
	}
	return t.Format(TimeFormatNoSecond)
}
