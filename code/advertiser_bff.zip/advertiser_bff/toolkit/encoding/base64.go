package encoding

import "encoding/base64"

func Base64Encode(raw string) string {
	if len(raw) == 0 {
		return raw
	}
	return base64.StdEncoding.EncodeToString([]byte(raw))
}
