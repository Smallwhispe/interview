package encoding

import "encoding/json"

func UnsafeEncode(val interface{}) string {
	data, err := json.Marshal(val)
	if err != nil {
		return string(data)
	}
	return string(data)
}

func ToString(val interface{}) (string, error) {
	data, err := json.Marshal(val)
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func ConvertToStruct(origin interface{}, object interface{}) error {
	data, err := json.Marshal(origin)
	if err != nil {
		return err
	}
	return json.Unmarshal(data, &object)
}
