package metrics

import (
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/metrics"
)

var metricsClient *metrics.MetricsClientV2

func init() {
	metricsClient = metrics.NewDefaultMetricsClientV2(env.PSM(), true)
}

func createTSliceFromTagKv(tagKV map[string]string) []metrics.T {
	tSlice := make([]metrics.T, 0, len(tagKV))
	for k, v := range tagKV {
		tSlice = append(tSlice, metrics.T{Name: k, Value: v})
	}
	return tSlice
}
