package metrics

const (
	ThirdRpc   = ".general.third.rpc.called"
	HttpResult = "through.counter"

	Success string = ".success"
	Error   string = ".error"
	Timer   string = ".timer"

	TagWarnTimeout = "limit_time_out"
	TagThirdMethod = "to_method"
	TagMethodName  = "from_method"

	TagTTLTrue  = "true"
	TagTTLFalse = "false"
)

func emitCounter(name string, tagKV map[string]string) {
	metricsClient.EmitCounter(name, 1, createTSliceFromTagKv(tagKV)...)
}

func emitTimer(name string, value interface{}, tagKV map[string]string) {
	metricsClient.EmitTimer(name, value, createTSliceFromTagKv(tagKV)...)
}

func EmitFail(name string, tagKV map[string]string) {
	emitCounter(name+Error, tagKV)
}

func EmitCounter(name string, tagKV map[string]string) {
	emitCounter(name+Success, tagKV)
}

func EmitTimer(name string, value interface{}, tagKV map[string]string) {
	emitTimer(name+Timer, value, tagKV)
}

func EmitHttpResult(tags map[string]string) {
	emitCounter(HttpResult, tags)
}
