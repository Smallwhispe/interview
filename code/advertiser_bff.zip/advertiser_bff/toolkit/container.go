package toolkit

type Slice[T comparable] []T

func (s Slice[T]) Contain(v T) bool {
	for _, val := range s {
		if val == v {
			return true
		}
	}
	return false
}

func Contains[T comparable](s []T, t T) bool {
	for _, tmp := range s {
		if tmp == t {
			return true
		}
	}
	return false
}
