#!/bin/bash
set -e

module_name=$(cat go.mod | grep module | cut -d ' ' -f 2-2)
echo "module_name is $module_name"

excludePkgCmd="go list ./... | grep -vE 'thrift_gen|kitex_gen|conf|test|clients|upstream|redis|toolkit|biz/handler|biz/model|biz/router|common'"
covPkgCmd="${excludePkgCmd} | paste -sd "," -"
covPkg=$(eval ${covPkgCmd})
echo "covPkg is $covPkg"

GO111MODULE=on

if [ "x${CI_JOB_ID}" != "x" ]; then
	wget https://code.byted.org/ad/common_tool/blob/auxiliary/toolkit/auxiliary/thrift && chmod +x thrift && mv thrift /usr/local/bin/

	go install code.byted.org/middleware/hertztool/v3@v3.1.2
	go install code.byted.org/kite/kitex/tool/cmd/kitex@v1.10.4

	# generate code of IDL
	make -f Makefile idl
fi

go test -gcflags="all=-N -l"  ./test/...   -v -covermode=set  -coverpkg=$covPkg -coverprofile=cover.out
go tool cover -func=cover.out -o cover_detail.txt
go tool cover -html=cover.out -o cover.html
