package interceptor

import (
	"context"
	"runtime/debug"

	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
)

func RecoveryInterceptor() app.HandlerFunc {
	return func(ctx context.Context, c *app.RequestContext) {
		defer func() {
			if err := recover(); err != nil {
				var method = string(c.Method())
				var queryString = getQueryStringParam(c)
				var requestBody = string(c.Request.Body())

				logs.CtxError(ctx, "!!!panic!!! error=%v\nrequest=%v %v %v\n%v",
					err, method, queryString, requestBody, string(debug.Stack()))
			}
		}()
		c.Next(ctx)
	}
}
