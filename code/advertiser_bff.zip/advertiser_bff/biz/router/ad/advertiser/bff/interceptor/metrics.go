package interceptor

import (
	"context"
	"fmt"

	"code.byted.org/ad/advertiser_bff/toolkit/metrics"
	"code.byted.org/ad/mwlib/basic/response"
	"code.byted.org/middleware/hertz/pkg/app"
)

const successCode = 0

func MetricsInterceptor() app.HandlerFunc {
	return func(ctx context.Context, c *app.RequestContext) {
		c.Next(ctx)

		var reply = response.UnmarshalResponse(c.Response.BodyBytes())

		metrics.EmitHttpResult(map[string]string{
			"router":      string(c.Path()),
			"status_code": fmt.Sprint(reply.Code),
			"is_success":  fmt.Sprint(reply.Code == successCode),
		})
	}
}
