package interceptor

import (
	"context"
	"net/http"
	"strings"

	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
)

func LoggerInterceptor() app.HandlerFunc {
	return func(ctx context.Context, c *app.RequestContext) {
		c.Next(ctx)

		if string(c.Method()) == http.MethodGet {
			logGetMethod(ctx, c)
			return
		}
		logPostMethod(ctx, c)
	}
}

func getQueryStringParam(c *app.RequestContext) string {
	var deleted = map[string]bool{
		"isInit":     true,
		"msToken":    true,
		"X-Bogus":    true,
		"_signature": true,
	}

	var data []string
	var list = strings.Split(c.Request.URI().QueryArgs().String(), "&")
	for _, val := range list {
		l, _, _ := strings.Cut(val, "=")
		if _, ok := deleted[l]; ok {
			continue
		}
		data = append(data, val)
	}

	return strings.Join(data, "&")
}

func logGetMethod(ctx context.Context, c *app.RequestContext) {
	var method = string(c.Method())
	var queryString = getQueryStringParam(c)
	var reply = string(c.Response.BodyBytes())

	if len(c.Errors) > 0 {
		logs.CtxWarn(ctx, "%v %v\nerror=%v\nresponse=%v", method, queryString,
			c.Errors.String(), reply)
		return
	}
	logs.CtxInfo(ctx, "%v %v\nresponse=%v", method, queryString, reply)
}

func logPostMethod(ctx context.Context, c *app.RequestContext) {
	var method = string(c.Method())
	var queryString = getQueryStringParam(c)
	var request = string(c.Request.Body())
	var reply = string(c.Response.BodyBytes())

	if len(c.Errors) > 0 {
		logs.CtxWarn(ctx, "%v %v\nerror=%v\nrequest=%v\nresponse=%v", method, queryString,
			c.Errors.String(), request, reply)
		return
	}
	logs.CtxInfo(ctx, "%v %v\nrequest=%v\nresponse=%v", method, queryString, request, reply)
}
