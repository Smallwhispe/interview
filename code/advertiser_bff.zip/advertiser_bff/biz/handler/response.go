package handler

import (
	"context"
	"net/http"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/common_mw_lib/mw_render"
	"code.byted.org/ad/mwlib/basic/response"
	"code.byted.org/gopkg/logs"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/middleware/hertz_ext/v2/binding"
	"github.com/cloudwego/hertz/pkg/protocol/consts"
)

func reply(ctx context.Context, c *app.RequestContext, reply interface{}, err error) {
	if err != nil {
		switch err.(type) {
		case *errcode.ErrCode:
		default:
			err = errcode.ErrSystemException
		}
		c.Render(consts.StatusOK, mw_render.NewMWErrorRender(ctx, c, err.(*errcode.ErrCode).ToMWError()))
		c.Abort()
		return
	}

	if err := binding.WriteHeader(c, &reply); err != nil {
		logs.CtxWarn(ctx, "failed to render header/cookie using respnse body, %v", err)
		c.Render(consts.StatusOK, mw_render.NewMWErrorRender(ctx, c, errcode.ErrSystemException.ToMWError()))
		c.Abort()
		return
	}

	c.JSON(http.StatusOK, response.SuccessRespBuilder().AddExtra(map[string]interface{}{}).AddData(reply))
}
