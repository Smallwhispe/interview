package sal

import (
	"context"
	"sync"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gptr"
	"github.com/spf13/viper"
)

const (
	errcodeAdvAccountNotExist = 101
)

var (
	once sync.Once
	auth *account_i18n.Auth
)

func getAuth() *account_i18n.Auth {
	once.Do(func() {
		auth = &account_i18n.Auth{
			AppKey:    viper.GetInt64("service.adv_account_i18n.auth.key"),
			AppSecret: viper.GetString("service.adv_account_i18n.auth.secret"),
		}
	})
	return auth
}

func GetAdvertiserInfo(ctx context.Context, advID int64, needIndustry bool) (*account_i18n.AdvertiserData, error) {
	var req = account_i18n.GetAdvAccountByIdRequest{
		AdvertiserId: &advID,
		Auth:         getAuth(),
	}

	if needIndustry {
		req.NeedIndustryVersion = gptr.Of(int32(400))
	}

	var resp, err = remote.GetAdvAccountClient().GetAdvAccountById(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "GetAdvAccountById failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() == errcodeAdvAccountNotExist {
		return nil, errcode.ErrDataNotFound
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "GetAdvAccountById failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp.GetAdvertiser(), nil
}

func GetAdvSensitiveContactInfo(ctx context.Context, uid int64, advID int64) (*account_i18n.AdvContactInfo, error) {
	var req = account_i18n.GetAdvSensitiveContactInfoRequest{
		AdvertiserId: advID,
		OperatorId:   &uid,
		Auth:         getAuth(),
	}

	var resp, err = remote.GetAdvAccountClient().GetAdvSensitiveContactInfo(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "GetAdvSensitiveContactInfo failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "GetAdvSensitiveContactInfo failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}

	return resp.GetContactInfo(), nil
}

func GetAdvContactInfo(ctx context.Context, userID int64, advID int64) (*account_i18n.AdvContactInfo, error) {
	var req = account_i18n.GetAdvContactInfoRequest{
		AdvertiserId: advID,
		OperatorId:   &advID,
		Auth:         getAuth(),
	}

	var resp, err = remote.GetAdvAccountClient().GetAdvContactInfo(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "GetAdvContactInfo failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "GetAdvContactInfo failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}

	return resp.GetContactInfo(), nil
}

func GetAdvTaxInfo(ctx context.Context, lang string, userID, advID int64) (*account_i18n.GetAdvTaxResponse, error) {
	var req = account_i18n.GetAdvTaxRequest{
		Auth:         getAuth(),
		Lang:         &lang,
		AdvertiserId: advID,
		OperatorId:   toolkit.NewPtr[int64](userID),
	}

	var resp, err = remote.GetAdvAccountClient().GetAdvTax(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "GetAdvTax failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "GetAdvTax failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp, nil
}

func MultiGetSubjectInfo(ctx context.Context, advIDs []int64,
	readMaster bool, needPayer *bool) (map[int64]*account_i18n.AdvertiserSubjectInfo, error) {
	var req = account_i18n.MultiGetAdvSubjectInfoRequest{
		AdvertiserIds: advIDs,
		ReadMaster:    &readMaster,
		NeedPayer:     needPayer,
		Auth:          getAuth(),
	}

	var resp, err = remote.GetAdvAccountClient().MultiGetAdvSubjectInfo(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "MultiGetAdvSubjectInfo failed, req=%v, err_msg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "MultiGetAdvSubjectInfo failed, err_code=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp.GetAdvertisers(), nil
}

func UpdateAdvAccount(ctx context.Context, req *account_i18n.UpdateAdvAccountRequest) error {
	resp, err := remote.GetAdvAccountClient().UpdateAdvAccount(ctx, req)
	if err != nil {
		logs.CtxWarn(ctx, "UpdateAdvAccount failed, req=%v, errmsg=%v", req, err)
		return errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "UpdateAdvAccount failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return errcode.ErrSystemException
	}
	return nil
}

func UpdateAdvTaxInfo(ctx context.Context, req *account_i18n.UpdateAdvTaxInfoRequest) error {
	resp, err := remote.GetAdvAccountClient().UpdateAdvTaxInfo(ctx, req)
	if err != nil {
		logs.CtxWarn(ctx, "UpdateAdvTaxInfo failed, req=%v, errmsg=%v", req, err)
		return errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "UpdateAdvTaxInfo failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return errcode.ErrSystemException
	}
	return nil
}

func WebIdSdkApi(ctx context.Context, req *account_i18n.WebIdSdkApiRequest) (
	*account_i18n.WebIdSdkApiResponse, error,
) {
	resp, err := remote.GetAdvAccountClient().WebIdSdkApi(ctx, req)
	if err != nil {
		logs.CtxWarn(ctx, "WebIdSdkApi failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "WebIdSdkApi failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp, nil
}

func GetWebId(ctx context.Context, ttwid string) int64 {
	if len(ttwid) == 0 {
		return 0
	}
	resp, err := WebIdSdkApi(ctx, &account_i18n.WebIdSdkApiRequest{
		Ttwid: ttwid,
	})
	if err != nil {
		return 0
	}
	return resp.WebID
}
