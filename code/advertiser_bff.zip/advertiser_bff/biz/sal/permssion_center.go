package sal

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/tt4b/permission_center"
	"code.byted.org/gopkg/logs"
)

const (
	PermissionCenterAppIDPlatform = 2
)

func CheckTwoStepVerify(ctx context.Context, userID int64, advID int64) (bool, error) {
	var req = permission_center.CheckTwoStepVerifyRequest{
		AppId: PermissionCenterAppIDPlatform,
		Subject: &permission_center.SubjectEntity{
			SubjectId:   userID,
			SubjectType: permission_center.SubjectType_BizUser,
		},
		Object: &permission_center.ObjectEntity{
			ObjectId:   advID,
			ObjectType: permission_center.ObjectType_Account,
		},
	}

	var resp, err = remote.GetPermissionCenterClient().CheckTwoStepVerify(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "CheckTwoStepVerify failed, req=%v, errmsg=%v", req, err)
		return false, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil || resp.BaseResp.StatusCode != 0 {
		return false, errcode.ErrSystemException
	}

	return resp.GetCanAccess(), nil
}
