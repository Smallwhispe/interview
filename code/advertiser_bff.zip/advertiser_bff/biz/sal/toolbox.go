package sal

import (
	"context"
	"strconv"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/currency"
	"code.byted.org/ad/advertiser_bff/toolkit/encoding"
	"code.byted.org/gopkg/logs"
)

type CurrencyInfo struct {
	En     string `json:"en"`
	Ja     string `json:"ja"`
	Num    string `json:"num"`
	Unit   string `json:"unit"`
	Name   string `json:"name"`
	Ratio  string `json:"ratio"`
	Symbol string `json:"symbol"`
}

// GetRatioInt64 转换 ratio 类型,转换失败返回 100000
func (c CurrencyInfo) GetRatioInt64() int64 {
	if val, err := strconv.ParseInt(c.Ratio, 10, 64); err == nil {
		return val
	}
	return 100000
}

func (c CurrencyInfo) GetUnitInt64() int64 {
	if val, err := strconv.ParseInt(c.Unit, 10, 64); err == nil {
		return val
	}
	return 0
}

func GetCurrencyInfo(ctx context.Context, code string) (*CurrencyInfo, error) {
	var info CurrencyInfo
	var req = currency.CurrencyRequest{Code: &code}

	var resp, err = remote.GetToolboxClient().GetCurrencyList(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "GetCurrencyList failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "GetCurrencyList failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	if len(resp.GetData()) == 0 || resp.GetData()[0].Attrs == nil {
		logs.CtxWarn(ctx, "GetCurrencyList data not found, code=%v", code)
		return nil, errcode.ErrDataNotFound
	}

	if err := encoding.ConvertToStruct(resp.GetData()[0].Attrs, &info); err != nil {
		return nil, err
	}
	return &info, nil
}
