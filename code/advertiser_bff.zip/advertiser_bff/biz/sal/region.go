package sal

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/region"
	"code.byted.org/gopkg/logs"
)

func GetRegionInfo(ctx context.Context, advID int64) (*region.EntityRegion, error) {
	var req = region.GetRegionInfoRequest{
		Entity: &region.Entity{
			Id:   &advID,
			Type: region.EntityType_ADVERTISER,
		},
	}
	var resp, err = remote.GetRegionClient().GetRegionInfo(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "GetRegionInfo failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "GetRegionInfo failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp.GetEntityRegion(), nil
}
