package sal

import (
	"context"
	"fmt"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/feature_gating_srv"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/gopkg/logs"
)

const (
	ProjectName = "business_center"
)

func BatchGetConfig(ctx context.Context, configs []string, entityID int64, contextStr *string,
	entityType feature_gating_srv.UserTagEntityType,
) (map[string]bool, error) {
	if len(configs) == 0 {
		return nil, nil
	}
	req := feature_gating_srv.BatchGetConfigRequest{
		ProjectName: ProjectName,
		ConfigNames: configs,
		EntityType:  entityType,
		EntityId:    fmt.Sprint(entityID),
		Context:     contextStr,
		SkipCache:   toolkit.NewPtr(true),
	}
	resp, err := remote.GetFGClient().BatchGetConfig(ctx, &req)
	if err != nil {
		logs.CtxWarn(ctx, "BatchGetConfig failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}

	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "BatchGetConfig failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp.IsEnabled, nil
}
