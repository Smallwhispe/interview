package sal

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/common/remote"
	legalEntityEnum "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_enums"
	legalEntityService "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service"
	"code.byted.org/gopkg/logs"
)

var BusinessLineMap = map[bff.BillingScene]legalEntityEnum.SubjectCountryBusinessLineEnum{
	bff.BillingScene_Virtual:   legalEntityEnum.SubjectCountryBusinessLineEnum_TT_VIRTUAL,
	bff.BillingScene_NonSelfBc: legalEntityEnum.SubjectCountryBusinessLineEnum_BC_NON_SELF,
}

func QueryTaxConfigRules(ctx context.Context, req *legalEntityService.QueryTaxConfigRulesRequest) (
	*legalEntityService.QueryTaxConfigRulesResponse, error,
) {
	resp, err := remote.GetLegalEntityClient().QueryTaxConfigRules(ctx, req)
	if err != nil {
		logs.CtxWarn(ctx, "QueryTaxConfigRules failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "QueryTaxConfigRules failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp, nil
}

func ValidateTaxNumber(ctx context.Context, req *legalEntityService.ValidateTaxNumberRequest) (
	*legalEntityService.ValidateTaxNumberResponse, error,
) {
	resp, err := remote.GetLegalEntityClient().ValidateTaxNumber(ctx, req)
	if err != nil {
		logs.CtxWarn(ctx, "ValidateTaxNumber failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "ValidateTaxNumber failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp, nil
}

func QueryAddressConfig(ctx context.Context, req *legalEntityService.QueryAddressConfigRuleRequest) (
	*legalEntityService.QueryAddressConfigRuleResponse, error,
) {
	resp, err := remote.GetLegalEntityClient().QueryAddressConfigRule(ctx, req)
	if err != nil {
		logs.CtxWarn(ctx, "QueryAddressConfig failed, req=%v, errmsg=%v", req, err)
		return nil, errcode.ErrSystemException
	}
	if resp == nil || resp.BaseResp == nil {
		return nil, errcode.ErrSystemException
	}
	if resp.GetBaseResp().GetStatusCode() != 0 {
		logs.CtxWarn(ctx, "QueryAddressConfig failed, errcode=%v", resp.GetBaseResp().GetStatusCode())
		return nil, errcode.ErrSystemException
	}
	return resp, nil
}
