package errcode

import (
	"fmt"

	"code.byted.org/ad/common_mw_lib/mw_error"
)

var (
	systemError = mw_error.NewSystemMWError()
	permDenied  = mw_error.NewPermissionDeniedMWError()
)

type ErrCode struct {
	Code  int32             `json:"code"`
	Msg   string            `json:"msg"`
	Data  interface{}       `json:"data"`
	Extra map[string]string `json:"extra"`
}

func NewErrCode(code int32, msg string, extra map[string]string) *ErrCode {
	return &ErrCode{Code: code, Msg: msg, Extra: extra, Data: map[string]interface{}{}}
}

func (ec ErrCode) Error() string {
	return fmt.Sprintf("code=%v errmsg=%v", ec.Code, ec.Msg)
}

func (ec ErrCode) ToMWError() mw_error.MWErrorInterface {
	return mw_error.NewMWError(ec.Code, ec.Msg, ec.Extra)
}

var (
	ErrInvalidParam     = NewErrCode(mw_error.STATUS_CODE_ERROR_PARAM, "Invalid parameters", nil)
	ErrDataNotFound     = NewErrCode(mw_error.STATUS_CODE_ERROR_NOT_EXIST, "Data not exist", nil)
	ErrSystemException  = NewErrCode(systemError.GetCode(), systemError.GetMsg(), systemError.GetExtra())
	ErrPermissionDenied = NewErrCode(mw_error.STATUS_CODE_ERROR_PERMISSION, permDenied.GetMsg(), permDenied.GetExtra())
	ErrEmailNotExist    = NewErrCode(40003, "Please set up the contact email of the ad account.", nil)
)
