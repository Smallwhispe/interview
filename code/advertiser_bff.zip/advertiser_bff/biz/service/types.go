package service

import (
	"context"
	"sync"
)

var (
	defaultCurrencyInfo = &CurrencyInfo{
		Ratio:     100000,
		Precision: 0,
	}
)

type CurrencyInfo struct {
	Ratio     int64
	Precision int64
}

func NewCurrencyInfo(ratio, prec int64) *CurrencyInfo {
	return &CurrencyInfo{Ratio: ratio, Precision: prec}
}

type permissionAggregator func(ctx context.Context) (interface{}, error)

type getAdvPermissionDetailHandler struct {
	svc         *Service
	err         error
	advID       int64
	userID      int64
	lock        sync.Mutex
	results     map[string]interface{}
	aggregators map[string]permissionAggregator
}

func newGetAdvPermissionDetailHandler(s *Service, advID, userID int64) *getAdvPermissionDetailHandler {
	return &getAdvPermissionDetailHandler{
		svc:         s,
		advID:       advID,
		userID:      userID,
		results:     make(map[string]interface{}),
		aggregators: make(map[string]permissionAggregator),
	}
}
