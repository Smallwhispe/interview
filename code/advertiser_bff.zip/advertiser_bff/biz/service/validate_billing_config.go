package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	legalEntityEnum "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_enums"
	legalEntityService "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/gopkg/lang/strings"
)

func (s *Service) ValidateBillingConfig(ctx context.Context, req *bff.ValidateBillingConfigRequest) (
	*bff.ValidateBillingConfigResponse, error,
) {
	var (
		businessLine legalEntityEnum.SubjectCountryBusinessLineEnum
		ok           bool
	)
	if businessLine, ok = sal.BusinessLineMap[req.Scene]; !ok {
		return nil, errcode.ErrInvalidParam
	}
	taxMap := make(map[string]string)
	for _, tax := range req.TaxInfos {
		if tax != nil && !strings.IsPtrEmpty(tax.TaxKey) && !strings.IsPtrEmpty(tax.TaxValue) {
			taxMap[*tax.TaxKey] = *tax.TaxValue
		}
	}
	validateResp, err := sal.ValidateTaxNumber(ctx, &legalEntityService.ValidateTaxNumberRequest{
		CountryCode:  req.CountryCode,
		TaxNumber:    taxMap,
		BusinessLine: toolkit.NewPtr(int32(businessLine)),
		TaxIdentity:  &req.TaxIdentity,
		DoEmptyCheck: true,
		Lang:         toolkit.NewPtr(s.GetLangType()),
	})
	if err != nil {
		return nil, err
	}

	var resp bff.ValidateBillingConfigResponse
	for key, res := range validateResp.ValidateRes {
		tmp := key
		resp.TaxValidateResult = append(resp.TaxValidateResult, &bff.TaxValidateItem{
			TaxKey:   &tmp,
			IsPassed: &res.IsPassed,
			Message:  &res.Message,
		})
	}
	return &resp, nil
}
