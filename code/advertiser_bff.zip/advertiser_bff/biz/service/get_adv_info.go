package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/lang/gg/gslice"
)

func (s *Service) GetAdvertiserInfo(ctx context.Context, req *bff.GetAdvertiserInfoRequest) (*bff.GetAdvertiserInfoResponse, error) {
	result, err := sal.GetAdvertiserInfo(ctx, req.GetAdvID(), true)
	if err != nil {
		return nil, err
	}

	info := bff.GetAdvertiserInfoResponse{
		Name:           result.GetName(),
		Status:         result.GetStatus(),
		Company:        result.GetCompany(),
		Currency:       result.GetCurrency(),
		Timezone:       result.GetDisplayTimezone(),
		Country:        result.GetCountry(),
		State:          result.GetState(),
		County:         result.GetCounty(),
		City:           result.GetCity(),
		SecondIndustry: result.GetSecondIndustryId(),
		PostCode:       result.GetPostalCode(),
		AddressDetail:  result.GetAddressDetail(),
		RejectReason:   result.GetReason(),
		CreateTime:     result.GetCreateTime(),
	}
	if info.Timezone == "" {
		info.Timezone = result.GetTimezone()
	}

	if result.IsSetIndustryInfoV4() {
		info.IndustryInfoV4 = &bff.IndustryInfo{
			IndustryID:      result.GetIndustryInfoV4().GetIndustryId(),
			IndustryIDLevel: result.GetIndustryInfoV4().GetIndustryIdLevel(),
		}
		info.IndustryInfoList = gslice.Map(result.IndustryInfoList, func(f *account_i18n.IndustryInfo) *bff.IndustryInfo {
			return &bff.IndustryInfo{
				IndustryID:      f.GetIndustryId(),
				IndustryIDLevel: f.GetIndustryIdLevel(),
			}
		})
	}

	advIDs := []int64{req.GetAdvID()}
	needPayer := true
	advInfos, _ := sal.MultiGetSubjectInfo(ctx, advIDs, true, &needPayer)
	if len(advInfos) > 0 {
		if adv, exist := advInfos[req.GetAdvID()]; exist {
			info.PayerName = adv.GetPayerName()
		}

	}

	return &info, nil
}
