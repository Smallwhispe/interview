package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	legalEntityEnum "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_enums"
	legalEntityService "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service"
	"code.byted.org/ad/advertiser_bff/toolkit"
)

func (s *Service) GetAddressConfig(ctx context.Context, req *bff.GetAddressConfigRequest) (
	*bff.GetAddressConfigResponse, error,
) {
	var (
		businessLine legalEntityEnum.SubjectCountryBusinessLineEnum
		ok           bool
	)
	if businessLine, ok = sal.BusinessLineMap[req.Scene]; !ok {
		return nil, errcode.ErrInvalidParam
	}

	config, err := sal.QueryAddressConfig(ctx, &legalEntityService.QueryAddressConfigRuleRequest{
		BusinessLine: int32(businessLine),
		CountryCode:  req.CountryCode,
		Lang:         toolkit.NewPtr(s.GetLangType()),
	})
	if err != nil {
		return nil, err
	}

	var resp bff.GetAddressConfigResponse
	if config.AddressConfigRule != nil {
		resp.AddressRequiredLevel = config.AddressConfigRule.AddressRequiredLevel
		if dac := config.AddressConfigRule.DetailAddressControl; dac != nil {
			resp.DetailAddressControl = toolkit.NewPtr(bff.TaxRuleControlType(*dac))
		}
		if zcc := config.AddressConfigRule.ZipCodeControl; zcc != nil {
			resp.ZipCodeControl = toolkit.NewPtr(bff.TaxRuleControlType(*zcc))
		}
	}
	return &resp, nil
}
