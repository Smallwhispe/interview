package service

import (
	"context"
	"fmt"

	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/passport/session_lib"

	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/ad/advertiser_bff/toolkit/syscontext"
	"code.byted.org/ad/common_mw_lib/constants"
	"code.byted.org/ad/mwlib/mwhertz"
	"code.byted.org/middleware/hertz/pkg/app"
)

type Service struct {
	appCtx *app.RequestContext
}

func NewService(ctx *app.RequestContext) *Service {
	return &Service{appCtx: ctx}
}

func (s *Service) GetAccessAdvID() int64 {
	return syscontext.GetAccessAdvID(s.appCtx)
}

func (s *Service) GetCoreUserID() int64 {
	return syscontext.GetCoreUserID(s.appCtx)
}

func (s *Service) GetCoreUserName() string {
	info, err := syscontext.GetAdvLoginInfo(s.appCtx)
	if err != nil || info.CoreUser == nil {
		return ""
	}
	return info.CoreUser.Name
}

func (s *Service) IsAdmin() bool {
	return mwhertz.IsStaffAdmin(s.appCtx)
}

func (s *Service) HasOwnerPerm() bool {
	return mwhertz.HasOwnerPerm(s.appCtx)
}

func (s *Service) GetStaffID() int64 {
	return syscontext.GetStaffID(s.appCtx)
}

func (s *Service) GetStaffName() string {
	info, err := syscontext.GetAdvLoginInfo(s.appCtx)
	if err != nil || info.Staff == nil {
		return ""
	}
	return info.Staff.Name
}

func (s *Service) GetPermissionRole() int64 {
	info, err := syscontext.GetAdvLoginInfo(s.appCtx)
	if err != nil {
		return 0
	}
	return info.PermissionRole
}

func (s *Service) GetAdvertiserRole() *int32 {
	info, err := syscontext.GetAdvLoginInfo(s.appCtx)
	if err != nil {
		return toolkit.NewPtr[int32](0)
	}
	return info.AdvertiserRole
}

func (s *Service) IsShopifyRequest() bool {
	return syscontext.IsShopifyRequest(s.appCtx)
}

func (s *Service) GetAdvCurrencyCode() string {
	info, err := syscontext.GetAdvLoginInfo(s.appCtx)
	if err != nil {
		return ""
	}
	return info.Currency
}
func (s *Service) GetUserEmail() *string {
	info, err := syscontext.GetAdvLoginInfo(s.appCtx)
	if err != nil {
		return nil
	}
	return info.CoreUser.Email
}
func (s *Service) GetUserPhone() *string {
	info, err := syscontext.GetAdvLoginInfo(s.appCtx)
	if err != nil {
		return nil
	}
	return info.CoreUser.Phone
}

func (s *Service) GetLangType() string {
	langType, ok := s.appCtx.Get(constants.LANG_TYPE)
	if !ok {
		return "en"
	}
	return fmt.Sprint(langType)
}

func (s *Service) BuildSharkParamGeneral(ctx context.Context, advID int64) map[string]any {
	riskInfo := make(map[string]any)
	s.putCommonParam(ctx, riskInfo)
	riskInfo["target"] = "web"
	riskInfo["real_ip"] = s.appCtx.ClientIP()
	riskInfo["scheme"] = s.appCtx.Request.Scheme()
	if did, err := session_lib.GetDeviceIDHertz(s.appCtx); err != nil {
		riskInfo["session_did"] = 0
	} else {
		riskInfo["session_did"] = did
	}
	if userType, err := session_lib.GetUserTypeHertz(s.appCtx); err != nil {
		riskInfo["session_login_type"] = 0
	} else {
		riskInfo["session_login_type"] = userType
	}
	riskInfo["url_path"] = s.appCtx.Request.Path()
	riskInfo["account_id"] = s.GetCoreUserID()
	riskInfo["user_id"] = s.GetCoreUserID()
	riskInfo["email_hash"] = s.GetUserEmail()
	riskInfo["phone_no"] = s.GetUserPhone()
	advertiserInfo, err := sal.GetAdvertiserInfo(ctx, advID, false)
	if err == nil && advertiserInfo != nil {
		riskInfo["priority_region"] = advertiserInfo.GetCountry()
		riskInfo["register_time"] = toolkit.TimeRemoveSecond(advertiserInfo.GetCreateTime())
	}
	return riskInfo
}

const TikTokAdsAppID = 1583

func (s *Service) putCommonParam(ctx context.Context, riskInfo map[string]any) {
	riskInfo["aid"] = TikTokAdsAppID
	riskInfo["app_name"] = "TikTokAds"
	riskInfo["did"] = "0"
	riskInfo["ttwid"] = string(s.appCtx.Cookie("ttwid"))
	if ttwid, exist := riskInfo["ttwid"]; exist {
		riskInfo["webid"] = sal.GetWebId(ctx, fmt.Sprintf("%v", ttwid))
	}
	riskInfo["user_agent"] = s.appCtx.GetHeader("User-Agent")
	riskInfo["ip"] = s.appCtx.ClientIP()
	riskInfo["forwarded"] = s.appCtx.GetHeader("X-Forwarded-For")
	riskInfo["refer"] = s.appCtx.GetHeader("Referer")
	riskInfo["device_platform"] = "web"
	riskInfo["captcha_check_result"] = s.appCtx.GetHeader("Captcha-Check-Result")
	riskInfo["web_sign_res"] = s.appCtx.GetHeader("Web_Sign_Res")
	riskInfo["web_ms_token"] = s.appCtx.GetHeader("Web_Ms_Token")
	if appid, err := session_lib.GetAppIDHertz(s.appCtx); err != nil {
		riskInfo["session_aid"] = 0
	} else {
		riskInfo["session_aid"] = appid
	}
}
