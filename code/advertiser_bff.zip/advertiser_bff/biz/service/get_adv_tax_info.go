package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/gopkg/logs"
)

// GetAdvTaxInfo 获取广告主税务信息
func (s *Service) GetAdvTaxInfo(ctx context.Context, req *bff.GetAdvTaxValueRequest) (*bff.GetAdvTaxValueResponse, error) {
	var (
		lang   = s.GetLangType()
		advID  = s.GetAccessAdvID()
		userID = s.GetCoreUserID()
	)

	tax, err := sal.GetAdvTaxInfo(ctx, lang, userID, advID)
	if err != nil {
		logs.CtxWarn(ctx, "get adv contact info failed, user_id=%v adv_id=%v errmsg=%v", userID, advID, err)
		return nil, err
	}

	var result = bff.GetAdvTaxValueResponse{
		TaxType:         tax.TaxType,
		TaxStatus:       convertTaxStatus(tax.TaxStatus),
		RejectReason:    tax.GetTaxRejectReason(),
		TaxAuditTime:    tax.GetTaxAuditTime(),
		FirstRejectTime: tax.GetFirstRejectTime(),
	}
	if taxValue := tax.GetTaxValue(); taxValue != nil {
		result.TaxValue = taxValue.GetOtherTaxs()
	}

	return &result, nil
}

func convertTaxStatus(status *account_i18n.QualificationStatus) *int64 {
	if status == nil {
		return nil
	}
	return toolkit.NewPtr[int64](int64(*status))
}
