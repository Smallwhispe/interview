package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/mwlib/mwregion"
	"code.byted.org/gopkg/env"
	"code.byted.org/gopkg/logs"
)

func GetRegion(ctx context.Context, advID int64) string {
	result, err := sal.GetRegionInfo(ctx, advID)
	if err != nil {
		var idc = mwregion.TransformVirtualName(env.IDC())
		logs.CtxWarn(ctx, "get advertiser region failed, return idc region %v", idc)
		return idc
	}
	return mwregion.TransformVirtualName(result.TargetIDC)
}
