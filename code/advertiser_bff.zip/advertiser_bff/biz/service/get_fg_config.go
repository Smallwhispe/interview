package service

import (
	"context"
	"strings"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/feature_gating_srv"
	"code.byted.org/ad/advertiser_bff/toolkit/encoding"
)

var configTypeMap = map[string]feature_gating_srv.UserTagEntityType{
	"virtual_tax_to_master_data": feature_gating_srv.UserTagEntityType_BUSINESS_CENTER,
}

func (s *Service) GetFGConfig(ctx context.Context, req *bff.GetFGConfigRequest) (
	*bff.GetFGConfigResponse, error,
) {
	resp := bff.GetFGConfigResponse{ServiceNamesResult: map[string]bool{}}
	advConfigs, bcConfigs, _ := groupConfigs(strings.Split(req.ServiceNames, ","))
	contextMap := map[string]any{
		"bc_id":  req.GetOrgID(),
		"adv_id": req.GetAdvID(),
	}
	contextStr, err := encoding.ToString(contextMap)
	if err != nil {
		return &resp, err
	}
	bcConfigRes, err := queryBCConfigRes(ctx, bcConfigs, req.GetOrgID(), &contextStr)
	if err != nil {
		return &resp, err
	}
	advConfigRes, err := queryAdvConfigRes(ctx, advConfigs, req.GetAdvID(), &contextStr)
	if err != nil {
		return &resp, err
	}
	for k, v := range advConfigRes {
		bcConfigRes[k] = v
	}
	resp.ServiceNamesResult = bcConfigRes
	return &resp, nil
}

func queryBCConfigRes(ctx context.Context, bcConfigs []string, bcID int64, contextStr *string) (
	map[string]bool, error,
) {
	return sal.BatchGetConfig(ctx, bcConfigs, bcID, contextStr,
		feature_gating_srv.UserTagEntityType_BUSINESS_CENTER)
}

func queryAdvConfigRes(ctx context.Context, advConfigs []string, advID int64, contextStr *string) (
	map[string]bool, error,
) {
	return sal.BatchGetConfig(ctx, advConfigs, advID, contextStr,
		feature_gating_srv.UserTagEntityType_ADVERTISER)
}

func groupConfigs(configs []string) (advConfigs []string, bcConfigs []string, userConfigs []string) {
	for _, config := range configs {
		switch configTypeMap[config] {
		case feature_gating_srv.UserTagEntityType_BUSINESS_CENTER:
			bcConfigs = append(bcConfigs, config)
		case feature_gating_srv.UserTagEntityType_ADVERTISER:
			advConfigs = append(advConfigs, config)
		case feature_gating_srv.UserTagEntityType_TT4B_USER:
			userConfigs = append(userConfigs, config)
		default:
			bcConfigs = append(bcConfigs, config)
		}
	}
	return
}
