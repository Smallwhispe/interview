package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/ad/advertiser_bff/toolkit/tcc"
	"code.byted.org/gopkg/logs"
	"code.byted.org/lang/gg/gslice"
	"golang.org/x/sync/errgroup"
)

const (
	handlerKeyCheck2sv       = "check2sv"
	handlerKeyGetAdvIdc      = "getAdvIdc"
	handlerKeyGetAdvInfo     = "getAdvInfo"
	handlerKeyGetAdvCurrency = "getAdvCurrency"
)

// GetAdvPermissionDetail retrieve permission info of adv
func (s *Service) GetAdvPermissionDetail(ctx context.Context) (*bff.GetAdvPermissionDetailResponse, error) {
	handler := newGetAdvPermissionDetailHandler(s, s.GetAccessAdvID(), s.GetCoreUserID())
	handler.addAggregator(handlerKeyGetAdvInfo, handler.getAdvAccountInfo).
		addAggregator(handlerKeyCheck2sv, noErrorHandlerWrapper(handler.check2sv)).
		addAggregator(handlerKeyGetAdvCurrency, noErrorHandlerWrapper(handler.getCurrencyInfo)).
		dispatch(ctx)
	return handler.merge()
}

// GetAdvPermissionDetail retrieve permission info of adv
func (s *Service) MIGetAdvPermissionDetail(ctx context.Context) (*bff.GetAdvPermissionDetailResponse, error) {
	handler := newGetAdvPermissionDetailHandler(s, s.GetAccessAdvID(), s.GetCoreUserID())
	handler.addAggregator(handlerKeyGetAdvInfo, handler.getAdvAccountInfo).
		addAggregator(handlerKeyCheck2sv, noErrorHandlerWrapper(handler.check2sv)).
		addAggregator(handlerKeyGetAdvIdc, noErrorHandlerWrapper(handler.getAdvRegionInfo)).
		addAggregator(handlerKeyGetAdvCurrency, noErrorHandlerWrapper(handler.getCurrencyInfo)).
		dispatch(ctx)
	return handler.merge()
}

func (h *getAdvPermissionDetailHandler) check2sv(ctx context.Context) interface{} {
	if h.svc.GetStaffID() > 0 {
		return true
	}
	if h.svc.IsShopifyRequest() {
		return true
	}
	if !tcc.GetOpen2SVSwitch(ctx) {
		return true
	}

	result, err := sal.CheckTwoStepVerify(ctx, h.userID, h.advID)
	if err != nil {
		return true
	}
	return result
}

func (h *getAdvPermissionDetailHandler) getAdvRegionInfo(ctx context.Context) interface{} {
	return GetRegion(ctx, h.advID)
}

func (h *getAdvPermissionDetailHandler) getCurrencyInfo(ctx context.Context) interface{} {
	code := h.svc.GetAdvCurrencyCode()
	if code == "" {
		return defaultCurrencyInfo
	}
	info, err := sal.GetCurrencyInfo(ctx, code)
	if err != nil {
		logs.CtxWarn(ctx, "get currency info failed, errmsg=%v", err)
		return defaultCurrencyInfo
	}

	return NewCurrencyInfo(info.GetRatioInt64(), info.GetUnitInt64())
}

func (h *getAdvPermissionDetailHandler) getAdvAccountInfo(ctx context.Context) (interface{}, error) {
	return sal.GetAdvertiserInfo(ctx, h.advID, true)
}

func (h *getAdvPermissionDetailHandler) dispatch(ctx context.Context) {
	g, ctx := errgroup.WithContext(ctx)

	for key, agg := range h.aggregators {
		key, agg := key, agg
		g.Go(func() error {
			result, err := agg(ctx)
			if err != nil {
				return err
			}
			h.lock.Lock()
			h.results[key] = result
			h.lock.Unlock()
			return nil
		})
	}
	h.err = g.Wait()
}

func (h *getAdvPermissionDetailHandler) addAggregator(
	name string, hdr permissionAggregator) *getAdvPermissionDetailHandler {
	h.aggregators[name] = hdr
	return h
}

func canVisitAdvertiser(advRole *int32) bool {
	if advRole == nil {
		return false
	}
	return toolkit.Slice[account_i18n.AdvertiserRole]{
		account_i18n.AdvertiserRole_ROLE_ADMIN,
		account_i18n.AdvertiserRole_ROLE_ADVERTISER,
		account_i18n.AdvertiserRole_ROLE_INTERNAL_ADV,
		account_i18n.AdvertiserRole_ROLE_VIRTAUL_ADVERTISER,
		account_i18n.AdvertiserRole_ROLE_PROMOTE_PRO,
	}.Contain(account_i18n.AdvertiserRole(int64(*advRole)))
}

func (h *getAdvPermissionDetailHandler) merge() (*bff.GetAdvPermissionDetailResponse, error) {
	if h.err != nil {
		return nil, h.err
	}

	var resp = bff.GetAdvPermissionDetailResponse{
		CoreUser: &bff.CoreUserInfo{
			ID:   h.userID,
			Name: h.svc.GetCoreUserName(),
		},
		Permission: &bff.PermissionInfo{
			IsAdmin:            h.svc.IsAdmin(),
			RefRole:            h.svc.GetPermissionRole(),
			CanVisitAdvertiser: canVisitAdvertiser(h.svc.GetAdvertiserRole()),
		},
		Staff: &bff.StaffInfo{
			StaffID: h.svc.GetStaffID(),
		},
		Account: &bff.AccountInfo{},
	}
	if h.svc.GetStaffID() > 0 {
		resp.Staff.StaffName = toolkit.NewPtr[string](h.svc.GetStaffName())
	}

	for key, value := range h.results {
		switch key {
		case handlerKeyCheck2sv:
			resp.Permission.Check2svPass = value.(bool)
		case handlerKeyGetAdvIdc:
			resp.Account.Idc = toolkit.NewPtr[string](value.(string))
		case handlerKeyGetAdvInfo:
			info := value.(*account_i18n.AdvertiserData)
			timezone := info.GetTimezone()

			if info.IsSetDisplayTimezone() {
				timezone = info.GetDisplayTimezone()
			}
			resp.Account.ID = info.Id
			resp.Account.Name = info.GetName()
			resp.Account.Role = info.GetRole()
			resp.Account.Origin = info.GetOrigin()
			resp.Account.Status = info.GetStatus()
			resp.Account.Country = info.GetCountry()
			resp.Account.Timezone = timezone
			resp.Account.Currency = info.GetCurrency()
			resp.Account.CreateTime = toolkit.UTC2LocalTime(info.GetCreateTime(), timezone)
			resp.Account.AccountType = info.GetAccountType()
			resp.Account.CustomerTypeValue = info.GetCustomerTypeValue()
			resp.Account.QualificationSource = int64(info.GetQualificationSource())
			if info.IsSetIndustryInfoV4() {
				resp.Account.IndustryInfoV4 = &bff.IndustryInfo{
					IndustryID:      info.IndustryInfoV4.IndustryId,
					IndustryIDLevel: info.IndustryInfoV4.IndustryIdLevel,
				}
				resp.Account.IndustryInfoList = gslice.Map(info.IndustryInfoList, func(f *account_i18n.IndustryInfo) *bff.IndustryInfo {
					return &bff.IndustryInfo{
						IndustryID:      f.GetIndustryId(),
						IndustryIDLevel: f.GetIndustryIdLevel(),
					}
				})
			}
		case handlerKeyGetAdvCurrency:
			info := value.(*CurrencyInfo)
			resp.Account.Ratio = info.Ratio
			resp.Account.CurrencyPrecision = info.Precision
		}
	}

	return &resp, nil
}

func noErrorHandlerWrapper(f func(context.Context) interface{}) func(context.Context) (interface{}, error) {
	return func(ctx context.Context) (interface{}, error) { return f(ctx), nil }
}
