package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/toolkit"
)

func (s *Service) GetBillingInfo(ctx context.Context, req *bff.GetBillingInfoRequest) (
	*bff.GetBillingInfoResponse, error,
) {
	taxResponse, err := sal.GetAdvTaxInfo(ctx, s.GetLangType(), s.GetCoreUserID(), req.GetAdvID())
	if err != nil {
		return nil, err
	}
	resp := bff.GetBillingInfoResponse{
		TaxStatus:       toolkit.NewPtr(bff.TaxStatus(taxResponse.GetTaxStatus())),
		TaxType:         taxResponse.TaxType,
		CanUpdate:       toolkit.NewPtr(s.HasOwnerPerm()),
		TaxAuditTime:    taxResponse.TaxAuditTime,
		RejectReason:    taxResponse.TaxRejectReason,
		FirstRejectTime: taxResponse.FirstRejectTime,
	}
	if taxResponse.TaxValue != nil {
		resp.TaxMap = taxResponse.TaxValue.OtherTaxs
	}
	if address := taxResponse.BillingAddressInfo; address != nil {
		resp.State = address.State
		resp.County = address.County
		resp.City = address.City
		resp.AddressDetail = address.SourceBillingAddress
		resp.PostCode = address.Postcode
	}
	return &resp, nil
}
