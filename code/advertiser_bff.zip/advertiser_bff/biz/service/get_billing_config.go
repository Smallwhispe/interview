package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	legalEntityEnum "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_enums"
	legalEntityService "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service"
	"code.byted.org/ad/advertiser_bff/toolkit"
)

func (s *Service) GetBillingConfig(ctx context.Context, req *bff.GetBillingConfigRequest) (
	*bff.GetBillingConfigResponse, error,
) {
	var (
		businessLine legalEntityEnum.SubjectCountryBusinessLineEnum
		ok           bool
	)
	if businessLine, ok = sal.BusinessLineMap[req.Scene]; !ok {
		return nil, errcode.ErrInvalidParam
	}

	rulesResponse, err := sal.QueryTaxConfigRules(ctx, &legalEntityService.QueryTaxConfigRulesRequest{
		BusinessLine: toolkit.NewPtr(int32(businessLine)),
		CountryCode:  req.GetCountryCode(),
		Lang:         toolkit.NewPtr(s.GetLangType()),
	})
	if err != nil {
		return nil, err
	}

	resp := &bff.GetBillingConfigResponse{
		TaxBasicInfo:           []*bff.TaxBasicInfo{},
		TaxIdentityConfigRules: []*bff.TaxIdentityConfigRule{},
	}
	if rulesResponse.TaxConfigRule != nil {
		resp.TaxBasicInfo = parseTaxBasicInfo(rulesResponse.TaxConfigRule.TaxBasicInfo)
		resp.TaxIdentityConfigRules = parseTaxConfigRules(rulesResponse.TaxConfigRule)
	}

	return resp, nil
}

func parseTaxConfigRules(rule *legalEntityService.TaxConfigRule) []*bff.TaxIdentityConfigRule {
	var result []*bff.TaxIdentityConfigRule
	for _, taxIdentityRule := range rule.TaxIdentityConfigRules {
		var taxRules []*bff.TaxRule
		for _, r := range taxIdentityRule.TaxRules {
			taxRules = append(taxRules, &bff.TaxRule{
				Control: bff.TaxRuleControlTypePtr(bff.TaxRuleControlType(r.Control)),
				TaxKey:  &r.TaxKey,
			})
		}
		result = append(result, &bff.TaxIdentityConfigRule{
			NeedVerify:      &taxIdentityRule.NeedVerify,
			TaxIdentity:     &taxIdentityRule.TaxIdentity,
			TaxIdentityName: &taxIdentityRule.TaxIdentityName,
			TaxIdentityTips: taxIdentityRule.TaxIdentityTips,
			TaxRules:        taxRules,
			TaxBasicInfo:    parseTaxBasicInfo(taxIdentityRule.TaxBasicInfo),
		})
	}
	return result
}

func parseTaxBasicInfo(taxBasicInfos []*legalEntityService.TaxBasicInfo) []*bff.TaxBasicInfo {
	var result []*bff.TaxBasicInfo
	for _, basic := range taxBasicInfos {
		var opts []*bff.TaxOption
		for _, opt := range basic.Options {
			opts = append(opts, &bff.TaxOption{
				Code: opt.Code,
				Name: opt.Name,
			})
		}
		inputType := bff.TaxInputType_Input
		if basic.Type != nil {
			inputType = bff.TaxInputType(*basic.Type)
		}
		result = append(result, &bff.TaxBasicInfo{
			TaxKey:  &basic.TaxKey,
			TaxName: &basic.TaxName,
			TaxTips: basic.TaxTips,
			Type:    &inputType,
			Options: opts,
		})
	}
	return result
}
