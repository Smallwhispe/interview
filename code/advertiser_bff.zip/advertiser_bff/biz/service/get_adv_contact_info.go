package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/ad/advertiser_bff/toolkit/encoding"
	"code.byted.org/gopkg/logs"
)

// GetAdvContactInfo 获取联系人信息
// NOTE: 允许在拉取信息失败时降级,字段返回空数据
func (s *Service) GetAdvContactInfo(ctx context.Context, req *bff.GetAdvContactInfoRequest) (
	map[string]*bff.GetAdvContactInfoResponse, error) {
	var (
		advID  = s.GetAccessAdvID()
		userID = s.GetCoreUserID()

		err         error
		info        bff.GetAdvContactInfoResponse
		contactInfo *account_i18n.AdvContactInfo
		result      = map[string]*bff.GetAdvContactInfoResponse{"contact_info": &info}
	)

	if req.GetSensitiveFlag() {
		contactInfo, err = sal.GetAdvSensitiveContactInfo(ctx, userID, advID)
	} else {
		contactInfo, err = sal.GetAdvContactInfo(ctx, userID, advID)
	}
	if err != nil {
		logs.CtxWarn(ctx, "get adv contact info failed, user_id=%v adv_id=%v errmsg=%v", userID, advID, err)
		return result, nil
	}

	if contactInfo != nil {
		convertContactOut(contactInfo, &info, req.GetSensitiveFlag())
	}

	return result, nil
}

func convertContactOut(contact *account_i18n.AdvContactInfo, info *bff.GetAdvContactInfoResponse, sensitive bool) {
	info.PhonenumberCountry = contact.PhonenumberCountry
	info.ContacterTelephoneCountry = contact.ContacterTelephoneCountry
	info.EmailVerifyStatus = toolkit.NewPtr(int16(contact.GetEmailVerifyStatus()))
	info.EmailVerifySource = toolkit.NewPtr(int16(contact.GetEmailVerifySource()))
	info.PhonenumberVerifyStatus = toolkit.NewPtr(int16(contact.GetPhonenumberVerifyStatus()))
	info.PhonenumberVerifySource = toolkit.NewPtr(int16(contact.GetPhonenumberVerifySource()))

	if sensitive {
		info.Email = encoding.Base64Encode(contact.GetEmail())
		info.Contacter = encoding.Base64Encode(contact.GetContacter())
		info.Telephone = encoding.Base64Encode(contact.GetContacterTelephone())
		info.Phonenumber = encoding.Base64Encode(contact.GetPhonenumber())
		info.ContacterEmail = encoding.Base64Encode(contact.GetContacterEmail())
		return
	}
	info.Email = contact.GetEmail()
	info.Contacter = contact.GetContacter()
	info.Telephone = contact.GetContacterTelephone()
	info.Phonenumber = contact.GetPhonenumber()
	info.ContacterEmail = contact.GetContacterEmail()
}
