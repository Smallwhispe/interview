package service

import (
	"context"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/kitex_gen/base"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/ad/advertiser_bff/toolkit/encoding"
)

var AddressAndTaxModuleList = []bff.UpdateBillingInfoModule{bff.UpdateBillingInfoModule_Address,
	bff.UpdateBillingInfoModule_Tax}

func (s *Service) UpdateBillingInfo(ctx context.Context, req *bff.UpdateBillingInfoRequest) (
	*bff.UpdateBillingInfoResponse, error,
) {
	if len(req.ModuleList) == 0 {
		req.ModuleList = AddressAndTaxModuleList
	}
	if err := checkContactEmail(ctx, req, s.GetCoreUserID()); err != nil {
		return nil, err
	}
	if toolkit.Contains(req.ModuleList, bff.UpdateBillingInfoModule_Address) {
		if err := s.updateBasicInfo(ctx, req); err != nil {
			return nil, err
		}
	}
	if toolkit.Contains(req.ModuleList, bff.UpdateBillingInfoModule_Tax) {
		if err := s.updateTaxInfo(ctx, req); err != nil {
			return nil, err
		}
	}

	var taxValue string
	if len(req.TaxMap) > 0 {
		for _, v := range req.TaxMap {
			taxValue = v
			break
		}
	}

	return &bff.UpdateBillingInfoResponse{
		City:          req.City,
		State:         req.State,
		County:        req.County,
		AddressDetail: req.AddressDetail,
		TaxValue:      &taxValue,
		PostCode:      req.Postcode,
		TaxMap:        req.TaxMap,
	}, nil
}

func (s *Service) updateTaxInfo(ctx context.Context, req *bff.UpdateBillingInfoRequest) error {
	return sal.UpdateAdvTaxInfo(ctx, &account_i18n.UpdateAdvTaxInfoRequest{
		Lang:         toolkit.NewPtr(s.GetLangType()),
		AdvertiserId: &req.AdvID,
		OperatorId:   toolkit.NewPtr(s.GetCoreUserID()),
		TaxValue: &account_i18n.TaxValue{
			OtherTaxs: req.TaxMap,
		},
		TaxType: toolkit.NewPtr(account_i18n.AdvertiserTaxType(req.GetTaxType())),
		Base: &base.Base{Extra: map[string]string{
			"HTTP_SHARK_REQUIRE_PARAMS": encoding.UnsafeEncode(s.BuildSharkParamGeneral(ctx, req.AdvID)),
		}},
	})
}

func (s *Service) updateBasicInfo(ctx context.Context, req *bff.UpdateBillingInfoRequest) error {
	updateReq := account_i18n.UpdateAdvAccountRequest{
		AdvertiserId:  &req.AdvID,
		OperatorId:    toolkit.NewPtr(s.GetCoreUserID()),
		State:         req.State,
		City:          req.City,
		AddressDetail: req.AddressDetail,
		PostCode:      req.Postcode,
		County:        req.County,
		Language:      toolkit.NewPtr(s.GetLangType()),
		Base: &base.Base{
			Extra: map[string]string{
				"HTTP_SHARK_REQUIRE_PARAMS": encoding.UnsafeEncode(s.BuildSharkParamGeneral(ctx, req.AdvID)),
			},
		},
	}
	if req.State != nil && req.City == nil {
		updateReq.City = toolkit.NewPtr(int64(0))
	}
	if req.State != nil && req.County == nil {
		updateReq.County = toolkit.NewPtr(int64(0))
	}
	return sal.UpdateAdvAccount(ctx, &updateReq)
}

func checkContactEmail(ctx context.Context, req *bff.UpdateBillingInfoRequest, uid int64) error {
	contactInfo, err := sal.GetAdvSensitiveContactInfo(ctx, uid, req.AdvID)
	if err != nil {
		return err
	}
	if contactInfo == nil || contactInfo.ContacterEmail == nil ||
		len(*contactInfo.ContacterEmail) == 0 {
		return errcode.ErrEmailNotExist
	}
	return nil
}
