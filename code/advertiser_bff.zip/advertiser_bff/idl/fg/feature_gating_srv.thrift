#!/usr/local/bin/thrift --gen py
include "../base.thrift"

namespace py ad.platform.feature_gating_srv
namespace go ad.platform.feature_gating_srv


enum UserTagEntityType {
    APP = 0;
    CUSTOMER = 1;
    ADVERTISER = 2;
    DEVELOPER = 3;
    TT4B_USER = 4;
    CRM_ACCOUNT = 5;
    BUSINESS_CENTER = 6;
}

enum UpdateTagsOpType {
    ADD = 0; // Add one or more tags to specific entity_id in database
    REMOVE = 1; //Remove one/more tags to specific entity_id in database
}

struct Entity{
    1: required UserTagEntityType entityType;
    2: required string entity_id;
}

struct V2ResponseType{
    1: optional bool is_enabled; // Determine if the entity should access to new feature
    2: optional string value; // Return user's customized string value as return
}

struct Pagination{
    1: required i64 total_page;                   # total number of pages
    2: required i64 total_count;                  # total number of items
    3: required i64 page_size;                    # number of items in each page
    4: required i64 page;                         # current page number starts from 1, default is 1
}

struct GetConfigRequest {
    1: required string project_name;
    2: required string config_name;
    3: required UserTagEntityType entity_type;
    4: required string entity_id;
    5: optional string context; // JSON blob
    6: optional string percentage_hash_id; // User random input id used for future hash
    7: optional bool skip_cache; // Read data directly from db if true, default is false

    255: optional base.Base Base;
}

struct BatchGetConfigRequest {
    1: required string project_name;
    2: required list<string> config_names;
    3: required UserTagEntityType entity_type;
    4: required string entity_id;
    5: optional string context; // JSON blob
    6: optional string percentage_hash_id; // User random input id used for future hash
    7: optional bool skip_cache; // Read data directly from db if true, default is false

    255: optional base.Base Base;
}

struct GetConfigResponse {
    1: required bool is_enabled; // Determine if the entity should access to new feature
    2: optional map<string, string> params

    255: base.BaseResp BaseResp;
}

struct GetConfigResponseV2 {
    1: optional V2ResponseType combo_value;
    2: optional map<string, string> params

    255: base.BaseResp BaseResp;
}

struct BatchGetConfigResponse {
    1: required map<string,bool> is_enabled; // Determine if the entity should access to new feature
    2: optional map<string, string> params

    255: base.BaseResp BaseResp;
}

struct BatchGetConfigResponseV2 {
    1: optional map<string,V2ResponseType> combo_values;
    2: optional map<string, string> params

    255: base.BaseResp BaseResp;
}

struct GetUserTagsRequest {
    1: required UserTagEntityType entity_type;
    2: required string entity_id;
    3: optional bool skip_cache; // Read data directly from db if true, default is false

    255: optional base.Base Base;
}

struct GetUserTagsResponse {
    1: list<string> tags;

    255: base.BaseResp BaseResp;
}

struct UpdateUserTagsRequest {
    1: required UpdateTagsOpType op_type;
    2: required UserTagEntityType entity_type;
    3: required string entity_id;
    4: required list<string> tags; // tags to be added or removed
    5: required i64 operator_staff_id; // id of staff who perform the operation

    255: optional base.Base Base;
}

struct UpdateUserTagsResponse {
    1: UpdateTagsOpType op_type;
    2: list<string> successful_tags; // tags successfully added or removed by the request
    3: list<string> failed_tags; // tags not successfully added or removed by the request

    255: base.BaseResp BaseResp;
}

struct GetEntitiesByTagNameRequest {
    1: required string tag_name;
    2: optional UserTagEntityType entityType;
    3: optional i64 page;
    4: optional i64 page_size;
    5: optional bool skip_cache; // Read data directly from db if true, default is false

    255: optional base.Base Base;
}

struct GetEntitiesByTagNameResponse {
    1: list<Entity> entity_list;
    2: Pagination pagination;

    255: base.BaseResp BaseResp;
}

struct UpdateEntitiesByTagNameRequest {
    1: required UpdateTagsOpType op_type;
    2: required list<Entity> entity_list; // list of entities to be updated
    3: required string tag_name;

    255: optional base.Base Base;
}

struct UpdateEntityTagFailedInfo {
    1: optional string failed_msg;
    2: optional list<Entity> entities;
}

struct UpdateEntitiesByTagNameResponse {
    1: UpdateTagsOpType op_type;
    2: list<Entity> successful_entities;
    3: list<Entity> failed_entities;
    4: optional list<UpdateEntityTagFailedInfo> failed_infos;

    255: base.BaseResp BaseResp;
}

service AdFeatureGatingService {
    /*
    GetConfig and BatchGetConfig will only return boolean no matter if users ever typed expected return value when creating config.
    GetConfigV2 and BatchGetConfigV2 will only return string. If config is old one without expected return value, it will
    return string 'true' or 'false'
    */
    GetConfigResponse GetConfig(1: GetConfigRequest req)

    BatchGetConfigResponse BatchGetConfig(1: BatchGetConfigRequest req)

    GetConfigResponseV2 GetConfigV2(1: GetConfigRequest req)

    BatchGetConfigResponseV2 BatchGetConfigV2(1: BatchGetConfigRequest req)

    GetUserTagsResponse GetUserTags(1: GetUserTagsRequest req)

    UpdateUserTagsResponse UpdateUserTags(1: UpdateUserTagsRequest req)

    GetEntitiesByTagNameResponse GetEntitiesByTagName(1: GetEntitiesByTagNameRequest req)

    UpdateEntitiesByTagNameResponse UpdateEntitiesByTagName(1: UpdateEntitiesByTagNameRequest req)
}
