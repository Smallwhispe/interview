include "idl/base.thrift"

namespace py ad.tt4b.permission_center
namespace go ad.tt4b.permission_center
namespace java ad.tt4b.permission_center

// Subject type
enum SubjectType {
    BizUser  = 1
    Account = 2
    Shop = 3
    TTShop = 10
}

// Object type
enum ObjectType {
    Account = 1
    Audience = 2
    Pixel = 3
    Catalog = 4
    Shop = 5
    Domain = 6
    ManualCatalog = 7
    TTAccount = 8
    FormLibrary = 9
    TTShop = 10
    TCMAccount = 11
    BC = 100
}

enum TimeType {
    Create = 1
    Modify = 2
}

struct PageOrder {
    1: i64 limit=500;  // Up to 500
    2: i64 last_id=0;  // use last primary id as offset in sql condition priorly
    3: i64 offset=0;   // sql offset, no longer support
}

// Subject
struct SubjectEntity {                        // Authentication Subject Abstraction
    1: required SubjectType subject_type;
    2: required i64 subject_id;
}

// Object
struct ObjectEntity {                        // Authentication Object Abstraction
    1: required ObjectType object_type;
    2: required i64 object_id;
    3: optional string open_id;         // tt Asset contains open_id
}

struct Origin {
    1: required i64 origin_type;  // 1:owner 2:BC
    2: required i64 origin_id;
}

struct Role {
    1: optional string name;
    2: optional string key;
    3: optional i64 group;
    4: optional i64 id;  // Compatible with advertiser role only
    5: optional bool is_owner;
    6: optional bool is_internal;
}

struct Permission {
    1: optional string name;
    2: optional string key;
}

struct RoleRelation {
    1: optional SubjectEntity subject;  // subject
    2: optional ObjectEntity object;   // object
    3: optional Role role;     // role (Specifying a role when deleting means deleting the specified role, if not, deleting all roles the user has on the asset)
    4: optional Origin origin;   // Authorized Source
    5: optional i64 update_time;  // role update timestamp
    6: optional i64 status;  // 1 bound 2 unbound
    7: optional list<Role> role_list;  // Dedicated to multiple roles
}

struct AssetsRelationQueryInfo {
    1: list<i64> asset_ids;               // max 100
    2: list<i64> asset_types;
    3: optional list<i64> query_types;
    4: optional list<i64> roleIds;
    5: optional list<i64> originIds;      //Currently user id is not stored in the database, only bc id can be specified for conditional query
    6: optional list<i64> originTypes;    //Currently invalid
    7: optional PageOrder page_order;     //Default limit=500, offset=0
}



struct AuthPermissionRequest {
    1: required i64 app_id;                  // business party id
    2: optional SubjectEntity subject;                 // Authentication subject (usually User)
    3: optional ObjectEntity object;                   // Authentication object (usually Account, Catalog)
    4: required list<Permission> permissions;   // Permissions, up to 100
    5: optional Origin origin;                     // Optional, specify source authentication (BC ID)
    6: optional bool internal_network;  // Intranet permission required
    255: base.Base Base;
}

struct AuthPermissionResponse {
    1: optional map<string,bool> authorized_list;        //Authentication result (permission_key)
    255: base.BaseResp BaseResp;
}



struct AuthRoleRequest {
    1: required i64 app_id;
    2: required SubjectEntity subject;
    3: required ObjectEntity object;
    4: required list<Role> roles; //Role, identified by key and id, priority id, no key, upper limit of 20
    5: optional Origin origin;  // Optional, specify source authentication
    6: optional bool internal_network;  //Intranet permission required
    255: base.Base Base;
}

struct AuthRoleResponse {
    1: optional map<string,bool> authorized_list;        // Authentication result (role_key)
    255: base.BaseResp BaseResp;
}



struct AddRoleRequest {                        // Add authentication rules
    1: required i64 app_id;
    2: required SubjectEntity subject;
    3: required ObjectEntity object;
    4: required Role role;
    5: optional Origin origin;  // Optional, specify source authentication
    6: optional i64 operator_id;  // The operator's user_id, operator_id and staff_id must be filled in one
    7: optional i64 staff_id;   // The operator's employee id,One of operator_id and staff_id must be filled
    255: base.Base Base;
}

struct AddRoleResponse {
    255: base.BaseResp BaseResp;
}

struct DelRoleRequest {            // delete authentication rules
    1: required i64 app_id;
    2: required SubjectEntity subject;
    3: required ObjectEntity object;
    4: optional Role role;           // Optional, if not, delete all roles under the subject, object, source
    5: optional Origin origin;         // Optional, specify source authentication
    6: optional i64 operator_id;  // The operator's user_id, operator_id and staff_id must be filled in one
    7: optional i64 staff_id;   // The operator's employee id,One of operator_id and staff_id must be filled
    255: base.Base Base;
}

struct DelRoleResponse {
    255: base.BaseResp BaseResp;
}


struct GetRolesRequest {
    1: required i64 app_id;
    2: required SubjectEntity subject;
    3: required ObjectEntity object;
    4: optional Origin origin;
    5: optional PageOrder page_order;
    6: optional bool internal_network;  // Intranet permission required
    255: base.Base Base;
}

struct GetRolesResponse {
    1: optional list<Role> roles;
    2: optional i64 total;

    100: optional i64 last_id;
    255: base.BaseResp BaseResp;
}


struct MGetRolesRequest {
    1: required i64 app_id;
    2: required list<RoleRelation> query_refs;  //subject, object, origin are required, role is not(The upper limit is 500, and an error will be reported if it exceeds)

    255: base.Base Base;
}

struct MGetRolesResponse {
    1: optional list<RoleRelation> role_refs;

    255: base.BaseResp BaseResp;
}



struct AddRolePermissionRefRequest {
    1: required i64 app_id;
    2: required Role role;
    3: optional list<Permission> permissions;
    255: base.Base Base;
}

struct AddRolePermissionRefResponse {
    255: base.BaseResp BaseResp;
}


struct DelRolePermissionRefRequest {
    1: required i64 app_id;
    2: required Role role;
    3: optional list<Permission> permissions;
    255: base.Base Base;
}

struct DelRolePermissionRefResponse {
    255: base.BaseResp BaseResp;
}


struct GetPermissionsByRoleRequest {
    1: required i64 app_id;
    2: required Role role;
    3: optional PageOrder page_order;
    255: base.Base Base;
}

struct GetPermissionsByRoleResponse {
    1: optional list<Permission> permissions;
    2: optional i64 total;

    100: optional i64 last_id;
    255: base.BaseResp BaseResp;
}

struct GetPermissionsRequest {
    1: required i64 app_id;
    2: required SubjectEntity subject;
    3: required ObjectEntity object;
    4: optional Origin origin;
    5: optional PageOrder page_order;
    6: optional bool internal_network;  // Intranet permission required
    255: base.Base Base;
}

struct GetPermissionsResponse {
    1: optional list<Permission> permissions;
    2: optional i64 total;

    100: optional i64 last_id;
    255: base.BaseResp BaseResp;
}

struct MModifyRoleRequest {
    1: required i64 app_id;
    2: optional list<RoleRelation>  add_refs;  //Add or modify the role relationship of the subject and object, the upper limit is 100
    3: optional list<RoleRelation>  delete_refs;  // Delete the role relationship of the subject and object, the upper limit is 100
    4: optional i64 operator_id;  //The operator's user_id, operator_id and staff_id must be filled in one
    5: optional i64 staff_id; //The operator's employee id,One of operator_id and staff_id must be filled
    255: base.Base Base;
}

struct MModifyRoleResponse {
    255: base.BaseResp BaseResp;
}

struct UnboundRelationBySubjectRequest {
    1: required i64 app_id;
    2: required SubjectEntity subject;  // subject
    3: optional Origin origin;  // Authorized source (not passed as unauthorized source)
    4: optional i64 operator_id;  //The operator's user_id, operator_id and staff_id must be filled in one
    5: optional i64 staff_id; // The operator's employee id,One of operator_id and staff_id must be filled
    255: base.Base Base;
}

struct UnboundRelationBySubjectResponse {
    255: base.BaseResp BaseResp;
}

struct UnboundRelationByObjectRequest {
    1: required i64 app_id;
    2: required ObjectEntity object;  // object
    3: optional Origin origin;  //  Authorized source (not passed as unauthorized source)
    4: optional i64 operator_id;  // The operator's user_id, operator_id and staff_id must be filled in one
    5: optional i64 staff_id;   //The operator's employee id,One of operator_id and staff_id must be filled
    255: base.Base Base;
}

struct UnboundRelationByObjectResponse {
    255: base.BaseResp BaseResp;
}

struct MUnboundRelationByObjectRequest {
    1: required i64 app_id;
    2: required list<i64> object_ids;  // List of object ids, up to 40 at a time
    3: required ObjectType type;      // object type
    4: required Origin origin;       // Authorized sources (BC sources only)
    5: optional i64 operator_id;  // The operator's user_id, operator_id and staff_id must be filled in one
    6: optional i64 staff_id;   // The operator's employee id,One of operator_id and staff_id must be filled
    255: base.Base Base;
}

struct MUnboundRelationByObjectResponse {
    255: base.BaseResp BaseResp;
}

struct CreateRoleEntityRequest {
    1: required i64 app_id;
    2: required Role role;
    3: required i64 domain_id;
    255: base.Base Base;
}

struct CreateRoleEntityResponse {
    255: base.BaseResp BaseResp;
}


struct CreatePermissionEntityRequest {
    1: required i64 app_id;
    2: required Permission permission;
    255: base.Base Base;
}

struct CreatePermissionEntityResponse {
    255: base.BaseResp BaseResp;
}

struct GetObjectsBySubjectRequest {
    1: required i64 app_id;
    2: required SubjectEntity subject;
    3: optional ObjectEntity object; // Specify a certain type of object that is related to the query subject. To query a certain type, you need to specify type, and to query a specific id, you need to specify type+id, which cannot be empty.
    4: optional list<Origin> origins;    // List of BC IDs of specified authorized sources
    5: optional list<Role> roles;   // Specify roles type, if not passed, check all; pls input bitmap role for pixel
    6: optional PageOrder page_order;
    255: base.Base Base;
}

struct GetObjectsBySubjectResponse {
    1: optional list<RoleRelation> refs;
    2: optional i64 total;

    100: optional i64 last_id;
    255: base.BaseResp BaseResp;
}

struct GetSubjectsByObjectRequest {
    1: required i64 app_id;
    2: required ObjectEntity object;
    3: optional SubjectEntity subject; //Specify a type subject that is related to the query object. When querying a certain type, you need to specify type. When querying a specific id, you need to specify type+id, which cannot be empty.
    4: optional list<Origin> origins;    // List of BC IDs of specified authorized sources
    5: optional list<Role> roles;   // Specify roles type, if not passed, check all
    6: optional PageOrder page_order;
    255: base.Base Base;
}

struct GetSubjectsByObjectResponse {
    1: optional list<RoleRelation> refs;
    2: optional i64 total;

    100: optional i64 last_id;
    255: base.BaseResp BaseResp;
}

struct GetAssetsRelationRequest {
    1: required i64 app_id;
    2: optional SubjectEntity subject;  // Subject asset, if it is only a certain type of subject asset under the object asset, you can only specify the SubjectType type of SubjectEntity, and specify 0 for id
    3: optional ObjectEntity object; // Object asset, if it is only a certain type of object asset under the subject asset, you can only specify the ObjectType type of ObjectEntity, and specify 0 for id
    4: optional Origin origin;    //List of BC IDs of specified authorized sources
    5: optional PageOrder page_order;
    6: optional list<i64> relation_status_list;  // 1 bound 2 unboud If not passed, the default is to check the bound status record
    255: base.Base Base;
}

struct GetAssetsRelationResponse {
    1: optional list<RoleRelation> refs;
    2: optional i64 total;

    100: optional i64 last_id;
    255: base.BaseResp BaseResp;
}

struct MModifyAssetsRelationRequest {
    1: required i64 app_id;
    2: optional list<RoleRelation>  add_refs;  //Add or modify the relationship between main assets, the upper limit is 100
    3: optional list<RoleRelation>  delete_refs;  //Delete the relationship between the main assets, the upper limit is 100
    4: optional i64 operator_id;  // The operator's user_id, operator_id and staff_id must be filled in one
    5: optional i64 staff_id; // The operator's employee id,One of operator_id and staff_id must be filled
    255: base.Base Base;
}

struct MModifyAssetsRelationResponse {
    255: base.BaseResp BaseResp;
}

struct GetAssetRelationByTypeRequest {
    1: required i64 app_id;
    2: required SubjectType subject_type;   //Subject asset type
    3: required ObjectType object_type;     //Object asset type
    4: required TimeType time_type;         //Query based on creation time or modification time
    5: required i64 start_time;             //Query start timestamp (utc-0) 13-bit timestamp
    6: required i64 end_time;               //Query termination timestamp (utc-0) 13-digit timestamp The query time range cannot exceed 1 hour
    7: optional PageOrder page_order;
    255: base.Base Base;
}

struct Condition {
    1: required SubjectEntity subject;  // subject（E.g user）
    2: required ObjectEntity object;   // object  (E.g adv)
    3: optional list<Role> roles;     // user   (E.g own,operator, if not passed, it is all permissions)
    4: optional Origin origin;   //Authorized Source   (For example, a BC, if not passed, all BCs)
    5: optional ObjectType rel_type;  // The associated permission type (eg tt)
    254: optional PageOrder page_order;
}


struct GetObjectsByConditionRequest {
    1: required i64 app_id;
    2: required Condition cond;  // Query under the specified relational conditions, for example, if the user has a certain authority to adv, the user has the authority tt.
    255: base.Base Base;
}

struct GetObjectsByConditionResponse {
    1: optional list<RoleRelation> refs;
    99: optional i64 total;
    100: optional i64 last_id;
    255: base.BaseResp BaseResp;
}

struct MGetAssetsRelationRequest {
    1: required i64 app_id;
    2: optional AssetsRelationQueryInfo sub_query_info;     //Query the object through the subject, such as checking the tcm account through adv
    3: optional AssetsRelationQueryInfo ob_query_info;      //When sub_query_info is empty, query the subject through the object, such as adv through the tcm account
    255: base.Base Base;
}

struct MGetAssetsRelationResponse {
    1: optional list<RoleRelation> refs;
    255: base.BaseResp BaseResp;
}

struct CheckTwoStepVerifyRequest {
    1: required i64 app_id;
    2: SubjectEntity subject;  // type=1(user), id=user_id
    3: ObjectEntity object;    // type=1(adv), 100(bc)
    255: required base.Base Base;
}

struct CheckTwoStepVerifyResponse {
    1: bool can_access;
    255: base.BaseResp BaseResp;
}

struct CoreUserInfo {
    1: optional i64 id;                    //user id
    2: optional string name;
    3: optional string email;              //User email after desensitization
}

struct StaffInfo {
    1: optional i64 id;           //staff id
    2: optional string email;     //Employee email
    3: optional string name;
    4: optional bool lark_expired;
    5: optional list<string> authCodes;    //Return to BC
    6: optional bool can_access;   //Return to BC
}

struct GetCoreUserAuthRequest {
    1: required i64 app_id;
    2: SubjectEntity subject;     //Support BizUser
    3: ObjectEntity object;       //Support BC、Account
    255: base.Base Base,
}

struct GetCoreUserAuthResponse {
    1: optional CoreUserInfo core_user_info;
    2: optional StaffInfo staff_info;
    255: base.BaseResp BaseResp,
}

struct DealPermTaskReq {
    1: required i64 app_id;  // business id
    2: required RoleRelation perm_ref;
    3: optional bool only_check;   // This field is true, just calculate the final role without writing to the data table
    4: optional string msg_id;     // Send message id, used to confirm receipt
    255: required base.Base Base
}

struct DealPermTaskResp {
    1: optional Role role;
    255: base.BaseResp BaseResp
}

// Subject type
enum MsgType {
    OverAll  = 1
    Tuple = 2
}

struct SendPermTaskReq {
    1: required i64 app_id;  // business id
    2: required MsgType msg_type;
    3: optional list<i64> user_list;
    4: optional list<i64> asset_list;
    5: optional ObjectType object_type;
    6: optional i64 bc_id;
    7: optional i64 delay_time;
    255: required base.Base Base
}

struct SendPermTaskResp {
    1: optional string msg_id;
    255: base.BaseResp BaseResp
}

struct AckReceiptReq {
    1: required i64 app_id;  // business id
    2: required string msg_id;
    255: required base.Base Base
}

struct AckReceiptResp {
    255: base.BaseResp BaseResp
}

struct MGetPermissionsByRoleRequest {
    1: required i64 app_id;
    2: required list<Role> roles;
    255: base.Base Base;
}

struct MGetPermissionsByRoleResponse {
    1: optional list<Permission> permissions;
    255: base.BaseResp BaseResp;
}

service PermissionCenterService {

    ############################# Authentication #############################
    // Authority point authentication
    AuthPermissionResponse AuthPermission(1:AuthPermissionRequest req);

    // role authentication
    AuthRoleResponse AuthRole(1:AuthRoleRequest req);

    ############################# Authentication #############################


    ############################# Modify roles, permissions#############################
    // Add role authentication
    AddRoleResponse AddRole(1:AddRoleRequest req);

    // Delete role authentication
    DelRoleResponse DelRole(1:DelRoleRequest req);

    // Add role permission correspondence
    AddRolePermissionRefResponse AddRolePermissionRef(1: AddRolePermissionRefRequest req);

    // Delete role permission correspondence
    DelRolePermissionRefResponse DelRolePermissionRef(1: DelRolePermissionRefRequest req);

    // Batch modify or delete the role of the subject to the object (transactional operation)
    MModifyRoleResponse MModifyRole(1: MModifyRoleRequest req);


    // Unbind the relationship under the specified principal
    UnboundRelationBySubjectResponse UnboundRelationBySubject(1: UnboundRelationBySubjectRequest req);

    // Unbind the relationship under the specified object
    UnboundRelationByObjectResponse UnboundRelationByObject(1: UnboundRelationByObjectRequest req);

    // Unbind objects in batches
    MUnboundRelationByObjectResponse MUnboundRelationByObject(1: MUnboundRelationByObjectRequest req);
    ############################# upadte roles, permissions #############################


    ############################# Query roles, permissions #############################
    // Query related roles based on subject, object, source
    GetRolesResponse GetRoles(1:GetRolesRequest req);

    // Query related roles based on subject, object and source (batch interface, currently only open to BC), the upper limit is 500
    MGetRolesResponse MGetRoles(1:MGetRolesRequest req);

    // Query related permission points based on subject, object and source
    GetPermissionsResponse GetPermissions(1: GetPermissionsRequest req);

    // Query all permission points under a role
    GetPermissionsByRoleResponse GetPermissionsByRole(1: GetPermissionsByRoleRequest req);
    ############################# Query roles, permissions #############################

    ############################# Create configuration roles, permissions#############################
    // Create a configuration role
    CreateRoleEntityResponse CreateRoleEntity(1:CreateRoleEntityRequest req);

    // Create configuration permissions
    CreatePermissionEntityResponse CreatePermissionEntity(1: CreatePermissionEntityRequest req);

    ############################# Create configuration roles, permissions #############################

    ############################# Query subject, object relationship #############################
    // Query related objects by subject
    GetObjectsBySubjectResponse GetObjectsBySubject(1:GetObjectsBySubjectRequest req);


    // Query related subjects through objects
    GetSubjectsByObjectResponse GetSubjectsByObject(1:GetSubjectsByObjectRequest req);

    // Query the associated object permissions through the subject*object dimension (for example, with user*adv permissions, the tt list that the user has permissions
    GetObjectsByConditionResponse GetObjectsByCondition(1:GetObjectsByConditionRequest req);
    ############################# Query subject, object relationship #############################


    ############################# Query the relationship between assets (subject and object) #############################
    // Query the relationship between assets
    GetAssetsRelationResponse GetAssetsRelation(1:GetAssetsRelationRequest req);

    ############################# Query the relationship between assets (subject and object) #############################



    ############################# Query the relationship between assets (subject and object) #############################
    // Modify or delete relationships between assets in bulk (transactional operations)
    MModifyAssetsRelationResponse MModifyAssetsRelation(1: MModifyAssetsRelationRequest req);

    ############################# Query the relationship between assets (subject and object) #############################


    ############################# Query the relationship between assets (subject and object) based on asset type and time range #############################

    GetAssetsRelationResponse GetAssetRelationByType(1: GetAssetRelationByTypeRequest req);

    ############################# Query the relationship between assets (subject and object) based on asset type and time range #############################

    MGetAssetsRelationResponse MGetAssetsRelation(1:MGetAssetsRelationRequest req);

    // Check 2SV permissions
    CheckTwoStepVerifyResponse CheckTwoStepVerify(1:CheckTwoStepVerifyRequest req);

    // Get internal employee permissions (including User->BC, User->Adv)
    GetCoreUserAuthResponse GetCoreUserAuth(1:GetCoreUserAuthRequest req);

    // Handling permission calculation tasks
    DealPermTaskResp DealPermTask(1: DealPermTaskReq req);

    // Send permission calculation message
    SendPermTaskResp SendPermTask(1: SendPermTaskReq req);

    // confirmation receipt
    AckReceiptResp AckReceipt(1: AckReceiptReq req);

    // Get permissions by role
    MGetPermissionsByRoleResponse MGetPermissionsByRole(1: MGetPermissionsByRoleRequest req);
}
