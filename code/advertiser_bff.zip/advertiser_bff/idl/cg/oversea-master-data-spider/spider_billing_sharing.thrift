include "../../base.thrift"
include "enums.thrift"
include "spider_common.thrift"

namespace java com.bytedance.cg.oversea.master.data.spider.thrift.bs

########################### billing sharing 相关对象结构体定义 ###############################

# billing sharing关系保存入参数
struct SaveBillingSharingRelationRequest {
    1: required i64 sourceId;            // 发起方id（bcId、advId）
    2: required i32 sourceType;          // 发起方id 类型（bc、adv）
    3: required i32 targetType;          // 接收方id 类型（bc、adv）
    4: required i64 targetId;            // 接收方id（bcId、advId）
    5: required i32 status;              // @see enums.BillingSharingStatusEnum
    6: required i64 operatorId;          // 操作人id
    254: optional string lang;           // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

# billing sharing关系查询入参数
struct QueryBillingSharingRequest {
    1: optional i64 bcId;                   // bcId，优先通过bcId查询存在的sharing关系
    2: optional i64 advId;                  // advId，没有bcId，则通过advId查询存在的sharing关系
    3: optional i32 bsType;                 // billing sharing 关系类型：1：发起的、2：接收的、3：all
    4: optional i32 status;                 // billing sharing 关系状态：1：申请中，2：已接受，3：解除中，4：已解除
    5: required spider_common.Page page;    // 分页参数
    254: optional string lang;              // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

# adv list 批量查询billing sharing关系查询入参数
struct BatchQueryBillingSharingRequest {
    1: required i64 bcId;                   // bcId，优先通过bcId查询存在的sharing关系
    2: required list<i64> advIds;           // adv list
    254: optional string lang;              // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

# billing sharing关系组
struct BillingSharingRelationItem {
    1: required i64 sourceId;        // 发起方id（bcId、advId）
    2: required i32 sourceType;      // 发起方id 类型（bc、adv）
    3: required i64 targetId;        // 接收方id（bcId、advId）
    4: required i32 targetType;      // 接收方id 类型（bc、adv）
    5: required i32 status;          // billing sharing 状态：1：申请、2：成功（接收）、3：解绑中、4：废弃（解绑成功） @see enums.BillingSharingStatusEnum
}

struct QueryBillingSharingResponse {
    1: optional list<BillingSharingRelationItem> relations;
    2: optional i64 total;
    255: required base.BaseResp BaseResp;
}

# adv和bc结算关系变更参数
struct ChangeBcAndAdvRelationRequest {
    1: required i64 advId;             // adv id
    2: optional i64 ownBcId;           // adv own bc Id
    3: optional i64 billingBcId;       // adv billing bc id
    4: optional i32 operateType;       // 操作类型：参考@see enums.AdvOperationTypeEnum
    5: optional i64 activeTime;        // 生效时间：utc-0 毫秒时间戳
    6: required i64 operatorId;        // 操作人id
    254: optional string lang;         // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

struct CheckFailedInfo {
    1: i32 failedType          # 失败类型，见 CheckFailedTypeEnum
    2: string failedReason     # 失败原因，1、仅供 BC 参考，BC 暴露给用户了；2、不是所有的报错都翻译了。其他业务方最好是自己翻译，不要直接暴露给用户
}

struct ChangeBcAndAdvRelationResponse {
    1: optional i64 advId;
    2: required bool checkPassed;
    3: required bool operationResult;
    4: optional list<CheckFailedInfo> failedInfos; # 校验失败时的信息，可能存在多个不通过的条目
    5: optional map<string, string> extraInfoMap; # 关户场景，校验通过时，在map中返回具体资金明细,key = prepayBalance/rebateBalance/adCreditBalance/creditBalance
    255: required base.BaseResp BaseResp;
}

# adv、bc、account关系查询接口
struct QueryAdvRelationByAdvRequest {
    1: optional i64 advId;                  // 优先用advId查询【可能是bcId和TCM id】
    2: optional list<i64> advIds;           // advId【可能是bcId和TCM id】批量查询，批量最大为100
    3: optional bool forceMaster;           // 是否要读主库，默认从库，主库性能可能会变差，需要走一道CRM兜底
    4: optional i32 repsCtrl;               // 返回的数据字段，默认为1， 1-只返回bcId 2-返回bcId和accountId
    254: optional string lang;              // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

struct QueryAdvRelationRequest {
    1: optional i64 accountId;                  // crm account id（优先按照accountId查询）
    2: optional i64 bcId;                       // bc id (没有accountId，则按照bcId查询)
    3: optional spider_common.Page page;        // 分页参数
    4: optional bool needTcm                    // 是否需要返回tcm信息
    5: optional i32 repsCtrl;                   // 返回的数据字段，默认为1， 1-只返回bcId 2-返回bcId和accountId
    254: optional string lang;                  // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

struct AdvRelationInfo {
    1: optional i64 advId;
    2: optional i64 ownBcId;                // adv的owner bc
    3: optional i64 accountId;              // adv的owner account，有agency取agency
    4: optional i64 billingBcId;            // adv的billing setting bc
    5: optional i64 billingAccountId;       // adv的所使用的payment的accountId，取值逻辑，优先billing setting，然后是owner account
    6: optional i32 status;                 // 当前该字段废弃，1:生效，2:切换中，3:失效
    7: optional i32 advType;                // adv类型：出入海信息，ad/bd，只有指定接口才会返回该字段，使用前请联系对应RD
    8: optional i32 bsRefType;              // 当前该字段废弃
    9: required i64 startTime;              // 起始时间：ut0, 毫秒单位，只有指定接口才会返回该字段，使用前请联系对应RD
    10: optional i64 endTime;               // 结束时间：ut0, 毫秒单位，只有指定接口才会返回该字段，使用前请联系对应RD
    11: optional bool isBc;                 // 标示该advId是否为bcId
}

struct QueryRelationResponse {
    1: optional list<AdvRelationInfo> relations;
    2: optional bool hasNext;                       //在需要分页查询的场景下，如果有下一页的话，查询的分页参数分页数量加1

    254: optional spider_common.ExtraRespBody extraRespBody;
    255: required base.BaseResp BaseResp;
}

# 指定时间区间，通过advId查询adv-bc关系
struct QueryPeriodAdvRelationRequest {
    1: required i64 advId;               // adv id【可能是bcId和TCM id】
    2: required i64 startTime;           // 起始时间：ut0, 毫秒单位
    3: optional i64 endTime;             // 结束时间：ut0, 毫秒单位
    4: optional bool forceMaster;           // 是否要读主库，默认为false
    254: optional string lang;           // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}


# adv查询可用的支付方式入参数
struct QueryPaymentByAdvIdRequest {
    1: required i64 advId;                  // advId
    2: optional i32 advertisingType;        // 广告主类型：0：全部 1：品牌，2：竞价
    3: optional i32 businessScope;          // 广告平台：0：全部 1：出海，2：入海
    4: optional i32 bizLine;                // 业务线：0：全部 1：ad，2：千川
    5: optional string currencyCode;        // 币种code
    6: optional bool onlyEffective;         // true: 仅查询当前生效的, false：可查询切换中
    7: optional bool forceMaster;           // 用adv查询需要查询结算关系，结算关系查询是否要读主库，默认从库，主库性能可能会变差

    254: optional string lang;              // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

struct PayMethodItem {
    1: required i32 businessScope;          // 业务范围，出入海，非空（维度信息）
    2: required i32 advertisingType;        // 广告类型，品牌竞价，非空（维度信息）
    3: required i32 bizLine;                // 业务线，1：ad，2：千川
    4: optional i32 payMethod;              // 支付方式，0：月账单(授信)，1：autoPay，2：预付
    5: optional i32 accountPeriodValue;     // 回款天数，支付方式为授信时返回
}

struct BcPaymentInfo {
    1: optional i64 bcId;                     // bc id
    2: optional i32 refType;                  // 关系类型：1：own，2：billing sharing
    3: optional i64 accountId;                // crm account id
    4: optional PayMethodItem payMethod;      // 支付方式
}

struct QueryAvailablePaymentResponse {
    1: optional list<BcPaymentInfo> payments;
    255: required base.BaseResp BaseResp;
}

struct AdvPaymentInfo {
    1: required i64 advId;                          // adv id
    2: required i64 billingBcId;                    // billing bc id
    3: required i64 billingAccountId;               // billing account id
    4: optional i32 refType;                        // 关系类型：own、billing sharing @see AdvBcRelationTypeEnum
    5: optional i32 status;                         // 支付方式状态 【1:生效，2:切换中，3:失效】@see PayMethodStatusEnum
    6: optional list<PayMethodItem> payMethodList;  // 支付方式
    7: optional string currencyCode;                // 币种（无用字段，无实现）
    8: optional i64 subjectId;                      // 主体id（无用字段，无实现）
    9: optional i64 ownBcId;
    10: optional i64 ownAccountId;                  // adv直接对应的account id
    11: optional i64 ownAgencyAccountId;            // own bc 对应的account id
    12: optional bool isBillingRelationFinallyEffective; //结算关系是否最终生效,包括结算关系的变更是否完成+生效时间是否到了. 所有条件都满足才为true
}

struct QueryAdvPaymentResponse {
    1: optional AdvPaymentInfo payment;
    255: required base.BaseResp BaseResp;
}

# adv支付方式查询参数
struct QueryPaymentItem {
    1: required i64 advId;                  // advId
    2: optional i32 advertisingType;        // 广告主类型：0：全部 1：品牌，2：竞价
    3: optional i32 businessScope;          // 广告平台：0：全部 1：出海，2：入海
    4: optional i32 bizLine;                // 业务线：0：全部 1：ad，2：千川
    5: optional string currencyCode;        // 币种code
    6: optional bool onlyEffective;         // true: 仅查询当前生效的, false：可查询切换中
}

struct BatchQueryPaymentByAdvRequest {
    1: required list<QueryPaymentItem> queryPaymentList;    // payment查询关系组合，advId查询
    2: optional bool forceMaster;                           // 用adv查询需要查询结算关系，结算关系查询是否要读主库，默认从库，主库性能可能会变差

    254: optional string lang;                              // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

# 批量adv查询支付方式返回结果
struct BatchQueryAdvPaymentResponse {
    1: optional map<i64, AdvPaymentInfo> paymentMap;    // advId--paymentInfo
    255: required base.BaseResp BaseResp;
}

struct QueryAdvHistoryPaymentResponse {
    1: optional list<AdvPaymentInfo> payments;
    255: required base.BaseResp BaseResp;
}

struct QueryByBCIdRequest {
    1: required i64 bcId;
    2: optional bool needTcm;
    3: optional spider_common.Page page;        // 分页参数
    255: optional base.Base Base;
}

struct QueryBillingSettingAdvResponse {
    1: optional list<AdvRelationInfo> inAdv;
    2: optional list<AdvRelationInfo> outAdv;
    3: optional list<AdvRelationInfo> switchingAdv;
    4: optional bool hasNext;
    255: required base.BaseResp BaseResp;
}

# bc partner关系
struct DeleteBcPartnerRelationRequest {
    1: required i64 sourceBcId;          // source bc id
    2: required i64 targetBcId;          // target bc id 需要解除sharing/setting关系的bc
    3: required i64 operatorId;          // 操作人id
    254: optional string lang;           // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

# bc own adv和partner关系
struct CheckPartnerBcBillingSharingRequest {
    1: required i64 sourceBcId;         // source bc id: 登陆bc
    2: required list<i64> targetBcIds;  // target bc id: partner bc
    254: optional string lang;          // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

struct CheckPartnerBcBillingSharingResponse {
    1: optional map<i64, bool> result;      // source bc id: 登陆bc
    255: required base.BaseResp BaseResp;
}

struct CheckAdvSharingRelationRequest {
    1: required list<i64> advIdList;         // advIdList  required <= 200
    254: optional string lang;          // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

struct CheckAdvSharingRelationResponse {
    1: optional map<i64, bool> result;      // advId bool
    255: required base.BaseResp BaseResp;
}

struct QueryTcmRelationRequest {
    1: optional i64 lastChangeTime;         // 数据变化时间：仅返回大于变化时间范围的数据，暂时忽略，数据量小
    2: required spider_common.Page page;    // 分页参数
    254: optional string lang;              // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

struct QueryTcmRelationResponse {
    1: optional map<i64, i64> ttamTcmMap;  // key: ttamId, value: tcmId
    2: optional i64 total;
    255: required base.BaseResp BaseResp;
}
