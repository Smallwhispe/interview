include "../../base.thrift"

namespace java com.bytedance.cg.oversea.master.data.spider.thrift.common

########################### 通用对象结构体定义 ###############################
# 通用 空返回
struct BaseResponse {
    255: required base.BaseResp BaseResp;
}

# 通用 bool返回
struct BoolResponse {
    1: optional bool result;
    255: required base.BaseResp BaseResp;
}

# 通用 保存/更新 返回类
struct CommonSaveResponse {
    1: optional i64 id;
    255: required base.BaseResp BaseResp;
}

# 通用分页组件
struct Page {
    1: required i32 pageNo              # 页码：1开始
    2: required i32 pageSize            # 页大小
}

# 通过accountId查询
struct QueryByAccountIdRequest {
    1: required i64 accountId;         // account id
    2: optional string lang;           // 多语言，默认：en
    255: optional base.Base Base;
}

# 批量查询：通过accountId查询
struct QueryByAccountIdsRequest {
    1: required list<i64> accountIds;   // account id list
    2: optional string lang;            // 多语言，默认：en
    255: optional base.Base Base;
}


# 通过advId查询
struct QueryByAdvIdRequest {
    1: required i64 advId;          // adv id
    2: optional string lang;        // 多语言，默认：en
    255: optional base.Base Base;
}

# 批量查询：通过advId查询
struct QueryByAdvIdsRequest {
    1: required list<i64> advIdList;    // 通过advId list查询
    2: optional string lang;            // 多语言，默认：en
    255: optional base.Base Base
}


# 通过contractId查询
struct QueryByContractIdRequest {
    1: required i64 contractId;         // contract id
    2: optional string lang;            // 多语言，默认：en
    255: optional base.Base Base;
}


# 通过spiderId查询
struct QueryBySpiderIdRequest {
    1: required i64 spiderId;         // spider id
    2: optional string lang;          // 多语言，默认：en
    255: optional base.Base Base;
}

# 批量查询：通过spiderId查询
struct QueryBySpiderIdsRequest {
    1: required list<i64> spiderIdList;    // 通过spider id list查询
    2: optional string lang;               // 多语言，默认：en
    255: optional base.Base Base
}


# 通过bcId查询
//struct QueryByBcIdRequest {
//    1: required i64 bcId;           // bc id
//    2: optional string lang;        // 多语言，默认：en
//    255: optional base.Base Base;
//}

# 批量查询：通过bcId查询
struct QueryByBcIdsRequest {
    1: required list<i64> bcIdList;  // bc id list
    2: optional string lang;         // 多语言，默认：en
    255: optional base.Base Base;
}

# 批量查询：通过bcId查询
struct ExtraRespBody {
    1: optional i32 code;
    2: optional string message;
}

struct BillingOption {
    1: optional i32 payMethodType;          // 1 prepay, 2 autopay, 3 MI
    2: optional i32 advertisingType;        // 1 品牌 2 竞价
    3: optional i32 businessApp;            // 1 出海-tt 2 入海-dy
    4: optional i32 businessLine;           // 1 广告 2 千川
    5: optional i32 accountPeriodValue;     // MI场景下，回款周期
}

struct BaseStatus {
    1: optional i32 statusCode;             // 结果code
    2: optional string statusMessage;       // 结果message
}
