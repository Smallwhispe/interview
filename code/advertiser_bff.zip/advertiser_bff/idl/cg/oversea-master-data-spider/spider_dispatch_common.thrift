include "../../base.thrift"
include "spider_billing_sharing.thrift"

namespace java com.bytedance.cg.oversea.master.data.spider.thrift.dispatch.common

struct ChangeMetaData {
    1: required i64 origin
    2: required i64 target
}

struct PayMethodChange {
    1: optional i32 advertisingType // 商务类型：品牌 1， 竞价 2， both 0
    2: optional i32 bizPlatform //目标区域：出海 1， 入海 2， both/default 0
    3: optional i32 businessLine // 业务线：TT/BC/Promote 等，
    4: required ChangeMetaData payMethod // 预付 2/授信 0/autopay 1
}

struct RegisterPayMethodRequest {
    1: required list<i64> accountIdList             // crm account id list
    2: optional list<PayMethodChange> payMethodRegistrationList
    3: optional i32 customerTypeChange              // 1:自助升级 2:自助变更 3:非自助新建 4:非自助变更 5:自助新建
    4: optional ChangeMetaData subjectChange        // 自助升级 须提供主体变化
    5: optional ChangeMetaData bizLineChange        // 自助升级 须提供业务线变化
    6: optional i64 contractId                      // 当前合同id
    7: optional i64 parentContractId                // 主合同id(如果有)
    8: optional i64 startDate                       // 包含时区信息的毫秒时间戳
    9: optional i64 endDate                         // 包含时区信息的毫秒时间戳
    10: optional map<string, string> callBackInfo    // 回调时所需信息
    255: optional base.Base Base
}

struct AccountProcessResult {
    1: optional i64 accountId
    2: optional string statusMessage = ""
    3: optional i32 statusCode = 0
    4: optional i32 processType // 1 支付方式竞价维度操作 2 支付方式品牌维度操作
}

struct RegisterPayMethodResponse {
    1: optional list<AccountProcessResult> accountRegistrationResult
    255: optional base.BaseResp BaseResp // status code = 0 表示调用成功
}



struct ApplyPayMethodRequest {
    1: required i64 contractId // 合同侧生效的 合同id
    255: optional base.Base Base
}

struct ApplyPayMethodResponse {
    1: optional list<AccountProcessResult> accountApplicationResult
    255: optional base.BaseResp BaseResp // status code = 0 表示调用成功
}



struct QueryAccountTransferRecordRequest {
    1: optional i64 originalAccountId;
    2: optional i64 targetAccountId;
    3: optional list<i32> statusList; # @see enums.TransferStatusEnum
    255: optional base.Base Base;
}

struct AccountTransferRecord {
    1: optional i64 advId
    2: optional i64 originalAccountId;
    3: optional i64 targetAccountId;
    4: optional i64 originalBCId;
    5: optional i64 targetBCId;
    6: optional i32 status;
    7: optional i64 originalAgencyAccountId;
    8: optional i64 targetAgencyAccountId;
    9: optional i32 transferScenario;
}

struct QueryAccountTransferRecordResponse {
    1: optional list<AccountTransferRecord> accountTransferRecordList
    2: optional i32 total # 如果入参仅指定成功状态，则total>0说明有成功记录
    255: required base.BaseResp BaseResp;
}



struct TransferAdvInfo{
    1: required i64 advId;
    2: optional i64 targetBCId;
    3: optional i64 targetAccountId;
    4: optional i64 targetOpportunityId;
    5: optional i64 targetAgencyAccountId;
    6: optional i64 targetAgencyOpportunityId;
    7: optional string tiktokEmail; //登录邮箱 透传给BC用，targetBCId与email不能同时为空
    8: optional map<string,string> extraInfoMap;
}

struct TransferAdvRequestV2 {
    1: optional list<TransferAdvInfo> advInfoList; // 需要执行转户的adv信息
    2: optional i64 operatorId;         // CRM转户必填
    3: required i32 transferScenario;   // @see TransferScenarioEnum
    4: optional i64 mergedAccountId;    // 被合并的accountID，account merge场景必填
    5: optional i64 targetAccountId;    // 目标accountID，account merge场景必填
    255: optional base.Base Base;
}

struct TransferAdvResponse {
    1: optional bool success;                           // 是否转户/转户校验全部成功
    2: optional map<i32, list<i64>> transferResult;     // key= transfer status code，value = adv id list 转户进度详情 （转户当前状态）
    3: optional map<i64, list<i32>> advFailureReason;   // key = advId/accountId, value = error code list @see AdvTransferFailureReasonsEnum
    255: required base.BaseResp BaseResp;
}



struct ChangePayMethodCheckRequest {
    1: required list<PayMethodChange> payMethodChangeList
    255: optional base.Base Base
}

struct ChangePayMethodCheckResponse {
    255: optional base.BaseResp BaseResp // status code = 0 表示调用成功
}



struct QueryPayMethodChangeRecordRequest {
    1: optional i64 contractId;   # 合同id
    254: optional string lang;
    255: optional base.Base Base
}

struct PayMethodChangeRecordResponse {
    1: optional bool processStarted;    // 调度相关操作是否已经开始(是不是触发了资产清空了)
    2: optional list<AccountProcessResult> accountStatus
    255: optional base.BaseResp BaseResp // status code = 0 表示调用成功
}



struct QuerySupportAndRecommendPayMethodRequest {
    1: i64 accountId;
    2: string countryCode; //iso_code
    3: i32 businessLine;  //@see enum.BusinessLineEnum
    255: optional base.Base Base;
}

struct CurrencyAndPayMethodInfo{
    1: string currencyCode;
    2: list<i32> supportPayMethod; //1-prepay 2-autopay 3-mi
    3: i32 recommendPayMethod;  //1-prepay 2-autopay 3-mi
    4: bool needCreditLineEmail  //选择mi时是否需要信控邮箱
}

struct QuerySupportAndRecommendPayMethodResponse {
   1: list<CurrencyAndPayMethodInfo> currencyAndPayMethodInfos;
   255: required base.BaseResp BaseResp;
}



struct AssetDetailInfo {
    1: i32 assetType // cash = 1， grant = 2， prepay+rebate = 3， credit = 4 (1与3、4)互斥
    2: string currencyCode
    3: i64 amount
    4: string refundSerial // 退款单据，assetType = 3 且 amount != 0的时候，该字段必填
}

struct AssetClearingCallbackRequest {
    1: required string callerRequestId   // 请求清空时传入的业务全局唯一ID
    2: required bool allCleared // 成功清空传true
    3: optional list<AssetDetailInfo> assetDetailList // 清空资产详情
    4: optional string serial // 转账单据
    255: optional base.Base Base;
}

struct AssetClearingCallbackResponse {
    255: required base.BaseResp BaseResp;
}



struct SyncTCMRelationRequest {
    1: i64 tcmId
    2: i64 ttamId
    255: optional base.Base Base;
}

struct SyncTCMRelationResponse{
    255: required base.BaseResp BaseResp;
}

struct QueryTCMRelationRequest{
    1: list<i64> tcmIds; // 每次上限50个
    255: optional base.Base Base;
}

struct QueryTCMRelationResponse{
    1: map<i64,i64> tcmRelatedTtamInfo; // key = tcm id value = ttam id
    255: required base.BaseResp BaseResp;
}



struct MergeInfo{
    1: i64 ttamId; // 可以是adv id，也可以是 bc id，如果是 bc id，需要指明 ttamIdType
    2: i32 ttamIdType; // 0 = adv, 1 = normal bc, 2 = agency bc, 4 = direct bc, 5 = self service direct bc, 6 = self service agency bc
    3: i32 tcmMode; // 1:net 2:gross
    4: string tcmCountryCode; // tcm country code
}

struct TcmMergeRequest{
    1: list<MergeInfo> mergeInfoList;
    255: optional base.Base Base;
}

struct TcmMergeResponse{
    1: map<i64, bool> subjectCheckResult; // key = ttam id, value = true if passed subject consistency check
    255: required base.BaseResp BaseResp;
}



struct CloseAutoPayRequest {
    1: i64 advId; // 需要关户的adv
    2: i64 effectiveAccount; // adv 对应的生效account，有agency给agency
    3: bool consumptionHasStopped; // 关户前是否已经进行过停投
    255: optional base.Base Base;
}

struct CloseAutoPayResponse {
    1: bool closeSuccess;
    2: bool existUnpaidBilling;
    3: list<i64> unpaidBillingIdList; // 仅当 existUnpaidBilling = true 时有值
    255: required base.BaseResp BaseResp;
}

struct RegisterPayMethodPreCheckRequest{
    1: required list<i64> accountIdList;
    2: required list<PayMethodChange> payMethodRegistrationList;
    3: optional i64 activeDate                    // 包含时区信息的毫秒时间戳
    4: optional i64 endDate                      // 包含时区信息的毫秒时间戳
    5: optional i64 contractId
    6: optional i64 parentContractId
    254: optional string lang // 默认en
    255: optional base.Base Base;
}

struct RegisterPayMethodPreCheckResponse{
    1: required bool checkPassed;
    2: optional list<spider_billing_sharing.CheckFailedInfo> failedInfos; # 校验失败时的信息，可能存在多个不通过的条目
    255: required base.BaseResp BaseResp;
}

struct SharkParam {
    1: optional string event; // shark 事件码
    2: required string sharkParamMap // shark 参数，json map 类型
}

// 通过Id查询
struct QueryByIdRequest {
    1: required i64 id;
    2: required i32 idType; // 1 adv 2 bc 3 account
    3: optional bool isSelfService;
    4: optional SharkParam sharkParam //（adv场景必填）
    254: optional string lang;
    255: optional base.Base Base;
}

struct RecomendedPayMethodResponse {
    1: required i32 payMethod;              // 推荐升级的支付方式 1预付 2autopay 3mi， 0代表无推荐
    2: required i32 payMethodChangeStatus;  // 支付方式变更状态
    3: optional string relatedUrl;          // hades所需的申请单链接
    4: optional i32 urlType;                // url类型，1：信控额度申请链接，2：MI升级链接
    255: required base.BaseResp BaseResp;
}

struct PayMethodChangeLogResponse {
    1: required i64 id;
    2: required i32 idType; // 1 adv 2 bc 3 account
    3: optional i32 currentPayMethod // 当前支付方式 （广告出海竞价维度）0-无 1-预付 2-autopay 3-mi
    4: optional i32 previousPayMethod // 上一个支付方式（广告出海竞价维度）0-无 1-预付 2-autopay 3-mi
    255: required base.BaseResp BaseResp;
}

struct UpgradePayMethodRequest {
    1: required i64 id;
    2: required i32 idType; // 1 adv 2 bc 3 account
    3: optional i32 targetPayMethod // 目标支付方式 （仅对广告出海竞价维度做升级操作，其他维度保持不变）1 预付 2autopay 3 mi
    255: optional base.Base Base
}

struct UpgradePayMethodResponse{
    255: optional base.BaseResp BaseResp // status code = 0 则成功，否则一律失败
}



// 通过advId查询
struct QueryByAdvIdRequest {
    1: required i64 advId;          // adv id
    2: optional string lang;        // 多语言，默认：en
    3: optional i32 advertisingType; // @see enums.AdvertisingTypeEnum
    255: optional base.Base Base;
}


struct BcAllPayMethodResponse {
    1: required i64 bcId
    2: optional list<i32> hisPayMethod      // 历史支付方式，会包含当前支付方式，1-PrePay 2-Autopay 3-MI
    3: optional list<i32> curPayMethod      // 当前支付方式，1-PrePay 2-Autopay 3-MI

    255: optional base.BaseResp BaseResp // status code = 0 则成功，否则一律失败
}
