namespace py enums
namespace go master_data_spider_enums
namespace java com.bytedance.cg.oversea.master.data.spider.thrift.enums

// 对象类型枚举
enum ObjectTypeEnum {
    SPIDER = 1,              # spider对象 （帐期使用）
    ACCOUNT_MASTER_DATA = 2, # 客户主数据对象 ( 地址/联系人）
    BILL_TO_PARTY = 3,       # bill to party对象 ( 地址/联系人）
    ADV = 4,                 # 广告主对象 (帐期使用）
    BC = 5,                  # BC对象
}

// 通用状态枚举
enum CommonStatusEnum {
    DELETE = 0  # 删除
    VALID  = 1  # 生效
    DRAFT  = 2  # 未生效，草稿态
    SNAPSHOT = 3 # 快照状态，仅用于Bill To Party
}

// spider base
// 业务线
enum BusinessLineEnum {
    DEFAULT=0,      #默认类型
    TCM_CUSTOMER=1, #广告主/客户
    TCM_PERSON=2,   #达人
    PROMOTE=3,      #Promote
    CREATOR_FUND=4, #Creator Fund
    SHOUT_OUT=5,    #SHOUT OUT
    SHOPIFY_REV_SHARE=6,     #Shopify_Rev_Share
    TCM_HTC=7,      #TCM hashtag challenge
    LIVE_ACCELERATOR=8,     #live accelerator
    PANGLE=9,       #pangle
    IN_FEED_ADS=10, #in-feed ads
    BRAND_TAKEOVER=11,     #brand takeover
    TOP_VIEW=12,    #topview
    BOOSTED_TIKTOK=13,      #Boosted TikTok
    BRANDED_EFFECT=14,      #Branded effect
    CREATOR_STARTER_PACK=15,#Creator Starter Pack
    RESSO=16,    #RESSO
    OASIS=17,    #绿洲
    BC_SELF=18,  # BC self
    BC_NON_SELF=19,  # BC non self
    PANGLE_DSP=20, # pangle dsp
}

// 广告类型
enum AdvertisingTypeEnum {
    BOTH=0, #品牌 + 竞价
    RESERVATION=1, #品牌 BRAND
    AUCTION=2,  #竞价 BIDDING
}

// 数据源
enum OriginSourceEnum {
    DEFAULT=0,
    TTP=1,
    VA=2,
    SG=3,
}

// 开票周期
enum InvoicePeriodTypeEnum {
    DEFAULT = 0   # 默认值
    BY_ORDER = 1, # 开票周期：按订单结
    BY_MONTH = 2, # 开票周期：按月结
}

// 支付方式
enum PayMethodEnum {
    DEFAULT = 255 # 默认值
    COLLECTION_PAYMENT = 0 # 发票回款
    AUTOMATIC_DEBIT_PAYMENT = 1 # 自动支付
    PREPAY = 2 , # 预付
}

/**
 * Marin 中类型枚举
 **/

// margin 地区
enum RegionEnum {
    DEFAULT = 0,
    JAPAN = 1,
    MIDDLE_EAST = 2,
    BRAZIL = 3,
    CAMBODIA = 4,
}

// 出入海
enum BizPlatformEnum {
    DEFAULT = 0,  # 默认值
    OVERSEA = 1,  # 出海
    DOMESTIC = 2, # 入海
}

// margin 资源
enum MarginResourceEnum {
    DEFAULT = 0, # 默认值
    TCM_HTC = 1 , # TCM挑战赛
    ADV=2, # 硬广
}

// magin 用途
enum MarginUsageEnum {
    DEFAULT=0, # 默认值
    REVENUE=1, # 记收
    INVOICE=2, # 开票
}

// 联系人类型
enum ContactTypeEnum {
    DEFAULT=0, #默认值
    SALES_PERSON=1, #销售
    TX_SALES_PERSON=2, #交易跟进销售
    INVOICE_RECEIVER=3, #发票接收人
    CONTRACT_CONTACT=4 #合同联系人
    INVOICE_CONTACT=5, #发票联系人
    SUBJECT_CONTACT=6, #主体联系人
    SETTLEMENT_CONTACT=7, #结算联系人
}

// 地址类型
enum AddressTypeEnum {
    DEFAULT=0,          #默认值
    CONTRACT_BILLING=1, #Billing address in contract
}

// 开票类型
enum ProjectTypeEnum {
    DEFAULT=0,     #默认值
    ADVERTISING_FEE=1,     #广告费
    MEDIA_FEE=2,     #媒介费
    ADVERTISING_SPEND=3,     #广告消耗
    MEDIA_SPEND=4,
    DIGITAL_MEDIA_SPEND=5,
    INFLUENCER_COST=6,
    MUSIC_LICENSE_FEE=7,
    MARKETING_EVENT_COST=8,
    PLANNING_FEE=9,
    OTHER=10,
    TCM_CONTENT_CREATION_AND_DISTRIBUTION=13,
    SERVICE_FEE=20,
}

// 主数据类型
enum MasterDataTypeEnum {
    DEFAULT=0,     #默认值
    ACCOUNT=1,     #account维度
    CONTRACT=2,     #合同维度
}

// 扩展数据类型
enum BillingExtendDataTargetTypeEnum {
    ADV=1,
    CAMPAIGN=2,
    SPIDER=3,
}

// 支付方式注册/变更错误码
enum StatusCodeEnum {
    SUCCESS = 0                                     // Success!
    PARAM_ERROR = 1                                 // Parameter check failed. Please check your input.
    AUTH_ERROR = 2                                  // Auth check failed. Please check your auth.
    SYSTEM_ERROR = 501                              // Internal system error. Please contact the admin.
    CRM_SYSTEM_ERROR = 100000                       // Failed to query info from CRM.
    HAS_MULTIPLE_AUTO_PAY_RECORDS = 200001          // Registration info contains multiple auto pay records.
    AUTO_PAY_ACCOUNT_CLOSE_FAILED = 200002          // Failed to close adv's autopay account in ad billing.
    EXISTS_UNPAID_BILLING = 200004                  // Exists unpaid billings.
    QUERY_UNPAID_BILLING_FAILED = 200005            // Failed to query unpaid billings because of system error!because of system error.
    HAS_NO_ONGOING_CHANGE_PROCESS = 200006          // Can not find ongoing change process.
    HAS_MULTIPLE_ONGOING_CHANGE_PROCESSES = 200007  // Has more than one ongoing change process.
    SUBJECT_TRANSFER_FAILED = 200008                // Failed to do subject transfer.
    HAS_NO_POST_PAY_CARD = 200009                   // Has no post pay card. Please bind card first.
    AUTO_PAY_ACCOUNT_OPEN_FAILED = 200010           // Failed to open auto pay account in ad billing, pls retry later.
    HAS_NO_BID_ADV = 200011                         // Has no bid adv.
    OBSOLETE_CREDIT_FAILED = 200012                 // Failed to obsolete credit under bid advs, 清空竞价授信额度失败
    CLEAR_CREDIT_POOL_FAILED = 200013
    CLEAR_CREDIT_POOL_COMMIT_FAILED = 200014
    CONSUMPTION_STOPPED = 200015
    FAILED_TO_START_APPLICATION = 200016
}

// 客户类型变更枚举
enum CustomerTypeChangeEnum {
     DEFAULT = 0
     SELF_TO_NON_SELF = 1
     SELF_TO_SELF = 2
     NEW_NON_SELF = 3
     NON_SELF_TO_NON_SELF = 4
     NEW_SELF = 5
}


// 转户状态枚举
enum TransferStatusEnum {
    DEFAULT = 0
    SUCCESSFUL = 1 # 转户成功
    VERIFICATION_IN_PROCESS = 2 # 业务校验中（机审）一般不披露此状态
    VERIFICATION_FAILED = 3 # 业务校验（机审）不通过，例如币种、支付方式等不满足要求
    MANUAL_APPROVING_IN_PROCESS = 4 # 业务校验完成，人工审批中
    MANUAL_APPROVING_PROCESS_FAILED = 5 # 业务校验完成，人工审批被拒绝
    WAITING_FOR_THIRD_PARTY_SYSTEM_CALL = 6 # 审批完成，等待上下游调用
    THIRD_PARTY_SYSTEM_CALL_FAILED = 7 # 上下游调度失败
    WAITING_FOR_MANUAL_APPROVE = 8
    WAITING_FOR_ASSET_CLEAR_CALLBACK = 9
    WAITING_FOR_BC_MANUAL_CHECK = 10
    WAITING_FOR_CRM_RETRY = 11
    PARAM_ERROR= 254 # 参数不足 或 有误
}

// adv转户场景
enum TransferScenarioEnum {
    TCM_TO_TTAM = 10
    CRM_AGENCY_TO_AGENCY = 1
    CRM_DIRECT_TO_DIRECT = 2
    CRM_AGENCY_TO_DIRECT = 3
    CRM_DIRECT_TO_AGENCY = 4
    CRM_AGENCY_BC_TO_BC = 6
    ACCOUNT_MERGE = 24
}

// 转户校验错误码
enum AdvTransferFailureReasonsEnum {
    CRM_ACCOUNT_STATUS_INVALID = 1
    ADV_STATUS_INVALID = 2
    ADV_PLATFORM_INVALID = 3
    ADV_TYPE_INVALID = 4
    TARGET_ACCOUNT_HAS_NO_EFFECTIVE_CONTRACT = 5
    ADV_CURRENCY_DOES_NOT_MATCH_WITH_BC = 6
    ADV_BC_CURRENCY_NOT_SUPPORTED_BY_TARGET_CONTRACT = 7
    TARGET_CONTRACT_USES_AUTO_PAY = 8
    ORIGINAL_CONTRACT_USES_AUTO_PAY = 9
    ADV_NOT_OWNED_BY_BC_NEEDS_TO_REFUND_FIRST = 10 //
}

# 以下广告主相关枚举来自广告主平台定义，account_i18n.thrift
enum AdvertiserRole {
    # 广告主角色枚举
    ROLE_ADVERTISER = 0                     # 一般广告主
    ROLE_AGENT = 1                          # 广告代理商(数据已迁出)
    ROLE_VIRTAUL_ADVERTISER = 2             # 虚拟广告主
    ROLE_ADMIN = 3                          # 管理员
    ROLE_INTERNAL_ADV = 4                   # 内部广告主
    ROLE_DSP_ADVERTISER = 8                 # 头条自建DSP 广告主
    ROLE_MAJORDOMO = 13                     # 账户管家
    ROLE_PROMOTE_I18N = 60                  # promote广告主
    ROLE_SANDBOX = 70                       # 国际化OPENAPI沙箱账户
}

enum AdvertiserOrigin {
    # i18n
    i18n_bpm = 100                          // 国际化BPM开户
    i18n_agent_ad = 101                     // 国际化代理商创建
    i18n_self_service = 102                 // 国际化自助开户

    i18n_promote_business = 103            // promote B端账户
    i18n_promote_consumer  = 104            // promote C端账户

    i18n_sandbox = 105                     // 国际化沙箱账户
}

enum AdvertiserStatus {
    # 广告主状态
    STATUS_DISABLE = 0                  // 已禁用
    STATUS_PENDING_CONFIRM = 1          // 待审核
    STATUS_PENDING_VERIFIED = 2         // 待邮箱验证，已废弃
    STATUS_CONFIRM_FAIL = 3             // 审核失败/可再次申请
    STATUS_ENABLE = 4                   // 已审核
    STATUS_CONFIRM_FAIL_END = 5         // 审核失败/最终状态
    STATUS_PENDING_CONFIRM_MODIFY = 6   // 修改审核
    STATUS_CONFIRM_MODIFY_FAIL = 7      // 修改审核失败
    STATUS_PUNISH = 8                   // 限制惩罚
    STATUS_WAIT_FOR_BPM_AUDIT = 9       // 等待CRM审核
    STATUS_SELF_SERVICE_UNAUDITED = 10  // 自助开户待验证资质
    STATUS_CONTRACT_PENDING = 15        // 待合同生效 避免历史冲突从15开始自增
}

enum AdvAccountType {
    # 广告主投放类型
    NO_SET = 0;                             # 未设置
    RESERVATION = 1;                        # 品牌广告平台
    AUCTION = 2;                            # 竞价广告平台
}

enum AdvertiserTaxType {
    # 国际化自助开户广告主税务身份字段，
    # https://bytedance.feishu.cn/sheets/shtcnZH2tLa9Sg71KpRUXWPglJc
    registered_individual = 1
    unregistered_individual = 2
    business = 3
    sez = 4
    local_authority = 5
    gv_authority = 6
    gv = 7
    unorganization = 8
    embassy = 9
    registered_vat = 10
    unregistered_vat = 11
}

enum AssetType {
    CASH = 1
    GRANT = 2 // ad credit 赠款
    PREPAY_REBATE= 3
    CREDIT = 4 // (1与3、4)互斥
}

# adv操作类型
enum AdvOperationTypeEnum {
    CREATE = 1         # adv create
    CLOSE = 2          # adv close
    BC_TRANSFER = 3    # bc transfer
    SET_PAYMENT = 4    # set payment
    STOP_PAYMENT = 5   # stop payment
}

enum CheckFailedTypeEnum{
     // 关户相关
    DELIVERING = 1,             # 还在广告投放中
    ONGOING_PAYMENT = 2,        # 有未支付账单
    PUNISHING = 3,              # 被惩罚中
    REQUEST_CONFLICT = 4        # 请求冲突，Payer 有正在处理的转账单
    AUTO_PAY_COST_UNBILLED = 5  # autopay有消耗还未出账单
    // 其他
    EXIST_BILLING_SHARING_RELATION = 6
    EXIST_BILLING_SETTING_RELATION = 7
    UNDER_PAY_METHOD_SWITCHING = 8
}

enum BillingSharingStatusEnum {
    INVITE = 1      # 邀请
    ACCEPT = 2      # 接受
    REJECT = 3      # 拒绝
    UNBINDING = 4   # 解绑中
    UNBIND = 5      # 解绑
}

enum QueryType {
    CUR_EFFECTIVE = 1                   // 只返回当前生效的合同的信息
    ALL_EFFECTIVE = 2                   // 优先返回当前生效的合同的信息，否则返回最后一份过期生效的合同
    FUTURE_EFFECTIVE = 3                // 优先返回当前生效的合同的信息，否则返回最近一份未来生效的合同
}

# adv支付方式状态
enum PayMethodStatusEnum {
    VALID = 1   # 生效
    SWITCH = 2  # 切换中
    INVALID = 3 # 失效
}

# adv和bc的关系类型
enum AdvBcRelationTypeEnum {
    BC_OWN = 1              # bc own
    BILLING_SETTING = 2     # billing setting
    NO_BC = 3               # 无bc
}

enum PayMethodChangeStatusEnum{
    NOT_AVAILABEL = 1 // 当前客户不可升级 (不在任意白名单中)
    UPGRADE_AVAILABEL= 2 // 可升级，MI场景会返回申请链接
    UNDER_REVIEW= 3 // 升级流程中
    FAILED = 4 // 已拒绝
    WAITING_FOR_MATERIALS= 5 // 待用户补充信息(MI特有)，MI场景会返回信息补充提交链接
    NO_NEED_TO_UPGRADE = 6
}

enum ApplicationType {
    DEFAULT = 0,
    SELF_TO_NONE_SELF = 1       //自助升级
    SELF_TO_SELF = 2            // 自助变更
    NEW_NON_SELF = 3            // 非自助新建
    NONE_SELF_TO_NONE_SELF = 4  // 非自助变更
    NEW_SELF = 5                // 自助新建
    ADV_TRANSFER = 6            // 转户导致的变更
    BILLING_SETTING = 7         // billing setting 导致的变更
    ADV_CLOSE = 8               // 关户导致的变更
}


enum BillingOptionOperateTypeEnum {
    DEFAULT = 0
    DRAFT = 1     // 新建保存草稿
    SUBMITTED = 2 // 提交审批
    AUTO_PASS = 3 // 自动审批通过
}

enum PayMethodTypeEnum {
    PREPAY = 1 // 预付
    AUTO_PAY = 2 // auto pay
    MI = 3 // 授信 - monthly invoice 月账单回款
}
