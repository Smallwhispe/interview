include "../../base.thrift"
include "enums.thrift"
include "spider_common.thrift"
include "spider_billing_sharing.thrift"
include "spider_dispatch_common.thrift"

namespace py oversea_master_data_spider_service
namespace go oversea_master_data_spider_service
namespace java com.bytedance.cg.oversea.master.data.spider.thrift

####################【重要】主数据服务接入须知 #########################################
#
# 【安全合规要求】
#       1.TTP用户数据不允许非TTP用户访问（不支持sg流量访问ttp数据）
#       2.TTP敏感数据不允许出TTP（sg机房没有ttp敏感数据）
#
# 【原则】业务上游调用主数据服务，尽量保证同机房访问，sg流量访问sg数据，ttp流量访问ttp数据，禁止sg流量访问ttp数据。
#
# 根据TTP安全合规要求，TTP敏感数据不允许出TTP，不支持sg机房访问，最多只允许非敏感信息出TTP，支持sg机房访问。
#   1.ttp敏感信息，不支持sg机房查询的，主要包括：
#       税号、detailAddress、联系人信息等
#
#   2.ttp非敏感信息，支持sg机房查询的，主要包括：
#       合同关系、adv关系、支付方式、币种、billingAddressId
#
# 【重要】不确定是否是敏感信息，sg机房是否支持查询的场景，请联系主数据同学先确认，再接入上线。（避免接入上线之后，无法访问，影响业务）
#
####################################################################################

# 支付方式(合同支持非自助autopay专用)
enum PayMethodBillingEnum {
    MONTHLY_INVOICING_PAYMENT = 0
    AUTOMATIC_DEBIT_PAYMENT = 1
    MANUAL = 2
}

enum AccountNumType {
    MAIN_ACCOUNT = 1        # 主账号
    SUB_ACCOUNT  = 2        # 子账号
}

struct BillingExtendData {
    1: optional string po_number  #po number
    2: optional i32 delete_po_number    #是否清空po number 0:false  1: true
}

/**
 *  批量修改BillingExtendData
**/
struct BillingExtendDataBatchSaveRequest {
    1: required map<i64, BillingExtendData> target_billing_data  #交易数据对象id list
    2: required i32 target_type    #交易数据对象类型， 1:advId  2: campaignId
    255: optional base.Base Base
}

struct BillingExtendDataSaveResponse {
    1: required bool success    # 是否更新成功
    255: optional base.BaseResp BaseResp
}

struct BillingExtendDataQueryRequest {
    1: required list<i64> target_id_list    #交易数据对象id list
    2: required i32 target_type    #交易数据对象类型， 1:advId  2: campaignId
    255: optional base.Base Base
}

struct BillingExtendDataQueryResponse {
    1: map<i64, BillingExtendData> billing_extend_data_map    #key: target_id,  val: BillingExtendData
    255: optional base.BaseResp BaseResp
}

struct PayMethod {
    1: optional i32 advertisingType // 商务类型：品牌 1， 竞价 2， both 0
    2: optional i32 bizPlatform //目标区域：出海 1， 入海 2， both/default 0
    3: optional i32 businessLine // 业务线：TT/BC/Promote 等，
    4: required i32 payMethod // 参见PayMethodBillingEnum
    5: optional i32 accountPeriodValue // 发票回款日期 30/45/60
    6: optional i32 type // SPIDER(1), ACCOUNT_MASTER_DATA(2), BILL_TO_PARTY(3), ADV(4)
}

struct ApplyForAutoPayRequest {
    1: required i64 accountId // grep account id
    2: required list<PayMethod> payMethodList
    255: optional base.Base Base
}


struct ApplyForAutoPayResponse {
    255: optional base.BaseResp BaseResp // status code = 0 则成功，否则一律失败
}

struct ChangePayMethodForSSCustomerResponse {
    255: optional base.BaseResp BaseResp // status code = 0 则成功，否则一律失败
}

struct SpiderAccountNum {
    1: optional i64 id
    2: required i64 spiderId
    3: required i64 accountId
    4: required i32 accountNumType  // @see AccountNumType
    5: required string currencyCode
    6: required i32 status         # @see enums.CommonStatusEnum
    7: optional i32 version
    8: required i64 createTimeTimestamp
    9: required i64 modifyTimeTimestamp
    10: required string accountNum
}

enum OperateType {
    DELETE      = 1
    UPDATE      = 2
    INSERT      = 3
}

struct OperateSpiderAccountNumResponse {
    1: required i64 id

    255: optional base.BaseResp BaseResp
}

struct OperateSpiderAccountNumRequest {
    1: required OperateType operateType
    2: required SpiderAccountNum spiderAccountNum

    255: optional base.Base Base
}


struct CommonQuerySpiderAccountNumResponse {
    1: required list<SpiderAccountNum> spiderAccountNum

    255: optional base.BaseResp BaseResp
}

struct CommonQuerySpiderAccountNumRequest {
    1: optional i64 spider
    2: optional i64 accountId
    3: optional string currencyCode

    255: optional base.Base Base
}

struct SpiderSubjectRef {
    1: optional i64 id
    2: required i64 spiderId
    3: required i64 subjectId
    4: required string subjectName
    5: required string accountNum           # 拼接起来的accountNum
    6: required string address
    7: required string accountName
    8: required string accountBank
    9: required string legalRepr
    10: required string billingAddress
    11: required string bankAddress
    12: required string tax
    13: required i32 status         # @see enums.CommonStatusEnum
    14: optional i32 version
    15: required i64 createTimeTimestamp
    16: required i64 modifyTimeTimestamp
    17: required i64 creatorId
}

struct CommonQuerySpiderSubjectRefResponse {
    1: required list<SpiderSubjectRef> refs

    255: optional base.BaseResp BaseResp
}

struct CommonQuerySpiderSubjectRefRequest {
    1: optional list<i64> spiderIds
    2: optional i64 subjectId
    3: optional list<i64> subjectIdList

    255: optional base.Base Base
}

struct SpiderBase {
    1: optional i64 spiderId
    2: optional i32 businessLine    #  @see enums.BusinessLineEnum
    3: optional i32 advertisingType #  @see enums.AdvertisingTypeEnum
    4: optional i32 originSource    #  @see enums.OriginSourceEnum
    5: optional i64 subjectId
    6: optional i32 status          #  @see enums.CommonStatusEnum
}

struct Contact {
    1: required i32 contactType # @see enums.ContactTypeEnum
    2: optional string name
    3: optional string phone
    4: optional string email
    5: optional i64 employeeId
    6: optional string emailSuffix
}

struct Address {
    1: required i32 addressType // @see enums.AddressTypeEnum
    2: optional string level1AddressId
    3: optional string level2AddressId
    4: optional string level3AddressId
    5: optional string level4AddressId
    6: optional string sourceDetailAddress
    7: optional string detailAddress
    8: optional string postcode
    9: optional bool geo
    10: optional string  contractDetailAddress
}

struct AccountBank {
    1: optional string bankName         # 银行名称
    2: optional string bankAccountName  # 银行账号名称
    3: optional string bankAccountNum   # 银行账号
    4: optional string subAccountNum
    5: optional string swiftCode
    6: optional string abaCode
    7: optional string ibanCode
    8: optional string bicCode
}

struct BillToParty {
   1: optional i64 accountId                    // 3M account id
   2: optional i64 beId                         // beid
   3: optional i64 startDate                    // 毫秒时间戳 开始时间
   4: optional i64 endDate                      // 毫秒时间戳 结束时间
   5: optional i64 activeTime                   // 毫秒时间戳 最新生效时间
   6: optional map<string, string> taxNumberMap // 税号
   7: optional i32 status                       // @see enums.CommonStatusEnum
   8: optional i64 creatorId                    // 创建人
   9: optional list<Address> addressList        // 地址list
   10: optional list<Contact> contactList       // 联系人list
   11: optional i64 billToPartyId               // 主键id
   12: optional string beName                   // beid 对应 name
   13: optional bool useAccountInfo             // 是否使用的account 的信息 （联动）
   14: optional i32 periodDay                   // 帐期时间
   15: optional string businessName             // 商务名称
   16: optional bool primary                    // 主 bill to
}

struct AccountMasterData {
    1: required i64 accountId                 // 3M account id
    2: optional i32 type                               // 自助：account 非自助：contract @see enums.MasterDataTypeEnum
    3: optional map<string, string> taxNumberMap       // 税相关信息
    4: optional i32 sequentialLiability                // 代理商客户相关 -- 顺序责任制
    5: optional i32 projectType                        // @see enums.ProjectTypeEnum
    6: optional i64 creatorId                          // 合同创建人(包括系统)/前端页面的AMD创建人
    7: optional list<AccountBank> accountBankList    // 客户银行信息
    8: optional list<BillToParty> billToPartyList    // 开票对象
    9: optional list<Address> addressList            // 地址list
    10: optional list<Contact> contactList           // 联系人list
    11: optional i64 spiderId                        // 更新场景传
    12: optional list<spider_common.BillingOption>  billingOptions // 支付方式信息
}

struct Payment {
    1: optional i32 invoiceTimeLimits
    2: optional i32 invoicePeriodType   # @see enums.InvoicePeriodTypeEnum
}

struct Margin {
    1: optional i32 region
    2: optional i32 bizPlatform    # @see enums.BizPlatformEnum
    3: optional i32 marginResource # @see enums.MarginResourceEnum
    4: optional i32 marginUsage    # @see enums.MarginUsageEnum
    5: optional string marginValue
    6: optional i64 startDate // 毫秒时间戳
    7: optional i64 endDate // 毫秒时间戳
    8: optional i32 groupIndex
}

struct ExtendInfo {
    1: optional string poNumber
    2: optional i32 targetType; // @see enums.BillingExtendDataTargetTypeEnum ADV(1), CAMPAIGN(2), SPIDER(3),
}

struct Currency {
    1: required string currencyCode // USD,GBP这一类， BP自己转成id
}

struct SpiderAdvInfo {
    1: list<i64> advIdList
}

struct ContractInfo {
    1: i64 contractId;              // 合同id
    2: optional i64 startDate;      // 毫秒时间戳
    3: optional i64 endDate;        // 毫秒时间戳
    4: optional i32 contractType;   // 合同类型
    5: optional string serial;      // 合同编号
}

struct SpiderBO {
    1: optional SpiderBase spiderBase
    2: optional ContractInfo contractInfo
    3: optional list<AccountMasterData> accountMasterDataList
    4: optional list<PayMethod> payMethodList
    5: optional list<Currency> currencyList
    6: optional list<Margin> marginList
    7: optional Payment payment
    8: optional list<SpiderAccountNum> spiderAccountNumList
    9: optional ExtendInfo extendInfo
    10: optional SpiderAdvInfo spiderAdvInfo
    11: optional i64 spiderId
    12: optional Contact subjectContact
}

struct CreateSpiderRequest {
    1: required SpiderBase spiderBase // spider id不为空，则先删除相关记录，然后新建
    2: optional ContractInfo contractInfo
    3: optional list<AccountMasterData> accountMasterDataList
    4: optional list<PayMethod> payMethodList
    5: optional list<Currency> currencyList
    6: optional list<Margin> marginList
    7: optional Payment payment
    8: optional list<SpiderAccountNum> spiderAccountNumList
    9: optional ExtendInfo extendInfo
    10: optional SpiderAdvInfo spiderAdvInfo
    11: optional bool isSpl
    12: optional Contact subjectContact
    255: optional base.Base Base
}

struct CreateSpiderResponse {
    1: required i64 spiderId
    255: required base.BaseResp BaseResp
}

struct QuerySpiderRequest {
    1: required i64 spiderId
    255: optional base.Base Base
}

struct QuerySpiderResponse {
    1:  optional SpiderBO spiderBO
    255: required base.BaseResp BaseResp
}

struct BatchQuerySpiderRequest {
    1: optional list<i64> spiderIdList
    2: required list<i32> moduleList
    3: optional list<i32> statusList  // @see enums.CommonStatusEnum
    4: optional list<i64> contractIdList  // 通过合同id 查询 spiderIdList contractIdList 选一个list 查询，优先通过spiderIdList
    255: optional base.Base Base
}

struct BatchQuerySpiderResponse {
    1:  optional list<SpiderBO> spiderBOList
    255: required base.BaseResp BaseResp
}

enum ModuleEnum {
    SPIDER_BASE = 0 //指定字段更新
    ACCOUNT_MASTER_DATA = 1 // 指定字段更新
    PAY_METHOD = 2 // 直接新建替换
    CURRENCY = 3 // 直接新建替换
    MARGIN = 4 // 只新增不覆盖已有数据
    PAYMENT = 5 // 指定字段更新
    SPIDER_ACCOUNT_NUM = 6 // 直接新建替换
    SPIDER_ADV = 7 // spider id + adv id 指定更新
    SPIDER_EXTEND_INFO = 8
    SPIDER_CONTRACT_INFO = 9
    ADDRESS = 10 // 需明确address_type 进行更新（type已存在则update，否则新增）
    CONTACT = 11 // 需明确contact_type 进行更新（type已存在则update，否则新增）
    BILL_TO_PARTY = 12
    ACCOUNT_BANK = 13  // 直接新建替换
    SUBJECT_CONTACT = 100  // 主体联系人
}

//分模块更新
struct UpdateSpiderRequest {
    1: optional SpiderBase spiderBase // spiderId 非空， 指定字段更新
    2: optional ContractInfo contractInfo
    3: optional list<AccountMasterData> accountMasterDataList
    4: optional list<PayMethod> payMethodList
    5: optional list<Currency> currencyList
    6: optional list<Margin> marginList
    7: optional Payment payment
    8: optional list<SpiderAccountNum> spiderAccountNumList
    9: optional ExtendInfo extendInfo
    10: optional SpiderAdvInfo spiderAdvInfo
    11: required list<i32> updateModuleList
    12: list<AccountMasterData> accountMasterDataAddList // 新增客户信息
    255: optional base.Base Base
}

struct UpdateSpiderResponse {
    255: required base.BaseResp BaseResp
}

struct UpdateAccountMasterRequest {
    1: required AccountMasterData accountMasterData
    2: required list<i32> updateModuleList
    255: optional base.Base Base
}

struct UpdateAccountMasterResponse {
    255: required base.BaseResp BaseResp
}


struct SpiderStatus {
    1: required i64 spiderId
    2: required i32 status         # @see enums.CommonStatusEnum
}

struct UpdateSpiderStatusRequest {
    1: required map<i32, list<i64>> spiderStatusMap                 # key: @see enums.CommonStatusEnum, value: spiderIds
    2: optional map<i64, list<BillToParty>> spiderBillToPartyMap    # key: spiderId, value: BillToParty list
    255: optional base.Base Base
}

struct UpdateSpiderStatusResponse {
    255: required base.BaseResp BaseResp
}


struct SpiderInfo {
    1: SpiderBase spiderBase
    2: list<AccountMasterData> accountMasterDataList
    4: list<PayMethod> payMethodList
    5: list<Currency> currencyList
    6: list<Margin> marginList
    7: Payment payment
    8: list<SpiderAccountNum> spiderAccountNumList
    9: ExtendInfo extendInfo
    10: SpiderAdvInfo spiderAdvInfo
}

struct QueryCurrencyReq {
    1: optional list<i64> ids;
    2: optional list<string> codes;
    3: optional string lang;
    255: optional base.Base Base;
}

# 币种信息
struct CurrencyInfo {
    1: required i64 id;
    2: required string name;
    3: required string code;
    4: required string i18nCode;
    5: required i32 precisionType;
}

struct QueryCurrencyResp {
    1: required list<CurrencyInfo> currencyInfoList;
    255: required base.BaseResp BaseResp;
}

struct QueryCityReq {
    1: required list<i64> cityIds;
    255: optional base.Base Base;
}

# 城市地区信息
struct CityInfo {
    1: required i64 id;
    2: required i64 pId;
    3: required i32 level;
    4: required string name;
    5: required string isoCode;
    6: required string iso3code;
    7: required string en;
    8: required string code;
    9: required string i18nCode;
    10: required i64 geoId;
}

struct QueryCityResp {
    1: required list<CityInfo> cityInfoList;
    255: required base.BaseResp BaseResp;
}

struct QueryCountryReq {
    1: optional list<i64> ids;
    2: optional list<string> codes;
    3: optional string lang;
    255: optional base.Base Base;
}

# 国家信息
struct CountryInfo {
    1: required i64 id;
    2: required string name;
    3: required string code;
    4: required string i18nCode;
    5: required i64 cityId;
    6: required string timeZoneName;
    7: required double utcDeltaHours
}

struct QueryCountryResp {
    1: required list<CountryInfo> countryInfoList;
    255: required base.BaseResp BaseResp;
}


struct QuerySpiderBaseRequest {
    // 通过合同id查询
    1: optional list<i64> contractIdList;

    // 通过spiderId查询
    2: optional list<i64> spiderIdList;

    // 通过account id查询
    3: optional list<i64> accountIdList;

    255: optional base.Base Base;
}

struct QuerySpiderBaseResponse {
    1: required map<i64, SpiderBase> spiderBaseMap;
    255: required base.BaseResp BaseResp;
}

struct QueryAccountMasterDataRequest {
    1: required list<i64> accountIds;
    2: required i32 masterDataType;
    255: optional base.Base Base
}

struct QueryAccountMasterDataResponse {
    1: required map<i64, list<AccountMasterData>> accountMasterDataMap
    255: required base.BaseResp BaseResp
}

struct AccountSubAccountNum {
    1: optional i64 id
    2: required i64 accountId           # 客户accountId
    3: optional i32 subjectId
    4: required i64 subAccountId        # 子账号ID
    5: required i32 status         # @see enums.CommonStatusEnum
    6: optional i32 version
}

struct QueryAccountSubAccountNumByAccountIdRequest {
    1: optional i64 accountId

    255: optional base.Base Base
}

struct QueryAccountSubAccountNumByAccountIdResponse {
    1: optional list<AccountSubAccountNum> subAccountNums

    255: optional base.BaseResp BaseResp
}

struct QueryUniqueAccountPayerIdResponse {
    1: required list<AccountSubAccountNum> subAccountNums

    255: optional base.BaseResp BaseResp
}

struct QueryUniqueAccountPayerIdRequest {
    1: required i64 accountId
    2: required i64 subjectId
    3: required i32 binId

    255: optional base.Base Base
}

struct CusWithSubAccountNum {
    1: required i64 accountId
    2: required string subAccountNum
}

struct QueryBySubAccountNumResponse {
    1: required list<CusWithSubAccountNum> cusWithSubAccountNums

    255: optional base.BaseResp BaseResp
}

struct QueryBySubAccountNumRequest {
    1: required string subAccountNum
    2: i16 isStrLike

    255: optional base.Base Base
}

struct CommonQueryAccountSubAccountNumsResponse {
    1: required list<AccountSubAccountNum> subAccountNums

    255: optional base.BaseResp BaseResp
}

struct CommonQueryAccountSubAccountNumsRequest {
    1: optional list<i64> accountIds

    253: optional i32 page = 1
    254: optional i32 limit = 100
    255: optional base.Base Base
}

struct SaveAccountSubAccountNumResponse {
    1: required i64 id

    255: optional base.BaseResp BaseResp
}

struct SaveAccountSubAccountNumRequest {
    1: required AccountSubAccountNum accountSubAccountNum
    2: required OperateType operateType

    255: optional base.Base Base
}

struct PayerIdInfo {
    1: optional string accountNum               # 账号
    2: optional i16 type                        # 账号类型 1-主账号 2-子账号
    3: optional list<string> currencyCodes      # 支持币种code列表
    4: optional i64 subjectId                   # 主体ID
    5: optional string subjectName              # 主体名字
}

struct CusSubAccountItem {
    1: i64 accountId                    # 客户id
    2: list<PayerIdInfo> subAccountNums
}

struct QuerySubAccountByGrepAccountListResponse {
    1: required list<CusSubAccountItem> cusSubAccounts

    255: optional base.BaseResp BaseResp
}

struct QueryPayerIdsRequest {
    1: required list<i64> accountIds    # 客户ID
    2: optional i32 type         # 1-只查询子账号 2-查询结果包含主账号和子账号

    255: optional base.Base Base
}

struct AccountPayerIdItem {
    1: optional list<PayerIdInfo> payerIds  # 客户的支付账号
    2: optional i64 accountId              # 客户ID
}

struct QueryPayerIdsResponse {
    1: optional list<AccountPayerIdItem> accountPayerIds

    255: optional base.BaseResp BaseResp
}


// 查询有效合同支付方式
struct QueryPayMethodRequest {
    1: required i64 accountId;       // crm account id
    2: optional i64 contractId;      // 合同id
    3: optional string innerDate;       // 0时区时间 "yyyy-MM-dd" 格式。(要求合同开始结束时间包含该时间）
    4: optional list<i32> contractTypeList; // 合同类型
    5: optional string currencyCode; // 币种code
    6: optional i32 advertisingType; // 广告主类型：0：全部 1：品牌，2：竞价
    7: optional i32 businessScope;   // 广告平台：0：全部 1：出海，2：入海
    8: optional i32 bizLine;         // 业务线：0：全部 1：ad，2：千川
    255: optional base.Base Base;
}

struct PayMethodItem {
    1: required i32 businessScope;          // 业务范围，出入海，非空（维度信息）
    2: required i32 advertisingType;        // 广告类型，品牌竞价，非空（维度信息）
    3: required i32 bizLine;                // 业务线，1：ad，2：千川
    4: optional i32 payMethod;              // 支付方式，0：月账单(授信)，1：autoPay，2：预付
    5: optional i32 accountPeriodValue;     // 回款天数，支付方式为授信时返回
    6: optional i32 payMethodType;          // @see PayMethodTypeEnum 1 prePay ,2 autoPay , 3 mi
    7: optional string payMethodName;       // 支付方式名称
    8: optional i32 status;                 // 支付方式状态，1:生效，2:草稿态，3:审批中，4:废弃
}

struct ContractPayMethodItem {
    1: required i64 contractId;              // 合同id
    2: optional string startDate;              // 开始时间毫秒时间戳
    3: optional string endDate;                // 结束时间毫秒时间戳
    4: required list<PayMethodItem> payMethodList;  // 支付方式
}

struct QueryPayMethodResponse {
    1: optional list<ContractPayMethodItem> payMethodList;  // 合同支付方式list
    255: optional base.BaseResp BaseResp;           // status code = 0 则成功，否则一律失败
}

// 查询合同支付方式
struct QueryPayMethodRequestV2 {
    1: optional i64 accountId;       // crm account id
    2: optional i64 contractId;      // 合同id
    3: optional string currencyCode; // 币种code
    4: required i32 advertisingType; // 广告主类型：0：全部 1：品牌，2：竞价
    5: required i32 businessScope;   // 广告平台：0：全部 1：出海，2：入海
    6: required i32 bizLine;         // 业务线：0：全部 1：ad，2：千川
    7: optional i64 advId;           // 如果没有account id，则使用ad account id查询
    8: optional i64 bcId;            // bc id
    9: required i64 sliceTime;       // 查询切片时间，校验合同有效期
    10: optional i32 queryType;      // see@enums.QueryType，如果传了sliceTime，该参数不生效
    11: optional bool forceMaster;           // 用adv查询需要查询结算关系，结算关系查询是否要读主库，默认从库，主库性能可能会变差，需要走一道CRM兜底
    254: optional string lang       // 多语言 默认 en
    255: optional base.Base Base;
}

struct ContractPayMethodItemV2 {
    1: required i64 contractId;                     // 合同id
    2: required i64 subjectId;                      // 我方主体id
    3: optional string billingAddressId;            // 交易地址id
    4: optional string countryCode;                 // 国家code
    5: required list<PayMethodItem> payMethodList;  // 支付方式
}

struct QueryPayMethodResponseV2 {
    1: optional ContractPayMethodItemV2 payMethod;  // 合同支付方式
    255: optional base.BaseResp BaseResp;           // status code = 0 则成功，否则一律失败
}

struct QueryBillToRequest {
    1: optional list<i64> contractIdList;
    2: optional i64 spiderId;
    3: optional i64 accountId;
    4: optional list<i64>  billToAccountIdList;
    5: optional list<i32> statusList;
    6: optional i64 date;
    7: optional list<i64> beIdList;
    8: optional bool needBeName;
    255: optional base.Base Base;
}

struct QueryBillToByIdRequest {
    1: optional list<i64> billToPartyIdList;
    2: optional bool needBeName;
    255: optional base.Base Base;
}

struct BillToPartyInfo {
    1: optional i64 spiderId
    2: optional i64 contractId
    3: optional i64 accountId
    4: optional BillToParty billToParty
}

struct QueryBillToResponse {
    1: optional list<BillToPartyInfo> billToPartyList;
    255: optional base.BaseResp BaseResp;           // status code = 0 则成功，否则一律失败
}


struct CreateSpiderContractDiffReq {
    1: required i64 spiderId;           // spider id
    2: optional i64 contractId;         // 合同id
    3: required string diffJson;        // 合同和spider查询diff结果
    255: optional base.Base Base;
}

# 新建，返回id场景
struct CreateResp {
    1: optional i64 id;                     // 返回记录id
    255: required base.BaseResp BaseResp;   // status code = 0 则成功，否则一律失败
}

struct DeleteSpiderContractDiffReq {
    1: required list<i64> contractIds;         // 合同id list
    255: optional base.Base Base;
}

// 通过accountId查询
struct QueryByAccountIdRequest {
    1: required i64 accountId;        // crm account id
    254: optional string lang;        // 多语言，默认：en
    255: optional base.Base Base;
}

struct QueryContactInfoResponse {
    1: optional string contactName;
    2: optional string phoneNum;
    3: optional string contactEmail;
    255: required base.BaseResp BaseResp;
}

// 我方信息
struct SubjectInfo {
    1: optional i64 subjectId;             // 我方签约主体id
    2: optional string subjectName;        // 我方签约主体名称
    3: optional string bankAccountName;    // 我方签约主体-账户名称
    4: optional string billingAddress;     // 我方签约主体-账单邮寄地址
    5: optional string accountBank;        // 我方签约主体-开户银行
    6: optional string legalRepr;          // 我方签约主体-法人名称
    7: optional string countryCode;        // 国家code
}

// 签约信息
struct SignatureInfo {
    1: optional string detailAddress;              // 用户手填地址
    2: optional string contractDetailAddress;      // 合同格式的详细地址
    3: optional string billingAddressId;           // billing region（Country-State-County-City）
    4: optional i64 level1Id;                      // 一级地区ID（Country、State、County、City）
    5: optional i64 level2Id;                      // 二级地区ID（Country、State、County、City）
    6: optional i64 level3Id;                      // 三级地区ID（Country、State、County、City）
    7: optional i64 level4Id;                      // 四级地区ID（Country、State、County、City）
    8: optional string postcode;                   // 邮编
    9: optional double timeZone;                   // 时区
    10: optional map<string, string> taxNumberMap; // 税号
    11: optional i32 sequentialLiability           // 代理商客户相关 -- 顺序责任制
    12: optional i64 level1GeoId;                      // 一级地区GeoID（Country、State、County、City）
    13: optional i64 level2GeoId;                      // 二级地区GeoID（Country、State、County、City）
    14: optional i64 level3GeoId;                      // 三级地区GeoID（Country、State、County、City）
    15: optional i64 level4GeoId;                      // 四级地区GeoID（Country、State、County、City）
}

struct QueryAccountInfoResponse {
    1: optional SubjectInfo subjectInfo;        // 我方主体信息
    2: optional SignatureInfo signatureInfo;    // 签约信息
    3: optional list<Contact> contacts;         // 联系人list
    4: optional map<string, string> extMap;     // 扩展信息，如：韩国主体信息
    255: required base.BaseResp BaseResp;
}

struct QueryMarginRequest {
    1: required i64 contractId
    2: required i64 activeDate
    255: optional base.Base Base
}

struct QueryMarginByContractIdListRequest {
    1: required list<i64> contractIdList
    2: required i64 activeDate
    255: optional base.Base Base
}

struct QueryLatestMarginRequest {
    1: required list<i64> contractIdList
    255: optional base.Base Base
}

struct QueryMarginResponse {
    1: optional map<i64,list<Margin>> contract2MarginMap   // contractId 2 marginlist
    255: required base.BaseResp BaseResp;   // status code = 0 则成功，否则一律失败
}

struct QuerySpiderContractRelationRequest {
    1: required list<i64> contractIdList
    255: optional base.Base Base
}

struct SpiderContractRelation {
    1: required i64 spiderId
    2: required i64 contractId
}

struct QuerySpiderContractRelationResponse {
    1: optional list<SpiderContractRelation> spiderContractRelationList   // contractId 2 marginlist
    255: required base.BaseResp BaseResp;   // status code = 0 则成功，否则一律失败
}

struct CommonQueryAccountRequest {
    1: optional list<i64> spiderIdList          # spiderIdList
    2: optional list<i64> accountIdList         # accountIdList
    3: optional list<i32> moduleEnumList        # 查询的数据类型
    4: optional list<i64> contractIdList        # contractIdList (contractId 和 spiderId 只有一个生效，优先contractId）
    255: optional base.Base Base
}

struct CommonQueryAccountResponse {
    1:  optional list<AccountMasterData> accountMasterDataList
    2:  optional list<SpiderContractRelation> spiderContractRelationList
    255: required base.BaseResp BaseResp
}

struct QuerySpiderBaseByAdvIdRequest {
    1: required list<i64> advIdList;   # 通过advId 查询 spider base
    255: optional base.Base Base
}

struct QuerySpiderBaseByAdvIdResponse {
    1: optional map<i64,list<SpiderBase>> adv2SpiderInfoMap
    255: required base.BaseResp BaseResp
}

struct DeleteSpiderRequest {
    1: optional i64 contractId  // 通过合同id
    2: optional i64 spiderId     // 通过spiderId,两个条件仅取其一,优先取spiderId
    255: optional base.Base Base;
}

struct DeleteSpiderResponse {
    255: required base.BaseResp BaseResp
}

struct UnbindAccountRequest {
    1: required i64 contractId  // 解绑合同id
    2: required i64 accountId   // 解绑accountId
    255: optional base.Base Base;
}

struct AccountMasterDataInfo {
    1: required i64 accountId;                          // 3M account id
    2: required i64 spiderId;                           // spider id
    3: required i32 type;                               // 自助：account 非自助：contract @see enums.MasterDataTypeEnum
    4: optional map<string, string> taxNumberMap;       // 税相关信息
    5: required i32 sequentialLiability;                // 顺序责任制，代理商是否连带责任，0：没有，1：true；2：false；
    6: required i32 projectType;                        // @see enums.ProjectTypeEnum
    7: required i32 enablePayerId;                      // 是否启用子账号 0-否 1-是
}

struct QueryByAccountIdListRequest {
    1: required list<i64> accountIds;
    255: optional base.Base Base;
}

struct QueryAccountMasterInfoResponse {
    1: optional list<AccountMasterDataInfo> accountMasterDataInfoList;
    255: required base.BaseResp BaseResp;
}

struct UpdateSequentialLiabilityRequest {
    1: required i64 accountId;                          // 3M account id
    2: required i32 sequentialLiability;                // 顺序责任制，代理商是否连带责任，0：没有，1：true；2：false；
    255: optional base.Base Base;
}

struct QueryTaxAuditRejectReasonRequest {
    1: required i64 accountId
    2: optional string lang
    255: optional base.Base Base
}
struct QueryTaxAuditRejectReasonResponse {
    1: optional string taxAuditRejectReson;
    255: required base.BaseResp BaseResp;
}

struct SliceSpiderInfoRequest {
    1: optional i64 contractId;         // 合同id
    2: optional i64 accountId;          // 3M account id
    3: optional i64 spiderSliceTime;    // 查询spider的切片的时间点
    4: optional i64 advId;              // 如果没有account id，则使用ad account id查询
    5: optional i32 queryType;          // see@enums.QueryType，如果有spiderSliceTime，则优先用spiderSliceTime去查询，查不到则根据queryType查询
    6: optional bool forceMaster;       // 用adv查询需要查询结算关系，结算关系查询是否要读主库，默认从库，主库性能可能会变差，需要走一道CRM兜底
    7: optional i32 sliceQueryType;     // see@enums.QueryType，支持切片查询时，按照queryType过滤筛选合同

    255: optional base.Base Base;
}

struct SliceSpiderInfoWithContractTypeRequest {
    1: required i64 contractId;         // 合同id
    2: required i32 contractType;       // 合同类型
    3: optional i64 accountId;          // 3M account id
    4: optional i64 spiderSliceTime;    // 查询spider的切片的时间点
    255: optional base.Base Base;
}

// 税号地址信息
struct AccountTaxAndAddressInfo {
    1: required i64 accountId;                     // 3M account id
    2: optional string detailAddress;              // 详细地址信息
    3: optional string billingAddressId;           // billing region（Country-State-County-City）
    4: optional i64 level1Id;                      // 一级地区ID（Country、State、County、City）
    5: optional i64 level2Id;                      // 二级地区ID（Country、State、County、City）
    6: optional i64 level3Id;                      // 三级地区ID（Country、State、County、City）
    7: optional i64 level4Id;                      // 四级地区ID（Country、State、County、City）
    8: optional string postcode;                   // 邮编
    9: optional map<string, string> taxNumberMap;  // 税号
    10: optional i32 sequentialLiability           // 代理商客户相关 -- 顺序责任制
    11: optional Contact contact                                        // 合同联系人，如果没有取发票联系人
    12: optional string billingAddress;                // billingAddressId对应的名称（Country-State-County-City）
}

// spider信息：主体、税种、地址信息等
struct SpiderInfoResponse {
    1: optional i64 spiderId;                                           // spiderId
    2: optional i32 businessLine;                                       // 业务线：TT/BC/Promote 等
    3: optional i32 advertisingType;                                    // 广告类型，品牌竞价，非空（维度信息）
    4: optional i32 originSource;                                       // 0 B端， 1 C端
    6: optional i64 subjectId;                                          // 我方主体id
    7: optional string subjectCountryCode;                              // 我方主体国家
    8: optional ContractInfo contractInfo;                              // 合同信息
    9: optional list<AccountTaxAndAddressInfo> taxAndAddressInfoList;   // 税号地址信息
    10: optional i64 advId;                                             // promote 业务场景，支持advId返回
    255: required base.BaseResp BaseResp;
}

struct QueryAdvAccountSalesRequest {
    1: optional list<i64> advIdList; # advIdList
    2: optional i64 contractId;      # 合同id 选传，需要跟进销售/交易owner需要传
    3: optional i64 accountId;       # accountId
    255: optional base.Base Base;
}

struct AccountInfo {
    1: optional i64 accountId;
    2: optional i64 salesId;
    3: optional string saleName;
    4: optional i64 saleDepartmentId;
    5: optional string saleDepartmentName;
    6: optional string accountName;
}

struct AdvAccountInfo {
    1: optional i64 advId;
    2: optional AccountInfo directAccountInfo;
    3: optional AccountInfo agencyAccountInfo;
}

struct QueryAdvAccountSalesResponse {
    1: optional i64 contractId;   # 合同id
    2: optional i64 accountId;    # accountId
    3: optional i64 txSalesId;    # 交易跟进销售
    4: optional i64 transactionOwner; # 交易owner
    5: optional list<AdvAccountInfo> advAccountInfoList; # advAccount 销售信息
    6: optional i64 txSalesDepId;    # 交易跟进销售部门ID
    7: optional i64 transactionOwnerDepId; # 交易owner部门ID
    255: required base.BaseResp BaseResp;
}

struct SaveBCBankInfoRequest {
    1: required i64 bcId;                # bcId
    2: optional AccountBank accountBank  # 银行信息
    3: optional i64 operatorId           # 操作人
    255: optional base.Base Base;
}

struct SaveBCBankInfoResponse {
    1: optional i64 bankId;
    255: required base.BaseResp BaseResp;
}

struct BatchQueryByBCIdRequest {
    1: required list<i64> bcIdList;
    255: optional base.Base Base;
}

struct BatchQueryBankInfoByBCResponse {
    1: optional map<i64,AccountBank> bc2BankInfoMap;
    255: required base.BaseResp BaseResp;
}

struct QueryBankInfoByAccountIdResponse {
    1: optional map<i64,AccountBank> bc2BankInfoMap;
    255: required base.BaseResp BaseResp;
}

struct AdvQueryInfo {
    1: required i64 advId;
    2: optional PayMethodItem payMethod; // 指定支付方式进行查询
    3: optional string currencyCode; // 指定币种进行查询 USD/JPY等
    4: optional i32 bizLine; // 指定合同业务线进行查询 @see BusinessLineEnum
    5: optional i64 accountId; // adv/bc 对应的有效 account id
}
struct BatchQueryBillingInfoByAdvIdRequest {
    1: required list<AdvQueryInfo> advInfoList; // 批量查询 adv每次不超过50个
    2: optional string lang; // 语言，默认en
    255: optional base.Base Base;
}

struct BillingAddressInfo {
    1: optional string completeBillingAddress   // 合同上完整的开票地址, 拼接后的开票地址（ sourceBillingAddress[,city][,county][,state][,country][,postcode]）
    2: optional string billingCountryCode       // 开票国家Code US/JP等
    3: optional i64 level1GeoId;                // 一级地区ID（Country、State、[County]、City）
    4: optional i64 level2GeoId;                // 二级地区ID（Country、State、[County]、City）
    5: optional i64 level3GeoId;                // 三级地区ID（Country、State、[County]、City）
    6: optional i64 level4GeoId;                // 四级地区ID（Country、State、[County]、City）
    7: optional string sourceBillingAddress   // 用户填写的开票地址
    8: optional string postcode;
}

struct BillingInfo {
    1: optional i64 contractId;
    2: optional i64 spiderId;
    3: optional map<string, string> taxMap              // 合同上的税相关信息, key由税种配置平台统一决定
    4: optional BillingAddressInfo billingAddressInfo   // 合同上开票地址信息
    5: optional list<PayMethodItem> payMethodList       // 合同上支付方式，如果入参指定了支付方式查询条件，则返回指定的
    6: optional i64 subjectId                           // 合同主体id
    7: optional bool existMultipleContract              // 是否存在多份符合入参场景的合同，若存在，代表当前合同信息是结束时间最晚的那一份合同
}

struct BatchQueryBillingInfoResponse {
    1: optional map<i64, BillingInfo> billingInfoMap; // key 为入参时使用的查询id
    255: required base.BaseResp BaseResp;
}

struct TransferAdvRequest {
    1: required list<i64> advIdList; // 需要执行转户的adv
    2: optional i64 originalBCId; // TCM 场景忽略
    3: optional i64 targetBCId; // TCM 场景必填
    4: optional i64 originalAccountId; // TCM 场景忽略
    5: optional i64 targetAccountId; // TCM 场景忽略
    6: optional i64 operatorId; // TCM 场景忽略
    7: optional map<i64, string> effectiveDateMap; // 广告主所在时区时间 yyyy-mm-dd, 若不填则默认发起当日
    8: required i32 transferScenario; // @see TransferScenarioEnum.TCM_TO_TTAM = 1
    9: optional map<i64, i64> relatedAdvMapping;//tcm关联的ttam advid，tcm:ttam
    10: optional map<i64, string> timezoneMap; // TCM广告主所在时区
    255: optional base.Base Base;
}

struct QueryBankInfoByAccountResponse {
    1: optional i64 accountId;
    2: optional list<AccountBank> accountBankList;
    3: optional map<i64,AccountBank> bc2BankInfoMap;
    255: required base.BaseResp BaseResp;
}

struct AdvertiserInfo {
    1: required i64 advId;                              // 账号ID
    2: optional string company;                         // 公司名称
    3: optional string name;                            // 广告主名称
    4: optional string currency;                        // 广告主币种编码，如JPY/INR/GBP/HKD等
    5: optional string timezone;                        // 广告主时区 Etc/GMT+0
    6: optional i16 role;                               // 枚举详见@see enums.AdvertiserRole, 用户身份
    7: optional i16 origin;                             // 举详见@see enums.AdvertiserOrigin，广告主来源
    8: optional i16 status;                             // 枚举详见@see enums.AdvertiserStatus，广告主状态，0-已禁用，1-待审核，2-待邮箱验证，3-审核失败/可再次申请，4-已审核，5-CRM审核失败/最终状态，6-修改审核，7-修改审核失败，8-惩罚限制，9-等待CRM审核，10-资质待提交，12-SMB客户待合同生效，13-SMB广告主待缴纳开户费，14-待对公验证
    9: optional i64 accountId;                          // 客户ID, gcrm 唯一公司实体
    10: optional i16 advType;                           // 广告主投放类型，详见@see enums.AdvAccountType
    11: optional string country;                        // 广告主注册地，默认值为us，ISO 3166-2相应代码，例如Mexico => MX
    12: optional string addressDetail;                  // 广告主开票地址
    13: optional string contacter;                      // 联系人
    14: optional string contacterEmail;                 // 联系人邮箱
    15: optional string contacterTelephone;             // 联系人电话
    16: optional map<string, string> taxMap             // 广告主税号数据，包含tax_id
    17: optional i64 taxIdentity;                       // 广告主税务身份 参考@see enums.AdvertiserTaxType
}

struct QueryAdvInfoResponse {
    1: optional AdvertiserInfo advInfo

    255: required base.BaseResp BaseResp;
}

struct QueryAdvInfoByAdvIdRequest {
    1: required i64 advId;
    2: optional i64 operatorId;
    3: optional bool needSensitiveInfo;

    255: optional base.Base Base;
}

struct QueryAccountResponse {
    1: optional list<AccountInfo> accountInfoList;
    255: required base.BaseResp BaseResp;
}

struct QueryAccountByBankInfoRequest {
    1: optional AccountBank accountBank;
    255: optional base.Base Base;
}

struct SaveAccountNameRequest {
    1: required i64 accountId;
    2: optional string accountName;
    255: optional base.Base Base;
}

# 通用 保存/更新 返回类
struct CommonSaveResponse {
    1: optional i64 id;
  255: required base.BaseResp BaseResp;
}

struct AddressInfo {
    1: optional string billingAddressId;        // billing region（Country-State-County-City）
    2: optional string detailAddress;           // 详细地址信息
    3: optional string postcode;                // 邮编
    4: optional string completeBillingAddress;  // 合同上完整的开票地址
    5: optional string countryCode;             // 国家Code US/JP等
    6: optional i64 level1GeoId;                // 一级地区ID（Country、State、[County]、City）
    7: optional i64 level2GeoId;                // 二级地区ID（Country、State、[County]、City）
    8: optional i64 level3GeoId;                // 三级地区ID（Country、State、[County]、City）
    9: optional i64 level4GeoId;                // 四级地区ID（Country、State、[County]、City）
    10: optional string level1Name;
    11: optional string level2Name;
    12: optional string level3Name;
    13: optional string level4Name;
}

struct QueryAddressInfoResponse {
    1: optional list<AddressInfo> addressList;
    255: required base.BaseResp BaseResp;
}

struct DebugRequest {       // 仅供主数据内部使用
    1: i64 recordId;        //转户表主键id
    2: bool needTransfer;
    3: string taskPsm;
    4: string env;
    5: i64 callerRequestId;
    6: i64 contractId;
    255: optional base.Base Base;
}

struct DebugResponse {
    255: required base.BaseResp BaseResp;
}

struct QuerySliceSubjectResponse {
    1: optional SubjectInfo subject;        // 主体信息
    255: required base.BaseResp BaseResp;
}

struct QuerySlicePayMethodResponse {
    1: optional PayMethodItem overseaBid;                // 出海竞价
    2: optional PayMethodItem overseaBrand;              // 出海品牌
    3: optional PayMethodItem domesticBid;               // 入海竞价
    4: optional PayMethodItem domesticBrand;             // 入海品牌
    5: optional PayMethodItem shoppingAdsOverseaBid;     // 千川出海竞价
    6: optional PayMethodItem shoppingAdsOverseaBrand;   // 千川出海品牌
    7: optional PayMethodItem shoppingAdsDomesticBid;    // 千川入海竞价
    8: optional PayMethodItem shoppingAdsDomesticBrand;  // 千川入海品牌
    255: required base.BaseResp BaseResp;
}

struct BaseIdRequest {
    1: optional i64 contractId;
    2: optional i64 accountId;
    255: optional base.Base Base;
}

struct OriginSourceResponse {
     1: optional i32 originSource;
     255: required base.BaseResp BaseResp;
}

struct QueryContractInfoByAdvIdResponse {
    1: optional i64 contractId
    2: optional i64 accountId;
    3: optional i64 subjectId
    4: optional string subject_name
    5: optional string serial
    255: required base.BaseResp BaseResp;
}

struct QueryByContractIdsRequest {
    1: optional list<i64> contractIds;              // 优先使用合同ID查询
    2: optional list<i64> accountIds;               // 次优用accountId查询
    3: optional list<i64> advIds;                   // 再次优用ad accountId查询
    4: optional i32 queryType;                      // see@enums.QueryType
    5: optional bool forceMaster;                   // 用adv查询需要查询结算关系，结算关系查询是否要读主库，默认从库，主库性能可能会变差

    255: optional base.Base Base;
}

// spider信息：主体、税种、地址信息等
struct SpiderBillingInfo {
    1: optional i64 spiderId;                                           // spiderId
    2: optional i32 businessLine;                                       // 业务线：TT/BC/Promote 等
    3: optional i32 advertisingType;                                    // 广告类型，品牌竞价，非空（维度信息）
    4: optional i32 originSource;                                       // 0 B端， 1 C端
    6: optional i64 subjectId;                                          // 我方主体id
    7: optional string subjectCountryCode;                              // 我方主体国家
    8: optional ContractInfo contractInfo;                              // 合同信息
    9: optional list<AccountTaxAndAddressInfo> taxAndAddressInfoList;   // 税号地址信息
    10: optional i64 advId;                                             // promote 业务场景，支持advId返回
}

struct BatchSpiderBillingInfoResponse {
    1: optional map<i64, SpiderBillingInfo> billingInfoMap;         // key: 请求的id，account/contract/adv
    255: required base.BaseResp BaseResp;
}

struct QueryContractIdByCountryIdRequest {
    1: required i64 countryId;      // 国家id: billingAddressId的一级id
    2: optional i64 minId;          // 分页查询，最小的id
    3: optional i32 limit;          // 分页size，不超过1000
    255: optional base.Base Base;
}

struct QueryContractIdByCountryIdResponse {
    1: optional list<SpiderContractRelation> itemList;      // 合同id信息
    2: optional i64 maxId;                                  // 分页ID：查询性能优化ID
    3: optional bool hasNext;                               // 是否还有下一页
    255: required base.BaseResp BaseResp;
}

// 查询合同主体国家信息
struct QuerySubjectCountryRequest {
    1: required i64 advId;            // 广告主id
    2: optional string currencyCode;  // 币种code：存在币种则筛选，否则返回全量币种
    255: optional base.Base Base;
}

// 查询合同主体国家信息
struct QuerySubjectCountryResponse {
    1: optional i64 subjectId;                                          // 我方主体id
    2: optional string subjectName;                                     // 我方主体name
    3: optional string subjectCountryCode;                              // 我方主体国家
    4: optional ContractInfo contractInfo;                              // 合同信息
    5: optional list<string> currencyCodes;                             // 支持币种code
    255: required base.BaseResp BaseResp;
}

struct QueryPayReadyReqeust {
    1: required list<i64> idList;
    2: required i32 idType; // 1 adv , 4 bc
    255: optional base.Base Base;
}

struct QueryPayReadyResponse {
    1: optional map<i64, bool> payMethodReadyMap;  # adv/bc 2 bool
    255: optional base.BaseResp BaseResp;
}


struct QueryContractForReconRequest {
    1: required i64 accountId
    2: required list<i64> dates                    // 时间点
    3: required i32 businessScope           // 广告平台：0：全部 1：出海，2：入海
    4: required string currencyCode;        // 币种编码
    5: optional i32 payMethod;              // 支付方式，1预付 2autopay 3mi

    255: optional base.Base Base
}

struct ReconContractInfo {
    1: required i64 contractId
    2: optional i64 date
    3: optional i32 contractType
}

struct QueryContractForReconResponse{
    1: optional list<ReconContractInfo> contracts   // 各个时间的合同信息

    255: optional base.BaseResp BaseResp // status code = 0 则成功，否则一律失败
}

struct QueryBillingInfoResponse {
    1: optional bool checkResult;                   // billing info是否完整，true：完整，false：不完整
    2: optional string remark;                      // 备注，说明信息不完整的信息
    3: optional SpiderBillingInfo billingInfo;      // billing info 辅助问题排查的【预留字段，部分信息未实现，使用需要check】
    255: required base.BaseResp BaseResp;
}

struct ChangeAccountRequest {
    1: required AccountMasterData accountMasterData;
    2: required i64 originAccountId;
}

struct QueryBillingInfoByIdRequest {
    1: required i64 id;               // bc id
    2: required i32 idType;           // 1 adv 2 bc 3 account
    3: optional list<i32> moduleList; // 需要查询的信息，不传默认全查 1 billing地址 2 税号信息 3 支付方式
    4: optional bool requireValidation; // 默认false，如果需要对模块信息进行准确性验证，填写true
    5: optional i32 scenario   //0-default 1-虚客 2-api虚客
    253: optional map<string, string> extraInfoMap; // "billingAccountId":""
    254: optional string lang;        // 多语言，默认：en
    255: optional base.Base Base;
}

struct TaxInfo {
    1: optional map<string,string> taxNumber; //做多余KEY的过滤。比如欧洲只有vat,东南亚只有tax_id
    2: optional i32 taxIdentity;
    3: optional i32 taxStatus;
    4: optional string taxStatusExplanation;  // 如果审核拒绝，返回拒绝原因
    5: optional i64 taxAuditTime;  //税号最近一次审核时间，对于部分存量数据，taxAuditTime=0
    6: optional i64 firstRejectTime; //税号第一次审核失败的时间
}

// 用于对外返回查询到的支付方式
struct BillingOptionOutputInfo {
    1: optional list<spider_common.BillingOption> billingOptionList;  // 按序优先返回广告出海竞价维度支付方式
}

struct QueryBillingInfoByIdResponse {
    1: optional map<i32, bool> completenessCheckMap; // requireValidation = false时，此map仅判断信息是否存在；requireValidation = true时，判断信息是否存在且通过校验； key = module id (1 billing地址 2 税号信息 3 支付方式)， value = true/false
    2: optional BillingAddressInfo billingAddressInfo;
    3: optional TaxInfo taxInfo;
    4: optional BillingOptionOutputInfo billingOptionOutputInfo;
    5: optional ContactInfo contactInfo;
    255: required base.BaseResp BaseResp;
}

struct SharkParam {
    1: optional string event; // shark 事件码
    2: required string sharkParamMap // shark 参数，json map 类型
}

struct BillingOptionInputInfo { // 用于外部选择支付方式
    1: list<spider_common.BillingOption> billingOptionList;
    2: list<SharkParam> sharkParamList; // 支付方式选择涉及与风控的交互，需要透传数据
    3: i64 userId; // 支付方式选择涉及与风控的交互，需要透传数据
    4: string fundRiskParam;
}

struct ContactInfo {
    1: optional string contactName;
    2: optional string contactPhone;
    3: optional string contactEmail;
}

struct SaveBillingRelatedInfoByIdRequest {
    1: required i64 id;               // bc id
    2: required i32 idType;           // 1 adv 2 bc 3 account
    3: optional list<i32> moduleList;  // 1 billing地址 2 税号信息 3 支付方式
    4: optional BillingAddressInfo address;
    5: optional TaxInfo taxInfo;
    6: optional BillingOptionInputInfo billingOptionInputInfo;
    7: optional ContactInfo contactInfo;
    8: optional i32 scenario   //0-default 1-虚客 2-api虚客
    253: optional map<string, string> extraInfoMap; //额外信息，比如{"company_name":"nike"}
    254: optional string lang;        // 多语言，默认：en
    255: optional base.Base Base;
}


struct SaveBillingRelatedInfoByIdResponse {
    1: optional list<i32> errorCodeList // 业务逻辑失败原因
    255: required base.BaseResp BaseResp; // 仅表示调用是否成功
}

struct BillingOptionLogItem {
    1: required i64 accountId;
    2: optional i64 createTime;
    3: optional i64 approvalTime;
    4: optional i64 activeTime;
    5: optional i64 operatorId;
    6: optional i32 businessScenario;
    7: optional list<PayMethod> payMethodList;
    8: optional map<string, string> extMap;
    9: optional bool selfContract;
}

struct BillingOptionLogRequest {
    1: optional list<BillingOptionLogItem> logList;
    2: optional i32 initType;
    3: optional list<i64> accountIds;
    254: optional string lang;                              // 语言标识，如：en、zh、jp等，必须规范
    255: optional base.Base Base;
}

# API list
service OverseaMasterDataSpiderService {

    # 批量更新BillingExtentData
    BillingExtendDataSaveResponse batchSaveBillingExtendData(1: BillingExtendDataBatchSaveRequest request);

    # 批量查询BillingExtentData
    BillingExtendDataQueryResponse queryBillingExtendData(1: BillingExtendDataQueryRequest request);

    # 注册合同支付方式(新建/变更)
    spider_dispatch_common.RegisterPayMethodResponse registerPayMethod(1: spider_dispatch_common.RegisterPayMethodRequest request);

    # 实现支付方式(新建/变更)
    spider_dispatch_common.ApplyPayMethodResponse applyPayMethod(1: spider_dispatch_common.ApplyPayMethodRequest request);

    # 查询指定account/contract 支付方式变更记录是否已经开始
    spider_dispatch_common.PayMethodChangeRecordResponse queryPayMethodChangeRecord(1: spider_dispatch_common.QueryPayMethodChangeRecordRequest request);

    # 创建Spider
    CreateSpiderResponse createSpider(1: CreateSpiderRequest request);

    # 查询 Spider 全部内容，内部使用
    QuerySpiderResponse querySpiderById(1: QuerySpiderRequest request);

    # 批量查询spider。返回内容，视modulelist 定。 筛选条件 spiderId or contractId 优先取 spiderId
    BatchQuerySpiderResponse batchQuerySpiderBySpiderIdList(1: BatchQuerySpiderRequest request);

    # 更新Spider
    UpdateSpiderResponse updateSpider(1: UpdateSpiderRequest request);

    # 更新Account master data
    UpdateAccountMasterResponse updateAccountMasterData(1: UpdateAccountMasterRequest request);

    # 合同审批通过后更新Spider状态
    UpdateSpiderStatusResponse updateSpiderStatus(1: UpdateSpiderStatusRequest request)

    # 查询spider绑定的账号信息
    CommonQuerySpiderAccountNumResponse commonQuerySpiderAccountNum(1: CommonQuerySpiderAccountNumRequest req);

    # 操作spider绑定的账号信息
    OperateSpiderAccountNumResponse operateSpiderAccountNum(1: OperateSpiderAccountNumRequest req);

    # 币种查询：如果req中不传ids和codeList则返回全量币种列表
    QueryCurrencyResp queryCurrencyList(1: QueryCurrencyReq req);

    # 国家查询：如果req中不传ids和codeList则返回全量国家列表
    QueryCountryResp queryCountryList(1: QueryCountryReq req);

    # 根据cityId 查询city的信息
    QueryCityResp queryCityInfo(1: QueryCityReq req);

    # 通过contractId查询SpiderBase
    QuerySpiderBaseResponse querySpiderBaseByContractId(1: QuerySpiderBaseRequest req);

    # 通过spiderId查询SpiderBase
    QuerySpiderBaseResponse querySpiderBaseBySpiderId(1: QuerySpiderBaseRequest req)

    # 通过accountId查询AccountMasterDataDTO
    QueryAccountMasterDataResponse queryAccountMasterDataDTOByAccountId(1: QueryAccountMasterDataRequest request);

    # 通过accountId查询AccountMasterModel
    QueryAccountMasterDataResponse queryAccountMasterModelByAccountId(1: QueryAccountMasterDataRequest request);

    # 根据客户account_id查询子账号信息
    QueryAccountSubAccountNumByAccountIdResponse queryAccountSubAccountNumByAccountId(1: QueryAccountSubAccountNumByAccountIdRequest request);

    # 查询唯一的客户-子账号关联信息
    QueryUniqueAccountPayerIdResponse queryUniqueAccountPayerId(1: QueryUniqueAccountPayerIdRequest request);

    # 根据子账号查询客户信息
    QueryBySubAccountNumResponse queryAccountBySubAccountNum(1: QueryBySubAccountNumRequest request);

    # 根据子账号ID查询客户-子账号关联信息
    CommonQueryAccountSubAccountNumsResponse commonQueryAccountSubAccountNums(1: CommonQueryAccountSubAccountNumsRequest request);

    # 插入客户和子账号关联信息
    SaveAccountSubAccountNumResponse saveAccountSubAccountNum(1: SaveAccountSubAccountNumRequest request);

    # query_sub_account_by_grep_account的批量查询接口
//    QuerySubAccountByGrepAccountListResponse querySubAccountByGrepAccountList(1: QueryByAccountIdListRequest req);

    # 账号查询 -- 返回的数据大部分依赖于 legal-entiy packAccount
    # 每次最多支持100个查询
    QueryPayerIdsResponse queryPayerIds(1: QueryPayerIdsRequest req);

    # 通过accountId查询支付方式
    QueryPayMethodResponse queryPayMethod(1: QueryPayMethodRequest request);

    # 通过accountId查询支付方式
    QueryPayMethodResponseV2 queryPayMethodV2(1: QueryPayMethodRequestV2 request);

    # 初始化合同支付方式
    spider_dispatch_common.RegisterPayMethodResponse initiateAccountContractPayMethodInfo(1: spider_dispatch_common.RegisterPayMethodRequest request);

    # 初始化合同支付方式
    spider_dispatch_common.RegisterPayMethodResponse initiateContractIdFromCallBackData(1: spider_dispatch_common.RegisterPayMethodRequest request);

    # 新建合同和spider diff结果
    CreateResp createSpiderContractDiff(1: CreateSpiderContractDiffReq request);

    # 删除合同和spider diff结果
    base.BaseResp deleteSpiderContractDiff(1: DeleteSpiderContractDiffReq request);

    # 通过accountId查询Account主数据，支持合同初始化
    QueryAccountInfoResponse queryAccountInfoByAccountId(1: QueryByAccountIdRequest request);

    # 查询 billTo,根据传入的条件筛选
    QueryBillToResponse queryBillToParty(1: QueryBillToRequest request);

    # 查询 billTo,根据传入的条件筛选
    QueryBillToResponse queryBillToPartyByIdList(1: QueryBillToByIdRequest request);

    # 查询 指定时间 margin
    QueryMarginResponse queryMarginByContractAndDate(1: QueryMarginRequest request);

    # 查询 指定时间 margin
    QueryMarginResponse batchQueryMarginByContractAndDate(1: QueryMarginByContractIdListRequest request);

    # 查询 合同最新一组margin
    QueryMarginResponse queryLatestMarginGroupByContractIdList(1: QueryLatestMarginRequest request);

    # 通过合同查对应的spiderId,不过滤spider 状态
    QuerySpiderContractRelationResponse querySpiderContractRelationByContractId(1: QuerySpiderContractRelationRequest request);

    # 通过 spiderId or accountId 查询。根据入参筛选，至少传一个条件
    CommonQueryAccountResponse commonQueryAccountMasterData(1: CommonQueryAccountRequest request);

    # 通过advId查询SpiderBase,同一advId 多个合同返回最新的那个
    QuerySpiderBaseByAdvIdResponse querySpiderBaseByAdvId(1: QuerySpiderBaseByAdvIdRequest request);

    # 硬删spider 脏数据（合同创建并回滚场景） todo 是否需要鉴权
    DeleteSpiderResponse deleteSpider(1: DeleteSpiderRequest deleteSpiderRequest);

    # 通过accountId查询AccountMasterDataInfo
    QueryAccountMasterInfoResponse queryAccountMasterDataInfo(1: QueryByAccountIdListRequest request);

    # 更新account的SL
    UpdateAccountMasterResponse updateSequentialLiability(1: UpdateSequentialLiabilityRequest request);

    # 通过accountId查询税号审核拒绝原因
    QueryTaxAuditRejectReasonResponse queryTaxAuditRejectReason(1: QueryTaxAuditRejectReasonRequest request);

    # 查询主数据spider切片信息
    SpiderInfoResponse querySliceSpiderInfo(1: SliceSpiderInfoRequest request);

    # 查询主数据spider切片信息 -- 特殊合同类型的查询
    SpiderInfoResponse queryOtherTypeSliceSpiderInfo(1: SliceSpiderInfoWithContractTypeRequest request);

    # 查询adv 直客/渠道销售/交易owner
    QueryAdvAccountSalesResponse queryAdvAccountSaleByAdvId(1: QueryAdvAccountSalesRequest request);

    # 查询 转户记录
    spider_dispatch_common.QueryAccountTransferRecordResponse queryAccountTransferRecord(1: spider_dispatch_common.QueryAccountTransferRecordRequest request);

    # 主数据转户接口（已废弃）
    spider_dispatch_common.TransferAdvResponse transferAdv(1: TransferAdvRequest request);

    # 主数据转户接口（CRM/SMB转户，TCM bc transfer + 转户）
    spider_dispatch_common.TransferAdvResponse transferAdvV2(1: spider_dispatch_common.TransferAdvRequestV2 request);

    # 主数据转户预校验接口
    spider_dispatch_common.TransferAdvResponse transferAdvPreCheck(1: spider_dispatch_common.TransferAdvRequestV2 request);

    # 通过accountId查询SpiderBase
    QuerySpiderBaseResponse querySpiderBaseByAccountId(1: QuerySpiderBaseRequest req)

    # 查询adv对应的billing详细信息
    BatchQueryBillingInfoResponse batchQueryBillingInfoByAdvId(1: BatchQueryBillingInfoByAdvIdRequest request);

    # 新增/更新/清空 银行信息
    SaveBCBankInfoResponse saveBankInfo(1:SaveBCBankInfoRequest request);

    # 查询银行信息byBcId
    BatchQueryBankInfoByBCResponse queryBankInfo(1: BatchQueryByBCIdRequest request);

    # 查询adv的详细信息
    QueryAdvInfoResponse queryAdvInfoByAdvId(1: QueryAdvInfoByAdvIdRequest request);

    # 查询AccountBP上的合同联系人
    QueryContactInfoResponse queryContactInfoByAccountId(1: QueryByAccountIdRequest request);

    # 通过 银行信息 查询 accountId
    QueryAccountResponse queryAccountByBankInfo(1 : QueryAccountByBankInfoRequest request);

    # 查询支持的支付方式，以及推荐的支付方式
    spider_dispatch_common.QuerySupportAndRecommendPayMethodResponse querySupportCurrencyAndPayMethod(1: spider_dispatch_common.QuerySupportAndRecommendPayMethodRequest req);

    # promote 查询 businessName
    QueryAccountResponse queryAccountNameForPromote(1 : QueryByAccountIdListRequest request);

    # promote 更新 buisnessName
    CommonSaveResponse updateBusinessNameForPromote(1 : SaveAccountNameRequest request);

    # 通过advId查询账单地址信息
    QueryAddressInfoResponse queryAddressInfoByAdvId(1: spider_dispatch_common.QueryByAdvIdRequest request);

    spider_dispatch_common.AssetClearingCallbackResponse assetClearingCallback(1: spider_dispatch_common.AssetClearingCallbackRequest request);

    # 查询客户合同的数据来源
    OriginSourceResponse queryAccountOriginSource(1: BaseIdRequest baseRequest);

    # 通过 advId 查询合同
    QueryContractInfoByAdvIdResponse queryContractInfoByAdvId(1: spider_dispatch_common.QueryByAdvIdRequest request)

    # 查询合同主体切片信息
    QuerySliceSubjectResponse querySliceSubjectInfo(1: SliceSpiderInfoRequest request);

    # 查询合同支付方式切片信息
    QuerySlicePayMethodResponse querySlicePayMethodInfo(1: SliceSpiderInfoRequest request);

    # TCM TTAM挂接
    spider_dispatch_common.SyncTCMRelationResponse syncTcmMergeInfo(1: spider_dispatch_common.SyncTCMRelationRequest request);

    # 根据TCM id 查询对应TTAM id
    spider_dispatch_common.QueryTCMRelationResponse queryTCMRelatedTTAMInfo(1: spider_dispatch_common.QueryTCMRelationRequest request);

    # 判断主体一致性
    spider_dispatch_common.TcmMergeResponse preCheckTcmMergeInfo(1: spider_dispatch_common.TcmMergeRequest request);

    # 批量查询当前的交易主数据：主体、结算地址、税号等信息
    BatchSpiderBillingInfoResponse queryCurrentBillingInfo(1: QueryByContractIdsRequest request);

    # billingAddressId查询合同id list
    QueryContractIdByCountryIdResponse queryContractIdByCountryId(1: QueryContractIdByCountryIdRequest request);

    # 给对账单提供的根据account查询合同的接口
    QueryContractForReconResponse queryContractForRecon(1: QueryContractForReconRequest request);

    ###################################### billing sharing 接口定义 #################################

    # 白名单控制接口 -- account维度
    spider_common.BoolResponse checkBillingSharingWhiteList(1: QueryByAccountIdRequest request);

    # 创建、接受、废弃 billing sharing关系
    spider_common.BaseResponse saveBillingSharingRelation(1: spider_billing_sharing.SaveBillingSharingRelationRequest request);

    # 通过bcId、或者advId查询billing sharing关系
    spider_billing_sharing.QueryBillingSharingResponse queryBillingSharingRelation(1: spider_billing_sharing.QueryBillingSharingRequest request);

    # 通过bcId和advId list查询billing sharing关系
    spider_billing_sharing.QueryBillingSharingResponse batchQueryBillingSharingRelation(1: spider_billing_sharing.BatchQueryBillingSharingRequest request);

    # adv新建、adv注销、adv BC转户、adv结算转移、stop结算转移 预校验接口
    spider_billing_sharing.ChangeBcAndAdvRelationResponse changeBcAndAdvRelationPreCheck(1: spider_billing_sharing.ChangeBcAndAdvRelationRequest request);

    # adv新建、adv注销、adv BC转户、adv结算转移、stop结算转移
    spider_billing_sharing.ChangeBcAndAdvRelationResponse changeBcAndAdvRelation(1: spider_billing_sharing.ChangeBcAndAdvRelationRequest request);

    # 支持advId查询、advIdList查询adv-bc，adv-account关系，只能查询到生效状态中的数据，批量最大为100
    spider_billing_sharing.QueryRelationResponse queryAdvRelationByAdv(1: spider_billing_sharing.QueryAdvRelationByAdvRequest request);

    # 支持accountId查询adv-bc，adv-account关系（注意分页），只能查询到生效状态中的数据，批量最大为200
    spider_billing_sharing.QueryRelationResponse queryAdvRelation(1: spider_billing_sharing.QueryAdvRelationRequest request);

    # 指定时间区间，通过advId查询adv-bc关系，只能查询到生效状态中的数据，该接口不返回adv-account信息
    spider_billing_sharing.QueryRelationResponse queryPeriodAdvRelation(1: spider_billing_sharing.QueryPeriodAdvRelationRequest request);

    # 通过advId查询生效的billing sharing关系和支付方式
    # BC查询支付方式的维度确定：ad、出海、竞价
    spider_billing_sharing.QueryAvailablePaymentResponse queryAvailablePayment(1: spider_billing_sharing.QueryPaymentByAdvIdRequest request);

    # 查询adv当前支付方式
    # onlyEffective: true，仅返回当前生效的支付方式、即使adv正在进行支付方式切换。
    # onlyEffective: false，如果adv正在进行支付方式切换，则返回切换中的支付方式。
    spider_billing_sharing.QueryAdvPaymentResponse queryCurrentPayment(1: spider_billing_sharing.QueryPaymentByAdvIdRequest request);

    # 查询adv历史全部的支付方式（包括变更中的）
    spider_billing_sharing.QueryAdvHistoryPaymentResponse queryHistoryPayment(1: spider_billing_sharing.QueryPaymentByAdvIdRequest request);

    # 通过advId查询合同国家主体信息（允许查询历史合同）
    QuerySubjectCountryResponse querySubjectCountryByAdv(1: QuerySubjectCountryRequest request);

    # 根据BC id查询生效中/处理中的billing setting
    spider_billing_sharing.QueryBillingSettingAdvResponse queryBillingSettingAdvByBcId(1: spider_billing_sharing.QueryByBCIdRequest request);

    # bc解绑partner关系
    spider_common.BaseResponse deleteBcPartnerRelation(1: spider_billing_sharing.DeleteBcPartnerRelationRequest request);

    # 校验bc own adv是否和partner bc之间存在billing sharing关系
    spider_billing_sharing.CheckPartnerBcBillingSharingResponse checkPartnerBcBillingSharing(1: spider_billing_sharing.CheckPartnerBcBillingSharingRequest request);

    # 提供autopay关户接口
    spider_dispatch_common.CloseAutoPayResponse closeAutoPay(1: spider_dispatch_common.CloseAutoPayRequest request);

    spider_dispatch_common.RecomendedPayMethodResponse queryRecommendedPayMethodById(1: spider_dispatch_common.QueryByIdRequest request);

    spider_dispatch_common.UpgradePayMethodResponse upgradePayMethodById(1: spider_dispatch_common.UpgradePayMethodRequest request);

    spider_billing_sharing.CheckAdvSharingRelationResponse checkAdvSharingRelation(1: spider_billing_sharing.CheckAdvSharingRelationRequest request);

    # 查询全量的tcm和ttam存在融合关系的数据
    spider_billing_sharing.QueryTcmRelationResponse queryTcmRelation(1: spider_billing_sharing.QueryTcmRelationRequest request);

    # 查询adv是否停投
    spider_common.BoolResponse queryConsumptionStopByAdvId(1: spider_dispatch_common.QueryByAdvIdRequest request);

    spider_dispatch_common.PayMethodChangeLogResponse queryPayMethodChangeLog (1: spider_dispatch_common.QueryByIdRequest request);

    # 查询 adv/bc 支付方式 label
    QueryPayReadyResponse queryPayReady(1: QueryPayReadyReqeust request);

    # bc查询billing info
    QueryBillingInfoResponse queryBillingInfoForBc(1: QueryByAccountIdRequest request);


    # 查询bcId的历史和当前支付方式，只查询出海竞价维度
    spider_dispatch_common.BcAllPayMethodResponse queryBcAllPayMethod(1: spider_dispatch_common.QueryByIdRequest request);

    # 直接通过contract id 完成翻转
    DebugResponse debugPayMethodChange (1: DebugRequest request);

    # 通过thrift执行定时任务
    DebugResponse manuallyExecuteTask (1: DebugRequest request);

    # pangle主体变更accountId
    UpdateAccountMasterResponse changeAccountForPangle(1: ChangeAccountRequest request);

    # 根据Id 按模块查询当前billing 相关信息
    QueryBillingInfoByIdResponse queryBillingRelatedInfoById(1: QueryBillingInfoByIdRequest request);

    # 根据Id 按模块存储当前billing 相关信息 * Billing option仅可存储一次，后续若通过此接口尝试更新会直接报错
    SaveBillingRelatedInfoByIdResponse saveBillingRelatedInfoById(1: SaveBillingRelatedInfoByIdRequest request);

    # 合同解绑accountId
    spider_common.BaseResponse unbindAccount(1: UnbindAccountRequest unbindAccountRequest);

    # 跨机房测试
    DebugResponse crossDcTest (1: DebugRequest request);

    # 初始化billing option log
    DebugResponse initBillingOptionLog(1: BillingOptionLogRequest request);
}
