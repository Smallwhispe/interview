include "idl/base.thrift"
include "enums.thrift"
namespace py legal_entity_service
namespace go legal_entity_service
namespace java com.bytedance.cg.legal.entity.thrift

# 城市地区信息
struct CityInfo {
    1: required i64 id;
    2: required i64 pId;
    3: required i32 level;
    4: required string name;
    5: required string isoCode;
    6: required string iso3code;
    7: required string en;
    8: required string code;
    9: required string i18nCode;
    10: required i64 geoId;
}

enum AccountNumType {
    MAIN_ACCOUNT = 1        # 主账号
    SUB_ACCOUNT  = 2        # 子账号
}

struct QuerySubjectMainAccountRequest{
    1: optional list<i64> subjectIds    # 主体id，为空就都查
    2: optional list<i64> currencyIds   # 币种id，为空就都查
    3: optional list<i64> subjectAccountNumIds
    4: optional i64 binId
    5: optional i64 greaterThanBinId

    254: optional base.Base Base
}

struct QuerySubjectMainAccountResponse{
    1: required list<SubjectMainAccount> mainAccounts

    255: optional base.BaseResp BaseResp
}

struct SubjectMainAccount {
    1: optional string bank          #主体开户银行
    2: optional string accountNum   #主体银行账号
    3: optional string accountName  #主体账户名称
    4: optional string bankAddress  #主体开户银行地址
    5: optional string swiftCode
    6: optional string ifscCode
    7: optional string abaCode
    8: optional string bsbCode
    9: optional string bicCode
    10: optional string sortCode
    11: optional string iban
    12: optional i64 id                     # subject_account_num表主键，兼容SubjectAccountNumInfo
    13: optional i64 subjectId              # 主体id，兼容SubjectAccountNumInfo
    14: optional i64 bankId                 # 银行id，兼容SubjectAccountNumInfo
    15: optional i64 currencyId             # 币种id，兼容SubjectAccountNumInfo
    16: optional i32 binId                  # binId，兼容SubjectAccountNumInfo
    17: optional list<string> supportCurrencyList     # 该主账号支持的全部币种
}

//struct QuerySubjectAccountNumRequest{
//    1: optional list<i64> subjectIds  #主体id列表，如果为空代表查所有
//    2: optional list<i64> currencyIds #币种id列表，如果为空代表查所有
//
//    255: optional base.Base Base
//}

//struct QuerySubjectAccountNumResponse{
//    1: list<SubjectAccountNumInfo> subjectAccountNumInfoList
//
//    255: optional base.BaseResp BaseResp
//}

//struct SubjectAccountNumInfo{
//    1: optional i64 id                  # subject_account_num表主键
//    2: optional i64 subjectId          # 主体id
//    3: optional i64 bankId             # 银行id
//    4: optional string accountNum      # 主账号
//    5: optional i64 currencyId         # 币种id
//    6: optional i32 binId              # binId
//    7: optional string swiftCode
//    8: optional string ifscCode
//    9: optional string iban
//    10: optional string sortCode
//    11: optional string abaCode
//    12: optional string bsb
//    13: optional string bic
//}

struct QueryAccountCurrencyResponse {
    1: required list<AccountNumCurrency> accountNumCurrency

    255: optional base.BaseResp BaseResp
}

struct QueryAccountCurrencyRequest {
    1: optional list<i64> accountIds
    2: optional list<i64> currencyIds

    255: optional base.Base Base
}

struct QueryAccountCurrencyByBinResponse {
    1: required list<AccountNumCurrency> accountNumCurrency

    255: optional base.BaseResp BaseResp
}

struct AccountNumCurrency {
    1: optional i64 id
    2: required i64 subjectId
    3: required i64 subjectAccountNumId         # 主账号ID
    4: required i32 binId
    5: optional string accountNum               # 主账号
    6: required i64 currencyId
    7: required string currencyCode
    8: required i32 status         # @see enums.CommonStatusEnum
    9: optional i32 version
    10: required i64 createTimeTimestamp
    11: required i64 modifyTimeTimestamp
    12: required i64 creatorId
}

struct QueryAccountCurrencyByBinRequest {
    1: required i32 binId
    2: required CompareType compareType         # 查询的比较类型，等于、大于等

    255: optional base.Base Base
}

enum CompareType {
    EQUAL   = 1
    GREATER = 2
}

enum OperateType {
    DELETE      = 1
    UPDATE      = 2
    INSERT      = 3   # 带ID插入
}

struct SaveSubAccountAndUpdateBinResponse {
    1: required SubjectSubAccountNum subAccountNum

    255: optional base.BaseResp BaseResp
}

struct SaveSubAccountAndUpdateBinRequest {
    1: required i32 subjectBinId
    2: required i64 accountId
    3: required i32 subjectId

    255: optional base.Base Base
}

struct SaveSubAccountNumResponse {
    1: required i64 id

    255: optional base.BaseResp BaseResp
}

struct SaveSubAccountNumRequest {
    1: required SubjectSubAccountNum subAccountNum
    2: required OperateType operateType

    255: optional base.Base Base
}

struct CommonQuerySubjectSubAccountNumResponse {
    1: required list<SubjectSubAccountNum> subjectSubAccountNums

    255: optional base.BaseResp BaseResp
}

struct SubjectSubAccountNum {
    1: optional i64 id                          # 子账号id
    2: required i32 binId
    3: required string subAccountNum            # 子账号
    4: required i32 status                      # @see enums.CommonStatusEnum
    5: optional i32 version
}

struct CommonQuerySubjectSubAccountNumRequest {
    1: optional list<i64> subAccountNumIds
    2: optional list<string> subAccountNums
    3: optional i32 binId

    253: optional i32 page = 1
    254: optional i32 limit = 100
    255: optional base.Base Base
}

struct CommonQuerySubjectResponse {
    1: required list<SubjectInfo> subjects

    255: optional base.BaseResp BaseResp
}

struct SubjectInfo {
    1: optional i64 id
    2: required string name
    3: required i64 oracleSubjectId
    4: required string countryCode
    5: required string address
    6: required string legalRepr
    7: optional string bankAddress
    8: required string tax
    9: required string billingAddress
    10: required string taxNoTemplate
    11: required string registrationNumber
    12: required string logo
    13: required string address1
    14: required string address2
    15: required string address3
    16: required i32 status   # @see enums.CommonStatusEnum
    17: required i32 version
    18: optional i64 createTimeTimestamp
    19: optional i64 modifyTimeTimestamp
    20: required i64 creatorId
    21: optional string accountName
    22: optional string accountBank
    23: optional string accountNum
    24: optional string swiftCode
    25: optional list<string> semiSelfCurrencyList
    26: optional i64 addressCityId0
    27: optional i64 addressCityId1
    28: optional i64 addressCityId2
    29: optional i64 addressCityId3
    30: optional string docusignSigner
    31: optional string docusignSignerEmail
}

struct CommonQuerySubjectRequest {
    1: optional list<i64> subject_id
    2: optional list<string> subject_name
    3: optional list<i64> oracleSubjectId

    253: optional i32 page = 1
    254: optional i32 limit = 10
    255: optional base.Base Base
}

struct QuerySubjectAccountNumBySubjectIdsResponse {
    1: required list<SubjectAccountNum> subjectAccountNums

    255: optional base.BaseResp BaseResp
}

struct SubjectAccountNum {
    1: optional i64 id                  # 主账号id
    2: required i64 subjectId
    3: required i64 subjectBankId
    4: required string accountNum       # 主账号
    5: required string abaCode
    6: required string sortCode
    7: required string iban
    8: required string ifscCode
    9: required string swiftCode
    10: required string bsb
    11: required string bic
    12: required i32 status         # @see enums.CommonStatusEnum
    13: optional i32 version
    14: required i64 createTimeTimestamp
    15: required i64 modifyTimeTimestamp
    16: required i64 creatorId
}

struct QuerySubjectAccountNumBySubjectIdsRequest {
    1: optional list<i64> subjectIds
    2: optional i64 binId
    3: optional i64 greaterThanBinId
    4: optional list<i64> currencyIds
    5: optional list<i64> subjectAccountNumIds

    255: optional base.Base Base
}

struct UpdateSubjectBinResponse {
    1: required i32 id

    255: optional base.BaseResp BaseResp
}

struct UpdateSubjectBinRequest {
    1: required SubjectBin subjectBin

    255: optional base.Base Base
}

struct CommonQuerySubjectBinResponse {
    1: required list<SubjectBin> bins

    255: optional base.BaseResp BaseResp
}

struct SubjectBin {
    1: optional i32 id
    2: required i64 subjectId
    3: required string binNum
    4: required i32 subAccountMinId
    5: required i32 subAccountWidth
    6: required i32 status         # @see enums.CommonStatusEnum
    7: optional i32 version
    8: required i64 creatorId
}

struct CommonQuerySubjectBinRequest {
    1: optional bool isValid
    2: optional i32 binId

    255: optional base.Base Base
}

struct CommonQuerySubjectBankResponse {
    1: required list<SubjectBank> banks

    255: optional base.BaseResp BaseResp
}

struct SubjectBank {
    1: optional i32 id
    2: required i64 subjectId
    3: required string accountName
    4: required string accountBank
    5: required string bankAddress
    6: required i32 status         # @see enums.CommonStatusEnum
    7: optional i32 version
    8: required i64 createTimeTimestamp
    9: required i64 modifyTimeTimestamp
    10: required i64 creatorId
}

struct CommonQuerySubjectBankRequest {
    1: optional list<i32> ids
    2: optional list<i64> subjectIds

    255: optional base.Base Base
}

struct SubjectCountryResponse {
    1: required list<SubjectCountry> subjectCountries

    255: optional base.BaseResp BaseResp
}

struct SubjectCountry {
    1: required i32 businessLine
    2: required i64 subjectId
    3: required string countryCode
    4: required i64 countryId
    5: required i32 status         # @see enums.CommonStatusEnum
    6: optional i64 id
    7: required i64 creatorId
    8: optional i64 version
    9: required i64 createTimeTimestamp
    10: required i64 modifyTimeTimestamp
}

struct SubjectCountryRequest {
    1: optional list<i64> subjectIds
    2: optional list<i64> countryIds
    3: optional list<string> countryCodes
    4: required i32 businessLine  # @see enums.SubjectCountryBusinessLine

    255: optional base.Base Base
}

struct AccountBank {
    1: string bankName
    2: string bankAccountName
    3: string bankAccountNum
    4: string subAccountNum
    5: string swiftCode
    6: string abaCode
    7: string ibanCode
    8: string bicCode
}

struct QuerySubjectWithDetailRequest {
    1: optional list<i64> subjectIdList
    255: required base.Base Base
}

struct QuerySubjectWithDetailResponse {
    1: required list<SubjectDetail> subjectDetailList
    255: optional base.BaseResp resp
}

struct SubjectDetail {
    1: required SubjectInfo subject
    2: required list<SubjectBank> subjectBankList
    3: required list<SubjectAccountNum> subjectAccountNumList
    4: required list<AccountNumCurrency> accountNumCurrencyList
    5: required list<SubjectCountry> subjectCountryList
    6: required list<string> subjectCurrencyList
    7: required bool isOpenToSemiSelfService
}

struct QueryTaxConfigRulesRequest {
    1: optional i64 subjectId           # 主体ID，如果有主体ID（id>0），则优先使用主体id和countryCode进行查找
    2: optional i32 businessLine        # @see enums.SubjectCountryBusinessLine，如果没有主体ID，则使用businessLine和countryCode查询
    3: required string countryCode      # 国家ISO_CODE，US、CN等

    254: optional string lang           # 不传默认为EN @see enums.LanguageType，传前面的字符串，不要传数字
    255: optional base.Base Base
}

struct QueryTaxConfigRulesResponse {
    1: optional TaxConfigRule taxConfigRule     # 为空表明无配置数据，则合同/BC/TT等调用方不需关心税务信息

    255: optional base.BaseResp BaseResp
}

struct TaxConfigRule {
    1: required i64 id
    2: required i64 subjectId                                   # 主体ID
    3: required string countryCode                              # 国家ISO_CODE，US、CN等
    4: optional list<TaxValidateRules> taxValidateRules         # 税种校验信息
    5: required TaxIdentityRule taxIdentityDefaultRule          # 默认的税务身份配置，提供给不需要税务身份信息的业务线使用，目前只有合同侧使用
    6: optional list<TaxIdentityRule> taxIdentityConfigRules    # 税务身份配置，提供给需要税务身份信息的业务线使用
    7: optional list<TaxBasicInfo> taxBasicInfo                 # 通用的税种基本配置信息
}

struct TaxBasicInfo {
    1: required string taxKey       # 税种通用key
    2: required string taxName      # 税种名称，不同主体+国家的税种展示名称不同，支持多语言
    3: optional string taxTips      # 税种规则提示，可配置url，支持多语言
    4: optional string errMsg       # 税种校验失败提示，支持多语言
    5: optional i32 type            # 税种类型 0-输入型 1-选择型
    6: optional list<TaxOption> options # 选择类型税号的选项
    7: optional string taxTemplateRule  # 税种模板，前端格式化使用
}
struct TaxOption {
    1: optional string code         # 选项code
    2: optional string name         # 选项名称
}

struct TaxIdentityRule {
    1: required i32 taxIdentity         # 税务身份枚举，@see enums.TaxIdentityType
    2: required i32 needVerify          # 是否需要送审，@see enums.NeedVerify
    3: required list<TaxRule> taxRules  # 具体的展示/填写控制规则
    4: required string taxIdentityName  # 税务身份名称，支持多语言
    5: optional string taxIdentityTips  # 税务身份提示
    6: optional list<TaxBasicInfo> taxBasicInfo  # 税务身份下个性化的税种基本信息
}

struct TaxRule {
    1: required string taxKey   # 税种通用key
    2: required i32 control     # @see enums.ControlType
}

struct TaxValidateRules {
    1: required string taxKey                       # 税种的通用key
    2: optional list<list<ValidateRule>> rules      # 具体的规则，两层list，内层或，外层且
}

struct ValidateRule {
    1: required i64 id
    2: required i32 ruleType        # @see enums.RuleType
    3: required string rule         # rule的具体规则，只有正则类型规则有值
    4: required string ruleName     # 规则名称，目前无starlingCode配置，返回库中的默认名称，下游如果需要规则提示，需要联系PM在TaxBasicInfo.tips中配置
}

struct ValidateTaxNumberRequest {
    1: optional i64 subjectId                   # 主体ID，如果有主体ID（id>0），则优先使用主体id和countryCode进行查找，否则用businessLine和countryCode进行查找
    2: required string countryCode              # 国家ISOcode
    3: required map<string,string> taxNumber    # 税号map，takKey-taxNumber
    4: optional i32 businessLine                # @see enums.SubjectCountryBusinessLine，必填
    5: optional i32 taxIdentity                 # 税务身份枚举，@see enums.TaxIdentityType，需要税务身份的业务线需要给该参数进行必填性校验
    6: optional bool ignoreExtraTaxKey = false  # 忽略taxNumber中不在 税种配置中的key，不校验且不返回，默认不忽略
    7: optional bool doEmptyCheck = false       # 对于空税号是否进行校验。比如taxNumber={},如果税务规则规定某个税号必填，则无法通过校验
    254: optional string lang                   # 不传默认为EN，@see enums.LanguageType，传前面的字符串，不要传数字
    255: optional base.Base Base
}

struct ValidateTaxNumberResponse {
    1: required map<string,ValidateResult> validateRes  # 校验结果，没有配置校验规则的默认通过

    255: optional base.BaseResp BaseResp
}
struct ValidateResult {
    1: required bool isPassed       # 校验是否通过
    2: required string message      # 校验通过为空串，否则有具体的该主体+国家+税种下的errMsg，controlType相关校验优先，required必填，hidden必不可填
}

struct GetAllTaxResponse {
    1: required list<TaxMeta> taxList

    255: optional base.BaseResp BaseResp
}

struct TaxMeta {
    1: required string taxKey
    2: required string taxName          # 该taxName目前废弃，结果不准确
    3: required string starlingCode
}

struct GetAllTaxRequest {
    1: optional string countryCode
    254: optional string lang       # 不传默认为EN，@see enums.LanguageType，传前面的字符串，不要传数字
    255: optional base.Base Base
}

struct QuerySubjectCurrencyResponse {
    1: required list<string> currencyCodes
    2: optional i64 subjectId

    255: optional base.BaseResp BaseResp
}

struct QuerySubjectCurrencyRequest {
    1: required i32 businessLine                # @see enums.SubjectCountryBusinessLine
    2: required string countryCode
    3: optional i64 accountId
    4: required bool isNonSelfBc = false        # 是否为非自助BC，默认为false
    5: optional i32 paymehthod                  # @see enums.PayMethodEnum

    255: optional base.Base Base
}

struct CheckAdvRegisteredAddressRequest {
    1: required i32 businessLine;        // 业务线：TT/BC/Promote 等
    2: required string countryCode;      // bc-account注册国家
    3: required string advCountryCode;   // adv的注册国家
    4: optional i64 accountId;           // 3M account id

    255: optional base.Base Base;
}

struct CheckAdvRegisteredAddressResponse {
    1: optional bool result;        // 是否通过校验

    255: required base.BaseResp BaseResp;
}

struct RegionConfigRequest {
    1: required i32 configType;                     // 配置类型：1-合同 2-BG 3-合同签章
    2: optional list<i64> deptIds;                         // 部门ID
    3: optional bool onlyRegion = false;            // 是否只需要区域信息
    4: optional list<i64> regionIds;                       // 根据region查询，deptId和regionid只需要传一个
    5: optional i32 customerType;                   // 客户类型，目前只支持BG的客户类型筛选

    254: optional string lang                       // 不传默认为EN @see enums.LanguageType，传前面的字符串，不要传数字
    255: optional base.Base Base;
}

struct RegionConfigResponse {
    1: optional list<RegionConfigInfo> regionConfig

    255: required base.BaseResp BaseResp;
}

struct RegionContractStampConfig {
    1: optional list<CodeName> signType
    2: optional list<CodeName> offlineStampOrder
    3: optional list<CodeName> onlineStampOrder
}

struct CodeName {
    1: optional i32 code
    2: optional string name
}

struct RegionConfigInfo {
    1: optional i64 deptId;                                             // 父部门ID
    2: optional string region;                                          // 部门所属区域
    3: optional list<RegionContractConfig> contractConfig;               // 合同的区域配置
    4: optional RegionBgConfig bgConfig;                                // BG的区域配置
    5: optional i64 regionId;
    6: optional i64 requestDeptId                                       // 请求中的deptId
    7: optional RegionContractStampConfig contractStampConfig           // 合同签章配置
    8: optional list<i32> contractTypeConfig                            // 区域支持的合同类型
}

struct RegionBgConfig {
    1: optional i32 defaultReconObject;
    2: optional i32 defaultReconBillTo;
    3: optional i32 defaultInvoiceDetailBy;
    4: optional string defaultBiddingDetailGroupBy;
    5: optional i32 defaultBiddingSplitLevel1;
    6: optional string defaultBiddingSplitLevel2;
    7: optional string defaultBrandDetailGroupBy;
    8: optional i32 defaultBrandSplitLevel1;
    9: optional string defaultBrandSplitLevel2;
    10: optional i32 defaultIsNeedStamp;
    11: optional i32 defaultIsNeedAct;
    12: optional i32 defaultDirectCreditMarkPrimary;
    13: optional i32 defaultAgentCreditMarkPrimary;
    14: optional i32 defaultPartnerCreditMarkPrimary;
    15: optional i32 defaultBillReport;
    16: optional i32 rfRule;
}

struct RegionContractConfig {
    1: optional list<i32> customerType;                      // ORCM客户类型，101-Direct，102-Agent，103-Virtual，104-Self，105-Partners
    2: optional list<string> role;                         // 角色类型，@see enum.CrmRole，该字段返回名称字符串
    3: optional list<i32> contractType;                     // 合同类型
}

struct BatchQueryTaxConfigRulesRequest {
    1: optional list<QueryTaxConfigParam> param

    254: optional string lang           # 不传默认为EN @see enums.LanguageType，传前面的字符串，不要传数字
    255: optional base.Base Base
}

struct QueryTaxConfigParam {
    1: optional i64 subjectId           # 主体ID，如果有主体ID（id>0），则优先使用主体id和countryCode进行查找
    2: optional i32 businessLine        # @see enums.SubjectCountryBusinessLine，如果没有主体ID，则使用businessLine和countryCode查询
    3: required string countryCode      # 国家ISO_CODE，US、CN等
}

struct BatchQueryTaxConfigRulesResponse {
    1: optional map<string, TaxConfigRule> taxConfigRuleMap     # key是拼接了QueryTaxConfigParam三个参数生成的，拼接规则为 subjectId-countryCode-businessLine，数据为null则转为0拼接

    255: optional base.BaseResp BaseResp
}

struct QueryAddressConfigRuleResponse{
    1: optional AddressConfigRule addressConfigRule
    255: optional base.BaseResp BaseResp
}

struct AddressConfigRule {
    1: optional i32 addressRequiredLevel #地址必填到几级
    2: optional i32 detailAddressControl #@see ControlType
    3: optional i32 zipCodeControl       #@see ControlType
}

struct QueryAddressConfigRuleRequest {
    1: required i32 businessLine        # @see enums.SubjectCountryBusinessLine，如果没有主体ID，则使用businessLine和countryCode查询
    2: required string countryCode      # 国家ISO_CODE，US、CN等
    254: optional string lang           # 不传默认为EN @see enums.LanguageType，传前面的字符串，不要传数字
    255: optional base.Base Base
}

# API list
service LegalEntityService {

    # 查询主体不同业务线适用的国家
    SubjectCountryResponse querySubjectCountry(1: SubjectCountryRequest request);

    # 查询银行账户信息
    CommonQuerySubjectBankResponse commonQuerySubjectBank(1: CommonQuerySubjectBankRequest request);

    # 查询subjectBin信息
    CommonQuerySubjectBinResponse commonQuerySubjectBin(1: CommonQuerySubjectBinRequest request);

    # 更新subjectBin信息
    UpdateSubjectBinResponse updateSubjectBin(1: UpdateSubjectBinRequest request);

    # 根据主体id查询主账号
    QuerySubjectAccountNumBySubjectIdsResponse querySubjectAccountNumBySubjectIds(1: QuerySubjectAccountNumBySubjectIdsRequest request);

    # 查询主体信息
    CommonQuerySubjectResponse commonQuerySubject(1: CommonQuerySubjectRequest req);

    # 查询子账号信息
    CommonQuerySubjectSubAccountNumResponse commonQuerySubjectSubAccountNum(1: CommonQuerySubjectSubAccountNumRequest req);

    # 生成子账号
    SaveSubAccountAndUpdateBinResponse saveSubAccountAndUpdateBin(1: SaveSubAccountAndUpdateBinRequest req);

    # 保存/更新子账号
    SaveSubAccountNumResponse saveSubAccountNum(1: SaveSubAccountNumRequest req);

    # 查询bin对应的主账号支持的币种信息
    QueryAccountCurrencyByBinResponse queryAccountCurrencyByBin(1: QueryAccountCurrencyByBinRequest req);

    # 查询主账号表Id和币种 查询主账号币种信息
    QueryAccountCurrencyResponse queryAccountCurrency(1: QueryAccountCurrencyRequest req);

    # 废弃！废弃！废弃！使用querySubjectMainAccount
    # 查询主账号信息,根据主体和币种列表筛选
//    QuerySubjectAccountNumResponse querySubjectAccountNum(1: QuerySubjectAccountNumRequest request);

    # 查询主体某个币种下的主账户信息（subject_account_num join account_num_currency）
    QuerySubjectMainAccountResponse querySubjectMainAccount(1: QuerySubjectMainAccountRequest req);

    # 查询主体的全部信息，包括银行、主账号、国家信息
    QuerySubjectWithDetailResponse querySubjectWithDetail(1: QuerySubjectWithDetailRequest req);

    # 查询税种配置规则
    QueryTaxConfigRulesResponse queryTaxConfigRules(1: QueryTaxConfigRulesRequest req);

    # 进行税号的税种校验
    ValidateTaxNumberResponse validateTaxNumber(1: ValidateTaxNumberRequest req);

    # 获取所有税种
    GetAllTaxResponse getAllTax(1: GetAllTaxRequest req);

    # 根据国家和业务线匹配主体，返回主体的币种信息
    QuerySubjectCurrencyResponse querySubjectCurrency(1: QuerySubjectCurrencyRequest req);

    # 校验广告主国家是否 属于 Account国家
    CheckAdvRegisteredAddressResponse checkAdvRegisteredAddress(1: CheckAdvRegisteredAddressRequest request);

    # 获取大区配置
    RegionConfigResponse getRegionConfig(1: RegionConfigRequest request);

    # 查询税种配置规则
    BatchQueryTaxConfigRulesResponse batchQueryTaxConfigRules(1: BatchQueryTaxConfigRulesRequest req);

    # 查询地址配置规则
    QueryAddressConfigRuleResponse queryAddressConfigRule(1: QueryAddressConfigRuleRequest req);
}
