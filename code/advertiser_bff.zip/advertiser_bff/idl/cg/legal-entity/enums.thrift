namespace py enums
namespace go legal_entity_enums
namespace java com.bytedance.cg.legal.entity.thrift.enums

// 通用状态枚举
enum CommonStatusEnum {
    DELETE = 0  # 删除
    VALID  = 1  # 生效
    DRAFT  = 2  #未生效，草稿态
}

// 主体国家业务线
enum SubjectCountryBusinessLineEnum {
    TCM = 1,
    PROMOTE = 2,
    SHOUT_OUT = 3,
    LIVE_ACCELERATOR = 4
    TCM_NET = 5,
    CONTRACT_BILLING = 6
    BC_SELF = 7
    BC_NON_SELF = 8
    TT_SELF = 9
    TT_VIRTUAL = 10
}

// 税种校验规则类型
enum RuleType {
    DEFAULT = 0                 # 默认，即为无
    REGULAR_EXPRESSION = 1      # 正则表达式处理
    NO_CONTINUOUS_NUMBER = 2    # 数字不可连续
    NUMBER_NOT_ALL_SAME = 3     # 数字不可全部相同
    NO_REVERSE_CONTINUOUS_NUMBER = 4     # 数字不可逆向连续
}

// 税务身份下税种填写的控制字段
enum ControlType {
    HIDDEN = 0          # 不显示
    REQUIRED = 1        # 必填
    NOT_REQUIRED = 2    # 非必填
}

enum TaxIdentityType {
    DEFAULT = 0                     # 默认值，给不需要税务身份的业务线使用
    REGISTERED_INDIVIDUAL = 1
    UNREGISTERED_INDIVIDUAL = 2
    BUSINESS = 3
    SEZ = 4
    LOCAL_AUTHORITY = 5
    GV_AUTHORITY = 6
    GV = 7
    UN_ORGANIZATION = 8
    EMBASSY = 9
    REGISTERED_VAT = 10
    UNREGISTERED_VAT = 11
}

enum LanguageType {
    zh = 1      # 中文
    en = 2      # 英文
    ja = 3      # 日文
    ar = 4      # 阿拉伯语
    de = 5      # 德语
    es = 6      # 西班牙语
    fil = 7     # 菲律宾语
    fr = 8      # 法语
    id = 9      # 印尼语
    it = 10     # 意大利语
    ko = 11     # 韩语
    ms = 12     # 马来语
    ru = 13     # 俄语
    th = 14     # 泰语
    tr = 15     # 土耳其语
    vi = 16     # 越南语
    ZH_TW = 17  # 中文（繁体）
    pt_BR = 18  # 葡萄牙语（巴西）
}

enum NeedVerify {
    YES = 1
    NO  = 0
}

enum CrmRole {
    OWNER = 1       // CRM的角色字段不维护OWNER，OWNER是通过ownerId字段标示
    APM = 2
    BPM = 3
    CST = 4
}

enum RegionBizType {
    CONTRACT = 1       // 合同
    BG = 2              // BG
    CONTRACT_STAMP = 3       // 合同签章
}

enum PayMethodEnum {
    DEFAULT = 0
    PREPAY  = 1
    CREDIT  = 2
    AUTOPAY = 3
}
