include "idl/base.thrift"

enum CurrencyCode {
    OMNI = -1;
    AED = 784;
    ALL	= 8;
    AOA	= 973;
    ARS	= 32;
    AUD = 36;
    BAM = 977;
    BDT = 50;
    BGN = 975;
    BHD = 48;
    BND = 96;
    BOB = 68;
    BRL = 986;
    BWP = 72;
    BYN = 933;
    CAD = 124;
    CHF = 756;
    CLP = 152;
    CNY = 156;
    COP = 170;
    CRC = 188;
    CZK = 203;
    DKK = 208;
    DZD = 12;
    EGP = 818;
    EUR = 978;
    GBP = 826;
    GHS = 936;
    GTQ = 320;
    GYD = 328;
    HKD = 344;
    HNL = 340;
    HRK = 191;
    HUF = 348;
    IDR = 360;
    ILS = 376;
    INR = 356;
    IQD = 368;
    IRR = 364;
    ISK = 352;
    JOD = 400;
    JPY = 392;
    KES = 404;
    KRW = 410;
    KWD = 414;
    KZT = 398;
    LAK = 418;
    LBP = 422;
    LKR = 144;
    LYD = 434;
    MAD = 504;
    MDL = 498;
    MKD = 807;
    MMK = 104;
    MNT = 496;
    MOP = 446;
    MUR = 480;
    MVR = 462;
    MWK = 454;
    MXN = 484;
    MYR = 458;
    NGN = 566;
    NIO = 558;
    NOK = 578;
    NPR = 524;
    NZD = 554;
    OMR = 512;
    PEN = 604;
    PHP = 608;
    PKR = 586;
    PLN = 985;
    PYG = 600;
    QAR = 634;
    RON = 946;
    RSD = 941;
    RUB = 643;
    SAR = 682;
    SDG = 938;
    SEK = 752;
    SGD = 702;
    SLL = 694;
    SRD = 968;
    SSP = 728;
    SYP = 760;
    THB = 764;
    TND = 788;
    TRY = 949;
    TWD = 901;
    TZS = 834;
    UAH = 980;
    UGX = 800;
    USD = 840;
    UYU = 858;
    UZS = 860;
    VEF = 937;
    VND = 704;
    XAF = 950;
    YER = 886;
    ZAR = 710;
    ZMW = 967;
    KHR = 116;
}

struct CurrencyRequest {
    1: optional string code,
    2: optional i32 num,
    255: required base.Base Base,
}

struct CurrencyDataRow {
    1: required string code,
    2: required map<string,string> attrs,
}

struct CurrencyResponse {
    1: required list<CurrencyDataRow> data,
    255: required base.BaseResp BaseResp,
}
