include "idl/base.thrift"
include "./currency.thrift"

namespace py ad.platform.toolbox_i18n
namespace go ad.platform.toolbox_i18n

service ToolboxI18nService {
    currency.CurrencyResponse GetCurrencyList(1: currency.CurrencyRequest req);
}
