namespace go ad.advertiser.bff

enum HTTPCode {
    Redirect = 302 (api.http_message='', api.http_code='302')
}

enum StatusCode {
	ErrorParameter = 40000 (api.http_message='参数错误', api.http_code='200')
	ErrorPermission = 40002 (api.http_message='权限错误', api.http_code='200')
	ErrorDataNotFound = 40003 (api.http_message='数据不存在', api.http_code='200')
	ErrorPermissionDenied = 40102 (api.http_message='无此操作权限', api.http_code='200')
	ErrorSystem = 50000 (api.http_message='系统错误', api.http_code='200')
}

struct GetAdvTaxValueRequest {
    1: required i64 adv_id (api.query="aadvid"); // adv id
}

struct GetAdvTaxValueResponse {
    1: optional i64 tax_type(go.tag = "json:\"tax_type\"");     // tax identification
    2: optional i64 tax_status(go.tag = "json:\"tax_status\""); // tax status
    3: map<string, string> tax_value;                           // tax value
    4: string reject_reason;                                    // tax reject reason
    5: i64 tax_audit_time;                                      // audit rejection time
    6: i64 first_reject_time;                                   // first audit rejection time
}

struct GetAdvContactInfoRequest {
    1: required i64 adv_id (api.query="aadvid");                  // adv id
    2: optional bool sensitive_flag (api.query="sensitive_flag"); // sensitive data check
}

struct GetAdvContactInfoResponse {
    1: string contacter;                            // contacter name
    2: string telephone;                            // contacter telephone
    3: string phonenumber;                          // contacter phonenumber
    4: string email;                                // email
    5: string contacter_email;                      // contacter email
    6: optional string phonenumber_country;         // home country of the phone number
    7: optional string contacter_telephone_country; // contacter home country of the phone number
    8: optional i16 email_verify_status;            // email verified status
    9: optional i16 phonenumber_verify_status;      // phone number verified status
    10: optional i16 email_verify_source;           // email verified source
    11: optional i16 phonenumber_verify_source;     // phonenumber verified source
}

struct GetAdvPermissionDetailRequest {
    1: optional i64 adv_id (api.query="aadvid"); // adv id
}

struct CoreUserInfo {
    1: i64 id (api.body="core_user_id,string"); // core user id
    2: string name;                             // core user name
}

struct PermissionInfo {
    1: bool can_visit_advertiser; // can visit advertiser flag
    2: bool check_2sv_pass;       // is pass 2sv verify
    3: bool is_admin;             // admin flag
    4: i64  ref_role;             // ref role
}

struct StaffInfo {
    1: i64 staff_id;               // staff id
    2: optional string staff_name; // staff name
}

struct AccountInfo {
    1: i64 id (api.body="id,string"); // advertiser id
    2: string currency;               // currency
    3: string timezone;               // timezone
    4: i64 customer_type_value;       // customer type
    5: i16 origin;                    // advertiser source
    6: i16 role;                      // advertiser role
    7: i16 account_type;              // advertiser delivery type
    8: i64 ratio;                     // currency ratio
    9: i64 qualification_source;      // qualification source
    10: i64 currency_precision;       // currency precision
    11: i16 status;                   // advertiser status
    12: string name;                  // advertiser name
    13: string create_time;           // advertiser created time
    14: string country;               // advertiser registed country
    15: optional string idc;          // request idc
    16: optional IndustryInfo industry_info_v4;  // industry id, version 4.x
    17: optional list<IndustryInfo> industry_info_list;  // for industry version >= 4.0, including L0 (virtual level)
}

struct GetAdvPermissionDetailResponse {
    1: CoreUserInfo core_user;    // core user info
    2: PermissionInfo permission; // permission info
    3: StaffInfo staff;           // staff info
    4: AccountInfo account;       // account info
}

struct GetAdvertiserInfoRequest {
    1: required i64 adv_id (api.query="aadvid")
}

struct IndustryInfo {
    1: required i64 industry_id // industry leaf id, maybe level 3 or level 4 in industry 4.0
    2: required i32 industry_id_level // 1,2,3,4
}

struct GetAdvertiserInfoResponse {
    1: string name;            // advertiser name
    2: i16 status;             // adveritser status
    3: string company;         // company name
    4: string currency;        // currency
    5: string timezone;        // advertiser timeonze
    6: string country;         // advertiser registed country
    7: i64 state;              // state of billing info
    8: i64 county;             // county of billing info
    9: i64 city;               // city of billing info
    10: i64 second_industry;   // second industry code
    11: string post_code;      // postal code of billing info
    12: string address_detail; // address detail of billing info
    13: string reject_reason;  // reason of audit rejection or punishment
    14: string create_time;    // advertiser created time
    15: string payer_name;     // default payer name
    16: optional IndustryInfo industry_info_v4;  // industry id, version 4.x
    17: optional list<IndustryInfo> industry_info_list;  // for industry version >= 4.0, including L0 (virtual level)
}

enum BillingScene {
  Virtual = 10 // Agency bc创建adv、虚客adv更新税号
  NonSelfBc = 8 // 非自助bc
}

struct GetBillingConfigRequest {
    1: required string countryCode (api.query="country_code")
    2: required BillingScene scene (api.query="scene")
}

enum TaxInputType {
  Input = 0
  OptionList = 1
}

struct TaxOption {
    1: optional string code
    2: optional string name
}

struct TaxBasicInfo {
    1: optional string tax_key
    2: optional string tax_name
    3: optional string tax_tips
    4: optional TaxInputType type
    5: optional list<TaxOption> options
}

enum TaxRuleControlType {
  NotShow = 0
  Required = 1
  Optional = 2
}

struct TaxRule {
    1: optional TaxRuleControlType control
    2: optional string tax_key
}

struct TaxIdentityConfigRule {
    1: optional i32 need_verify
    2: optional i32 tax_identity
    3: optional string tax_identity_name
    4: optional string tax_identity_tips
    5: optional list<TaxRule> tax_rules
    6: optional list<TaxBasicInfo> tax_basic_info
}

struct GetBillingConfigResponse {
    1: required list<TaxBasicInfo> tax_basic_info
    2: required list<TaxIdentityConfigRule> tax_identity_config_rules
}

struct TaxInfo {
    1: optional string tax_key
    2: optional string tax_value
}

struct ValidateBillingConfigRequest {
    1: required string countryCode (api.body="country_code")
    2: required BillingScene scene (api.body="scene")
    3: required list<TaxInfo> taxInfos (api.body="tax_info_list")
    4: required i32 taxIdentity (api.body="tax_identity")
}

struct TaxValidateItem {
    1: optional string tax_key
    2: optional bool is_passed
    3: optional string message
}

struct ValidateBillingConfigResponse {
    1: required list<TaxValidateItem> tax_validate_result
}

struct GetAddressConfigRequest {
    1: required string countryCode (api.query="country_code")
    2: required BillingScene scene (api.query="scene")
}

struct GetAddressConfigResponse {
    1: optional i32 address_required_level
    2: optional TaxRuleControlType detail_address_control
    3: optional TaxRuleControlType zip_code_control
}

struct GetBillingInfoRequest {
    1: optional i64 adv_id (api.query="aadvid", api.vd="$>0; msg:'advID can not be zero'"); // adv id
}

enum TaxStatus {
    Approving = 0
    Reject = 1
    Pass = 2
    Default = 100
}

struct GetBillingInfoResponse {
    1: optional map<string, string> tax_map
    2: optional string reject_reason
    3: optional TaxStatus tax_status
    4: optional i64 county
    5: optional i64 state
    6: optional i64 city
    7: optional string address_detail
    8: optional string post_code
    9: optional bool can_update
    10: optional i64 tax_type
    11: optional i64 tax_audit_time
    12: optional i64 first_reject_time
}

enum UpdateBillingInfoModule {
    Address = 1
    Tax = 2
}

struct UpdateBillingInfoRequest {
    1: required i64 advID (api.query="aadvid", api.vd="$>0; msg:'advID can not be zero'")
    2: optional string postcode (api.body="post_code")
    3: optional string addressDetail (api.body="address_detail")
    4: optional string taxValue (api.body="tax_value")
    5: optional i64 city (api.body="city")
    6: optional i64 state (api.body="state")
    7: optional i64 county (api.body="county")
    8: optional map<string, string> taxMap (api.body="tax_map")
    9: optional i64 taxType (api.body="tax_type")
    10: optional list<UpdateBillingInfoModule> moduleList (api.body="module_list")
}

struct UpdateBillingInfoResponse {
    1: optional i64 city
    2: optional i64 state
    3: optional i64 county
    4: optional string address_detail
    5: optional string tax_value
    6: optional string post_code
    7: optional map<string, string> tax_map
}

struct GetFGConfigRequest {
    1: optional i64 advID (api.query="aadvid", api.vd="$>0; msg:'advID can not be zero'")
    2: optional i64 orgID (api.query="org_id", api.vd="$>0; msg:'org_id can not be zero'")
    3: required string serviceNames (api.query="service_names")
}

struct GetFGConfigResponse {
    1: required map<string, bool> service_names_result
}
service AdvertiserBffService {
    // @name: retrieve advertiser tax info
	// @desc: retrieve advertiser tax info
	// @err_enum: ErrorSystem,ErrorPermission
    GetAdvTaxValueResponse GetAdvTaxValue(1: GetAdvTaxValueRequest req) (api.category="tax", api.get="/api/v3/i18n/account/advertiser/tax_value/")

    // @name: retrieve advertiser contact info
    // @desc: retrieve advertiser contact info
	// @err_enum: ErrorSystem,ErrorPermission,ErrorPermissionDenied
    GetAdvContactInfoResponse GetAdvContactInfo(1: GetAdvContactInfoRequest req) (api.category="contact", api.get="/api/v3/i18n/account/contact_info/")

    // @name: retrieve advertiser permission detail
    // @desc: retrieve advertiser permission detail V4 version
	// @err_enum: ErrorSystem,ErrorPermission
	// @err_enum: Redirect 
    GetAdvPermissionDetailResponse GetAdvPermissionDetail(1: GetAdvPermissionDetailRequest req)(api.category="base", api.get="/api/v4/i18n/account/permission/detail/")

    // @name: retrieve advertiser permission detail
    // @desc: retrieve advertiser permission detail V4 version for MI
	// @err_enum: ErrorSystem,ErrorPermission
	// @err_enum: Redirect 
    GetAdvPermissionDetailResponse GetAdvPermissionDetailMI(1: GetAdvPermissionDetailRequest req)(api.category="base", api.get="/mi/api/v4/i18n/account/permission/detail/")

    // @name: retrieve advertiser info
    // @desc: retrieve advertiser info
	// @err_enum: ErrorSystem,ErrorPermission,ErrorParameter,ErrorDataNotFound
    GetAdvertiserInfoResponse GetAdvertiserInfo(1: GetAdvertiserInfoRequest req) (api.category="base", api.get="/api/v4/i18n/account/advertiser/info/")

    GetBillingConfigResponse GetBillingConfig(1: GetBillingConfigRequest req) (api.category="billing", api.get="/api/v4/i18n/common/billing_config/")
    GetBillingInfoResponse GetBillingInfo(1: GetBillingInfoRequest req) (api.category="billing", api.get="/api/v4/i18n/account/billing_info/")
    GetAddressConfigResponse GetAddressConfig(1: GetAddressConfigRequest req) (api.category="billing", api.get="/api/v4/i18n/common/address_config/")
    GetFGConfigResponse GetFGConfig(1: GetFGConfigRequest req) (api.category="common", api.get="/api/v4/i18n/common/fg_config/")
    ValidateBillingConfigResponse ValidateBillingConfig(1: ValidateBillingConfigRequest req) (api.category="billing", api.post="/api/v4/i18n/common/billing_validate/")
    UpdateBillingInfoResponse UpdateBillingInfo(1: UpdateBillingInfoRequest req) (api.category="billing", api.post="/api/v4/i18n/account/billing_info/")
}
