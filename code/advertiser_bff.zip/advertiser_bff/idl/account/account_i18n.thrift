include "idl/base.thrift"

namespace go ad.advertiser.adv_account.account_i18n
namespace py ad.advertiser.adv_account.account_i18n
namespace java ad.advertiser.adv_account.account_i18n
namespace cpp ad.advertiser.adv_account.account_i18n

enum QualificationType {
    Description = 0            // 广告主推广描述资质
    License = 1                // 营业执照
    Qualification = 2          // 其他开户资质
    AdQualification = 3        // 投放资质，非中国区无此类型，同步国内
    SezQualification = 4       // 国际化自助广告主sez税号
}

enum CustomerTypeValue {
    # 客户类型
    ka =11                     # KA直客
    local = 12                 # 北上广本地直客
    region = 13                # 区域直客
    branch = 14                # 分公司直客
    internet = 15              # 网服直客
    internal = 16              # 内部客户
    la = 17                    # LA直客
    smb = 18                   # SMB直客
    ka_agent = 21              # KA代理商
    la_agent = 27              # LA代理商
    smb_agent = 28             # KA虚客
    virtual_ka = 31            # LA虚客
    virtual_la = 37            # 置换合作客户
    virtual_smb = 38           # MB虚客

    # 对应category中的self_service
    self_service = 51          # 自助注册

    # i18n
    i18n_adv = 101             # 国际化直客
    i18n_agent = 102           # 国际化代理商
    i18n_virtual = 103         # 国际化虚客
    i18n_self = 104            # 国际化自助
    i18n_cooperate = 105       # 国际化合作方

    vertical = 251             # 垂直合作客户
    exchange = 252             # 置换合作客户
    dsp = 253                  # DSP
    game = 254                 # 游戏
    virtual_cus = 255          # 虚拟广告主

}

enum AdvertiserTaxType {
    # 国际化自助开户广告主税务身份字段
    # https://bytedance.feishu.cn/sheets/shtcnZH2tLa9Sg71KpRUXWPglJc

    registered_individual = 1
    unregistered_individual = 2
    business = 3
    sez = 4
    local_authority = 5
    gv_authority = 6
    gv = 7
    unorganization = 8
    embassy = 9
    registered_vat = 10
    unregistered_vat = 11

}

enum AdvertiserStatus {
    # 广告主状态
    STATUS_DISABLE = 0                  // 已禁用
    STATUS_PENDING_CONFIRM = 1          // 待审核
    STATUS_PENDING_VERIFIED = 2         // 待邮箱验证，已废弃
    STATUS_CONFIRM_FAIL = 3             // 审核失败/可再次申请
    STATUS_ENABLE = 4                   // 已审核
    STATUS_CONFIRM_FAIL_END = 5         // 审核失败/最终状态
    STATUS_PENDING_CONFIRM_MODIFY = 6   // 修改审核
    STATUS_CONFIRM_MODIFY_FAIL = 7      // 修改审核失败
    STATUS_PUNISH = 8                   // 限制惩罚
    STATUS_WAIT_FOR_BPM_AUDIT = 9       // 等待CRM审核
    STATUS_SELF_SERVICE_UNAUDITED = 10  // 自助开户待验证资质
    STATUS_CONTRACT_PENDING = 15        // 待合同生效 避免历史冲突从15开始自增
}

enum AdvertiserRole {
    # 广告主角色枚举
    ROLE_ADVERTISER = 0                     # 一般广告主
    ROLE_AGENT = 1                          # 广告代理商(数据已迁出)
    ROLE_VIRTAUL_ADVERTISER = 2             # 虚拟广告主
    ROLE_ADMIN = 3                          # 管理员
    ROLE_INTERNAL_ADV = 4                   # 内部广告主
    ROLE_DSP_ADVERTISER = 8                 # 头条自建DSP 广告主
    ROLE_MAJORDOMO = 13                     # 账户管家
    ROLE_PROMOTE_I18N = 60                  # promote广告主
    ROLE_PROMOTE_PRO = 61                   # promote pro广告主
    ROLE_SANDBOX = 70                       # 国际化OPENAPI沙箱账户
}

enum AdvPunishType {
    # 广告主惩罚类型
    ADMIN = 1;                              # 管理员惩罚广告主,审核平台、AD管理员平台
    AGENT = 2;                              # 代理商直接惩罚广告主,代理商平台
    REFUND = 3;                             # 广告主退款,资金平台
    AGENT_RELATE = 4;                       # 代理商被惩罚，其下广告主被关联惩罚
    CREDIT_CARD_DEDUCTION_FAIL = 5;         # 信用卡扣款失败
    OVERDUE_PAYMENT = 6;                    # 逾期欠款惩罚
    NON_TRADE_COMPLIANCE = 7;               # 贸易合规惩罚
    CLEAR_CAPITAL_ASSET = 8;                # 资金清空暂时封禁
    OVERSEAS_REFUND = 9;                    # 海外adv退款
    AGENCY_ACCOUNT_RELATE = 10;             # agency suspend
}

enum AdvAccountType {
    # 广告主投放类型
    NO_SET = 0;                             # 未设置
    RESERVATION = 1;                        # 品牌广告平台
    AUCTION = 2;                            # 竞价广告平台
}

enum AdvOperationtype {
    # 广告主惩罚类型
    PUNISH = 1;                # 惩罚广告主
    UNPUNISH = 2;              # 解除惩罚广告主
}

/* 资质状态 */
enum QualificationStatus {
    Audit = 0                               // 审核中
    Reject = 1                              // 审核拒绝
    OK = 2                                  // 审核通过
    Default = 100                           // 无需审核
}

/* 账号来源 */
enum AdvertiserOrigin {
    # i18n
    i18n_bpm = 100                          // 国际化BPM开户
    i18n_agent_ad = 101                     // 国际化代理商创建
    i18n_self_service = 102                 // 国际化自助开户

    i18n_promote_business = 103            // promote B端账户
    i18n_promote_consumer  = 104            // promote C端账户

    i18n_sandbox = 105                     // 国际化沙箱账户
}

/* 广告账户资质来源 */
enum QualificationSource {
    own_qualification = 0 // 独立资质
    bc_qualification = 1 // 共享BC资质
    offline_agency = 2 // 线下代理资质
}

enum AdSystemOrigin {
    toutiao = 0                 // 普通广告
    pgc_promotion = 1           // 老版PC端号外, 需要自己录入素材
    pgc_media = 2               // 自营广告
    ad_article_promotion = 3    // 广告后台专业版号外, 给广告主用, 号外里消耗最大的
    union_ad = 4                // 开屏联播
    user_promotion = 5          // 移动版号外, 和pgc_promotion是同一个产品, 不需要录入素材, 打包拿的文章的
    pgc_promotion_v2 = 6        // 新版PC端号外, 不需要自己录入素材
    open_api = 7                // OpenAPI
    bpm = 8                     // bmp系统
    jd_open_api = 9             // JDOpenAPI广告
    hotsoon = 10                // 火山直播账号
    dsp = 11                    // dsp系统
    temai = 12                  // 鲁班特卖
    self_ad = 13                // 头条号自助广告
    aweme_promotion = 15
    lab_open_api = 16           // 智能实验室OpenAPI
    hotsoon_promotion = 17      // 火山广告
    oversea = 18                // 海外
    ad_aweme_promotion = 19     // 广告平台创建 dou+ GD广告
    zeus = 20                   // zeus平台
    derived_ad = 21             // 衍生计划
    doudian = 22                // 抖店计划
    aweme_commercial = 23       // dou+商业推广
    ad_hotsoon_promotion = 24   // 平台火山快上热门（GD）
}

/**
* 公司审核状态
**/
enum AuditStatus {
    /** 未提交资质 */
    NOT_SUBMIT = 0
    /** 待审核 */
    NOT_STARTED = 1
    /** 审核中 */
    UNDER_REVIEWING = 2
    /** 审核通过 */
    APPROVAL = 3
    /** 不通过 */
    REJECT = 4
    /** 过期 */
    EXPIRE = 5
    /** 失效 */
    INVALID = 6
}

/**
* 公司规模大小
**/
enum CompanySize {
    /** 1-5 employee */
    EMPLOYEE_1_5 = 1
    /** 5-20 employee */
    EMPLOYEE_5_20 = 2
    /** 20-100 employee */
    EMPLOYEE_20_100 = 3
    /** more than 100 employee */
    EMPLOYEE_MORE_THAN_100 = 4
}


/**
* 每月花费预算
**/
enum MonthlyBudget {
    /** 0-500 USD */
    USD_0_500 = 1
    /** 500-5000 USD */
    USD_500_5000 = 2
    /** 5000-50K USD */
    USD_5000_50K = 3
    /** more than 50K USD */
    USD_MORE_THAN_50K = 4
}

/**
* 内部员工权限枚举
**/
enum EmployeePermissionRole {
    /** 管理员 对应bsm的rwa */
    ADMIN = 1
    /** 操作者 对应bsm的rw */
    OPERATOR = 2
    /** 观察者 对应bsm的r */
    STATEMENT = 3
}

enum PaymentType {
    Manual = 1          //预付
    Automatic = 2       //授信
}

/* 转户类型 */
enum TransferType {
    virtual_virtual = 1   // 虚客转虚客
    direct_direct = 2      // 直客转直客
    virtual_direct = 3    // 虚客转直客
    direct_virtual = 4     // 直客转虚客
    smb_direct_direct = 12  // 自助转户-直客转直客
    smb_direct_virtual = 14 // 自助转户-直客转代理
}


/* 事件类型 */
enum EventType {
    crm_info_change = 1 // 客户消息变更
}

enum ContactWayVerifyStatus {
    unverified = 0 // unverified
    verified = 1   // verified
}

enum ContactWayVerifySource {
    none = 0            // not verified
    passport = 1        // from passport
    registration = 2    // from adv registration
    account_setting = 3 // from account setting page
}

struct IndustryInfo {
    1: required i64 industry_id // industry leaf id, maybe level 3 or level 4 in industry 4.0
    2: required i32 industry_id_level // 1,2,3,4
}

struct AdvertiserData {
    1: required i64 id;                     // 账号ID
    2: optional string company;             // 公司名称
    3: optional string name;                // 广告主名称
    4: optional string currency;            // 广告主币种编码，如JPY/INR/GBP/HKD等
    5: optional string timezone;            // 广告主时区 Etc/GMT+0
    6: optional i16 role;                   // 枚举详见AdvertiserRole, 用户身份
    7: optional i16 origin;                 // 举详见AdvertiserOrigin，广告主来源
    8: optional i16 status;                 // 枚举详见AdvertiserStatus，广告主状态，0-已禁用，1-待审核，2-待邮箱验证，3-审核失败/可再次申请，4-已审核，5-CRM审核失败/最终状态，6-修改审核，7-修改审核失败，8-惩罚限制，9-等待CRM审核，10-资质待提交，12-SMB客户待合同生效，13-SMB广告主待缴纳开户费，14-待对公验证
    9: optional i64 customer_id;            // 客户ID 已废弃勿用 背景咨询@gujianqi 用account_id代替customer_id
    10: optional string create_time;        // 创建时间，格式 '2018-01-26 10:45:25'
    11: optional i16 account_type;          // 广告主投放类型，详见AdvAccountType
    12: optional i64 customer_type_value;   // 客户类型，详情参见CustomerTypeValue
    13: optional string country;            // 广告主注册地，默认值为us，ISO 3166-2相应代码，例如Mexico => MX
    14: optional string display_timezone;   // 广告主时区 Europe/London 仅做展示使用
    15: optional i64 second_industry_id;    // 行业3.0 二级id
    16: optional string reason;             // 原因，比如审核未通过/惩罚原因等
    17: optional string address_detail;     // 广告主开票地址
    18: optional i16 system_origin;         // 已废弃。枚举详见AdSystemOrigin, 广告主所属业务来源
    19: optional string audit_time;         // 已废弃。账号审核时间，一般为状态变更对应时间，格式 '2018-01-26 10:45:25'
    20: optional i64 audit_time_ts;         // 已废弃。账号审核时间对应timestamp，一般为状态变更对应时间
    21: optional QualificationSource qualification_source // 账号资质是否共享BC资质
    22: optional string language // 语种
    23: optional i64 promotion_area // 已废弃。营销区域
    24: optional i64 state;  // 州 Geoid
    25: optional i64 city;  // 城市 Geoid
    26: optional string postal_code; // 邮政编码
    27: optional i64 account_id; // gcrm 唯一公司实体
    28: optional i64 county; // 郡
    30: optional IndustryInfo industry_info_v4  // industry id, version 4.x
    31: optional list<IndustryInfo> industry_info_list  // for industry version >= 4.0, including L0 (virtual level)
}

struct AdvertiserCacheData {
    1: required i64 id;                     // 账号ID
    2: optional string currency;            // 广告主币种编码，如JPY/INR/GBP/HKD等
    3: optional string timezone;            // 广告主时区 Etc/GMT+0
    4: optional i16 origin;                 // 举详见AdvertiserOrigin，广告主来源
    5: optional string create_time;        // 创建时间，格式 '2018-01-26 10:45:25'
    6: optional i16 account_type;          // 广告主投放类型，详见AdvAccountType
    7: optional string country;            // 广告主注册地，默认值为us，ISO 3166-2相应代码，例如Mexico => MX
    8: optional string display_timezone;   // 广告主时区 Europe/London 仅做展示使用
}

// auth
struct Auth {
    1: required i64     app_key;            // 业务访问app_key，需申请
    2: required string  app_secret;         // 业务访问密钥
}

struct GetAdvAccountByIdRequest {
    1: optional i64 advertiser_id;
    2: optional Auth auth;                          // 必须，调用认证
    3: optional i32 need_industry_version; // 400 = industry 4.0, 仅支持 4.0之后版本。历史兼容，3.2持续提供
    255: base.Base Base;
}

struct GetAdvAccountByIdResponse {
    1: optional AdvertiserData advertiser;
    255: base.BaseResp BaseResp;
}


struct MultiGetAdvRequest {
    1: required list<i64> advertiser_ids;
    2: optional Auth auth;                          // 必须，调用认证
    3: optional bool read_master;  // true强制走主库,非强一致性需求不要传此参数
    255: base.Base Base;
}

struct MultiGetAdvResponse {
    1: optional list<AdvertiserData> advertisers;
    255: base.BaseResp BaseResp;
}

struct MultiGetAdvCacheRequest {
    1: required list<i64> advertiser_ids;            // 一次查询上限100
    2: optional Auth auth;                          // 必须，调用认证
    255: base.Base Base;
}

struct MultiGetAdvCacheResponse {
    1: optional list<AdvertiserCacheData> advertisers;
    255: base.BaseResp BaseResp;
}

struct AdvOperationItem {
    1: required i64 advertiser_id;
    2: required bool success;
    3: optional string message;
}

struct ReasonVariable {
    1: optional string key;             // 惩罚原因模板中的变量key
    2: optional string value;           // 惩罚原因模板中的变量value
}

struct AdvPunishReasonVariable {
    1: optional i64 advertiser_id;
    2: optional list<ReasonVariable> reason_variables;   // 惩罚原因模板中的变量
}

struct HandlePunishAdvertiserRequest {
    1: optional Auth auth;                          // 必须，调用认证
    2: required list<i64> advertiser_ids;           // 广告主id，上限100
    3: required list<AdvPunishType> punish_types;   // 惩罚类型，不同auth具有不同的punish_types权限
    4: required string reason;                      // 惩罚原因
    5: required AdvOperationtype operation_type;    // 操作类型，可选PUNISH/UNPUNISH
    6: required i64 operator_id;                    // 操作者头条号id
    7: required i64 operator_staff_id;              // 操作者员工号
    8: optional string punish_time;                 // 惩罚到期时间，operation_type=惩罚时必须,格式 '2018-01-26 10:45:25'
    9: optional string reason_i18n_key;             // 惩罚原因模板starling key
    10: optional list<AdvPunishReasonVariable> adv_reason_variables;  // 惩罚原因变量
    255: required base.Base Base
}

struct AdvPunishRecord {
    1: optional i64 advertiser_id;
    3: optional AdvPunishType punish_type;          // 惩罚类型
    4: optional string reason;                      // 惩罚原因
    8: optional string punish_time;                 // 惩罚到期时间,格式 '2018-01-26 10:45:25'
}

struct GetAdvPunishRequest {
    1: required i64 advertiser_id = 0;
    2: optional Auth auth;                          // 必须，调用认证
    3: optional list<i64> advertiser_ids;           // 兼容批量查询， 广告主id列表，上限20
    4: optional string lang;                        // 惩罚原因语言类型
    5: optional bool read_master;                   //true查询走主库,非强一致性场景不要传此参数
    255: base.Base Base;
}

struct GetAdvPunishResponse {
    1: optional list<AdvPunishRecord> records;
    255: base.BaseResp BaseResp;
}

struct GetAdvPunishLogRequest {
    1: optional Auth auth;                          // 必须，调用认证
    2: required i64 advertiser_id;                  // 广告主id
    3: optional i64 page_no = 1;                    // default 1
    4: optional i64 page_size = 100;                 // 最大100
    255: base.Base Base;
}

struct AdvPunishLog {
    1: optional i64 id;                             // 日志记录id
    2: optional i64 advertiser_id;                  // 广告主id
    3: optional i16 punish_type;                    // 惩罚类型，详见AdvPunishType
    4: optional string reason;                      // 惩罚原因
    5: optional i16 operation_type;                 // 操作类型，详见AdvOperationtype
    6: optional i64 operator_id;                    // 操作者头条号id
    7: optional i64 operator_staff_id;              // 操作者员工号
    8: optional string operator_platform;           // 操作平台
    9: optional string punish_time;                 // 惩罚到期时间，operation_type=惩罚时有,格式 '2018-01-26 10:45:25'
    10: optional string create_time;                // 创建时间,格式 '2018-01-26 10:45:25'
}

struct GetAdvPunishLogResponse {
    1: optional i64 page_no;
    2: optional i64 page_size;
    3: optional i64 total;
    4: required list<AdvPunishLog> logs;
    255: base.BaseResp BaseResp;
}

struct HandlePunishAdvertiserResponse {
    1: optional list<AdvOperationItem> operation_items;  // 操作结果，id-result-massage
    255: base.BaseResp BaseResp
}

struct AddApplicationRequest {
    1: optional Auth    auth;               // 必须，调用认证
    2: optional i64     app_key;            // 业务访问app_key，需申请
    3: optional string  app_secret;         // 业务访问密钥
    4: optional string  name;               // 业务名字
    255: optional base.Base Base;
}

struct AddApplicationResponse {
    255: base.BaseResp BaseResp;
}

struct Appication {
    1: optional i64         app_key;                    // 业务访问app_key，需申请
    2: optional string      name;                       // app名称
    3: optional string      create_time;                // 创建时间,格式 '2018-01-26 10:45:25'
}

struct ListApplicationRequest {
    1: optional Auth          auth;                     // 必须，调用认证
    2: optional list<i64>     app_keys;                 // 业务访问app_key，需申请
    255: optional base.Base Base;
}

struct ListApplicationResponse {
    1: optional list<Appication> apps;                   // 应用列表
    255: base.BaseResp BaseResp;
}

struct AddInterfaceAclRequest {
    1: optional Auth    auth;                           // 必须，调用认证
    2: optional i64     app_key;                        // 业务访问app_key
    3: optional string  interface_name;                 // 业务访问接口名字
    255: optional base.Base Base;
}

struct AddInterfaceAclResponse {
    255: base.BaseResp BaseResp
}

struct InterfaceAcl {
    1: optional i64         app_key;                        // 业务访问app_key，需申请
    2: optional string      interface_name;                 // 接口名字
    3: optional string      create_time;                    // 创建时间,格式 '2018-01-26 10:45:25'
}

struct ListInterfaceAclRequest {
    1: optional Auth            auth;                       // 必须，调用认证
    2: optional i64             app_key;                    // 业务访问app_key
    3: optional string          interface_name;             // 业务访问interface
    255: optional base.Base Base;
}

struct ListInterfaceAclResponse {
    1: optional list<InterfaceAcl> interface_acls;            // 接口控制列表
    255: base.BaseResp BaseResp;
}

struct DisableAdvertiserRequest {
    1: optional Auth auth;                          // 必须，调用认证
    2: required list<i64> advertiser_ids;           // 广告主id，上限100
    3: required string reason;                      // 禁用原因
    4: required i64 operator_id;                    // 操作者头条号id
    5: required i64 operator_staff_id;              // 操作者员工号
    255: required base.Base Base
}

struct DisableAdvertiserResponse {
    1: optional list<AdvOperationItem> operation_items;  // 操作结果，id-result-massage
    255: base.BaseResp BaseResp
}

struct GetAdvInfoForSharkRequest {
    1: Auth auth;                           // 必须，调用认证
    2: required i64 uid;                    // 广告主id
    255: base.Base Base;
}

struct GetAdvInfoForSharkResponse {
    1: i64 advertiser_id;
    2: string create_time;
    3: string register_ip;
    4: string ad_platform;
    5: i64 aid;                     // app id?
    6: list<i64> i18n_core_user_id;
    7: i16 adv_counts;
    8: string timezone;             // Etc/GMT
    9: string email;                // ucenter/desen_sdk 加密
    10: string name;                // md5后16进制encode string
    11: i16 classify;               //5-个人 6-公司
    12: i16 status;
    13: i16 adv_type;               // 1-直客 2-虚客
    14: string first_industry;
    15: string second_industry;
    16: string contacter;           // md5后16进制encode string
    17: string telephone;           // ucenter/desen_sdk 加密
    18: string contacter_email;     // ucenter/desen_sdk 加密
    255: base.BaseResp BaseResp;
}

struct LicenseQulification {
    1: optional string license_no;                     // 主体资质编号
    2: optional string license_uri;                    // 已废弃 主体资质文件地址，tos key，格式参考 bucket/toskey=ad-site-i18n/201906205d0deb3c30d832d0458a847e
    3: optional string license_file_id;                // 主体资质文件地址，敏感资质托管file_id,格式参考 e7cdec75-5bbc-4aee-a208-fe8d43f87d9a

}

struct CreateAdvQulification {
    1: optional string promotion_link;                 // 推广链接，等同历史的description
    2: optional LicenseQulification license;           // 营业执照信息
    3: optional list<string> accountQulifications      // 已废弃 其他开户资质地址，格式 bucket/toskey=ad-site-i18n/201906205d0deb3c30d832d0458a847e
    4: optional string language;                       // 资质提交语言
    5: optional list<string> accountQulificationFileIds // 其他开户资质地址，敏感资质托管file_id,格式参考 e7cdec75-5bbc-4aee-a208-fe8d43f87d9a

}

struct ContacterInfo {
    1: optional string contacter;                                  // 广告主联系人名字
    2: optional string email;                                      // 广告主联系人名字邮箱
    3: optional string phonenumber;                                // 广告主联系人手机号码
    4: optional string telephone;                                  // 广告主联系人电话号码
    5: optional string contacter_email;                            // 联系人邮箱
    6: optional string phonenumber_country;                        // 注册手机所属国家
    7: optional string contacter_telephone_country;                // 联系人手机所属国家
    8: optional ContactWayVerifyStatus email_verify_status;        // 邮箱认证状态
    9: optional ContactWayVerifySource email_verify_source;        // 邮箱认证渠道
    10: optional ContactWayVerifyStatus phonenumber_verify_status; // 手机号码认证状态
    11: optional ContactWayVerifySource phonenumber_verify_source; // 手机号码认证渠道
}

struct AdvContactInfo {
    1: optional i64 advertiser_id;                                 // 广告主id
    2: optional string phonenumber;                                // 注册电话
    3: optional string email;                                      // 注册邮箱
    4: optional string contacter;                                  // 联系人
    5: optional string contacter_email;                            // 联系人邮箱
    6: optional string contacter_telephone;                        // 联系人电话
    7: optional string phonenumber_country;                        // 注册电话所属国家
    8: optional string contacter_telephone_country;                // 联系人手机所属国家
    9: optional ContactWayVerifyStatus email_verify_status;        // 邮箱认证状态
    10: optional ContactWayVerifySource email_verify_source;       // 邮箱认证渠道
    11: optional ContactWayVerifyStatus phonenumber_verify_status; // 手机号码认证状态
    12: optional ContactWayVerifySource phonenumber_verify_source; // 手机号码认证渠道
}


struct TaxValue {
    1: optional list<string> sez;     // sez税号 敏感资源的fileId的列表
    2: optional map<string, string> other_taxs;  //其他税号,key代表具体税号名称，如gstin，pan.. value代表对应税号
}

struct CreateAdvAccountRequest {
    1: optional Auth auth;                             // 必须，调用认证
    2: optional CreateAdvQulification qulification     // 开户相关资质
    3: optional ContacterInfo contacter_info           // 广告主相关联系人
    4: optional AdvertiserOrigin origin;               // 广告主来源, 必须，举详见AdvertiserOrigin
    5: optional AdvertiserRole role;                   // 广告主角色类型，必须，枚举详见AdvertiserRole
    6: optional string name;                           // 广告主名称，注意广告主账号里名称唯一性，默认"广告主-advid"
    7: optional string timezone;                       // 广告主时区,必须,Australia/Broken_Hill
    8: optional string currency;                       // 广告主币种，必须
    9: optional string country;                        // 广告主注册地，必须Mexico => MX，ISO 3166-2相应代码
    10: optional i64 customer_id;                      // 客户id
    11: optional i64 core_user_id;                     // passport登陆用户id
    12: optional AdvAccountType account_type;          // 必须，广告主投放类型，详见AdvAccountType
    13: optional string address_detail;                 // 广告主开票地址
    14: optional TaxValue tax_value;                    // 广告主税号
    15: optional QualificationSource qualification_source; // 资质类型
    16: optional i16 bc_status;                         // 共享bc的状态
    17: optional string company;                         // 公司名称
    18: optional string second_industry;                    // 二级行业id
    19: optional i64 account_id;
    20: optional i64 bc_id; // bc创建需要传对应的id
    21: optional string extra_id; // 开户链接扩展参数
	22: optional i64 state;   // 州
	23: optional i64 city;    // 城市
	24: optional i64 county;  // 郡

    255: required base.Base Base
}

struct CreateAdvAccountResponse {
    1: required i64 advertiser_id;
    2: optional i64 core_user_id;
    3: optional i64 customer_id; // 已经下线 勿用 背景咨询@gujianqi 用account_id代替customer_id
    4: optional i64 account_id;
    5: optional i64 qualification_id;
    255: base.BaseResp BaseResp
}

struct CheckAdvExistRequest {
    1: optional Auth auth;                          // 必须，调用认证
    2: optional string name;
    255: optional base.Base Base;
}

struct CheckAdvExistResponse {
    1: required bool exist;
    255: base.BaseResp BaseResp
}


struct UpdateAdvContactInfoRequest {
    1: optional Auth auth;                                         // 必须，调用认证
    2: optional i64 advertiser_id;                                 // 必填，需要更新联系方式的广告主id
    3: optional string phonenumber;                                // 注册电话
    4: optional string email;                                      // 注册邮箱
    5: optional string contacter;                                  // 联系人
    6: optional string contacter_email;                            // 联系人邮箱
    7: optional string contacter_telephone;                        // 联系人电话
    8: optional i64 operator_id;                                   // 必须，操作者id，可以用core_user_id或staff_id
    9: optional string phonenumber_country;                        // 注册手机所属国家
    10: optional string contacter_telephone_country;               // 联系人手机所属国家
    11: optional ContactWayVerifyStatus email_verify_status;       // 邮箱认证状态
    12: optional ContactWayVerifySource email_verify_source;       // 邮箱认证渠道
    13: optional ContactWayVerifyStatus phonenumber_verify_status; // 手机号码认证状态
    14: optional ContactWayVerifySource phonenumber_verify_source; // 手机号码认证渠道
    255: optional base.Base Base;
}

struct UpdateAdvContactInfoResponse {
    255: base.BaseResp BaseResp;
}

struct GetAdvContactInfoRequest {
    1: i64 advertiser_id;                  // 广告主id
    2: optional Auth auth;                 // 必须，调用认证
    3: optional i64 operator_id;          // 必须，操作者id，可以用core_user_id或staff_id
    255: required base.Base Base;
}

struct GetAdvContactInfoResponse {
    1: optional AdvContactInfo contact_info;
    255: base.BaseResp BaseResp;
}

struct GetAdvSensitiveContactInfoRequest {
    1: i64 advertiser_id;                  // 广告主id
    2: optional Auth auth;                 // 必须，调用认证
    3: optional i64 operator_id;          // 必须，操作者id，可以用core_user_id或staff_id
    255: required base.Base Base;
}


struct GetAdvSensitiveContactInfoResponse {
    1: optional AdvContactInfo contact_info;
    255: base.BaseResp BaseResp;
}


struct MultiGetAdvContactInfoRequest {
    1: required list<i64> advertiser_ids;   // 广告主id集合，上限100个
    2: optional Auth auth;                 // 必须，调用认证
    3: optional i64 operator_id;          // 必须，操作者id，可以用core_user_id或staff_id
    255: required base.Base Base;
}

struct MultiGetAdvContactInfoResponse {
    1: optional list<AdvContactInfo> contact_infos;
    255: base.BaseResp BaseResp;
}

struct MultiGetAdvSensitiveContactInfoRequest {
    1: required list<i64> advertiser_ids;   // 广告主id集合，上限100个
    2: optional Auth auth;                 // 必须，调用认证
    3: optional i64 operator_id;          // 必须，操作者id，可以用core_user_id或staff_id
    255: required base.Base Base;
}

struct MultiGetAdvSensitiveContactInfoResponse {
    1: optional list<AdvContactInfo> contact_infos;
    255: base.BaseResp BaseResp;
}


// 资质证明图片
struct QualificationImgItem {
    1: required string qualification = "";  //已废弃 资质图片地址, tos key格式, 格式参考 bucket/toskey=ad-site-i18n/201906205d0deb3c30d832d0458a847e
    2: optional i64 id;                //资质id，新增资质没有id，修改资质要填写原有资质id
    3: optional string qualification_file_id  // 资质地址，敏感资质托管file_id, 格式参考 e7cdec75-5bbc-4aee-a208-fe8d43f87d9a
}

// 资质更新接口
// 字段6 qualifications 为全量覆盖更新，即广告主已有的资质id不在qualifications中会被删除掉
struct UpdateAdvQualificationsRequest {
    1: optional Auth auth;                                  // 必须，调用认证
    2: required i64 advertiser_id;                          // 必须，需要更新资质的广告主id
    3: optional string promotion_link;                      // 推广链接,不填则不更新，填空会置空
    4: optional list<string> sez_uri;                       // 已废弃 国际化自助广告主sez税号，不填则不更新，填空会置空。形式为图片http地址
    5: optional LicenseQulification license_qulification;  // 营业执照信息，不填则不更新，填空会置空
    6: optional list<QualificationImgItem> qualifications; // 资质证明图片，格式 资质id-资质证明图片地址，不填则不更新，填空会置空。
    7: optional i64 operator_id;                            // 必须，操作者id，可以用core_user_id或staff_id
    8: optional bool need_submit_task;                     // 是否需要将资质送审到认证中心，如果填true，会将更新后的资质进行送审。不填或者false则不进行资质送审
    9: optional list<string> sez_file_ids;     // 国际化自助广告主sez税号，不填则不更新，填空会置空。形式为敏感资源托管file_id
    10: optional i16 qualification_source; // 详细见QualificationSource enum 资质类型 不需要改变账号资质来源勿填
    11: optional bool okStatus;             // true表示本次修改后资质状态记为ok；而不是送审中。转户专用
    255: base.Base Base;
}

struct UpdateAdvQualificationsResponse {
    255: base.BaseResp BaseResp;
}

struct GetAdvTaxRequest {
    1: optional Auth auth;                                  // 必须，调用认证
    2: required i64 advertiser_id;                          // 必须，需要更新资质的广告主id
    3: optional i64 operator_id;                            // 必须，操作者id，可以用core_user_id或staff_id
    4: optional string lang;                                // 可选，语种
    255: base.Base Base;
}

struct BillingAddressInfo {
    1: optional string completeBillingAddress   // 合同上完整的开票地址, 拼接后的开票地址（ sourceBillingAddress[,city][,county][,state][,country][,postcode]）
    2: optional string billingCountryCode       // 开票国家Code US/JP等
    3: optional i64 country;                // 一级地区ID（Country、State、[County]、City）
    4: optional i64 state;                // 二级地区ID（Country、State、[County]、City）
    5: optional i64 county;                // 三级地区ID（Country、State、[County]、City）
    6: optional i64 city;                // 四级地区ID（Country、State、[County]、City）
    7: optional string sourceBillingAddress   // 用户填写的开票地址
    8: optional string postcode;
}

struct GetAdvTaxResponse {
    1: optional TaxValue tax_value;         //广告主税号数据
    2: optional i64 tax_type;              //广告主税务身份 参考AdvertiserTaxType
    3: optional string tax_id;            //广告主税务id
    4: optional QualificationStatus tax_status; // 税务状态
    5: optional string tax_reject_reason;          // 税务审核拒审理由
    6: optional i64 tax_audit_time;                // 最新的审核时间，对于部分存量数据，taxAuditTime=0
    7: optional i64 first_reject_time;             // 第一次审核拒绝时间
    8: optional BillingAddressInfo billingAddressInfo;
    255: base.BaseResp BaseResp;
}

struct AdvQualification {
    1: optional i64 qualification_id;                       //资质id
    2: optional i16 qualification_type;                     // 资质类型，资质类型参考QualificationType
    3: optional i16 qualification_status;                   // 资质状态，资质类型参考QualificationStatus
    4: optional string promotion_link;                      // 推广链接,type = 0 时有这项
    5: optional list<string> sez_uris;                       // 国际化自助广告主sez税号，type = 4 时有这项
    6: optional LicenseQulification license_qulification;   // 营业执照信息 type = 1时有这项
    7: optional list<QualificationImgItem> qualifications;  // 资质证明图片，type = 2时有这项
    8: optional string reason;                               //拒审理由
    9: optional list<string> sez_file_ids // 国际化自助广告主sez税号，敏感资质托管file_id,格式参考 e7cdec75-5bbc-4aee-a208-fe8d43f87d9a

}

struct GetAdvQualificationsRequest {
    1: optional Auth auth;                                  // 必须，调用认证
    2: optional i64 advertiser_id;                          // 必须，需要查询资质的广告主id
    3: optional i64 operator_id;                            // 必须，操作者id，可以用core_user_id或staff_id
    4: optional QualificationType qualification_type;       // 选填，没有则代表查询所有类型资质，有代表查询广告主指定类型的资质，资质类型参考QualificationType
    5: optional QualificationStatus qualification_status;   // 选填，没有则代表查询所有状态资质，有代表查询广告主指定状态的资质，资质状态参考QualificationStatus
    255: base.Base Base;
}

struct GetAdvQualificationsResponse {
    1: optional list<AdvQualification> qualifications;      //资质数据
    2: optional i64 reuseAccountId; //复用了哪个adv的资质。目前只有虚客复用资质的场景存在值
    255: base.BaseResp BaseResp;
}

struct GetAdvCompanyCreditResquest {
    1: optional Auth auth;
    2: optional i64 advertiser_id; /* 广告主id */
    255: base.Base Base;
}

struct GetAdvCompanyCreditResponse {
   1: optional i64 customer_type_value;   // 104为非中国区自助用户 客户类型，详情参见CustomerTypeValue
   2: optional string company_credit_id;     // 唯一标识 国家名称加公司名称后base64编码
   3: optional i16 status; // 公司认证状态 3为认证成功 详情参见 AuditStatus
   4: optional string company_name; //认证公司名称
   5: optional i16 role; // 枚举详见AdvertiserRole, 广告主身份
   255: base.BaseResp BaseResp;
}

struct GetAdvAgentQuestionRequest{
    1: optional Auth auth;
    2: optional i64 advertiser_id; /* 广告主id */
   255: base.Base Base;
}

struct GetAdvAgentQuestionResponse{
    1: optional i64 advertiser_id; /* 广告主id */
    2: optional bool agency;  /* 是否是代理商身份 */
    3: optional i16 company_size; /* 公司规模大小 CompanySize */
    4: optional i16 monthly_budget; /* 每月花费预算 MonthlyBudget */
    5: optional bool is_submit; /* 是否提交问卷 */
    255: base.BaseResp BaseResp;
}

struct UpdateAdvAgentQuestionRequest{
     1: optional Auth auth;
     2: optional i64 advertiser_id; /* 广告主id */
     3: optional bool agency;  /* 是否是代理商身份 */
     4: optional i16 company_size; /* 公司规模大小 */
     5: optional i16 monthly_budget; /* 每月花费预算 */
     255: base.Base Base;
}

struct UpdateAdvAgentQuestionResponse{
    1: optional i64 advertiser_id;
    255: base.BaseResp BaseResp;
}

struct UpdateInternalAccountRoleRequest {
    1: required Auth auth;
    2: required i64 advertiser_id;
    3: required i64 operator_id;
    4: required i64 operator_staff_id;
    255: optional base.Base Base;
}

struct UpdateInternalAccountRoleResponse {
    255: base.BaseResp BaseResp;
}

struct UpdateAdvAccountRequest {
    1: optional Auth auth;
    2: optional i64 advertiser_id;
    3: optional i64 operator_id;
    4: optional string name;
    5: optional i64 state;
    6: optional i64 city;
    7: optional string address_detail;
    8: optional string post_code;
    9: optional string company;
    10: optional string language;
    11: optional i64 county;
    12: optional string second_industry_id;
    13: optional string payer_name;
    255: base.Base Base;
}

struct UpdateAdvAccountResponse {
    255: base.BaseResp BaseResp;
}

struct UpdateAdvTaxInfoRequest {
    1: optional Auth auth;
    2: optional i64 advertiser_id;
    3: optional i64 operator_id;
    4: optional AdvertiserTaxType tax_type;
    5: optional TaxValue tax_value;
    6: optional string lang;
    255: optional base.Base Base;
}

struct UpdateAdvTaxInfoResponse {
    255: base.BaseResp BaseResp
}

struct SelfBindAdvAccountRequest {
    1: optional Auth auth;
    2: optional i64 advertiser_id;
    3: optional i64 operator_id;
    4: optional string second_industry_id;
    5: optional PaymentType payment;
    255: optional base.Base Base;
}

struct SelfBindAdvAccountResponse {
    255: base.BaseResp BaseResp
}

enum CustomerType {
    ACTIVE = 1;
    AGENT = 2;
}

struct SyncI18nApprovedContractRequest {
    1: required Auth auth;
    2: required i64 contract_id;
    3: required i64 customer_id;
    4: required string serial; # 合同编号
    5: required CustomerType cus_type;
    6: required string start_time;
    7: required string end_time;
    8: required i64 ou; # 投放签约主体
    9: required i32 bid_paymethod_category; # 竞价支付方式：1=预付，2=授信
    10: required i32 non_bid_paymethod_category; # 非竞价支付方法：1=预付，2=授信
    11: optional i16 post_pay_meyhod; # 合同后付款方式: 0=发票回款，1=自动扣费
    255: required base.Base Base;
}

struct SyncI18nApprovedContractV2Request {
    1: required i64 contract_id;
    2: required i64 account_id; // gcrm id
    3: required i32 bid_paymethod_category; # 竞价支付方式：1=预付，2=授信
    4: required i32 non_bid_paymethod_category; # 非竞价支付方法：1=预付，2=授信
    5: optional i16 post_pay_meyhod; # 合同后付款方式: 0=发票回款，1=自动扣费
    6: optional list<i64> advertiser_ids; # adv id 用来处理account级联更新adv后传入分片键
    255: required base.Base Base;
}

struct SyncI18nApprovedContractResponse {
    255:base.BaseResp BaseResp;
}

struct TransferAdvAccountRequest {
    1: optional Auth auth;                        # auth校验，必填
    2: required list<i64> advertiser_ids;         # 发起转户的广告主id列表，必填，上限100
    3: required TransferType transfer_type;       # 发起转户的广告主类型，必填
    4: required i64 transfer_cusid;               # 发起转户后的客户id，必填
    5: required i64 operator_id;                  # 操作者用户id
    6: required i64 operator_staff_id;            # 操作者员工号
    255: required base.Base Base;
}

struct TransferAdvAccountResponse {
    1: optional list<AdvOperationItem> operation_items;  // 操作结果，id-result-massage
    255:base.BaseResp BaseResp;
}

struct TransferAdvAccountV2Request {
    1: required list<i64> advertiser_ids;         # 发起转户的广告主id列表，必填，上限100
    2: required TransferType transfer_type;       # 转户类型，必填
    3: required i64 transfer_account_id;          # 目标account id，必填
    4: optional i64 transfer_customer_id;         # 目标customer id
    5: required i64 operator_id;                  # 操作者用户id
    6: required i64 operator_staff_id;            # 操作者员工号
    255: required base.Base Base;
}

struct TransferAdvAccountV2Response {
    1: optional list<AdvOperationItem> operation_items;  // 操作结果，id-result-massage
    255:base.BaseResp BaseResp;
}

struct HandleCrmInfoChangeRequest {
    1: optional Auth auth;
    2: required i64 customer_id;
    3: optional i64 account_id;
    4: optional i64 adv_id;
    255: optional base.Base Base;
}
struct HandleCrmInfoChangeResponse {
    255: base.BaseResp BaseResp;
}

struct QualificationAuditInfo {
    1: required AuditStatus audit_status;
    2: required string audit_time;
    3: optional string reject_reason;
    4: required string qualification_id;
    5: required i64 category;
}

struct HandleAdvAuditRequest {
    1: optional Auth auth;
    2: required i64 advertiser_id;
    3: required i64 operator_id;
    4: required string serial_no;
    5: required AuditStatus audit_status;
    6: required string reject_reason;
    7: required list<QualificationAuditInfo> qualification_audit_info;
    8: required string msg;
    255: optional base.Base Base;
}

struct HandleAdvAuditResponse {
    1: AdvertiserStatus status;    # 审核处理后广告主状态
    255: base.BaseResp BaseResp;
}

struct FixAdvStatusRequest {
    1: optional Auth auth;
    2: required i64 advertiser_id;
    255: optional base.Base Base;
}
struct FixAdvStatusResponse {
    1: AdvertiserStatus status;
    255: base.BaseResp BaseResp;
}

struct HandleContractMsgRequest {
    1: optional Auth auth;
    2: required i64 customer_id;
    3: required i16 customer_type
    4: required i16 con_account_type;
    5: required i16 consumption_change;
    6: optional i64 account_id;
    255: optional base.Base Base;
}

struct  HandleContractMsgResponse {
    255:base.BaseResp BaseResp;
}

struct MultiGetAdvSubjectInfoRequest{
  1: required list<i64> advertiser_ids;              // 一次上限最多100
  2: optional Auth auth;                             // 必须，调用认证
  3: optional bool read_master;         //true查询走主库,非强一致性场景不要传此参数
  4: optional bool need_payer;          // 是否必须需要查询payer信息，只有true时一定会返回payer_name，false时该字段可能无值

  255: base.Base Base;

}

struct AdvertiserSubjectInfo {
    1: required i64 id;                      // 账号ID
    2: optional string currency;             // 广告主币种编码，如JPY/INR/GBP/HKD等
    3: optional string timezone;             // 广告主时区 Etc/GMT+0
    4: optional string display_timezone;     // 广告主时区 Europe/London 仅做展示使用
    5: optional string create_time;          // 创建时间，格式 '2018-01-26 10:45:25'
    6: optional i16 account_type;            // 广告主投放类型，详见AdvAccountType
    7: optional string country;              // 广告主注册地，默认值为us，ISO 3166-2相应代码，例如Mexico => MX
    8: optional i16 origin;                  // 举详见AdvertiserOrigin，广告主来源
    9: optional i16 status;                  // 枚举详见AdvertiserStatus，广告主状态，0-已禁用，1-待审核，2-待邮箱验证，3-审核失败/可再次申请，4-已审核，5-CRM审核失败/最终状态，6-修改审核，7-修改审核失败，8-惩罚限制，9-等待CRM审核，10-资质待提交，12-SMB客户待合同生效，13-SMB广告主待缴纳开户费，14-待对公验证
    10: optional i16 role;                   // 枚举详见AdvertiserRole, 用户身份
    11: optional i64 customer_id;            // 客户ID 已经下线勿用!!! 背景咨询@gujianqi 用account_id代替customer_id
    12: optional i16 customer_type_value;    // 客户类型，详情参见CustomerTypeValue
    13: optional i64 second_industry_id;     // 行业3.0 二级id
    14: optional string name; // 广告主名称
    15: optional i64 account_id;  // gcrm 实体id 标志唯一公司实体
    16: optional string payer_name;          // 广告默认payer name
}

struct MultiGetAdvSubjectInfoResponse{
  1: optional map<i64, AdvertiserSubjectInfo> advertisers;
 255:base.BaseResp BaseResp;

}

struct CountryCurrency {
    1: required string country;
    2: required list<string> currency;
}

struct GetCountryCurrencyConfResponse {
    1: optional list<CountryCurrency> country_currency; //国家与可用币种映射
    255: base.BaseResp BaseResp;
}

struct GetCountryCurrencyConfRequest {
    1:optional Auth auth;
    255: required base.Base Base;
}

struct Industry {
    1: optional string industry_id;
    2: optional string industry_name;
}

struct NonForbiddenIndustry {
    1: optional string first_industry_name;
    2: optional list<Industry> second_industries;
}

struct ForbiddenIndustry {
    1: optional string type_name;
    2: optional list<Industry> industry;
}

struct GetSelfServeIndustryConfResponse {
    1: optional list<NonForbiddenIndustry> non_forbidden_industry;
    2: optional ForbiddenIndustry forbidden_industry;
    255: base.BaseResp BaseResp;
}

struct GetSelfServeIndustryConfRequest {
    1: optional Auth auth;
    2: optional string lang;
    255: required base.Base Base;
}

struct SelfAccountSubmitQualificationRequest {
    1: optional Auth auth;                             // 必须，调用认证
    2: optional i64 advertiser_id;
    3: optional i64 operator_id;
    4: optional string description;
    5: optional bool agency;
    6: optional i64 state;
    7: optional i64 city;
    8: optional string address_detail;
    9: optional string post_code;
    10: required AdvertiserTaxType tax_type;
    11: optional TaxValue tax_value;
    12: optional string company;
    13: optional ContacterInfo contacter_info;
    14: optional string second_industry_id;
    15: required PaymentType payment;
    16: optional string risk_info;
    17: optional i64 county;

    255: required base.Base Base;
}

struct SelfAccountSubmitQualificationResponse {
    255: base.BaseResp BaseResp;
}

struct ValidateSelfServeTaxResponse {
    1: optional i64 code;
    2: optional string message;
    255: base.BaseResp BaseResp;
}

struct ValidateSelfServeTaxRequest {
    1: optional Auth auth;
    2: optional string country;
    3: optional i16 tax_type;
    4: optional map<string, string> tax_value;
    255: required base.Base Base;
}

struct SubmitAuditTaskRequest{
    1: optional Auth auth;
    2: required i64 advertiser_id;
    3: optional string lang;
    255: base.Base Base;
}

struct SubmitAuditTaskResponse{
    255:base.BaseResp BaseResp;
}

struct HandleAsyncMsgRequest{
    1: required EventType event_type;
    2: optional string msg;
    255: required base.Base Base;
}

struct HandleAsyncMsgResponse{
    255: required base.BaseResp BaseResp;
}

struct WebIdSdkApiRequest {
    1: required string ttwid;         # 解密前的
    255: required base.Base Base;
}

struct WebIdSdkApiResponse {
    1: required i64 webID;  // 解密后的
    255:base.BaseResp BaseResp;
}

struct HandleCertificationMsgRequest {
    1: required i64 platform;
    2: required i64 accountID;
    3: required i16  accountType;
    4: required i16  relationType;
    5: required i16  qualificationStatus;
    6: required i64 qualificationID;
    7: required i16  qualificationType;
    8: required string reason;
    255: required base.Base Base;
}

struct HandleCertificationMsgResponse {
    255: required base.BaseResp BaseResp;
}

service AccountService {
    # account
    # 创建广告主
    CreateAdvAccountResponse CreateAdvAccount(1: CreateAdvAccountRequest req);
    # 更新广告主基本信息
    UpdateAdvAccountResponse UpdateAdvAccount(1: UpdateAdvAccountRequest req);

    # 更新广告主基本信息
    UpdateAdvAccountResponse UpdateAdvAccountWhiteList(1: UpdateAdvAccountRequest req);

    # 更新广告主税务信息
    UpdateAdvTaxInfoResponse UpdateAdvTaxInfo(1: UpdateAdvTaxInfoRequest req);
    # 自助挂接客户
    SelfBindAdvAccountResponse SelfBindAdvAccount(1: SelfBindAdvAccountRequest req);
    # 根据广告主id查询单个广告主账号信息
    GetAdvAccountByIdResponse GetAdvAccountById(1: GetAdvAccountByIdRequest req);
    /* 批量广告主id获取,上限100 */
    MultiGetAdvResponse MultiGetAdvAccount(1: MultiGetAdvRequest req);
    # 广告主是否存在
    CheckAdvExistResponse CheckAdvExist(1: CheckAdvExistRequest req);

    # 惩罚/解除惩罚广告主
    HandlePunishAdvertiserResponse HandlePunishAdvertiser(1: HandlePunishAdvertiserRequest req);
    /* 获取广告主有效惩罚记录*/
    GetAdvPunishResponse GetAdvPunish(1: GetAdvPunishRequest req);
     # 获取广告主惩罚日志， 默认按照创建时间降序排序
    GetAdvPunishLogResponse GetAdvPunishLog(1: GetAdvPunishLogRequest req);

    # 禁用广告主
    DisableAdvertiserResponse DisableAdvertiser(1: DisableAdvertiserRequest req);

    ############################# 提供风控 #############################
    /* 风控因子回调查询 */
    GetAdvInfoForSharkResponse GetAdvInfoForShark(1: GetAdvInfoForSharkRequest req);
    ############################# 提供风控  #############################

    ############################# 接入应用与认证 #############################
    /* 增加广告主接入应用 */
    AddApplicationResponse AddApplication(1: AddApplicationRequest req)
    /* list广告主接入应用 */
    ListApplicationResponse ListApplication(1: ListApplicationRequest req)

    /* 增加应用接口权限 */
    AddInterfaceAclResponse AddInterfaceAcl(1: AddInterfaceAclRequest req)
    /* list应用接口权限 */
    ListInterfaceAclResponse ListInterfaceAcl(1: ListInterfaceAclRequest req)
    ############################# 接入应用与认证  #############################


    ############################# 广告主联系方式相关操作 #############################
    /* 更新联系方式接口 */
    UpdateAdvContactInfoResponse UpdateAdvContactInfo(1:UpdateAdvContactInfoRequest req);

    /* 查询联系方式接口，返回信息均为脱敏信息 */
    GetAdvContactInfoResponse GetAdvContactInfo(1:GetAdvContactInfoRequest req);
    /* 查询联系方式接口，返回信息均为明文 */
    GetAdvSensitiveContactInfoResponse GetAdvSensitiveContactInfo(1:GetAdvSensitiveContactInfoRequest req);

    /* 批量查询联系方式接口，返回信息均为脱敏信息 */
    MultiGetAdvContactInfoResponse MultiGetAdvContactInfo(1:MultiGetAdvContactInfoRequest req);
    /* 批量查询联系方式接口，返回信息均为明文 */
    MultiGetAdvSensitiveContactInfoResponse MultiGetAdvSensitiveContactInfo(1:MultiGetAdvSensitiveContactInfoRequest req);
    ############################# 广告主联系方式相关操作 #############################

    ############################# 广告主资质相关操作 #############################
    /* 更新资质接口 */
    UpdateAdvQualificationsResponse UpdateAdvQualifications(1: UpdateAdvQualificationsRequest req)

    /* 查询资质接口 */
    GetAdvQualificationsResponse GetAdvQualifications(1: GetAdvQualificationsRequest req)
    ############################# 广告主资质相关操作 #############################

    /* 税号数据查询接口 */
    GetAdvTaxResponse GetAdvTax(1: GetAdvTaxRequest req)

    /* SMB查询公司认证状态 */
    GetAdvCompanyCreditResponse GetCompanyCredit(1: GetAdvCompanyCreditResquest req)

     /* 查询广告主是否是代理商和问卷信息 */
    GetAdvAgentQuestionResponse GetAdvAgentQuestion(1:GetAdvAgentQuestionRequest req)

    /* 更新代理商广告主问卷信息 */
    UpdateAdvAgentQuestionResponse UpdateAdvAgentQuestion(1:UpdateAdvAgentQuestionRequest req)

    /* 查询广告主信息缓存，对于不变字段，高QPS请求建议走该接口 */
    MultiGetAdvCacheResponse MultiGetAdvAccountCache(1: MultiGetAdvCacheRequest req);

    /* 更新为内广账户角色 */
    UpdateInternalAccountRoleResponse UpdateInternalAccountRole(1: UpdateInternalAccountRoleRequest req);

    // 过审后付合同同步
    SyncI18nApprovedContractResponse SyncI18nApprovedContract(1: SyncI18nApprovedContractRequest req)

    // 支付方式同步 v2 临时接口
    SyncI18nApprovedContractResponse SyncI18nApprovedContractV2(1: SyncI18nApprovedContractV2Request req)

    /* 转移广告主账户, 直客，虚客，自助互转 */
    TransferAdvAccountResponse TransferAdvAccount(1: TransferAdvAccountRequest req)

    TransferAdvAccountV2Response TransferAdvAccountV2(1: TransferAdvAccountV2Request req)

    /* 客户信息变更 */
    HandleCrmInfoChangeResponse HandleCrmInfoChange(1: HandleCrmInfoChangeRequest req)

    /* 处理审核结果 */
    HandleAdvAuditResponse HandleAdvAudit(1: HandleAdvAuditRequest req)

    /* 修正广告主状态 */
    FixAdvStatusResponse FixAdvStatus(1: FixAdvStatusRequest req)

    /*  合同到期or生效  */
    HandleContractMsgResponse HandleContractMsg(1: HandleContractMsgRequest req)

    /* 批量查询广告主主体信息 接口使用缓存 性能高 */
    MultiGetAdvSubjectInfoResponse  MultiGetAdvSubjectInfo(1: MultiGetAdvSubjectInfoRequest req)

    /* 获取国家币种映射配置 */
    GetCountryCurrencyConfResponse GetCountryCurrencyConf(1: GetCountryCurrencyConfRequest req);

    /* 获取自助行业配置 */
    GetSelfServeIndustryConfResponse GetSelfServeIndustryConf(1: GetSelfServeIndustryConfRequest req);

    /* 校验税务信息 */
    ValidateSelfServeTaxResponse ValidateSelfServeTax(1: ValidateSelfServeTaxRequest req)

    /* 自助补全资质 */
    SelfAccountSubmitQualificationResponse SelfAccountSubmitQualification(1: SelfAccountSubmitQualificationRequest req)

    /* 资质送审 */
    SubmitAuditTaskResponse SubmitAuditTask(1: SubmitAuditTaskRequest req)

    /* 异步消息处理 */
    HandleAsyncMsgResponse HandleAsyncMsg(1: HandleAsyncMsgRequest req);

    /* 封装风控sdk */
    WebIdSdkApiResponse WebIdSdkApi(1: WebIdSdkApiRequest req)

    HandleCertificationMsgResponse HandleCertificationMsg(1: HandleCertificationMsgRequest req)
}
