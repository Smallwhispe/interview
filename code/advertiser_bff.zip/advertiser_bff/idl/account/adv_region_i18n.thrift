include "idl/base.thrift"

namespace go ad.platform.region
namespace py ad.platform.region

enum BusinessType {
   PROMOTE = 1,
   PLATFORM = 2,
}

struct GetIDCByCountryRequest {
   1: required string Country, // countryCode
   2: optional BusinessType BusinessType, // PROMOTE or PLARFORM ; default = PLATFORM
   3: optional i16 role,
   4: optional i16 origin,
   5: optional i16 qualification_source,
   255: optional base.Base Base,
}

struct GetIDCByCountryResponse {
   1: required string IDC, // 国家映射机房的IDC
   255: optional base.BaseResp BaseResp,
}

enum EntityType {
    ADVERTISER = 1
    BC = 2
    CAMPAIN = 3
    AD = 4
    CREATIVE = 5
    TBP = 6
}

enum StatusType {
    STOP_WRITE = 1
    NORMAL = 2
}

struct EntityRegion {
   1: required string TargetIDC, // 当前数据应写入的idc
   2: required string OriginIDC, // 原始数据所在idc
   3: required StatusType Status, // 停写中 or 正常
   4: optional i64 AdvID, // 户口对应的广告主ID

}

struct Entity {
  1: optional i64 Id, //实体id
  2: required EntityType Type, //实体类型
  3: optional string PrimaryKey, //TBP 类型需传该KEY
}

struct GetRegionInfoRequest {
  1: required Entity Entity,
  255: optional base.Base Base,
}

struct GetRegionInfoResponse {
  1: optional EntityRegion EntityRegion,
  255: optional base.BaseResp BaseResp,
}

struct MultiGetRegionInfoRequest {
  1: required list<i64> Entities, // 最大数量: 100
  2: required EntityType Type, //实体类型
  255: optional base.Base Base,
}

struct MultiGetRegionInfoResponse {
  1: optional map<i64, EntityRegion> EntityRegions,
  255: optional base.BaseResp BaseResp,
}

struct GraySwitchRequest {
  1: required Entity Entity,
  255: optional base.Base Base,
}

struct GrayInfo {
  1: required bool Gray, //是否在灰度白名单内 true=命中
  2: optional i64 AdvId, //实体关联的广告主id
}

struct GraySwitchResponse {
  1: required GrayInfo GrayInfo,
  255: optional base.BaseResp BaseResp,
}


service RegionService {

GetIDCByCountryResponse GetIDCByCountry (1: GetIDCByCountryRequest request),

GetRegionInfoResponse GetRegionInfo(1: GetRegionInfoRequest request),

MultiGetRegionInfoResponse MultiGetRegionInfo(1: MultiGetRegionInfoRequest request),

GraySwitchResponse GraySwitch(1: GraySwitchRequest request),

}
