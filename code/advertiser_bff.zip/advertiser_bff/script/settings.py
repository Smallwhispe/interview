# coding: utf-8

PRODUCT="ad"
SUBSYS="advertiser"
MODULE="bff"

APP_TYPE="binary"
