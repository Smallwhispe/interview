module code.byted.org/ad/advertiser_bff

go 1.18

require (
	code.byted.org/ad/bc_core_sdk v1.0.5-0.20250925165915-d2f56088ae9e
	code.byted.org/ad/common_mw_lib v0.0.25
	code.byted.org/ad/mwlib v0.1.16
	code.byted.org/gopkg/env v1.6.18
	code.byted.org/gopkg/lang v0.21.6
	code.byted.org/gopkg/logs v1.2.25
	code.byted.org/gopkg/metrics v1.4.25
	code.byted.org/gopkg/mockito v1.3.0
	code.byted.org/gopkg/tccclient v1.6.0
	code.byted.org/kite/kitex v1.18.0
	code.byted.org/kitex/apache_monitor v0.1.1
	code.byted.org/lang/gg v0.17.0
	code.byted.org/luoshiqi/mockito v1.4.0
	code.byted.org/middleware/hertz v1.13.1
	code.byted.org/middleware/hertz_ext/v2 v2.1.6
	code.byted.org/passport/session_lib v1.10.11-hertz-v1
	github.com/apache/thrift v0.16.0
	github.com/cloudwego/gopkg v0.1.3
	github.com/cloudwego/hertz v0.9.2
	github.com/cloudwego/kitex v0.12.0
	github.com/cloudwego/kitex/pkg/protocol/bthrift v0.0.0-20241121032620-4e238714e458
	github.com/golang/mock v1.6.0
	github.com/smartystreets/goconvey v1.8.1
	github.com/spf13/viper v1.9.0
	golang.org/x/sync v0.11.0
)

require (
	code.byted.org/ad/adv_common_i18n v0.0.0-20230302035401-5b65368b6d2a // indirect
	code.byted.org/ad/error_code v1.0.1 // indirect
	code.byted.org/aiops/apm_vendor_byted v0.0.27 // indirect
	code.byted.org/aiops/metrics_codec v0.0.24 // indirect
	code.byted.org/aiops/monitoring-common-go v0.0.4 // indirect
	code.byted.org/aweme-go/hstruct v0.1.0 // indirect
	code.byted.org/bytedance/app_determination v1.0.4 // indirect
	code.byted.org/bytedance/framework_context v0.0.3 // indirect
	code.byted.org/bytedance/framework_context/ginex_framework_context v0.0.3 // indirect
	code.byted.org/bytedance/framework_context/hertz_v1_framework_context v0.0.3 // indirect
	code.byted.org/bytedance/framework_context/http v0.0.1 // indirect
	code.byted.org/bytedtrace/bytedtrace-client-go v1.2.2 // indirect
	code.byted.org/bytedtrace/bytedtrace-common/go v0.0.13 // indirect
	code.byted.org/bytedtrace/bytedtrace-compatible-client-go v0.0.16 // indirect
	code.byted.org/bytedtrace/bytedtrace-conf-provider-client-go v0.0.26 // indirect
	code.byted.org/bytedtrace/bytedtrace-gls-switch v1.3.0 // indirect
	code.byted.org/bytedtrace/interface-go v1.0.22 // indirect
	code.byted.org/bytedtrace/serializer-go v1.0.0 // indirect
	code.byted.org/cpputil/model v0.0.0-20250725100153-b366e609d508 // indirect
	code.byted.org/gin/ginex v1.8.0 // indirect
	code.byted.org/golf/consul v2.1.13+incompatible // indirect
	code.byted.org/golf/ssconf v0.0.1 // indirect
	code.byted.org/gopkg/apm_vendor_interface v0.0.3 // indirect
	code.byted.org/gopkg/asynccache v0.0.0-20210422090342-26f94f7676b8 // indirect
	code.byted.org/gopkg/circuitbreaker v3.8.1+incompatible // indirect
	code.byted.org/gopkg/confx v0.9.14 // indirect
	code.byted.org/gopkg/confx/core v0.9.13 // indirect
	code.byted.org/gopkg/confx/loader v0.5.2 // indirect
	code.byted.org/gopkg/confx/loader/tcc v0.5.3 // indirect
	code.byted.org/gopkg/confx/parser v0.2.1 // indirect
	code.byted.org/gopkg/consul v1.2.6 // indirect
	code.byted.org/gopkg/ctxgov v1.0.5 // indirect
	code.byted.org/gopkg/ctxgov/vlite v1.0.6 // indirect
	code.byted.org/gopkg/ctxvalues v0.5.0 // indirect
	code.byted.org/gopkg/debug v0.10.1 // indirect
	code.byted.org/gopkg/etcd_util v2.3.3+incompatible // indirect
	code.byted.org/gopkg/etcdproxy v0.1.1 // indirect
	code.byted.org/gopkg/gopool v0.13.1 // indirect
	code.byted.org/gopkg/idgenerator v1.0.15 // indirect
	code.byted.org/gopkg/jsonx v0.3.0 // indirect
	code.byted.org/gopkg/logid v0.0.0-20241008043456-230d03adb830 // indirect
	code.byted.org/gopkg/logs/v2 v2.1.54 // indirect
	code.byted.org/gopkg/metainfo v0.1.5-0.20230906023549-18ce210d2d75 // indirect
	code.byted.org/gopkg/metrics/v3 v3.1.35 // indirect
	code.byted.org/gopkg/metrics/v4 v4.1.4 // indirect
	code.byted.org/gopkg/metrics_core v0.0.39 // indirect
	code.byted.org/gopkg/net2 v1.5.0 // indirect
	code.byted.org/gopkg/pkg v0.0.0-20210817064112-6fe00340bb36 // indirect
	code.byted.org/gopkg/rand v0.0.0-20200622102840-8cd9b682e5b4 // indirect
	code.byted.org/gopkg/retry v0.0.0-20230209024914-cf290f094aa7 // indirect
	code.byted.org/gopkg/stats v1.2.12 // indirect
	code.byted.org/gopkg/thrift v1.13.0 // indirect
	code.byted.org/hystrix/hystrix-go v0.0.0-20190214095017-a2a890c81cd5 // indirect
	code.byted.org/ies/i18n-sdk-go v0.2.0 // indirect
	code.byted.org/ies/starling-i18n-go v0.2.0 // indirect
	code.byted.org/ies/starling_goclient v0.5.4 // indirect
	code.byted.org/ies/starling_sdk_api_http v0.0.8 // indirect
	code.byted.org/iespkg/bytedkits-go/goext v0.4.0 // indirect
	code.byted.org/iespkg/retry-go v0.1.2 // indirect
	code.byted.org/inf/infsecc v1.0.3 // indirect
	code.byted.org/kite/endpoint v3.7.5+incompatible // indirect
	code.byted.org/kite/kitc v3.10.21+incompatible // indirect
	code.byted.org/kite/kite v3.9.30+incompatible // indirect
	code.byted.org/kite/kitex-overpass-suite v0.0.35 // indirect
	code.byted.org/kite/kitutil v3.8.4+incompatible // indirect
	code.byted.org/kite/rpal v0.1.22 // indirect
	code.byted.org/lang/trace v0.0.3 // indirect
	code.byted.org/lidar/profiler v0.4.4 // indirect
	code.byted.org/lidar/profiler/hertz v0.0.0-20230801111316-7e5562fd8659 // indirect
	code.byted.org/lidar/profiler/kitex v0.4.5 // indirect
	code.byted.org/log_market/gosdk v0.0.0-20230524072203-e069d8367314 // indirect
	code.byted.org/log_market/loghelper v0.1.11 // indirect
	code.byted.org/log_market/tracelog v0.1.5 // indirect
	code.byted.org/log_market/ttlogagent_gosdk v0.0.6 // indirect
	code.byted.org/log_market/ttlogagent_gosdk/v4 v4.0.53 // indirect
	code.byted.org/middleware/fic_client v0.2.8 // indirect
	code.byted.org/middleware/gocaller v0.0.6 // indirect
	code.byted.org/overpass/ad_tt4b_permission_center v0.0.0-20221114160947-c71ef72adaf7 // indirect
	code.byted.org/overpass/common v0.0.0-20240815141408-18f972b75038 // indirect
	code.byted.org/overpass/data_abtest_vm_framed v0.0.0-20230403072604-772068918c41 // indirect
	code.byted.org/overpass/lab_mt_chief v0.0.0-20220808172032-6e87b8345b30 // indirect
	code.byted.org/overpass/tiktok_location_location v0.0.0-20240514033443-5817cf910770 // indirect
	code.byted.org/overpass/tiktok_passport_session_v2 v0.0.0-20250730023705-46b996af20e1 // indirect
	code.byted.org/security/certinfo v1.0.2 // indirect
	code.byted.org/security/cryptoutils v1.1.3 // indirect
	code.byted.org/security/go-spiffe-v2 v1.0.8 // indirect
	code.byted.org/security/gokms-extension v1.0.1 // indirect
	code.byted.org/security/golangope v0.0.1 // indirect
	code.byted.org/security/kms-v2-sdk-golang v1.2.97 // indirect
	code.byted.org/security/memfd v0.0.1 // indirect
	code.byted.org/security/sensitive_finder_engine v0.3.18 // indirect
	code.byted.org/security/spiffe_spire v0.0.0-20201116193931-c566c1c41bdf // indirect
	code.byted.org/security/volc_kms_encryption_sdk/v2 v2.0.7 // indirect
	code.byted.org/security/volczti-helper v1.5.7 // indirect
	code.byted.org/security/zen v0.2.5 // indirect
	code.byted.org/security/zen-ext/profile v0.1.5 // indirect
	code.byted.org/security/zero-trust-identity-helper v1.0.14 // indirect
	code.byted.org/security/zti-jwt-helper-golang v1.0.16 // indirect
	code.byted.org/service_mesh/shmipc v0.2.16 // indirect
	code.byted.org/tiktok/account_fundamental_lib/canary_controller v0.0.11 // indirect
	code.byted.org/tiktok/account_fundamental_lib/framework_context v0.0.4 // indirect
	code.byted.org/tiktok/account_fundamental_lib/framework_context/ginex_framework_context v0.0.4 // indirect
	code.byted.org/tiktok/account_fundamental_lib/framework_context/hertz_v1_framework_context v0.0.4 // indirect
	code.byted.org/tiktok/account_fundamental_lib/framework_context/http v0.0.1-rc.1 // indirect
	code.byted.org/tiktok/account_fundamental_lib/httpadapter v0.0.3-hertz-v1-rc.1 // indirect
	code.byted.org/tiktok/account_fundamental_lib/metrics v0.0.10-rc.1 // indirect
	code.byted.org/tiktok/account_fundamental_lib/sdk_determination v0.0.6 // indirect
	code.byted.org/tiktok/account_fundamental_lib/strings v0.0.5-rc.1 // indirect
	code.byted.org/tiktok/buildinfo v0.0.1 // indirect
	code.byted.org/tiktok/passport_crypto_lib v0.0.3 // indirect
	code.byted.org/tiktok/session_lib_plugin v0.0.0-20240510050858-3c5852169705 // indirect
	code.byted.org/tiktok/tiktok_session_lib v1.9.14-hertz-v1 // indirect
	code.byted.org/tiktok/tiktok_ttwid_lib v1.6.5-hertz-v1 // indirect
	code.byted.org/tiktok/tiktok_user_identity_token_lib v1.2.61 // indirect
	code.byted.org/trace/trace-client-go v1.3.7 // indirect
	code.byted.org/ttarch/lego_client/host v1.16.59 // indirect
	code.byted.org/ucenter/bdsso_sessionlib v1.2.0-hertz-v1 // indirect
	code.byted.org/ucenter/gogo/canary_controller v0.0.1 // indirect
	code.byted.org/ucenter/gogo/datetime v0.0.1 // indirect
	code.byted.org/ucenter/gogo/errors v0.0.1 // indirect
	code.byted.org/ucenter/gogo/httpadapter v0.0.6 // indirect
	code.byted.org/ucenter/gogo/metrics v0.0.1 // indirect
	code.byted.org/ucenter/gogo/strings v0.0.1 // indirect
	code.byted.org/ucenter/gogo/traffic/strategy v0.0.0-20240312023553-fafee75e0115 // indirect
	code.byted.org/ucenter/gogo/values v0.0.0-20240312023354-0b618b3a54bf // indirect
	code.byted.org/ucenter/ttwid_lib v1.6.0-hertz-v1 // indirect
	code.byted.org/ucenter/user_identity_token_lib v1.2.55 // indirect
	github.com/EverythingMe/inbloom v0.0.0-20190617073926-1d67c94ae5dc // indirect
	github.com/Knetic/govaluate v3.0.1-0.20171022003610-9aa49832a739+incompatible // indirect
	github.com/Masterminds/semver v1.5.0 // indirect
	github.com/andres-erbsen/clock v0.0.0-20160526145045-9e14626cd129 // indirect
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/apaxa-go/helper v0.0.0-20180607175117-61d31b1c31c3 // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/bitly/go-simplejson v0.5.0 // indirect
	github.com/bits-and-blooms/bitset v1.13.0 // indirect
	github.com/bits-and-blooms/bloom/v3 v3.6.0 // indirect
	github.com/bluele/gcache v0.0.2 // indirect
	github.com/bytedance/go-tagexpr/v2 v2.9.3 // indirect
	github.com/bytedance/gopkg v0.1.1 // indirect
	github.com/bytedance/mockey v1.2.13 // indirect
	github.com/bytedance/sonic v1.12.5 // indirect
	github.com/bytedance/sonic/loader v0.3.0 // indirect
	github.com/caarlos0/env/v6 v6.2.2 // indirect
	github.com/capitalone/fpe v1.2.1 // indirect
	github.com/cespare/xxhash v1.1.0 // indirect
	github.com/cespare/xxhash/v2 v2.2.0 // indirect
	github.com/choleraehyq/pid v0.0.21 // indirect
	github.com/choleraehyq/rwlock v0.0.13 // indirect
	github.com/cloudwego/base64x v0.1.4 // indirect
	github.com/cloudwego/configmanager v0.2.2 // indirect
	github.com/cloudwego/dynamicgo v0.4.6 // indirect
	github.com/cloudwego/fastpb v0.0.5 // indirect
	github.com/cloudwego/frugal v0.2.3 // indirect
	github.com/cloudwego/iasm v0.2.0 // indirect
	github.com/cloudwego/localsession v0.1.2 // indirect
	github.com/cloudwego/netpoll v0.6.5 // indirect
	github.com/cloudwego/runtimex v0.1.1 // indirect
	github.com/cloudwego/thriftgo v0.3.18 // indirect
	github.com/davecgh/go-spew v1.1.2-0.20180830191138-d8f796af33cc // indirect
	github.com/fatih/color v1.13.0 // indirect
	github.com/fatih/structtag v1.2.0 // indirect
	github.com/fsnotify/fsnotify v1.6.0 // indirect
	github.com/gin-contrib/sse v0.1.0 // indirect
	github.com/gin-gonic/gin v1.8.1 // indirect
	github.com/go-jose/go-jose/v3 v3.0.0 // indirect
	github.com/go-kit/log v0.2.1 // indirect
	github.com/go-logfmt/logfmt v0.5.1 // indirect
	github.com/go-ole/go-ole v1.2.6 // indirect
	github.com/go-playground/locales v0.14.0 // indirect
	github.com/go-playground/universal-translator v0.18.0 // indirect
	github.com/go-playground/validator/v10 v10.10.0 // indirect
	github.com/goccy/go-json v0.9.11 // indirect
	github.com/gogo/protobuf v1.3.2 // indirect
	github.com/golang/protobuf v1.5.4 // indirect
	github.com/google/go-cmp v0.6.0 // indirect
	github.com/google/pprof v0.0.0-20240727154555-813a5fbdbec8 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/gopherjs/gopherjs v1.17.2 // indirect
	github.com/gorilla/mux v1.8.0 // indirect
	github.com/gotnospirit/makeplural v0.0.0-20180622080156-a5f48d94d976 // indirect
	github.com/gotnospirit/messageformat v0.0.0-20221001023931-dfe49f1eb092 // indirect
	github.com/grpc-ecosystem/go-grpc-middleware v1.3.0 // indirect
	github.com/hashicorp/go-hclog v1.2.2 // indirect
	github.com/hashicorp/golang-lru v0.5.4 // indirect
	github.com/hashicorp/hcl v1.0.0 // indirect
	github.com/hbollon/go-edlib v1.6.0 // indirect
	github.com/henrylee2cn/ameda v1.4.10 // indirect
	github.com/henrylee2cn/goutil v0.0.0-20210127050712-89660552f6f8 // indirect
	github.com/hertz-contrib/http2 v0.1.1 // indirect
	github.com/hertz-contrib/localsession v0.1.0 // indirect
	github.com/iancoleman/strcase v0.2.0 // indirect
	github.com/influxdata/influxdb1-client v0.0.0-20220302092344-a9ab5670611c // indirect
	github.com/jhump/protoreflect v1.8.2 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/jtolds/gls v4.20.0+incompatible // indirect
	github.com/jxskiss/base62 v0.0.0-20191017122030-4f11678b909b // indirect
	github.com/klauspost/compress v1.15.9 // indirect
	github.com/klauspost/cpuid/v2 v2.2.5 // indirect
	github.com/kuangchanglang/graceful v1.0.2 // indirect
	github.com/leodido/go-urn v1.2.1 // indirect
	github.com/magiconair/properties v1.8.6 // indirect
	github.com/mattn/go-colorable v0.1.12 // indirect
	github.com/mattn/go-isatty v0.0.17 // indirect
	github.com/matttproud/golang_protobuf_extensions v1.0.1 // indirect
	github.com/miscreant/miscreant.go v0.0.0-20200214223636-26d376326b75 // indirect
	github.com/mitchellh/mapstructure v1.4.2 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/mohae/deepcopy v0.0.0-20170929034955-c48cc78d4826 // indirect
	github.com/nicksnyder/go-i18n/v2 v2.1.1 // indirect
	github.com/nyaruka/phonenumbers v1.0.56 // indirect
	github.com/onsi/ginkgo v1.16.5 // indirect
	github.com/onsi/gomega v1.17.0 // indirect
	github.com/opentracing/opentracing-go v1.2.1-0.20210205174328-3088eee7e4d2 // indirect
	github.com/pelletier/go-toml v1.9.4 // indirect
	github.com/pelletier/go-toml/v2 v2.0.1 // indirect
	github.com/pierrec/lz4/v4 v4.1.15 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/pmezard/go-difflib v1.0.1-0.20181226105442-5d4384ee4fb2 // indirect
	github.com/power-devops/perfstat v0.0.0-20220216144756-c35f1ee13d7c // indirect
	github.com/prometheus/client_golang v1.12.2 // indirect
	github.com/prometheus/client_model v0.4.0 // indirect
	github.com/prometheus/common v0.32.1 // indirect
	github.com/prometheus/procfs v0.7.3 // indirect
	github.com/satori/go.uuid v1.2.1-0.20181028125025-b2ce2384e17b // indirect
	github.com/shirou/gopsutil/v3 v3.22.5 // indirect
	github.com/sirupsen/logrus v1.9.0 // indirect
	github.com/smarty/assertions v1.15.0 // indirect
	github.com/spf13/afero v1.9.2 // indirect
	github.com/spf13/cast v1.4.1 // indirect
	github.com/spf13/jwalterweatherman v1.1.0 // indirect
	github.com/spf13/pflag v1.0.5 // indirect
	github.com/spiffe/spire-api-sdk v1.9.6 // indirect
	github.com/stretchr/testify v1.10.0 // indirect
	github.com/subosito/gotenv v1.2.0 // indirect
	github.com/tidwall/gjson v1.17.3 // indirect
	github.com/tidwall/match v1.1.1 // indirect
	github.com/tidwall/pretty v1.2.0 // indirect
	github.com/twitchyliquid64/golang-asm v0.15.1 // indirect
	github.com/ugorji/go/codec v1.2.7 // indirect
	github.com/yusufpapurcu/wmi v1.2.2 // indirect
	github.com/zeebo/errs v1.3.0 // indirect
	go.mozilla.org/pkcs7 v0.0.0-20210826202110-33d05740a352 // indirect
	go4.org/unsafe/assume-no-moving-gc v0.0.0-20230525183740-e7c30c78aeb2 // indirect
	golang.org/x/arch v0.11.0 // indirect
	golang.org/x/crypto v0.22.0 // indirect
	golang.org/x/net v0.24.0 // indirect
	golang.org/x/sys v0.26.0 // indirect
	golang.org/x/text v0.22.0 // indirect
	golang.org/x/time v0.5.0 // indirect
	google.golang.org/genproto v0.0.0-20231002182017-d307bd883b97 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20231002182017-d307bd883b97 // indirect
	google.golang.org/grpc v1.58.2 // indirect
	google.golang.org/protobuf v1.33.0 // indirect
	gopkg.in/ini.v1 v1.63.2 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

replace github.com/apache/thrift => github.com/apache/thrift v0.13.0
