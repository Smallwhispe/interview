package toolkit

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/ad/advertiser_bff/toolkit/tcc"
	"code.byted.org/gopkg/tccclient"
	"code.byted.org/luoshiqi/mockito"
	"github.com/smartystreets/goconvey/convey"
)

func TestTccGet(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey("TestGet_ok", t, func() {
		mockito.Mock(((*tccclient.ClientV2).Get)).Return("aljl", nil).Build()
		result, err := tcc.Get(ctx, &tccclient.ClientV2{}, "key")
		convey.So(err, convey.ShouldBeNil)
		convey.So(result, convey.ShouldEqual, "aljl")
	})

	mockito.PatchConvey("TestGet_error", t, func() {
		mockito.Mock(((*tccclient.ClientV2).Get)).Return("aljl", errors.New("mock error")).Build()
		_, err := tcc.Get(ctx, &tccclient.ClientV2{}, "key")
		convey.So(err, convey.ShouldNotBeNil)
	})
}

func TestTccGetBoolean(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey("TestGetBoolean_ok", t, func() {
		mockito.Mock(((*tccclient.ClientV2).Get)).Return("true", nil).Build()
		result, err := tcc.GetBoolean(ctx, &tccclient.ClientV2{}, "key")
		convey.So(err, convey.ShouldBeNil)
		convey.So(result, convey.ShouldBeTrue)
	})

	mockito.PatchConvey("TestGetBoolean_error", t, func() {
		mockito.Mock(((*tccclient.ClientV2).Get)).Return("aljl", errors.New("mock error")).Build()
		_, err := tcc.GetBoolean(ctx, &tccclient.ClientV2{}, "key")
		convey.So(err, convey.ShouldNotBeNil)
	})
}

func TestTccGetBooleanWithDefault(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey("TestGetBooleanWithDefault_ok", t, func() {
		mockito.Mock(((*tccclient.ClientV2).Get)).Return("true", nil).Build()
		result := tcc.GetBooleanWithDefault(ctx, &tccclient.ClientV2{}, "key", false)
		convey.So(result, convey.ShouldBeTrue)
	})

	mockito.PatchConvey("TestGetBoolean_error", t, func() {
		mockito.Mock(((*tccclient.ClientV2).Get)).Return("aljl", errors.New("mock error")).Build()
		result := tcc.GetBooleanWithDefault(ctx, &tccclient.ClientV2{}, "key", true)
		convey.So(result, convey.ShouldBeTrue)
	})
}

func TestTccGetAndParse(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey("TestGetBooleanWithDefault_ok", t, func() {
		data := map[string]interface{}{}
		mockito.Mock(((*tccclient.ClientV2).Get)).Return(`{"a":10}`, nil).Build()
		err := tcc.GetAndParse(ctx, &tccclient.ClientV2{}, "key", &data)
		convey.So(err, convey.ShouldBeNil)
		convey.So(data["a"].(float64), convey.ShouldEqual, 10)
	})

	mockito.PatchConvey("TestGetBoolean_error", t, func() {
		mockito.Mock(((*tccclient.ClientV2).Get)).Return("aljl", errors.New("mock error")).Build()
		err := tcc.GetAndParse(ctx, &tccclient.ClientV2{}, "key", nil)
		convey.So(err, convey.ShouldNotBeNil)
	})
}
