package toolkit

import (
	"testing"

	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"github.com/smartystreets/goconvey/convey"
)

func TestUTC2LocalTime(t *testing.T) {
	var testcases = []struct {
		utctime        string
		timezone       string
		result         string
		negativeSample bool
	}{
		{"2023-01-02 12:12:14", "America/Sao_Paulo", "2023-01-02 09:12:14", false},
		{"2023-01-02 12:12:14", "Europe/Oslo", "2023-01-02 13:12:14", false},
		{"2023-01-02 12:12:14", "Europe/Oslo_not_exist", "2023-01-02 12:12:14", true},
	}

	mockito.PatchConvey("TestGet_ok", t, func() {
		for _, testcase := range testcases {
			result := toolkit.UTC2LocalTime(testcase.utctime, testcase.timezone)
			convey.So(result, convey.ShouldEqual, testcase.result)
		}
	})
}
