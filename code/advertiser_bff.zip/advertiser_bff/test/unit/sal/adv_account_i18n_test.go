//go:generate mockgen -source=../../../kitex_gen/ad/advertiser/adv_account/account_i18n/accountservice/client.go -destination=mocker/advaccountmocker/adv_account_i18n_mocker.go -package=advaccountmocker
package sal

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/kitex_gen/base"
	"code.byted.org/ad/advertiser_bff/test/unit/sal/mocker/advaccountmocker"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/gopkg/mockito"
	"github.com/golang/mock/gomock"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetAdvertiserInfo(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()

	mockito.PatchConvey(
		"TestGetAdvertiserInfo_success", t, func() {
			var reply = account_i18n.GetAdvAccountByIdResponse{
				Advertiser: &account_i18n.AdvertiserData{
					Id:         1,
					Company:    toolkit.NewPtr[string]("company"),
					Name:       toolkit.NewPtr[string]("name"),
					Currency:   toolkit.NewPtr[string]("USD"),
					Timezone:   toolkit.NewPtr[string]("timezone"),
					Role:       toolkit.NewPtr[int16](2),
					Origin:     toolkit.NewPtr[int16](101),
					Status:     toolkit.NewPtr[int16](4),
					CreateTime: toolkit.NewPtr[string]("2024-10-01 11:12:13"),
				},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvAccountById(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			resp, err := sal.GetAdvertiserInfo(ctx, 1, false)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.GetId(), convey.ShouldEqual, 1)
			convey.So(resp.GetCompany(), convey.ShouldEqual, "company")
			convey.So(resp.GetName(), convey.ShouldEqual, "name")
			convey.So(resp.GetCreateTime(), convey.ShouldEqual, "2024-10-01 11:12:13")
		})

	mockito.PatchConvey(
		"TestGetAdvertiserInfo_return_error", t, func() {
			var reply = account_i18n.GetAdvAccountByIdResponse{
				Advertiser: &account_i18n.AdvertiserData{},
				BaseResp:   &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvAccountById(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvertiserInfo(ctx, 1, false)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvertiserInfo_return_base_error", t, func() {
			var reply = account_i18n.GetAdvAccountByIdResponse{
				Advertiser: &account_i18n.AdvertiserData{},
				BaseResp:   nil,
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvAccountById(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvertiserInfo(ctx, 1, false)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvertiserInfo_return_biz_error", t, func() {
			var reply = account_i18n.GetAdvAccountByIdResponse{
				Advertiser: &account_i18n.AdvertiserData{},
				BaseResp:   &base.BaseResp{StatusCode: 1},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvAccountById(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvertiserInfo(ctx, 1, false)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})
}

func TestMultiGetSubjectInfo(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()
	advId := int64(1)
	mockito.PatchConvey(
		"TestMultiGetSubjectInfo", t, func() {

			var reply = account_i18n.MultiGetAdvSubjectInfoResponse{
				Advertisers: map[int64]*account_i18n.AdvertiserSubjectInfo{
					advId: {
						Id:         advId,
						PayerName:  toolkit.NewPtr[string]("payerName"),
						Name:       toolkit.NewPtr[string]("name"),
						Currency:   toolkit.NewPtr[string]("USD"),
						Timezone:   toolkit.NewPtr[string]("timezone"),
						Role:       toolkit.NewPtr[int16](2),
						Origin:     toolkit.NewPtr[int16](101),
						Status:     toolkit.NewPtr[int16](4),
						CreateTime: toolkit.NewPtr[string]("2024-10-01 11:12:13"),
					},
				},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}

			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().MultiGetAdvSubjectInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr
			needPayer := true
			resp, err := sal.MultiGetSubjectInfo(ctx, []int64{1}, true, &needPayer)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp[advId].GetId(), convey.ShouldEqual, 1)
			convey.So(resp[advId].GetName(), convey.ShouldEqual, "name")
			convey.So(resp[advId].GetCreateTime(), convey.ShouldEqual, "2024-10-01 11:12:13")
			convey.So(resp[advId].GetPayerName(), convey.ShouldEqual, "payerName")
		})

	mockito.PatchConvey(
		"TestMultiGetSubjectInfo system error", t, func() {
			var reply = account_i18n.MultiGetAdvSubjectInfoResponse{
				Advertisers: map[int64]*account_i18n.AdvertiserSubjectInfo{
					advId: {
						Id:         advId,
						PayerName:  toolkit.NewPtr[string]("payerName"),
						Name:       toolkit.NewPtr[string]("name"),
						Currency:   toolkit.NewPtr[string]("USD"),
						Timezone:   toolkit.NewPtr[string]("timezone"),
						Role:       toolkit.NewPtr[int16](2),
						Origin:     toolkit.NewPtr[int16](101),
						Status:     toolkit.NewPtr[int16](4),
						CreateTime: toolkit.NewPtr[string]("2024-10-01 11:12:13"),
					},
				},
				BaseResp: &base.BaseResp{StatusCode: 1},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().MultiGetAdvSubjectInfo(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.AdvAccountClient = mkr

			needPayer := true
			_, err := sal.MultiGetSubjectInfo(ctx, []int64{1}, true, &needPayer)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestMultiGetSubjectInfo biz error", t, func() {
			var reply = account_i18n.MultiGetAdvSubjectInfoResponse{
				Advertisers: map[int64]*account_i18n.AdvertiserSubjectInfo{
					advId: {
						Id:         advId,
						PayerName:  toolkit.NewPtr[string]("payerName"),
						Name:       toolkit.NewPtr[string]("name"),
						Currency:   toolkit.NewPtr[string]("USD"),
						Timezone:   toolkit.NewPtr[string]("timezone"),
						Role:       toolkit.NewPtr[int16](2),
						Origin:     toolkit.NewPtr[int16](101),
						Status:     toolkit.NewPtr[int16](4),
						CreateTime: toolkit.NewPtr[string]("2024-10-01 11:12:13"),
					},
				},
				BaseResp: &base.BaseResp{StatusCode: 1},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().MultiGetAdvSubjectInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr
			needPayer := true
			_, err := sal.MultiGetSubjectInfo(ctx, []int64{1}, true, &needPayer)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestMultiGetSubjectInfo network error", t, func() {
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().MultiGetAdvSubjectInfo(ctx, gomock.Any()).Return(nil, nil)

			remote.AdvAccountClient = mkr

			needPayer := true
			_, err := sal.MultiGetSubjectInfo(ctx, []int64{1}, true, &needPayer)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

}

func TestGetAdvSensitiveContactInfo(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()

	mockito.PatchConvey(
		"TestGetAdvSensitiveContactInfo_success", t, func() {
			var reply = account_i18n.GetAdvSensitiveContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{
					AdvertiserId:              toolkit.NewPtr[int64](1),
					Phonenumber:               toolkit.NewPtr[string]("12"),
					Email:                     toolkit.NewPtr[string]("email@g.com"),
					Contacter:                 toolkit.NewPtr[string]("zack"),
					ContacterEmail:            toolkit.NewPtr[string]("email@gmail.com"),
					ContacterTelephone:        toolkit.NewPtr[string]("123"),
					PhonenumberCountry:        toolkit.NewPtr[string]("US"),
					ContacterTelephoneCountry: toolkit.NewPtr[string]("US"),
				},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvSensitiveContactInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			resp, err := sal.GetAdvSensitiveContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.GetAdvertiserId(), convey.ShouldEqual, 1)
			convey.So(resp.GetPhonenumber(), convey.ShouldEqual, "12")
			convey.So(resp.GetEmail(), convey.ShouldEqual, "email@g.com")
			convey.So(resp.GetContacterEmail(), convey.ShouldEqual, "email@gmail.com")
		})

	mockito.PatchConvey(
		"TestGetAdvSensitiveContactInfo_return_error", t, func() {
			var reply = account_i18n.GetAdvSensitiveContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{},
				BaseResp:    &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvSensitiveContactInfo(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvSensitiveContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvSensitiveContactInfo_return_base_error", t, func() {
			var reply = account_i18n.GetAdvSensitiveContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{},
				BaseResp:    nil,
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvSensitiveContactInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvSensitiveContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvSensitiveContactInfo_return_biz_error", t, func() {
			var reply = account_i18n.GetAdvSensitiveContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{},
				BaseResp:    &base.BaseResp{StatusCode: 1},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvSensitiveContactInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvSensitiveContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})
}

func TestGetAdvContactInfo(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()

	mockito.PatchConvey(
		"TestGetAdvContactInfo_success", t, func() {
			var reply = account_i18n.GetAdvContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{
					AdvertiserId:              toolkit.NewPtr[int64](1),
					Phonenumber:               toolkit.NewPtr[string]("12"),
					Email:                     toolkit.NewPtr[string]("email@g.com"),
					Contacter:                 toolkit.NewPtr[string]("zack"),
					ContacterEmail:            toolkit.NewPtr[string]("email@gmail.com"),
					ContacterTelephone:        toolkit.NewPtr[string]("123"),
					PhonenumberCountry:        toolkit.NewPtr[string]("US"),
					ContacterTelephoneCountry: toolkit.NewPtr[string]("US"),
				},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvContactInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			resp, err := sal.GetAdvContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.GetAdvertiserId(), convey.ShouldEqual, 1)
			convey.So(resp.GetPhonenumber(), convey.ShouldEqual, "12")
			convey.So(resp.GetEmail(), convey.ShouldEqual, "email@g.com")
			convey.So(resp.GetContacterEmail(), convey.ShouldEqual, "email@gmail.com")
		})

	mockito.PatchConvey(
		"TestGetAdvContactInfo_return_error", t, func() {
			var reply = account_i18n.GetAdvContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{},
				BaseResp:    &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvContactInfo(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvContactInfo_return_base_error", t, func() {
			var reply = account_i18n.GetAdvContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{},
				BaseResp:    nil,
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvContactInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvContactInfo_return_biz_error", t, func() {
			var reply = account_i18n.GetAdvContactInfoResponse{
				ContactInfo: &account_i18n.AdvContactInfo{},
				BaseResp:    &base.BaseResp{StatusCode: 1},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvContactInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvContactInfo(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})
}

func TestGetAdvTaxInfo(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()

	mockito.PatchConvey(
		"TestGetAdvTaxInfo_success", t, func() {
			var reply = account_i18n.GetAdvTaxResponse{
				TaxValue:        &account_i18n.TaxValue{Sez: nil, OtherTaxs: map[string]string{"tax_id": "8ACD8E"}},
				TaxType:         toolkit.NewPtr[int64](3),
				TaxId:           toolkit.NewPtr[string]("8ACD8E"),
				TaxStatus:       toolkit.NewPtr[account_i18n.QualificationStatus](account_i18n.QualificationStatus_OK),
				TaxRejectReason: toolkit.NewPtr[string]("&_&"),
				TaxAuditTime:    toolkit.NewPtr[int64](123),
				FirstRejectTime: toolkit.NewPtr[int64](123),
				BaseResp:        &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvTax(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			resp, err := sal.GetAdvTaxInfo(ctx, "en", 1, 2)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.GetTaxType(), convey.ShouldEqual, 3)
			convey.So(resp.GetTaxId(), convey.ShouldEqual, "8ACD8E")
			convey.So(resp.GetTaxStatus(), convey.ShouldEqual, account_i18n.QualificationStatus_OK)
		})

	mockito.PatchConvey(
		"TestGetAdvTaxInfo_return_error", t, func() {
			var reply = account_i18n.GetAdvTaxResponse{
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvTax(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvTaxInfo(ctx, "en", 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvTaxInfo_return_base_error", t, func() {
			var reply = account_i18n.GetAdvTaxResponse{
				BaseResp: nil,
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvTax(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvTaxInfo(ctx, "en", 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetAdvTaxInfo_return_biz_error", t, func() {
			var reply = account_i18n.GetAdvTaxResponse{
				BaseResp: &base.BaseResp{StatusCode: 1},
			}
			mkr := advaccountmocker.NewMockClient(ctl)
			mkr.EXPECT().GetAdvTax(ctx, gomock.Any()).Return(&reply, nil)

			remote.AdvAccountClient = mkr

			_, err := sal.GetAdvTaxInfo(ctx, "en", 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})
}
