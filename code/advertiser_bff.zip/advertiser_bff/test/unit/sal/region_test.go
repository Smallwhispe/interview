//go:generate mockgen -source=../../../kitex_gen/ad/platform/region/regionservice/client.go -destination=mocker/regionmocker/region_mocker.go -package=regionmocker
package sal

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/region"
	"code.byted.org/ad/advertiser_bff/kitex_gen/base"
	"code.byted.org/ad/advertiser_bff/test/unit/sal/mocker/regionmocker"
	"code.byted.org/gopkg/mockito"
	"github.com/golang/mock/gomock"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetRegionInfo(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()

	mockito.PatchConvey(
		"TestGetRegionInfo_success", t, func() {
			var reply = region.GetRegionInfoResponse{
				EntityRegion: &region.EntityRegion{
					TargetIDC: "sg1",
				},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := regionmocker.NewMockClient(ctl)
			mkr.EXPECT().GetRegionInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.RegionClient = mkr

			resp, err := sal.GetRegionInfo(ctx, 1)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.GetTargetIDC(), convey.ShouldEqual, "sg1")
		})

	mockito.PatchConvey(
		"TestGetRegionInfo_return_error", t, func() {
			var reply = region.GetRegionInfoResponse{
				EntityRegion: &region.EntityRegion{
					TargetIDC: "sg1",
				},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := regionmocker.NewMockClient(ctl)
			mkr.EXPECT().GetRegionInfo(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.RegionClient = mkr

			_, err := sal.GetRegionInfo(ctx, 1)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetRegionInfo_return_biz_error", t, func() {
			var reply = region.GetRegionInfoResponse{
				EntityRegion: &region.EntityRegion{
					TargetIDC: "sg1",
				},
			}
			mkr := regionmocker.NewMockClient(ctl)
			mkr.EXPECT().GetRegionInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.RegionClient = mkr

			_, err := sal.GetRegionInfo(ctx, 1)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetRegionInfo_return_base_error", t, func() {
			var reply = region.GetRegionInfoResponse{
				EntityRegion: &region.EntityRegion{
					TargetIDC: "sg1",
				},
				BaseResp: &base.BaseResp{StatusCode: 1},
			}
			mkr := regionmocker.NewMockClient(ctl)
			mkr.EXPECT().GetRegionInfo(ctx, gomock.Any()).Return(&reply, nil)

			remote.RegionClient = mkr

			_, err := sal.GetRegionInfo(ctx, 1)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})
}
