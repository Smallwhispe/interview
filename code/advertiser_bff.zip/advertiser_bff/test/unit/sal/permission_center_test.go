//go:generate mockgen -source=../../../kitex_gen/ad/tt4b/permission_center/permissioncenterservice/client.go -destination=mocker/permissioncentermocker/permissioncenter_mocker.go -package=permissioncentermocker
package sal

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/tt4b/permission_center"
	"code.byted.org/ad/advertiser_bff/kitex_gen/base"
	"code.byted.org/ad/advertiser_bff/test/unit/sal/mocker/permissioncentermocker"
	"code.byted.org/gopkg/mockito"
	"github.com/golang/mock/gomock"
	"github.com/smartystreets/goconvey/convey"
)

func TestCheckTwoStepVerify(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()

	mockito.PatchConvey(
		"TestCheckTwoStepVerify_success", t, func() {
			var reply = permission_center.CheckTwoStepVerifyResponse{
				CanAccess: true,
				BaseResp:  &base.BaseResp{StatusCode: 0},
			}
			mkr := permissioncentermocker.NewMockClient(ctl)
			mkr.EXPECT().CheckTwoStepVerify(ctx, gomock.Any()).Return(&reply, nil)

			remote.PermissionCenterClient = mkr

			resp, err := sal.CheckTwoStepVerify(ctx, 1, 2)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp, convey.ShouldBeTrue)
		})

	mockito.PatchConvey(
		"TestCheckTwoStepVerify_return_error", t, func() {
			var reply = permission_center.CheckTwoStepVerifyResponse{
				CanAccess: true,
				BaseResp:  &base.BaseResp{StatusCode: 0},
			}
			mkr := permissioncentermocker.NewMockClient(ctl)
			mkr.EXPECT().CheckTwoStepVerify(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.PermissionCenterClient = mkr

			resp, err := sal.CheckTwoStepVerify(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
			convey.So(resp, convey.ShouldBeFalse)
		})

	mockito.PatchConvey(
		"TestCheckTwoStepVerify_return_base_error", t, func() {
			var reply = permission_center.CheckTwoStepVerifyResponse{
				CanAccess: true,
				BaseResp:  &base.BaseResp{StatusCode: 1},
			}
			mkr := permissioncentermocker.NewMockClient(ctl)
			mkr.EXPECT().CheckTwoStepVerify(ctx, gomock.Any()).Return(&reply, nil)

			remote.PermissionCenterClient = mkr

			resp, err := sal.CheckTwoStepVerify(ctx, 1, 2)
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
			convey.So(resp, convey.ShouldBeFalse)
		})
}
