//go:generate mockgen -source=../../../kitex_gen/ad/platform/toolbox_i18n/toolboxi18nservice/client.go -destination=mocker/toolboxmocker/toolbox_mocker.go -package=toolboxmocker
package sal

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/common/remote"
	"code.byted.org/ad/advertiser_bff/kitex_gen/base"
	"code.byted.org/ad/advertiser_bff/kitex_gen/currency"
	"code.byted.org/ad/advertiser_bff/test/unit/sal/mocker/toolboxmocker"
	"code.byted.org/gopkg/mockito"
	"github.com/golang/mock/gomock"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetCurrencyInfo(t *testing.T) {
	ctx := context.Background()
	ctl := gomock.NewController(t)
	defer ctl.Finish()

	mockito.PatchConvey(
		"TestGetCurrencyInfo_success", t, func() {
			var reply = currency.CurrencyResponse{
				Data: []*currency.CurrencyDataRow{
					{
						Code: "USD",
						Attrs: map[string]string{
							"en":     "US Dollar",
							"ja":     "ドル",
							"name":   "美元",
							"num":    "840",
							"ratio":  "1",
							"symbol": "$",
							"unit":   "2",
						},
					},
				},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := toolboxmocker.NewMockClient(ctl)
			mkr.EXPECT().GetCurrencyList(ctx, gomock.Any()).Return(&reply, nil)

			remote.ToolboxClient = mkr

			resp, err := sal.GetCurrencyInfo(ctx, "USD")
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.GetRatioInt64(), convey.ShouldEqual, 1)
			convey.So(resp.GetUnitInt64(), convey.ShouldEqual, 2)
		})

	mockito.PatchConvey(
		"TestGetCurrencyInfo_return_error", t, func() {
			var reply = currency.CurrencyResponse{
				Data:     []*currency.CurrencyDataRow{},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := toolboxmocker.NewMockClient(ctl)
			mkr.EXPECT().GetCurrencyList(ctx, gomock.Any()).Return(&reply, errors.New("mock error"))

			remote.ToolboxClient = mkr

			_, err := sal.GetCurrencyInfo(ctx, "USD")
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetCurrencyInfo_return_base_error", t, func() {
			var reply = currency.CurrencyResponse{
				Data:     []*currency.CurrencyDataRow{},
				BaseResp: nil,
			}
			mkr := toolboxmocker.NewMockClient(ctl)
			mkr.EXPECT().GetCurrencyList(ctx, gomock.Any()).Return(&reply, nil)

			remote.ToolboxClient = mkr

			_, err := sal.GetCurrencyInfo(ctx, "USD")
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetCurrencyInfo_return_biz_error", t, func() {
			var reply = currency.CurrencyResponse{
				Data:     []*currency.CurrencyDataRow{},
				BaseResp: &base.BaseResp{StatusCode: 1},
			}
			mkr := toolboxmocker.NewMockClient(ctl)
			mkr.EXPECT().GetCurrencyList(ctx, gomock.Any()).Return(&reply, nil)

			remote.ToolboxClient = mkr

			_, err := sal.GetCurrencyInfo(ctx, "USD")
			convey.So(err, convey.ShouldEqual, errcode.ErrSystemException)
		})

	mockito.PatchConvey(
		"TestGetCurrencyInfo_not_found", t, func() {
			var reply = currency.CurrencyResponse{
				Data:     []*currency.CurrencyDataRow{},
				BaseResp: &base.BaseResp{StatusCode: 0},
			}
			mkr := toolboxmocker.NewMockClient(ctl)
			mkr.EXPECT().GetCurrencyList(ctx, gomock.Any()).Return(&reply, nil)

			remote.ToolboxClient = mkr

			_, err := sal.GetCurrencyInfo(ctx, "USD")
			convey.So(err, convey.ShouldEqual, errcode.ErrDataNotFound)
		})
}
