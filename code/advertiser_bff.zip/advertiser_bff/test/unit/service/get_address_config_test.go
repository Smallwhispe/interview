package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"code.byted.org/middleware/hertz/pkg/app"
)

func TestService_GetAddressConfig(t *testing.T) {
	type fields struct {
		appCtx *app.RequestContext
	}
	type args struct {
		ctx context.Context
		req *bff.GetAddressConfigRequest
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
		actions []func()
	}{
		// Add test cases.
		{
			name:   "TestService_GetAddressConfig case1",
			fields: fields{appCtx: NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetAddressConfigRequest{
					CountryCode: "",
					Scene:       0,
				},
			},
			wantErr: true,
		},
		{
			name:   "TestService_GetAddressConfig case2",
			fields: fields{appCtx: NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetAddressConfigRequest{
					CountryCode: "HK",
					Scene:       bff.BillingScene_Virtual,
				},
			},
			wantErr: true,
			actions: []func(){
				func() {
					mockito.Mock(sal.QueryAddressConfig).
						Return(nil, errcode.ErrSystemException).Build()
				},
			},
		},
		{
			name:   "TestService_GetAddressConfig case3",
			fields: fields{appCtx: NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetAddressConfigRequest{
					CountryCode: "HK",
					Scene:       bff.BillingScene_Virtual,
				},
			},
			wantErr: false,
			actions: []func(){
				func() {
					mockito.Mock(sal.QueryAddressConfig).
						Return(&legal_entity_service.QueryAddressConfigRuleResponse{
							AddressConfigRule: &legal_entity_service.AddressConfigRule{
								AddressRequiredLevel: toolkit.NewPtr(int32(1)),
								DetailAddressControl: toolkit.NewPtr(int32(1)),
								ZipCodeControl:       toolkit.NewPtr(int32(1)),
							},
						}, nil).Build()
				},
			},
		},
	}
	for _, tt := range tests {
		mockito.PatchConvey(tt.name, t, func() {
			for _, action := range tt.actions {
				action()
			}
			s := service.NewService(tt.fields.appCtx)
			_, err := s.GetAddressConfig(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
