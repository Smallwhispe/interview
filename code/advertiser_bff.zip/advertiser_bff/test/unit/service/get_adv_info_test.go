package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetAdvInfo(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey(
		"TestGetAdvInfo_success", t, func() {
			appCtx := NewAppContext()
			SetAdvID(appCtx, DefaultAdvID)
			SetUserID(appCtx, DefaultUserID)

			expected := bff.GetAdvertiserInfoResponse{
				Name:           "advertiser",
				Status:         4,
				Company:        "Advertiser",
				Currency:       "INR",
				Timezone:       "Pacific/Apia",
				Country:        "AF",
				State:          -1,
				County:         -1,
				City:           -1,
				SecondIndustry: 123,
				PostCode:       "postal_code",
				AddressDetail:  "address detail",
				RejectReason:   "no rejection",
				CreateTime:     "2023-08-11 12:13:14",
				PayerName:      "payerName",
				IndustryInfoV4: &bff.IndustryInfo{
					IndustryID:      12345,
					IndustryIDLevel: 3,
				},
				IndustryInfoList: []*bff.IndustryInfo{
					{
						IndustryID:      12,
						IndustryIDLevel: 0,
					},
					{
						IndustryID:      123,
						IndustryIDLevel: 1,
					},
					{
						IndustryID:      1234,
						IndustryIDLevel: 2,
					},
					{
						IndustryID:      12345,
						IndustryIDLevel: 3,
					},
				},
			}

			var req = bff.GetAdvertiserInfoRequest{AdvID: DefaultAdvID}
			mockito.Mock(sal.GetAdvertiserInfo).Return(&account_i18n.AdvertiserData{
				Id:               DefaultAdvID,
				Company:          toolkit.NewPtr[string]("Advertiser"),
				Name:             toolkit.NewPtr[string]("advertiser"),
				Currency:         toolkit.NewPtr[string]("INR"),
				Timezone:         toolkit.NewPtr[string]("Pacific/Apia"),
				Country:          toolkit.NewPtr[string]("AF"),
				Status:           toolkit.NewPtr[int16](4),
				State:            toolkit.NewPtr[int64](-1),
				County:           toolkit.NewPtr[int64](-1),
				City:             toolkit.NewPtr[int64](-1),
				SecondIndustryId: toolkit.NewPtr[int64](123),
				PostalCode:       toolkit.NewPtr[string]("postal_code"),
				AddressDetail:    toolkit.NewPtr[string]("address detail"),
				Reason:           toolkit.NewPtr[string]("no rejection"),
				CreateTime:       toolkit.NewPtr[string]("2023-08-11 12:13:14"),
				IndustryInfoV4: toolkit.NewPtr(account_i18n.IndustryInfo{
					IndustryId:      12345,
					IndustryIdLevel: 3,
				}),
				IndustryInfoList: []*account_i18n.IndustryInfo{
					{
						IndustryId:      12,
						IndustryIdLevel: 0,
					},
					{
						IndustryId:      123,
						IndustryIdLevel: 1,
					},
					{
						IndustryId:      1234,
						IndustryIdLevel: 2,
					},
					{
						IndustryId:      12345,
						IndustryIdLevel: 3,
					},
				},
			}, nil).Build()

			payerName := "payerName"
			subjectInfo := map[int64]*account_i18n.AdvertiserSubjectInfo{
				DefaultAdvID: &account_i18n.AdvertiserSubjectInfo{
					Id:        DefaultAdvID,
					PayerName: &payerName,
				},
			}
			mockito.Mock(sal.MultiGetSubjectInfo).Return(subjectInfo, nil).Build()

			svc := service.NewService(appCtx)
			resp, err := svc.GetAdvertiserInfo(ctx, &req)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.Name, convey.ShouldEqual, expected.Name)
			convey.So(resp.Status, convey.ShouldEqual, expected.Status)
			convey.So(resp.Company, convey.ShouldEqual, expected.Company)
			convey.So(resp.Currency, convey.ShouldEqual, expected.Currency)
			convey.So(resp.Timezone, convey.ShouldEqual, expected.Timezone)
			convey.So(resp.Country, convey.ShouldEqual, expected.Country)
			convey.So(resp.State, convey.ShouldEqual, expected.State)
			convey.So(resp.City, convey.ShouldEqual, expected.City)
			convey.So(resp.SecondIndustry, convey.ShouldEqual, expected.SecondIndustry)
			convey.So(resp.PostCode, convey.ShouldEqual, expected.PostCode)
			convey.So(resp.AddressDetail, convey.ShouldEqual, expected.AddressDetail)
			convey.So(resp.RejectReason, convey.ShouldEqual, expected.RejectReason)
			convey.So(resp.CreateTime, convey.ShouldEqual, expected.CreateTime)
			convey.So(resp.PayerName, convey.ShouldEqual, expected.PayerName)
			convey.So(resp.IndustryInfoV4, convey.ShouldEqual, expected.IndustryInfoV4)
		})
}
