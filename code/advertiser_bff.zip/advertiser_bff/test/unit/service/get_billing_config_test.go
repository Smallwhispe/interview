package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	legalEntityService "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"code.byted.org/middleware/hertz/pkg/app"
)

func TestService_GetBillingConfig(t *testing.T) {
	type fields struct {
		appCtx *app.RequestContext
	}
	type args struct {
		ctx context.Context
		req *bff.GetBillingConfigRequest
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
		actions []func()
	}{
		// Add test cases.
		{
			name:   "TestService_GetBillingConfig case1",
			fields: fields{appCtx: NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetBillingConfigRequest{
					CountryCode: "",
					Scene:       0,
				},
			},
			wantErr: true,
		},
		{
			name:   "TestService_GetBillingConfig case2",
			fields: fields{appCtx: NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetBillingConfigRequest{
					CountryCode: "MX",
					Scene:       bff.BillingScene_Virtual,
				},
			},
			wantErr: true,
			actions: []func(){
				func() {
					mockito.Mock(sal.QueryTaxConfigRules).
						Return(nil, errcode.ErrSystemException).Build()
				},
			},
		},
		{
			name:   "TestService_GetBillingConfig case3",
			fields: fields{appCtx: NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetBillingConfigRequest{
					CountryCode: "MX",
					Scene:       bff.BillingScene_Virtual,
				},
			},
			wantErr: false,
			actions: []func(){
				func() {
					mockito.Mock(sal.QueryTaxConfigRules).
						Return(&legalEntityService.QueryTaxConfigRulesResponse{
							TaxConfigRule: &legalEntityService.TaxConfigRule{
								Id:               0,
								SubjectId:        0,
								CountryCode:      "",
								TaxValidateRules: nil,
								TaxIdentityConfigRules: []*legalEntityService.TaxIdentityRule{
									{
										TaxRules: []*legalEntityService.TaxRule{
											{
												TaxKey:  "rfc",
												Control: 1,
											},
										},
										NeedVerify:      1,
										TaxIdentity:     3,
										TaxIdentityName: "business",
										TaxIdentityTips: toolkit.NewPtr("tips"),
									},
								},
								TaxBasicInfo: []*legalEntityService.TaxBasicInfo{
									{
										Type:    toolkit.NewPtr(int32(1)),
										TaxKey:  "key",
										TaxName: "name",
										TaxTips: toolkit.NewPtr("tip"),
										Options: []*legalEntityService.TaxOption{
											{
												Code: toolkit.NewPtr("code"),
												Name: toolkit.NewPtr("name"),
											},
										},
									},
								},
							},
						}, nil).Build()
				},
			},
		},
	}
	for _, tt := range tests {
		mockito.PatchConvey(tt.name, t, func() {
			for _, action := range tt.actions {
				action()
			}
			s := service.NewService(tt.fields.appCtx)
			_, err := s.GetBillingConfig(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetBillingConfig() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
