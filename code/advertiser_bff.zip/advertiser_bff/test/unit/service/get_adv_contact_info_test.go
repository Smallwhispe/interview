package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetAdvContactInfo(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey(
		"TestGetAdvContactInfo_success", t, func() {
			appCtx := NewAppContext()
			SetAdvID(appCtx, DefaultAdvID)
			SetUserID(appCtx, DefaultUserID)

			expected := &bff.GetAdvContactInfoResponse{
				Email:                     DefaultEmail,
				Contacter:                 DefaultContact,
				Telephone:                 DefaultPhoneNumber,
				Phonenumber:               DefaultPhoneNumber,
				ContacterEmail:            DefaultContactEmail,
				PhonenumberCountry:        toolkit.NewPtr[string]("US"),
				ContacterTelephoneCountry: toolkit.NewPtr[string]("US"),
			}

			req := bff.GetAdvContactInfoRequest{
				AdvID: DefaultAdvID,
			}

			mockito.Mock(sal.GetAdvContactInfo).Return(
				&account_i18n.AdvContactInfo{
					AdvertiserId:              toolkit.NewPtr[int64](DefaultAdvID),
					Phonenumber:               toolkit.NewPtr[string](DefaultPhoneNumber),
					Email:                     toolkit.NewPtr[string](DefaultEmail),
					Contacter:                 toolkit.NewPtr[string](DefaultContact),
					ContacterEmail:            toolkit.NewPtr[string](DefaultContactEmail),
					ContacterTelephone:        toolkit.NewPtr[string](DefaultPhoneNumber),
					PhonenumberCountry:        toolkit.NewPtr[string]("US"),
					ContacterTelephoneCountry: toolkit.NewPtr[string]("US"),
				}, nil,
			).Build()

			svc := service.NewService(appCtx)
			resp, err := svc.GetAdvContactInfo(ctx, &req)
			convey.So(err, convey.ShouldBeNil)
			real := resp["contact_info"]
			convey.So(real.Email, convey.ShouldEqual, expected.Email)
			convey.So(real.Telephone, convey.ShouldEqual, expected.Telephone)
			convey.So(real.Contacter, convey.ShouldEqual, expected.Contacter)
			convey.So(real.Phonenumber, convey.ShouldEqual, expected.Phonenumber)
			convey.So(real.ContacterEmail, convey.ShouldEqual, expected.ContacterEmail)
			convey.So(*real.PhonenumberCountry, convey.ShouldEqual, *expected.PhonenumberCountry)
			convey.So(*real.ContacterTelephoneCountry, convey.ShouldEqual, *expected.ContacterTelephoneCountry)
		})

	mockito.PatchConvey(
		"TestGetAdvContactInfo_sensitive_success", t, func() {
			appCtx := NewAppContext()
			SetAdvID(appCtx, DefaultAdvID)
			SetUserID(appCtx, DefaultUserID)

			expected := &bff.GetAdvContactInfoResponse{
				Contacter:                 "emFjaw==",
				Telephone:                 "KzEtMjEyLTk2My0zMjA5",
				Phonenumber:               "KzEtMjEyLTk2My0zMjA5",
				Email:                     "cG9wdWxhdGlvbkB1bi5vcmc=",
				ContacterEmail:            "emFjay5wdWJsaWNAdW4ub3Jn",
				PhonenumberCountry:        toolkit.NewPtr[string]("US"),
				ContacterTelephoneCountry: toolkit.NewPtr[string]("US"),
			}

			req := bff.GetAdvContactInfoRequest{
				AdvID:         DefaultAdvID,
				SensitiveFlag: toolkit.NewPtr[bool](true),
			}

			mockito.Mock(sal.GetAdvSensitiveContactInfo).Return(
				&account_i18n.AdvContactInfo{
					AdvertiserId:              toolkit.NewPtr[int64](DefaultAdvID),
					Phonenumber:               toolkit.NewPtr[string](DefaultPhoneNumber),
					Email:                     toolkit.NewPtr[string](DefaultEmail),
					Contacter:                 toolkit.NewPtr[string](DefaultContact),
					ContacterEmail:            toolkit.NewPtr[string](DefaultContactEmail),
					ContacterTelephone:        toolkit.NewPtr[string](DefaultPhoneNumber),
					PhonenumberCountry:        toolkit.NewPtr[string]("US"),
					ContacterTelephoneCountry: toolkit.NewPtr[string]("US"),
				}, nil,
			).Build()

			svc := service.NewService(appCtx)
			resp, err := svc.GetAdvContactInfo(ctx, &req)
			convey.So(err, convey.ShouldBeNil)
			real := resp["contact_info"]
			convey.So(real.Email, convey.ShouldEqual, expected.Email)
			convey.So(real.Telephone, convey.ShouldEqual, expected.Telephone)
			convey.So(real.Contacter, convey.ShouldEqual, expected.Contacter)
			convey.So(real.Phonenumber, convey.ShouldEqual, expected.Phonenumber)
			convey.So(real.ContacterEmail, convey.ShouldEqual, expected.ContacterEmail)
			convey.So(*real.PhonenumberCountry, convey.ShouldEqual, *expected.PhonenumberCountry)
			convey.So(*real.ContacterTelephoneCountry, convey.ShouldEqual, *expected.ContacterTelephoneCountry)
		})

	mockito.PatchConvey(
		"TestGetAdvContactInfo_sensitive_failed_sal", t, func() {
			appCtx := NewAppContext()
			SetAdvID(appCtx, DefaultAdvID)
			SetUserID(appCtx, DefaultUserID)

			req := bff.GetAdvContactInfoRequest{
				AdvID:         DefaultAdvID,
				SensitiveFlag: toolkit.NewPtr[bool](true),
			}

			mockito.Mock(sal.GetAdvSensitiveContactInfo).Return(nil, errcode.ErrSystemException).Build()

			svc := service.NewService(appCtx)
			resp, err := svc.GetAdvContactInfo(ctx, &req)
			convey.So(err, convey.ShouldBeNil)
			real := resp["contact_info"]
			convey.So(real.Contacter, convey.ShouldEqual, "")
		})
}
