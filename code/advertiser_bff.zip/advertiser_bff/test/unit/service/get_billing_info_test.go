package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"code.byted.org/middleware/hertz/pkg/app"
)

func TestService_GetBillingInfo(t *testing.T) {
	type fields struct {
		appCtx *app.RequestContext
	}
	type args struct {
		ctx context.Context
		req *bff.GetBillingInfoRequest
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
		actions []func()
	}{
		// Add test cases.
		{
			name:   "TestService_GetBillingInfo case1",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetBillingInfoRequest{AdvID: toolkit.NewPtr(int64(123))},
			},
			wantErr: true,
			actions: []func(){
				func() {
					mockito.Mock(sal.GetAdvTaxInfo).
						Return(nil, errcode.ErrSystemException).Build()
				},
			},
		},
		{
			name:   "TestService_GetBillingInfo case2",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.GetBillingInfoRequest{AdvID: toolkit.NewPtr(int64(123))},
			},
			wantErr: false,
			actions: []func(){
				func() {
					mockito.Mock(sal.GetAdvTaxInfo).Return(&account_i18n.GetAdvTaxResponse{
						TaxValue:           &account_i18n.TaxValue{OtherTaxs: map[string]string{}},
						TaxType:            toolkit.NewPtr(int64(3)),
						TaxId:              toolkit.NewPtr("23333333"),
						TaxStatus:          toolkit.NewPtr(account_i18n.QualificationStatus_OK),
						BillingAddressInfo: &account_i18n.BillingAddressInfo{},
					}, nil).Build()
				},
			},
		},
	}
	for _, tt := range tests {
		mockito.PatchConvey(tt.name, t, func() {
			for _, action := range tt.actions {
				action()
			}
			s := service.NewService(tt.fields.appCtx)
			_, err := s.GetBillingInfo(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetBillingInfo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
