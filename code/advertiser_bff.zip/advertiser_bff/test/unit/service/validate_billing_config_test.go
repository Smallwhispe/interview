package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	legalEntityService "code.byted.org/ad/advertiser_bff/kitex_gen/legal_entity_service"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"code.byted.org/middleware/hertz/pkg/app"
)

func TestService_ValidateBillingConfig(t *testing.T) {
	type fields struct {
		appCtx *app.RequestContext
	}
	type args struct {
		ctx context.Context
		req *bff.ValidateBillingConfigRequest
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
		actions []func()
	}{
		// Add test cases.
		{
			name:   "TestService_ValidateBillingConfig case1",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.ValidateBillingConfigRequest{
					CountryCode: "",
					Scene:       0,
					TaxInfos:    nil,
					TaxIdentity: 0,
				},
			},
			wantErr: true,
		},
		{
			name:   "TestService_ValidateBillingConfig case2",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.ValidateBillingConfigRequest{
					CountryCode: "MX",
					Scene:       bff.BillingScene_Virtual,
					TaxInfos: []*bff.TaxInfo{
						{
							TaxKey:   toolkit.NewPtr("key"),
							TaxValue: toolkit.NewPtr("val"),
						},
					},
					TaxIdentity: 0,
				},
			},
			wantErr: true,
			actions: []func(){
				func() {
					mockito.Mock(sal.ValidateTaxNumber).
						Return(nil, errcode.ErrSystemException).Build()
				},
			},
		},
		{
			name:   "TestService_ValidateBillingConfig case3",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.ValidateBillingConfigRequest{
					CountryCode: "MX",
					Scene:       bff.BillingScene_Virtual,
					TaxInfos: []*bff.TaxInfo{
						{
							TaxKey:   toolkit.NewPtr("key"),
							TaxValue: toolkit.NewPtr("val"),
						},
					},
					TaxIdentity: 0,
				},
			},
			wantErr: false,
			actions: []func(){
				func() {
					mockito.Mock(sal.ValidateTaxNumber).
						Return(&legalEntityService.ValidateTaxNumberResponse{
							ValidateRes: map[string]*legalEntityService.ValidateResult_{
								"rfc": {IsPassed: true, Message: "ok"},
							},
						}, nil).Build()
				},
			},
		},
	}
	for _, tt := range tests {
		mockito.PatchConvey(tt.name, t, func() {
			for _, action := range tt.actions {
				action()
			}
			s := service.NewService(tt.fields.appCtx)
			_, err := s.ValidateBillingConfig(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("ValidateBillingConfig() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
