package service

import (
	"code.byted.org/ad/common_mw_lib/constants"
	"github.com/cloudwego/hertz/pkg/app"
)

const (
	DefaultAdvID   = 0x1
	DefaultUserID  = 0x11
	DefaultStaffID = 0x111

	DefaultUserName     = "zack"
	DefaultStaffName    = "zack 萨克"
	DefaultEmail        = "population@un.org"
	DefaultContact      = "zack"
	DefaultPhoneNumber  = "+1-212-963-3209"
	DefaultContactEmail = "zack.public@un.org"
)

func NewAppContext() *app.RequestContext {
	return app.NewContext(32 * 1024)
}

func NewDefaultAppContext() *app.RequestContext {
	appContext := NewAppContext()
	appContext.Set(constants.ADVERTISER_ID, DefaultAdvID)
	appContext.Set(constants.CORE_USER_ID, DefaultUserID)
	appContext.Set(constants.STAFF_ID, DefaultStaffID)
	return appContext
}

func SetAdvID(ctx *app.RequestContext, id int64) {
	ctx.Set(constants.ADVERTISER_ID, id)
}

func SetUserID(ctx *app.RequestContext, id int64) {
	ctx.Set(constants.CORE_USER_ID, id)
}

func SetStaffID(ctx *app.RequestContext, id int64) {
	ctx.Set(constants.STAFF_ID, id)
}
