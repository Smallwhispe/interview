package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/region"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/ad/advertiser_bff/toolkit/syscontext"
	"code.byted.org/ad/advertiser_bff/toolkit/tcc"
	"code.byted.org/ad/mwlib/basic/model"
	"code.byted.org/ad/mwlib/mwhertz"
	"code.byted.org/luoshiqi/mockito"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetAdvPermissionDetailInfo(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey(
		"TestGetAdvPermissionDetail_admin_success", t, func() {
			appCtx := NewAppContext()
			SetAdvID(appCtx, DefaultAdvID)
			SetUserID(appCtx, DefaultUserID)
			SetStaffID(appCtx, DefaultStaffID)

			expected := bff.GetAdvPermissionDetailResponse{
				CoreUser: &bff.CoreUserInfo{
					ID:   DefaultUserID,
					Name: DefaultUserName,
				},
				Staff: &bff.StaffInfo{
					StaffID:   DefaultStaffID,
					StaffName: toolkit.NewPtr[string](DefaultStaffName),
				},
				Permission: &bff.PermissionInfo{
					CanVisitAdvertiser: true,
					Check2svPass:       true,
					IsAdmin:            true,
					RefRole:            1,
				},
				Account: &bff.AccountInfo{
					AccountType:         0,
					Country:             "RU",
					CreateTime:          "2019-04-22 12:24:52",
					Currency:            "USD",
					CurrencyPrecision:   2,
					CustomerTypeValue:   101,
					ID:                  DefaultAdvID,
					Name:                "TTAM-Demo",
					Origin:              100,
					QualificationSource: 1,
					Ratio:               4,
					Role:                4,
					Status:              1,
					Timezone:            "America/Sao_Paulo",
					IndustryInfoV4: &bff.IndustryInfo{
						IndustryID:      12345,
						IndustryIDLevel: 3,
					},
					IndustryInfoList: []*bff.IndustryInfo{
						{
							IndustryID:      12,
							IndustryIDLevel: 0,
						},
						{
							IndustryID:      123,
							IndustryIDLevel: 1,
						},
						{
							IndustryID:      1234,
							IndustryIDLevel: 2,
						},
						{
							IndustryID:      12345,
							IndustryIDLevel: 3,
						},
					},
				},
			}

			mockito.Mock(mwhertz.IsStaffAdmin).Return(true).Build()
			mockito.Mock(tcc.GetOpen2SVSwitch).Return(true).Build()
			mockito.Mock(sal.CheckTwoStepVerify).Return(true, nil).Build()
			mockito.Mock(syscontext.IsShopifyRequest).Return(false).Build()
			mockito.Mock(sal.GetCurrencyInfo).Return(&sal.CurrencyInfo{Unit: "2", Ratio: "4"}, nil).Build()
			mockito.Mock(mwhertz.GetAdvLogInfo).Return(
				&model.AdvLoginInfo{
					Currency: "USD",
					Staff: &model.StaffInfo{
						Name: DefaultStaffName,
					},
					CoreUser: &model.CoreUserInfo{
						Name: DefaultUserName,
					},
					PermissionRole: 1,
					AdvertiserRole: toolkit.NewPtr[int32](int32(account_i18n.AdvertiserRole_ROLE_VIRTAUL_ADVERTISER)),
				}, nil).Build()
			mockito.Mock(sal.GetAdvertiserInfo).Return(&account_i18n.AdvertiserData{
				Id:                  DefaultAdvID,
				Name:                toolkit.NewPtr[string]("TTAM-Demo"),
				AccountType:         toolkit.NewPtr[int16](0),
				Country:             toolkit.NewPtr[string]("RU"),
				Currency:            toolkit.NewPtr[string]("USD"),
				CreateTime:          toolkit.NewPtr[string]("2019-04-22 15:24:52"),
				Origin:              toolkit.NewPtr[int16](100),
				QualificationSource: toolkit.NewPtr[account_i18n.QualificationSource](1),
				Role:                toolkit.NewPtr[int16](4),
				Status:              toolkit.NewPtr[int16](1),
				Timezone:            toolkit.NewPtr[string]("America/Sao_Paulo"),
				IndustryInfoV4: toolkit.NewPtr(account_i18n.IndustryInfo{
					IndustryId:      12345,
					IndustryIdLevel: 3,
				}),
				IndustryInfoList: []*account_i18n.IndustryInfo{
					{
						IndustryId:      12,
						IndustryIdLevel: 0,
					},
					{
						IndustryId:      123,
						IndustryIdLevel: 1,
					},
					{
						IndustryId:      1234,
						IndustryIdLevel: 2,
					},
					{
						IndustryId:      12345,
						IndustryIdLevel: 3,
					},
				},
			}, nil).Build()

			svc := service.NewService(appCtx)
			resp, err := svc.GetAdvPermissionDetail(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.CoreUser.ID, convey.ShouldEqual, expected.CoreUser.ID)
			convey.So(resp.CoreUser.Name, convey.ShouldEqual, expected.CoreUser.Name)
			convey.So(resp.Staff.StaffID, convey.ShouldEqual, expected.Staff.StaffID)
			convey.So(resp.Staff.GetStaffName(), convey.ShouldEqual, *expected.Staff.StaffName)

			convey.So(resp.Permission.CanVisitAdvertiser, convey.ShouldEqual, expected.Permission.CanVisitAdvertiser)
			convey.So(resp.Permission.Check2svPass, convey.ShouldEqual, expected.Permission.Check2svPass)
			convey.So(resp.Permission.IsAdmin, convey.ShouldEqual, expected.Permission.IsAdmin)
			convey.So(resp.Permission.RefRole, convey.ShouldEqual, expected.Permission.RefRole)

			convey.So(resp.Account.ID, convey.ShouldEqual, expected.Account.ID)
			convey.So(resp.Account.Country, convey.ShouldEqual, expected.Account.Country)
			convey.So(resp.Account.CreateTime, convey.ShouldEqual, expected.Account.CreateTime)
			convey.So(resp.Account.Currency, convey.ShouldEqual, expected.Account.Currency)
			convey.So(resp.Account.CurrencyPrecision, convey.ShouldEqual, expected.Account.CurrencyPrecision)
			convey.So(resp.Account.Ratio, convey.ShouldEqual, expected.Account.Ratio)
			convey.So(resp.Account.Role, convey.ShouldEqual, expected.Account.Role)
			convey.So(resp.Account.Status, convey.ShouldEqual, expected.Account.Status)
		})

	mockito.PatchConvey(
		"TestMIGetAdvPermissionDetail_admin_success", t, func() {
			appCtx := NewAppContext()
			SetAdvID(appCtx, DefaultAdvID)
			SetUserID(appCtx, DefaultUserID)
			SetStaffID(appCtx, DefaultStaffID)

			expected := bff.GetAdvPermissionDetailResponse{
				CoreUser: &bff.CoreUserInfo{
					ID:   DefaultUserID,
					Name: DefaultUserName,
				},
				Staff: &bff.StaffInfo{
					StaffID:   DefaultStaffID,
					StaffName: toolkit.NewPtr[string](DefaultStaffName),
				},
				Permission: &bff.PermissionInfo{
					CanVisitAdvertiser: true,
					Check2svPass:       true,
					IsAdmin:            true,
					RefRole:            1,
				},
				Account: &bff.AccountInfo{
					AccountType:         0,
					Country:             "RU",
					CreateTime:          "2019-04-22 23:24:52",
					Currency:            "USD",
					CurrencyPrecision:   2,
					CustomerTypeValue:   101,
					ID:                  DefaultAdvID,
					Name:                "TTAM-Demo",
					Origin:              100,
					QualificationSource: 0,
					Ratio:               4,
					Role:                4,
					Status:              1,
					Timezone:            "Etc/GMT-8",
					Idc:                 toolkit.NewPtr[string]("alisg"),
				},
			}

			mockito.Mock(mwhertz.IsStaffAdmin).Return(true).Build()
			mockito.Mock(tcc.GetOpen2SVSwitch).Return(true).Build()
			mockito.Mock(sal.CheckTwoStepVerify).Return(true, nil).Build()
			mockito.Mock(syscontext.IsShopifyRequest).Return(false).Build()
			mockito.Mock(sal.GetRegionInfo).Return(&region.EntityRegion{TargetIDC: "sg1"}, nil).Build()
			mockito.Mock(sal.GetCurrencyInfo).Return(&sal.CurrencyInfo{Unit: "2", Ratio: "4"}, nil).Build()
			mockito.Mock(mwhertz.GetAdvLogInfo).Return(
				&model.AdvLoginInfo{
					Currency: "USD",
					Staff: &model.StaffInfo{
						Name: DefaultStaffName,
					},
					CoreUser: &model.CoreUserInfo{
						Name: DefaultUserName,
					},
					PermissionRole: 1,
					AdvertiserRole: toolkit.NewPtr[int32](int32(account_i18n.AdvertiserRole_ROLE_VIRTAUL_ADVERTISER)),
				}, nil).Build()
			mockito.Mock(sal.GetAdvertiserInfo).Return(&account_i18n.AdvertiserData{
				Id:                  DefaultAdvID,
				Name:                toolkit.NewPtr[string]("TTAM-Demo"),
				AccountType:         toolkit.NewPtr[int16](0),
				Country:             toolkit.NewPtr[string]("RU"),
				Currency:            toolkit.NewPtr[string]("USD"),
				CreateTime:          toolkit.NewPtr[string]("2019-04-22 15:24:52"),
				Origin:              toolkit.NewPtr[int16](100),
				QualificationSource: toolkit.NewPtr[account_i18n.QualificationSource](1),
				Role:                toolkit.NewPtr[int16](4),
				Status:              toolkit.NewPtr[int16](1),
				Timezone:            toolkit.NewPtr[string]("Etc/GMT-8"),
			}, nil).Build()

			svc := service.NewService(appCtx)
			resp, err := svc.MIGetAdvPermissionDetail(ctx)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.CoreUser.ID, convey.ShouldEqual, expected.CoreUser.ID)
			convey.So(resp.CoreUser.Name, convey.ShouldEqual, expected.CoreUser.Name)
			convey.So(resp.Staff.StaffID, convey.ShouldEqual, expected.Staff.StaffID)
			convey.So(resp.Staff.GetStaffName(), convey.ShouldEqual, *expected.Staff.StaffName)

			convey.So(resp.Permission.CanVisitAdvertiser, convey.ShouldEqual, expected.Permission.CanVisitAdvertiser)
			convey.So(resp.Permission.Check2svPass, convey.ShouldEqual, expected.Permission.Check2svPass)
			convey.So(resp.Permission.IsAdmin, convey.ShouldEqual, expected.Permission.IsAdmin)
			convey.So(resp.Permission.RefRole, convey.ShouldEqual, expected.Permission.RefRole)

			convey.So(resp.Account.ID, convey.ShouldEqual, expected.Account.ID)
			convey.So(resp.Account.Country, convey.ShouldEqual, expected.Account.Country)
			convey.So(resp.Account.CreateTime, convey.ShouldEqual, expected.Account.CreateTime)
			convey.So(resp.Account.Currency, convey.ShouldEqual, expected.Account.Currency)
			convey.So(resp.Account.CurrencyPrecision, convey.ShouldEqual, expected.Account.CurrencyPrecision)
			convey.So(resp.Account.Ratio, convey.ShouldEqual, expected.Account.Ratio)
			convey.So(resp.Account.Role, convey.ShouldEqual, expected.Account.Role)
			convey.So(resp.Account.Status, convey.ShouldEqual, expected.Account.Status)
			convey.So(resp.Account.GetIdc(), convey.ShouldEqual, expected.Account.GetIdc())
		})
}
