package service

import (
	"context"
	"errors"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/platform/region"
	"code.byted.org/ad/mwlib/mwregion"
	"code.byted.org/gopkg/env"
	"code.byted.org/luoshiqi/mockito"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetRegion(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey(
		"TestGetRegion_success", t, func() {
			mockito.Mock(sal.GetRegionInfo).Return(&region.EntityRegion{
				TargetIDC: env.DC_MALIVA,
			}, nil).Build()

			resp := service.GetRegion(ctx, DefaultAdvID)
			convey.So(resp, convey.ShouldEqual, "useast1a")
		})

	mockito.PatchConvey(
		"TestGetRegion_reveal", t, func() {
			mockito.Mock(sal.GetRegionInfo).Return(&region.EntityRegion{
				TargetIDC: env.DC_MALIVA,
			}, errors.New("mock error")).Build()

			resp := service.GetRegion(ctx, DefaultAdvID)
			convey.So(resp, convey.ShouldEqual, mwregion.DefaultIDC)
		})
}
