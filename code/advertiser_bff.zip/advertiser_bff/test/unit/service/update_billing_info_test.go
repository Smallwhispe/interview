package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/errcode"
	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/ad/advertiser_bff/toolkit/syscontext"
	"code.byted.org/ad/mwlib/basic/model"
	"code.byted.org/luoshiqi/mockito"
	"code.byted.org/middleware/hertz/pkg/app"
	"code.byted.org/passport/session_lib"
)

func TestService_UpdateBillingInfo(t *testing.T) {
	type fields struct {
		appCtx *app.RequestContext
	}
	type args struct {
		ctx context.Context
		req *bff.UpdateBillingInfoRequest
	}
	tests := []struct {
		name    string
		fields  fields
		args    args
		wantErr bool
		actions []func()
	}{
		// Add test cases.
		{
			name:   "TestService_UpdateBillingInfo case1",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.UpdateBillingInfoRequest{},
			},
			wantErr: true,
			actions: []func(){
				func() {
					mockito.Mock(sal.GetAdvSensitiveContactInfo).
						Return(nil, errcode.ErrSystemException).Build()
				},
			},
		},
		{
			name:   "TestService_UpdateBillingInfo case2",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.UpdateBillingInfoRequest{},
			},
			wantErr: true,
			actions: []func(){
				func() {
					mockito.Mock(sal.GetAdvSensitiveContactInfo).
						Return(nil, nil).Build()
				},
			},
		},
		{
			name:   "TestService_UpdateBillingInfo case3",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.UpdateBillingInfoRequest{
					State: toolkit.NewPtr(int64(123)),
				},
			},
			wantErr: true,
			actions: []func(){
				func() {
					mockito.Mock(sal.GetAdvSensitiveContactInfo).
						Return(&account_i18n.AdvContactInfo{
							ContacterEmail: toolkit.NewPtr("email"),
						}, nil).Build()

					mockito.Mock((*service.Service).BuildSharkParamGeneral).
						Return(nil).Build()

					mockito.Mock(sal.UpdateAdvAccount).Return(errcode.ErrSystemException).Build()
				},
			},
		},
		{
			name:   "TestService_UpdateBillingInfo case4",
			fields: fields{NewDefaultAppContext()},
			args: args{
				ctx: context.Background(),
				req: &bff.UpdateBillingInfoRequest{
					State:  toolkit.NewPtr(int64(123)),
					TaxMap: map[string]string{"rfc": "123321"},
				},
			},
			wantErr: false,
			actions: []func(){
				func() {
					mockito.Mock(sal.GetAdvSensitiveContactInfo).
						Return(&account_i18n.AdvContactInfo{
							ContacterEmail: toolkit.NewPtr("email"),
						}, nil).Build()

					mockito.Mock(sal.GetWebId).Return(123).Build()
					mockito.Mock(sal.GetAdvertiserInfo).Return(nil, nil).Build()
					mockito.Mock(session_lib.GetAppIDHertz).Return(123, nil).Build()
					mockito.Mock(session_lib.GetDeviceIDHertz).Return(123, nil).Build()
					mockito.Mock(session_lib.GetUserTypeHertz).Return(123, nil).Build()
					mockito.Mock(syscontext.GetAdvLoginInfo).Return(&model.AdvLoginInfo{
						CoreUser: &model.CoreUserInfo{Email: toolkit.NewPtr("email")},
					}, nil).Build()

					mockito.Mock(sal.UpdateAdvAccount).Return(nil).Build()
					mockito.Mock(sal.UpdateAdvTaxInfo).Return(nil).Build()
				},
			},
		},
	}
	for _, tt := range tests {
		mockito.PatchConvey(tt.name, t, func() {
			for _, action := range tt.actions {
				action()
			}
			s := service.NewService(tt.fields.appCtx)
			_, err := s.UpdateBillingInfo(tt.args.ctx, tt.args.req)
			if (err != nil) != tt.wantErr {
				t.Errorf("UpdateBillingInfo() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
		})
	}
}
