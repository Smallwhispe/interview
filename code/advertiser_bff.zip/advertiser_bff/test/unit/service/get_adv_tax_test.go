package service

import (
	"context"
	"testing"

	"code.byted.org/ad/advertiser_bff/biz/model/ad/advertiser/bff"
	"code.byted.org/ad/advertiser_bff/biz/sal"
	"code.byted.org/ad/advertiser_bff/biz/service"
	"code.byted.org/ad/advertiser_bff/kitex_gen/ad/advertiser/adv_account/account_i18n"
	"code.byted.org/ad/advertiser_bff/kitex_gen/base"
	"code.byted.org/ad/advertiser_bff/toolkit"
	"code.byted.org/luoshiqi/mockito"
	"github.com/smartystreets/goconvey/convey"
)

func TestGetAdvTaxInfo(t *testing.T) {
	ctx := context.Background()

	mockito.PatchConvey(
		"TestGetAdvTaxInfo_success", t, func() {
			appCtx := NewAppContext()
			SetAdvID(appCtx, DefaultAdvID)
			SetUserID(appCtx, DefaultUserID)

			var req = bff.GetAdvTaxValueRequest{}

			mockito.Mock(sal.GetAdvTaxInfo).Return(
				&account_i18n.GetAdvTaxResponse{
					TaxValue: &account_i18n.TaxValue{
						Sez:       []string{"啥也不是"},
						OtherTaxs: map[string]string{"tax_id": "phonenumber"},
					},
					TaxType:         toolkit.NewPtr[int64](3),
					TaxId:           toolkit.NewPtr[string]("tax_id"),
					TaxStatus:       toolkit.NewPtr[account_i18n.QualificationStatus](account_i18n.QualificationStatus_OK),
					TaxRejectReason: toolkit.NewPtr[string]("hhha"),
					TaxAuditTime:    toolkit.NewPtr[int64](1223),
					FirstRejectTime: toolkit.NewPtr[int64](123),
					BaseResp:        &base.BaseResp{StatusCode: 0},
				}, nil,
			).Build()

			svc := service.NewService(appCtx)
			resp, err := svc.GetAdvTaxInfo(ctx, &req)
			convey.So(err, convey.ShouldBeNil)
			convey.So(resp.GetTaxType(), convey.ShouldEqual, 3)
			convey.So(resp.GetTaxValue()["tax_id"], convey.ShouldEqual, "phonenumber")
			convey.So(resp.GetTaxStatus(), convey.ShouldEqual, 2)
			convey.So(resp.GetRejectReason(), convey.ShouldEqual, "hhha")
			convey.So(resp.GetTaxAuditTime(), convey.ShouldEqual, 1223)
		})
}
