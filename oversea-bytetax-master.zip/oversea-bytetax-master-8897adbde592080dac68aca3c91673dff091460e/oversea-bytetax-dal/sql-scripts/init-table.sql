 CREATE TABLE `tax_country`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `country_geo_id`   bigint(11)          unsigned NOT NULL  COMMENT '地理中台国家id',
    `level_one`        bigint(11)          unsigned NOT NULL  COMMENT '地理中台一级地址id',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='上税国家表';

CREATE TABLE `tax_country_bind`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `country_geo_id`       bigint(11)          unsigned NOT NULL COMMENT '地理中台国家id',
    `subject_id`       bigint(11)          unsigned NOT NULL COMMENT '主体id',
    `tax_no`           varchar(128)        NOT NULL DEFAULT '' COMMENT '税号',
    `tax_no_country`   bigint(11)          unsigned NOT NULL DEFAULT '0' COMMENT '税号所在国家',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='上税国家主体绑定表';

CREATE TABLE `tax_biz`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `name`             varchar(128)        NOT NULL DEFAULT '' COMMENT '业务线名称',
    `code`             varchar(128)        NOT NULL DEFAULT '' COMMENT '业务线code',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='税务业务线表';

CREATE TABLE `tax_biz_bind`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `country_bind_id`  bigint(11)          unsigned NOT NULL COMMENT '国家绑定id',
    `biz_id`           bigint(11)          unsigned NOT NULL COMMENT '业务线id',
    `rule`             varchar(1024)       NOT NULL DEFAULT '' COMMENT '业务线规则',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='税务业务线国家主体绑定表';

CREATE TABLE `tax_item`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `name`             varchar(128)        NOT NULL DEFAULT '' COMMENT '商品名称',
    `code`             varchar(128)        NOT NULL DEFAULT '' COMMENT '商品code',
    `description`      varchar(256)        NOT NULL DEFAULT '' COMMENT '商品描述',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='税务商品表';



CREATE TABLE `tax_category_bind`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `tax_category_id`      bigint(11)          unsigned NOT NULL COMMENT '税种id',
    `item_id`          bigint(11)          unsigned NOT NULL COMMENT '商品id',
    `tax_rate`         decimal(18, 6)      NOT NULL DEFAULT '0.000000' COMMENT '税率',
    `include_tax`      tinyint             NOT NULL DEFAULT '0' COMMENT '是否含税价',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='税务税种绑定表';

CREATE TABLE `tax_category`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `code`             varchar(128)        NOT NULL DEFAULT '' COMMENT 'code',
    `name`             varchar(128)        NOT NULL DEFAULT '' COMMENT '税种',
    `description`      varchar(256)        NOT NULL DEFAULT '' COMMENT '税种描述',
    `country_geo_id`   bigint(11)          unsigned NOT NULL COMMENT '地理中台国家id',
    `include_tax`      tinyint             NOT NULL DEFAULT '0' COMMENT '是否含税价',
    `default_tax_rate` decimal(18, 6)      NOT NULL DEFAULT '0.000000' COMMENT '默认税率',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='税务税种表';

CREATE TABLE `tax_rule`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `bill_from`        varchar(256)        NOT NULL DEFAULT '' COMMENT '资金from',
    `bill_to`          varchar(256)        NOT NULL DEFAULT '' COMMENT '资金to',
    `ship_from`        varchar(256)        NOT NULL DEFAULT '' COMMENT '物流from',
    `ship_to`          varchar(256)        NOT NULL DEFAULT '' COMMENT '物流to',
    `item_id`          bigint(11)          unsigned NOT NULL COMMENT '商品id',
    `from_with_tax_no` tinyint             NOT NULL DEFAULT '0' COMMENT 'from是否有税号',
    `from_vat_country` bigint(11)          unsigned NOT NULL DEFAULT '0' COMMENT 'from税号所在国家',
    `to_with_tax_no`   tinyint             NOT NULL DEFAULT '0' COMMENT 'to是否有税号',
    `to_vat_country`   bigint(11)          unsigned NOT NULL DEFAULT '0' COMMENT 'to税号所在国家',
    `tax_category_id`      bigint(11)          unsigned NOT NULL COMMENT '税种id',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `approve_status`   int(11)             NOT NULL DEFAULT '0' COMMENT '审批状态',
    `remark`           varchar(128)        NOT NULL DEFAULT '' COMMENT '备注',
    `version`          int(11)             NOT NULL DEFAULT '1' COMMENT '版本',
    `head`             tinyint             NOT NULL DEFAULT '1' COMMENT '是否最新版本',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='税务规则表';

  CREATE TABLE `tax_exemption`
(
    `id`               bigint(11)          unsigned NOT NULL,
    `code`             varchar(128)        NOT NULL DEFAULT '' COMMENT '豁免code',
    `remark`           varchar(128)        NOT NULL DEFAULT '' COMMENT '备注',
    `white_list`       varchar(512)        NOT NULL DEFAULT '' COMMENT '名单列表',
    `operator_id`      int(11)             NOT NULL DEFAULT '0' COMMENT '创建人',
    `create_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `modify_time`      datetime            NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
    `is_delete`        tinyint             NOT NULL DEFAULT '0' COMMENT '逻辑删除标志',
    PRIMARY KEY (`id`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='豁免表';

CREATE TABLE `transaction` (
  `id` bigint PRIMARY KEY,
  `invoice_no` varchar(255) COMMENT '发票编号' default '',
  `transaction_type` bigint COMMENT '交易类型' not null,
  `tax_country_id` bigint COMMENT '国家主体绑定表id' not null,
  `total_taxable` decimal COMMENT '总税基' not null,
  `total_tax` decimal COMMENT '总税额' not null,
  `account_id` bigint COMMENT '用户id' default 0,
  `account_name` varchar(255) COMMENT '用户名字' default '',
  `billing_address` varchar(255) COMMENT '用户地址' not null,
  `currency_code` varchar(255) COMMENT '交易币种' not null,
  `exchange_rate` decimal COMMENT '交易币种 到税务局所需币种的汇率' not null,
  `invoice_date` datetime COMMENT '开票时间' not null ,
  `discount` decimal COMMENT '折扣' default 0,
  `extend` varchar(255) COMMENT '扩展' default null,
  `remark` varchar(255) COMMENT '备注' default '',
  `version` int COMMENT '版本' default 0,
  `head` int COMMENT '是否最新版本' default 1,
  `create_time` datetime default now(),
  `modify_time` datetime default now(),
  `is_delete` int default 0
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='交易信息记录表';

CREATE TABLE `transaction_detail` (
  `id` bigint PRIMARY KEY,
  `tax_category_bind_id` bigint COMMENT '税种商品信息' not null,
  `transaction_id` bigint COMMENT '关联的交易' not null,
  `taxable` decimal COMMENT '税基' not null ,
  `tax` decimal COMMENT '税额' not null ,
  `discount` decimal COMMENT '折扣' default 0,
  `extend` varchar(255) COMMENT '扩展' default null,
  `remark` varchar(255) COMMENT '备注' default '',
  `version` int COMMENT '版本' default 0,
  `head` int COMMENT '是否最新版本' default 1,
  `create_time` datetime default now(),
  `modify_time` datetime default now(),
  `is_delete` int default 0
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8mb4 COMMENT ='交易记录详情表';

 CREATE TABLE `whitelist_tax_rate` (
                                       `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
                                       `account_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '客户ID',
                                       `subject_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '主体ID',
                                       `country` varchar(256) NOT NULL DEFAULT '' COMMENT '国家',
                                       `valid_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) COMMENT '生效时间',
                                       `invalid_time` datetime(3) NOT NULL DEFAULT '2999-01-01 00:00:00.000' COMMENT '失效时间',
                                       `version` int(11) NOT NULL DEFAULT '1' COMMENT '版本号',
                                       `create_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) COMMENT '创建时间',
                                       `modify_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) COMMENT '修改时间',
                                       `tax_category` varchar(256) NOT NULL DEFAULT '' COMMENT '税种',
                                       `tax_rate` decimal(18,6) NOT NULL DEFAULT '0.000000' COMMENT '税率',
                                       `status` int(11) NOT NULL DEFAULT '0' COMMENT '生效状态：0=有效，1=失效'
  PRIMARY KEY (`id`),
                                       KEY `idx_account_subject` (`account_id`,`subejct_id`),
                                       KEY `idx_account_time` (`valid_time`,`invalid_time`),
                                       KEY `idx_modify_time` (`modify_time`),
                                       KEY `idx_subejct_id` (`subejct_id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客户白名单税率'