alter table transaction_primary
    add tax_biz_id bigint default 0 not null comment '业务线ID';


create table async_task
(
    id          bigint auto_increment comment '主键id'
        primary key,
    type        int                                not null comment '任务类型',
    status      int                                not null comment '任务状态 1-初始化 2-计算中 3-成功 4-失败',
    args        varchar(2048)                      not null comment '任务参数',
    result      varchar(2048)                      null comment '执行结果',
    done_time   datetime default                   null comment '任务完成时间',
    creator_id  bigint                             null comment '创建人id',
    is_delete   int                                null comment '逻辑删除标志 0-未删除 1-删除',
    create_time datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    update_time datetime default CURRENT_TIMESTAMP not null comment '更新时间'
)
    comment '异步任务表';
