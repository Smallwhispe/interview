package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhitelistTaxRateMetaDO {

    /**
     * 主键
     */
    private Long id;

    /**
     * 客户ID
     */
    private Long accountId;

    /**
     * 主体ID
     */
    private Long subjectId;

    /**
     * 国家
     */
    private String country;

    /**
     * 生效时间
     */
    private Date validTime;

    /**
     * 失效时间
     */
    private Date invalidTime;

    /**
     * 版本号
     */
    private Integer version;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 税种
     */
    private String taxCategory;

    /**
     * 税种类型
     */
    private EnumTaxClassify taxClassify;

    /**
     * 税率
     */
    private BigDecimal taxRate;

    /**
     * 生效状态：0=有效，1=失效
     */
    private EnumActiveStatus status;

    /**
     * 操作人
     */
    private Integer operatorId;

    /**
     * 合同ID
     */
    private Long contractId;
}
