package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxBizQuery;

import java.util.List;
import java.util.Map;

/**
 * bytedance
 * 2021/12/6 11:18 上午
 */
public interface TaxBizRepository {
    void save(TaxBizMetaDO metaDO);

    void updateByIdSelective(TaxBizMetaDO metaDO);

    TaxBizMetaDO getTaxBizByBizId(Long taxBizId);

    PageResult<TaxBizMetaDO> queryTaxBizList(TaxBizQuery query);

    List<TaxBizMetaDO> getAll();

    List<TaxBizMetaDO> getByIds(List<Long> ids);

    Map<Long, TaxBizMetaDO>  getTaxBizByIds(List<Long> ids);
}
