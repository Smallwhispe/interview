package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.lock.annotation.BlockAcquireLock;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoAPIRules;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoCheckStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoCheckResultMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxNoCheckResultMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckResultMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckResultPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckResultPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckResultQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxNoCheckResultRepository;
import com.google.common.base.Stopwatch;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
@Slf4j
@Repository
public class TaxNoCheckResultRepositoryImpl implements TaxNoCheckResultRepository {

    @Resource
    private TaxNoCheckResultMapper taxNoCheckResultMapper;

    @Resource
    @Lazy
    private TaxNoCheckResultRepository taxNoCheckResultRepository;

    @Override
    public TaxNoCheckResultMetaDO save(TaxNoCheckResultMetaDO metaDO) {
        Date now = new Date();
        metaDO.setCreateTime(now);
        metaDO.setModifyTime(now);
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        TaxNoCheckResultPO po = TaxNoCheckResultMapping.MAPPING.toPO(metaDO);
        taxNoCheckResultMapper.insertSelective(po);
        return TaxNoCheckResultMapping.MAPPING.toMetaDO(po);
    }

    @Override
    @BlockAcquireLock(prefix = "tax_no_result_update_",keyTimeOut=3000,blockingTimeout=3000, value = "#metaDO.getId()")
    public void updateByIdSelective(TaxNoCheckResultMetaDO metaDO) {
        //添加税号校验结果更新时间埋点
        StopWatch stopWatch=new StopWatch();
        stopWatch.start();
        Date now = new Date();
        metaDO.setModifyTime(now);
        taxNoCheckResultMapper.updateByPrimaryKeySelective(TaxNoCheckResultMapping.MAPPING.toPO(metaDO));
        stopWatch.stop();
        log.info("Tax No Check Result update by id, id.{},cost {}",metaDO.getId(),stopWatch.getTotalTimeMillis());
    }

    @Override
    public TaxNoCheckResultMetaDO getTaxNoCheckResultById(Long id) {
        if (id == null) {
            return null;
        }
        TaxNoCheckResultPO po = taxNoCheckResultMapper.selectByPrimaryKey(id);
        return TaxNoCheckResultMapping.MAPPING.toMetaDO(po);
    }

    @Override
    public TaxNoCheckResultMetaDO updateAPIRuleAndCheckResult(TaxNoCheckResultMetaDO resultMetaDO, EnumTaxNoAPIRules apiRules, EnumTaxNoCheckStatus checkStatus) {
        resultMetaDO.setApiRuleId(apiRules);
        resultMetaDO.setApiCheckResult(checkStatus);
        taxNoCheckResultRepository.updateByIdSelective(TaxNoCheckResultMetaDO.builder().id(resultMetaDO.getId()).apiRuleId(apiRules).apiCheckResult(checkStatus).build());
        return resultMetaDO;
    }

    @Override
    public boolean updatePrimaryKeyFromApi(EnumTaxNoAPIRules apiSource, String idFromApi, TaxNoCheckResultMetaDO resultMetaDO) {
        TaxNoCheckResultPOExample example = new TaxNoCheckResultPOExample();
        TaxNoCheckResultPOExample.Criteria criteria = example.createCriteria();
        criteria.andApiRuleIdEqualTo(apiSource.getCode());
        criteria.andApiPrimaryKeyEqualTo(idFromApi);
        return taxNoCheckResultMapper.updateByExampleSelective(TaxNoCheckResultMapping.MAPPING.toPO(resultMetaDO), example) > 0;
    }

    @Override
    public TaxNoCheckResultMetaDO SelectByPrimaryKeyFromApi(EnumTaxNoAPIRules apiSource, String idFromApi) {
        TaxNoCheckResultPOExample example = new TaxNoCheckResultPOExample();
        TaxNoCheckResultPOExample.Criteria criteria = example.createCriteria();
        criteria.andApiRuleIdEqualTo(apiSource.getCode());
        criteria.andApiPrimaryKeyEqualTo(idFromApi);
        List<TaxNoCheckResultPO> taxNoCheckResultPOS = taxNoCheckResultMapper.selectByExample(example);
        return CollectionUtils.isEmpty(taxNoCheckResultPOS) ? null : TaxNoCheckResultMapping.MAPPING.toMetaDO(taxNoCheckResultPOS.get(0));
    }


    @Override
    public List<TaxNoCheckResultMetaDO> query(TaxNoCheckResultQuery query) {
        TaxNoCheckResultPOExample example = new TaxNoCheckResultPOExample();
        TaxNoCheckResultPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if (CollectionUtils.isNotEmpty(query.getApiRuleIds())) {
            criteria.andApiRuleIdIn(query.getApiRuleIds());
        }
        if (query.getStartTime() != null) {
            criteria.andModifyTimeGreaterThanOrEqualTo(query.getStartTime());
        }
        if (query.getEndTime() != null) {
            criteria.andModifyTimeLessThan(query.getEndTime());
        }
        if (CollectionUtils.isNotEmpty(query.getApiCheckResults())) {
            criteria.andApiCheckResultIn(query.getApiCheckResults());
        }
        if (query.getTaskId() != null) {
            criteria.andApiPrimaryKeyEqualTo(query.getTaskId());
        }
        return TaxNoCheckResultMapping.MAPPING.toMetaDOList(taxNoCheckResultMapper.selectByExample(example));
    }
}
