package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.ValidTaxRateMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.fasterxml.jackson.core.type.TypeReference;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, JsonUtil.class, ValidTaxRateMetaDO.class, TypeReference.class, EnumTaxClassify.class})
public interface TaxCategoryMapping {

    TaxCategoryMapping MAPPING = Mappers.getMapper(TaxCategoryMapping.class);

    @Mapping(target = "classify", expression = "java(EnumUtils.getCode(metaDO.getTaxClassify()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "validTaxRate", expression = "java(JsonUtil.writeValueAsString(metaDO.getValidTaxRate()))")
    TaxCategoryPO toPO(TaxCategoryMetaDO metaDO);

    @Mapping(target = "taxClassify", expression = "java(EnumUtils.getEnumByCode(EnumTaxClassify.values(), po.getClassify()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "validTaxRate", expression = "java(JsonUtil.readValue(po.getValidTaxRate(), new TypeReference<List<ValidTaxRateMetaDO>>(){}))")
    TaxCategoryMetaDO toMetaDO(TaxCategoryPO po);

    List<TaxCategoryMetaDO> toMetaDOList(List<TaxCategoryPO> pos);

}
