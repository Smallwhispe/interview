package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckBiParamPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckBiParamPOExample;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TaxNoCheckBiParamMapper {
    int insert(TaxNoCheckBiParamPO record);

    int insertSelective(TaxNoCheckBiParamPO record);

    List<TaxNoCheckBiParamPO> selectByExample(TaxNoCheckBiParamPOExample example);

    TaxNoCheckBiParamPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxNoCheckBiParamPO record);

    int updateByPrimaryKey(TaxNoCheckBiParamPO record);
}