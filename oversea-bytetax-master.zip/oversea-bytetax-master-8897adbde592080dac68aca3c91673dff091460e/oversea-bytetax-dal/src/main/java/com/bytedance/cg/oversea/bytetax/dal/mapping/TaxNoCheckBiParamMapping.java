package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxIdentity;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckBiParamMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckBiParamPO;
import com.fasterxml.jackson.core.type.TypeReference;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 7/11/23 3:40 PM
 */
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {JsonUtil.class, EnumUtils.class, List.class, TypeReference.class,
                EnumTaxIdentity.class, EnumDeleteStatus.class})
public interface TaxNoCheckBiParamMapping {

    TaxNoCheckBiParamMapping MAPPING = Mappers.getMapper(TaxNoCheckBiParamMapping.class);


    @Mapping(target = "paramList", expression = "java(JsonUtil.readValue(po.getParamList(), new TypeReference<List<String>>(){}))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "taxIdentity", expression = "java(EnumUtils.getEnumByCode(EnumTaxIdentity.values(), po.getTaxIdentity()))")
    TaxNoCheckBiParamMetaDO toMetaDO(TaxNoCheckBiParamPO po);

}
