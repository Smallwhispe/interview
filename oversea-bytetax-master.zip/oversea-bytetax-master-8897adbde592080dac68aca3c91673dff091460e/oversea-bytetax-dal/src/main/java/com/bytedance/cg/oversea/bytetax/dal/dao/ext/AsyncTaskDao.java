package com.bytedance.cg.oversea.bytetax.dal.dao.ext;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author wangjian.2021
 * @date 2022/6/14
 **/
@Mapper
public interface AsyncTaskDao {

    /**
     * 如果在 初始化/失败 状态 ， 更新任务状态为计算中
     *
     * @param id
     * @return affect rows
     */
    int setProcessingIfCan(Long id);
}
