package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoType;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.compress.utils.Lists;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2022/10/26
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionInfoExtend {

    private List<TaxAdminInfo> taxAdminInfo;

    // es中直接以string存储，因为不需要作为筛选条件
    private Map<EnumTaxNoType, String> customerTaxInfo;

    private Boolean acquireExchangeRate;

    /**
     * 匹配到的预扣税规则ID
     */
    private List<WhtInfo> whtInfos;

    private String bizTransactionId;

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class TaxAdminInfo {

        private Long taxAdminId;

        private Long taxAdminBindId;
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class WhtInfo {

        /**
         * 规则ID
         */
        private Long ruleId;

        /**
         * 税额（交易币种）
         */
        private BigDecimal transactionTax;

        /**
         * 税基（交易币种）
         */
        private BigDecimal transactionTaxable;

        /**
         * 税率
         */
        private BigDecimal taxRate;
    }


    public Map<EnumTaxNoType, String> getOrGenCustomerTaxInfo() {
        if (customerTaxInfo == null) {
            customerTaxInfo = Maps.newHashMap();
        }
        return customerTaxInfo;
    }

    public List<TaxAdminInfo> getOrGenTaxAdminInfo() {
        if (taxAdminInfo == null) {
            taxAdminInfo = Lists.newArrayList();
        }
        return taxAdminInfo;
    }
}
