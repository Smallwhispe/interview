package com.bytedance.cg.oversea.bytetax.dal.metado.script;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * bytedance
 * 2022/5/24 9:28 下午
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaxAdminSubjectBindExcelMetaDO {

    /**
     * 我方主体
     */
    private Long subjectId;



    private String adminBelongCountry;

    /**
     * 税务局名称
     */
    private String taxAdminName;

    /**
     * 税号
     */
    private String taxNo;

    /**
     * 税务局id
     */
    private Long taxAdminId;
}
