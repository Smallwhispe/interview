package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.bytedtrace.utils.CollectionUtils;
import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxCategoryMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxCategoryQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.ChangeLogRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCategoryRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2022/4/21
 **/
@Repository
public class TaxCategoryRepositoryImpl implements TaxCategoryRepository {

    @Resource
    private TaxCategoryMapper taxCategoryMapper;

    @Resource
    @Lazy
    private TaxCategoryRepository taxCategoryRepository;

    @Override
    public TaxCategoryMetaDO save(TaxCategoryMetaDO metaDO){
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        metaDO.setCode("to be generated");
        TaxCategoryPO taxCategoryPO = TaxCategoryMapping.MAPPING.toPO(metaDO);
        taxCategoryMapper.insert(taxCategoryPO);
        Long id = taxCategoryPO.getId();
        taxCategoryPO.setCode(genCode(taxCategoryPO.getCategory(), id));
        taxCategoryMapper.updateByPrimaryKeySelective(taxCategoryPO);
        return TaxCategoryMapping.MAPPING.toMetaDO(taxCategoryPO);
    }

    public String genCode(String category, Long id) {
        return category + String.format("%05d", id);
    }


    @Override
    public TaxCategoryMetaDO updateByIdSelective(TaxCategoryMetaDO metaDO){
        metaDO.setModifyTime(new Date());
        TaxCategoryPO taxCategoryPO = TaxCategoryMapping.MAPPING.toPO(metaDO);
        taxCategoryMapper.updateByPrimaryKeySelective(taxCategoryPO);
        return TaxCategoryMapping.MAPPING.toMetaDO(taxCategoryPO);
    }

    @Override
    public TaxCategoryMetaDO getTaxCategoryById(Long id){
        if(id == null) {
            return null;
        }
        TaxCategoryPOExample taxCategoryPOExample = new TaxCategoryPOExample();
        taxCategoryPOExample.createCriteria().andIdEqualTo(id);
        TaxCategoryPO taxCategoryPO = taxCategoryMapper.selectByPrimaryKey(id);
        if(taxCategoryPO == null) {
            return null;
        }
        return TaxCategoryMapping.MAPPING.toMetaDO(taxCategoryPO);
    }

    @Override
    public Map<Long, TaxCategoryMetaDO> getTaxCategoriesByIds(List<Long> ids) {
        if (org.apache.commons.collections4.CollectionUtils.isEmpty(ids)) {
            return Maps.newHashMap();
        }
        TaxCategoryPOExample example = new TaxCategoryPOExample();
        example.createCriteria().andIdIn(ids);
        List<TaxCategoryMetaDO> taxCategoryMetaDOS = TaxCategoryMapping.MAPPING.toMetaDOList(taxCategoryMapper.selectByExample(example));
        return Optional.ofNullable(taxCategoryMetaDOS).orElse(Collections.emptyList()).
                stream().collect(Collectors.toMap(TaxCategoryMetaDO::getId, Function.identity()));
    }


    @Override
    public PageResult<TaxCategoryMetaDO> queryTaxCategoryList(TaxCategoryQuery query) {
        TaxCategoryPOExample example = new TaxCategoryPOExample();
        example.setOrderByClause("modify_time desc");
        TaxCategoryPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if (query.getId() != null) {
            criteria.andIdEqualTo(query.getId());
        }
        if (checkString(query.getCode())) {
            criteria.andCodeEqualTo(validate(query.getCode()) );
        }
        if (checkString(query.getCategory())) {
            criteria.andCategoryEqualTo(validate(query.getCategory()));
        }
        if (query.getTaxClassify() != null) {
            criteria.andClassifyEqualTo(query.getTaxClassify().getCode());
        }
        if (checkString(query.getDescription())) {
            criteria.andDescriptionLike("%" + validate(query.getDescription()) + "%");
        }
        if (query.getTaxAdminId() != null){
            criteria.andTaxAdminIdEqualTo(query.getTaxAdminId());
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxCategoryPO> taxCategoryPOPageInfo = new PageInfo<>(taxCategoryMapper.selectByExample(example));
        return new PageResult<>(taxCategoryPOPageInfo.getTotal(),
                TaxCategoryMapping.MAPPING.toMetaDOList(taxCategoryPOPageInfo.getList()));
    }

    private String validate(String str){
        str = str.trim();
        StringBuilder ans = new StringBuilder();
        for(char c : str.toCharArray()){
            if(c == '_' || c == '%'){
                ans.append("\\");
            }
            ans.append(c);
        }
        return ans.toString();
    }

    private boolean checkString(String str){
        return !(str == null || str.trim().length() == 0);
    }

    @Override
    public List<TaxCategoryMetaDO> queryByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        TaxCategoryPOExample example = new TaxCategoryPOExample();
        example.createCriteria().andIdIn(ids);
        return TaxCategoryMapping.MAPPING.toMetaDOList(taxCategoryMapper.selectByExample(example));
    }

    @Override
    public List<TaxCategoryMetaDO> queryAllTaxRate(){
        TaxCategoryPOExample example = new TaxCategoryPOExample();
        example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxCategoryPO> taxCategoryPOS = taxCategoryMapper.selectByExample(example);
        List<TaxCategoryMetaDO> taxCategoryMetaDOS = TaxCategoryMapping.MAPPING.toMetaDOList(taxCategoryPOS);
        return taxCategoryMetaDOS;
    }
}
