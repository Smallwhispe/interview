package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.CasesPO;
import com.bytedance.cg.oversea.bytetax.dal.po.CasesPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CasesMapper {
    int insert(CasesPO record);

    int insertSelective(CasesPO record);

    List<CasesPO> selectByExample(CasesPOExample example);

    CasesPO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") CasesPO record, @Param("example") CasesPOExample example);

    int updateByExample(@Param("record") CasesPO record, @Param("example") CasesPOExample example);

    int updateByPrimaryKeySelective(CasesPO record);

    int updateByPrimaryKey(CasesPO record);
}