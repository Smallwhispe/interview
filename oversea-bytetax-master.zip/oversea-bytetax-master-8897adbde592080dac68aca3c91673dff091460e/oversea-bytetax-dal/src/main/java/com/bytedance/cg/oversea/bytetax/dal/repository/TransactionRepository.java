package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPO;
import com.bytedance.cg.oversea.bytetax.dal.query.TransactionQuery;
import com.bytedance.cg.oversea.bytetax.dal.query.elasticsearch.TransactionKeyDataEsQuery;
import com.github.pagehelper.PageInfo;
import org.joda.time.DateTime;

import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2022/1/14
 **/
public interface TransactionRepository {
    TransactionMetaDO queryTransactionById(Long id);

    PageResult<TransactionMetaDO> queryTransactionByIds(List<Long> ids);

    TransactionMetaDO querySalesInvoiceByBizId(String bizTransactionId);

    List<TransactionMetaDO> queryTransactionMetaDOS(Long adminId, Long offsetId, int limit, DateTime startTime, DateTime endTime);

    PageInfo<TransactionPO> queryTransactionMetaDOS(Long subjectId, List<Long> adminIds, Integer pageNumber, Integer pageSize, DateTime startTime, DateTime endTime);

    Long queryTransactionCnt(List<Long> taxAdminIds, DateTime startTime, DateTime endTime);

    int save(TransactionMetaDO transactionMetaDO);

    int update(TransactionMetaDO transactionMetaDO);

    int delete(Long id);

    List<TransactionMetaDO> queryTaxReportTransaction(String invoiceNo, Long taxAdminId);

    List<TransactionMetaDO> queryTaxReportTransactionByInvoice(String invoiceNo);

    PageResult<TransactionMetaDO> queryTransactionMetaDOS(TransactionQuery query);

    Map<String, TransactionMetaDO> queryTransactionByInvoiceSerials(List<String> serials);

}