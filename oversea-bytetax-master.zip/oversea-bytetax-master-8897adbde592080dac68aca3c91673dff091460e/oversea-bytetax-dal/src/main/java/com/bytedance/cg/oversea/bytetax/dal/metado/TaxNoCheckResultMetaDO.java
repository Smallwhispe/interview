package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaxNoCheckResultMetaDO {

    /**
     *
     */
    private Long id;

    /**
     * 税号
     */
    private String taxNo;

    /**
     * individual/business，对应枚举类
     */
    private EnumTaxIdentity taxIdentity;

    /**
     * 税号校验规则 tax_no_check_rule 的id
     */
    private Long checkRuleId;

    /**
     * API校验规则, 对应 EnumTaxNoAPIRules
     */
    private EnumTaxNoAPIRules apiRuleId;

    /**
     * 外部校验记录的主键
     */
    private String apiPrimaryKey;

    /**
     * 格式校验校验结果，对应枚举类 EnumTaxNoMatchResult
     */
    private EnumTaxNoCheckStatus formatCheckResult;

    /**
     * API校验校验结果，对应枚举类 EnumTaxNoMatchResult
     */
    private EnumTaxNoCheckStatus apiCheckResult;

    /**
     * 异步source查询接口返回id，用于后续结果查询，如{"FONOA_API_SOURCE":"xxxxx"}
     */
    private Map<String, String> extraId;

    /**
     * 主体状态
     */
    private EnumActiveStatus businessStatus;

    /**
     * 公司名称
     */
    private String companyName;

    /**
     * 公司额外信息，以map的json字符串格式储存
     */
    private String companyExtraInfo;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;

    /**
     * 上游业务方主键
     */
    private String bizPrimaryId;

    /**
     * 上游业务方Id
     */
    private Long businessLineId;

    /**
     * 请求extend
     */
    private Map<String, String> requestExtend;

    /**
     * 结果extend
     */
    private TaxNoExtMetaDO responseExtend;

    /**
     * 版本
     */
    private EnumVersion version;

    public void putExtraId(EnumTaxNoAPIRules apiRules, String extraId) {
        if (this.extraId == null) {
            this.extraId = new HashMap<>(ConstantValue.FOUR);
        }
        this.extraId.put(apiRules.getName(), extraId);
    }

    public String getExtraIdValue(EnumTaxNoAPIRules apiRules) {
        if (this.extraId == null) {
            this.extraId = new HashMap<>(ConstantValue.FOUR);
        }
        return this.extraId.get(apiRules.getName());
    }

    public void putRequestExtend(String key, String value) {
        if (this.requestExtend == null) {
            this.requestExtend = new HashMap<>(ConstantValue.FOUR);
        }
        this.requestExtend.put(key, value);
    }

    public String getRequestExtendValue(String key) {
        if (this.requestExtend == null) {
            this.requestExtend = new HashMap<>(ConstantValue.FOUR);
        }
        return this.requestExtend.get(key);
    }
}
