package com.bytedance.cg.oversea.bytetax.dal.query;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

/**
 * @author wangjian.2021
 * @date 2022/6/9
 **/
@Data
@NoArgsConstructor
public class TransactionQuery {
    /**
     * 主体ID
     */
    private Long subjectId;

    /**
     * 交易ID
     */
    private Long id;

    /**
     * 交易时间开始时间
     */
    private DateTime transactionTimeBegin;

    /**
     * 交易时间结束时间
     */
    private DateTime transactionTimeEnd;

    /**
     * 交易类别
     */
    private EnumTransactionCategory transactionCategory;

    /**
     * 客户名称关键词
     */
    private String accountNameKw;

    /**
     * 客户Level0地址ID
     */
    private Long billingAddressIdL0;

    /**
     * 客户Level1地址ID
     */
    private Long billingAddressIdL1;

    /**
     * 单页大小
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNumber;
}
