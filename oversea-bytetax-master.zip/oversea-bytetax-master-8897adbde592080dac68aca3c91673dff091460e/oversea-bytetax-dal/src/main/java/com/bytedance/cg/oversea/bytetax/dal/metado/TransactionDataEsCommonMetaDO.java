package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * bytedance
 * 2022/10/12 12:45 下午
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class TransactionDataEsCommonMetaDO {
    private List<TransactionDataEsPO> transactionDataEsPOS;

    private Long total;
}
