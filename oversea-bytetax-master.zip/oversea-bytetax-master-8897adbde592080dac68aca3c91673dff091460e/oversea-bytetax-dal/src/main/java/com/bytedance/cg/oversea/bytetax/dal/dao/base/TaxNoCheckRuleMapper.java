package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckRulePOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxNoCheckRuleMapper {
    int insert(TaxNoCheckRulePO record);

    int insertSelective(TaxNoCheckRulePO record);

    List<TaxNoCheckRulePO> selectByExample(TaxNoCheckRulePOExample example);

    TaxNoCheckRulePO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxNoCheckRulePO record);

    int updateByPrimaryKey(TaxNoCheckRulePO record);
}