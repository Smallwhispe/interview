package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxCalculateType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryBindPO;
import jnr.ffi.annotations.In;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, EnumTaxCalculateType.class})
public interface TaxCategoryBindMapping {

    TaxCategoryBindMapping MAPPING = Mappers.getMapper(TaxCategoryBindMapping.class);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "includeTax", expression = "java(metaDO.getTaxCalculateType().getCode())")
    TaxCategoryBindPO toPO(TaxCategoryBindMetaDO metaDO);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "taxCalculateType", expression = "java(EnumUtils.getEnumByCode(EnumTaxCalculateType.values(), po.getIncludeTax()))")
    TaxCategoryBindMetaDO toMetaDO(TaxCategoryBindPO po);

    List<TaxCategoryBindMetaDO> toMetaDOList(List<TaxCategoryBindPO> pos);

}
