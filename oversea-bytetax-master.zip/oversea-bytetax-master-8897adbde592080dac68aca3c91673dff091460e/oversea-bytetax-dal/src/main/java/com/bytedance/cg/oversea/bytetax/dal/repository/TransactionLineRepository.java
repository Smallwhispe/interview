package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionLineMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.ValidTaxRateMetaDO;

import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
public interface TransactionLineRepository {

    /**
     * 根据交易Id查询详情
     * @return
     */
    List<TransactionLineMetaDO> queryDetailByTransactionId(Long transactionId);
    /**
     * 根据交易Ids查询详情
     * @return
     */
    Map<Long, List<TransactionLineMetaDO>> queryDetailByTransactionIds(List<Long> transactionIds);

    List<TaxCategoryMetaDO> queryByTranIdAndItemId(Long tranId, Long itemId);


    int save(List<TransactionLineMetaDO> transactionLineMetaDOs);
}
