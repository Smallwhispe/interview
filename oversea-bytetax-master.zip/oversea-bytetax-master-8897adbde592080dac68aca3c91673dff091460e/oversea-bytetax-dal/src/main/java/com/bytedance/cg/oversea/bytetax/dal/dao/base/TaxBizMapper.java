package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxBizMapper {
    int insert(TaxBizPO record);

    int insertSelective(TaxBizPO record);

    List<TaxBizPO> selectByExample(TaxBizPOExample example);

    TaxBizPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxBizPO record);

    int updateByPrimaryKey(TaxBizPO record);
}