package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author wangjian.2021
 * @date 2022/6/14
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AsyncTaskMetaDO {

    /**
     * 主键id
     */
    private Long id;

    /**
     * 任务类型
     */
    private EnumAsyncTaskType type;

    /**
     * 任务状态 1-初始化 2-计算中 3-成功 4-失败
     */
    private EnumAsyncTaskStatus status;

    /**
     * 任务参数
     */
    private String args;

    /**
     * 执行结果
     */
    private String result;

    /**
     * 任务完成时间
     */
    private Date doneTime;

    /**
     * 创建人id
     */
    private Long creatorId;

    /**
     * 逻辑删除标志 0-未删除 1-删除
     */
    private EnumDeleteStatus isDelete;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;
}
