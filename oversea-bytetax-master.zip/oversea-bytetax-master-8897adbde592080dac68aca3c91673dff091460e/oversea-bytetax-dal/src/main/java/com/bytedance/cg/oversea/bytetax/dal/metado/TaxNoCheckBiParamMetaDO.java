package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxIdentity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 7/11/23 3:11 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoCheckBiParamMetaDO {
    /**
     * id
     */
    private Long id;

    /**
     * 国家二字iso码
     */
    private String countryIso;

    /**
     * 税务身份
     */
    private EnumTaxIdentity taxIdentity;

    /**
     * 入参列表，字符串列表的JSON字符串
     */
    private List<String> paramList;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;
}
