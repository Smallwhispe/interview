package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxSubjectCompanyCodeBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxSubjectCompanyCodeBindPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxSubjectCompanyCodeBindMapper {
    int insert(TaxSubjectCompanyCodeBindPO record);

    int insertSelective(TaxSubjectCompanyCodeBindPO record);

    List<TaxSubjectCompanyCodeBindPO> selectByExample(TaxSubjectCompanyCodeBindPOExample example);

    TaxSubjectCompanyCodeBindPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxSubjectCompanyCodeBindPO record);

    int updateByPrimaryKey(TaxSubjectCompanyCodeBindPO record);
}