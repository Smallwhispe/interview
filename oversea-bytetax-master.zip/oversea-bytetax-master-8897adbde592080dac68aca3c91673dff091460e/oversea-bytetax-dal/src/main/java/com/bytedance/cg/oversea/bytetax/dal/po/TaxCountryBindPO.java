package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxCountryBindPO {
    /**
     * 
     */
    private Long id;

    /**
     * 地理中台国家id
     */
    private Long countryGeoId;

    /**
     * 
     */
    private Long secondGeoId;

    /**
     * 主体id
     */
    private Long subjectId;

    /**
     * 税号
     */
    private String taxNo;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 税号所在国家
     */
    private Long taxNoCountry;

    /**
     * 
     */
    private Long taxAdminId;
}