package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author wangjian.2021
 * @date 2022/8/11
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxAdminSubjectBindQuery {

    /**
     * 主键
     */
    private Long id;

    /**
     * 税务局ID
     */
    private Long taxAdminId;

    /**
     * 每页数量
     */
    private Integer pageSize;

    /**
     * 页码 从1开始
     */
    private Integer pageNumber;

    public boolean checkValid() {
        return this.taxAdminId != null || this.id != null;
    }
}
