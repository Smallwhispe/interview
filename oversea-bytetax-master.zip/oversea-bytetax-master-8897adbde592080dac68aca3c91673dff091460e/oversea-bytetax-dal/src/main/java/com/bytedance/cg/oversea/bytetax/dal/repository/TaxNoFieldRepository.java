package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoFieldMetaDO;

import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2023/8/22
 **/
public interface TaxNoFieldRepository {

    Map<Long, TaxNoFieldMetaDO> queryByIds(List<Long> ids);

    List<TaxNoFieldMetaDO> queryAllWithCache();
}
