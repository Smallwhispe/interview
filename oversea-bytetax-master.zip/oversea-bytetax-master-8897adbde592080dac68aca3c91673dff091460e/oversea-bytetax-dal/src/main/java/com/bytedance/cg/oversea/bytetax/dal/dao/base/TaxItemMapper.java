package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxItemMapper {
    int insert(TaxItemPO record);

    int insertSelective(TaxItemPO record);

    List<TaxItemPO> selectByExample(TaxItemPOExample example);

    TaxItemPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxItemPO record);

    int updateByPrimaryKey(TaxItemPO record);
}