package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxItemBindMetaDO;

public interface TaxItemBindRepository {

    TaxItemBindMetaDO queryByItemId(Long itemId);

    TaxItemBindMetaDO queryByBizItemCode(String itemCode, Long bizLineId);

    TaxItemBindMetaDO queryByPlatformItemCode(String platformItemCode, Long bizLineId);
}
