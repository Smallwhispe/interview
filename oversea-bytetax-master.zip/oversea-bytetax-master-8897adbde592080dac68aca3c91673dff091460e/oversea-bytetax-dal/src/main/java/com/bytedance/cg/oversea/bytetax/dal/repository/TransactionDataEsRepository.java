package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsCommonMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import java.util.List;

/**
 * bytedance
 * 2022/9/26 4:00 下午
 */
public interface TransactionDataEsRepository {
    TransactionDataEsCommonMetaDO transactionSelectScroll(SearchSourceBuilder builder);

    TransactionDataEsCommonMetaDO transactionSelect(SearchSourceBuilder builder);
}
