package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TransactionMapper {
    long countByExample(TransactionPOExample example);

    int insert(TransactionPO record);

    int insertSelective(TransactionPO record);

    List<TransactionPO> selectByExample(TransactionPOExample example);

    TransactionPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TransactionPO record);

    int updateByPrimaryKey(TransactionPO record);
}