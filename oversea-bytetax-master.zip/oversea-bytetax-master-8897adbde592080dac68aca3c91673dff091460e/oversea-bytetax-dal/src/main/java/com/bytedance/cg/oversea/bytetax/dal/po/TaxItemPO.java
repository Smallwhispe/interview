package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxItemPO {
    /**
     * 
     */
    private Long id;

    /**
     * 商品名称
     */
    private String name;

    /**
     * 商品code
     */
    private String code;

    /**
     * 商品描述
     */
    private String description;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 商品种类
     */
    private Integer type;
}