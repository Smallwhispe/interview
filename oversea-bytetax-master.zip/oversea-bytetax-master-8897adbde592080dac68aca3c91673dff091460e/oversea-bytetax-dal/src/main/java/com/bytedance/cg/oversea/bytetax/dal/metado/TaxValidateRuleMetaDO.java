package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoFormatRuleType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/08/14 7:17 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxValidateRuleMetaDO {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 规则大类，1-正则，非1-其他
     */
    private EnumTaxNoFormatRuleType ruleType;

    /**
     * 正则表达式（如有）
     */
    private String rule;

    /**
     * 页面展示的规则名称
     */
    private String ruleName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;
}
