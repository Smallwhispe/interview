package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxAdminSubjectBindQuery;

import java.util.List;
import java.util.Map;

public interface TaxAdminSubjectRepository {

    Map<Long, TaxAdminSubjectMetaDO> queryTaxAdminSubject(List<Long> ids, Long subjectId);

    TaxAdminSubjectMetaDO getById(Long id);

    List<TaxAdminSubjectMetaDO> getByIds(List<Long> id);

    List<TaxAdminSubjectMetaDO> queryTaxAdminSubjectByAdminId(Long adminId);

    void saveSelective(TaxAdminSubjectMetaDO metaDO);

    void fullSave(TaxAdminSubjectMetaDO metaDO);

    List<Long> queryTaxAdminSubjectBySubjectId(Long subjectId);

    PageResult<TaxAdminSubjectMetaDO> query(TaxAdminSubjectBindQuery query);

    List<TaxAdminSubjectMetaDO> getAllTaxAdminSubjectByAdminId(Long adminId, boolean onlyNeedActive);

    TaxAdminSubjectMetaDO queryById(Long id, boolean onlyNeedActive);

    void deleteById(Long id);
}
