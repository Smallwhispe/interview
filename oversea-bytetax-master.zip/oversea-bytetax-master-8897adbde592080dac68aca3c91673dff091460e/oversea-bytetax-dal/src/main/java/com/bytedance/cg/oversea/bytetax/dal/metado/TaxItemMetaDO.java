package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxItemMetaDO {
    /**
     *
     */
    private Long id;

    /**
     * 商品名称
     */
    private String name;

    /**
     * 商品code
     */
    private String code;

    /**
     * 商品描述
     */
    private String description;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;

    /**
     * 商品种类
     */
    private Integer type;

//    /**
//     * 商品类别
//     */
//    private String category;
//
//    /**
//     * 商品组别
//     */
//    private String itemGroup;
}