package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.WhitelistTaxRateMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.WhitelistTaxRateQuery;

public interface WhitelistTaxRateRepository {
    void save(WhitelistTaxRateMetaDO metaDO);

    void updateByIdSelective(WhitelistTaxRateMetaDO metaDO);

    WhitelistTaxRateMetaDO getById(Long id);

    PageResult<WhitelistTaxRateMetaDO> queryList(WhitelistTaxRateQuery query);
}
