package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxAdminSubjectMapper {
    int insert(TaxAdminSubjectPO record);

    int insertSelective(TaxAdminSubjectPO record);

    List<TaxAdminSubjectPO> selectByExample(TaxAdminSubjectPOExample example);

    TaxAdminSubjectPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxAdminSubjectPO record);

    int updateByPrimaryKey(TaxAdminSubjectPO record);
}