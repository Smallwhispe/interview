package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.dal.elasticsearch.TransactionDataEsDAO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsCommonMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsScrollMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import com.bytedance.cg.oversea.bytetax.dal.repository.TransactionDataEsRepository;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * bytedance
 * 2022/9/27 5:26 下午
 */
//@Repository
//@Profile({"prod-sg", "boe-prod", "boe-va", "dev"})
public class TransactionDataEsRepositoryImpl implements TransactionDataEsRepository {
    @Resource
    private TransactionDataEsDAO transactionDataEsDAO;
    // 大批量查询时才需要，判断是否需要;适用于异步下载，量级比较大的情况
    @Override
    public TransactionDataEsCommonMetaDO transactionSelectScroll(SearchSourceBuilder sourceBuilder) {
        List<TransactionDataEsPO> results = Lists.newArrayList();
        TransactionDataEsScrollMetaDO transactionDataEsScrollMetaDO = transactionDataEsDAO.transactionSelectScroll(sourceBuilder);
        try {
            while(CollectionUtils.isNotEmpty(transactionDataEsScrollMetaDO.getTransactionDataEsPOS())) {
                results.addAll(transactionDataEsScrollMetaDO.getTransactionDataEsPOS());
                transactionDataEsScrollMetaDO = transactionDataEsDAO.scrollEachTag(transactionDataEsScrollMetaDO.getScrollId());
            }
        } finally {
            // clear操作
            transactionDataEsDAO.clearScroll(transactionDataEsScrollMetaDO.getScrollId());
        }
        return TransactionDataEsCommonMetaDO.builder().transactionDataEsPOS(results).total(Long.valueOf(results.size())).build();
    }

    @Override
    public TransactionDataEsCommonMetaDO transactionSelect(SearchSourceBuilder sourceBuilder) {
        return transactionDataEsDAO.transactionSelect(sourceBuilder);
    }
}
