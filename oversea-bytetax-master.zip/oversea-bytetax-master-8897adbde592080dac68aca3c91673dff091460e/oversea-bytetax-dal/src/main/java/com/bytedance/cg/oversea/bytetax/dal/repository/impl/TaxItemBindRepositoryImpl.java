package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.StringUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxItemBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxItemBindMapping;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxItemMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxItemBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxItemBindRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class TaxItemBindRepositoryImpl implements TaxItemBindRepository {

    @Resource
    private TaxItemBindMapper taxItemBindMapper;

    @Override
    public TaxItemBindMetaDO queryByItemId(Long itemId) {
        if (itemId == null) {
            return null;
        }
        TaxItemBindPOExample example = new TaxItemBindPOExample();
        example.createCriteria().andItemIdEqualTo(itemId).andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxItemBindPO> taxItemBindPOS = taxItemBindMapper.selectByExample(example);
        return TaxItemBindMapping.MAPPING.toMetaDO(CollectionUtils.isEmpty(taxItemBindPOS) ? null : taxItemBindPOS.get(ConstantValue.ZERO));
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_5M_CACHE, unless = "#result == null")
    public TaxItemBindMetaDO queryByBizItemCode(String itemCode, Long bizLineId) {
        if (StringUtil.isEmpty(itemCode) || bizLineId == null) {
            return null;
        }
        TaxItemBindPOExample example = new TaxItemBindPOExample();
        example.createCriteria().andBizItemCodeEqualTo(itemCode).andBizLineIdEqualTo(bizLineId).andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxItemBindPO> taxItemBindPOS = taxItemBindMapper.selectByExample(example);
        return TaxItemBindMapping.MAPPING.toMetaDO(CollectionUtils.isEmpty(taxItemBindPOS) ? null : taxItemBindPOS.get(ConstantValue.ZERO));
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_5M_CACHE, unless = "#result == null")
    public TaxItemBindMetaDO queryByPlatformItemCode(String platformItemCode, Long bizLineId) {
        if (StringUtil.isEmpty(platformItemCode) || bizLineId == null) {
            return null;
        }
        TaxItemBindPOExample example = new TaxItemBindPOExample();
        example.createCriteria().andItemIdEqualTo(Long.parseLong(platformItemCode)).andBizLineIdEqualTo(bizLineId).andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxItemBindPO> taxItemBindPOS = taxItemBindMapper.selectByExample(example);
        return TaxItemBindMapping.MAPPING.toMetaDO(CollectionUtils.isEmpty(taxItemBindPOS) ? null : taxItemBindPOS.get(ConstantValue.ZERO));
    }
}
