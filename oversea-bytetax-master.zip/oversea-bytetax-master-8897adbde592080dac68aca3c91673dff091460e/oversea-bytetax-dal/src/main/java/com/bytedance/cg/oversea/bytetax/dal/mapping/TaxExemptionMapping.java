package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.CertificateMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxExemptionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxExemptionPO;
import com.fasterxml.jackson.core.type.TypeReference;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, JsonUtil.class, TypeReference.class, CertificateMetaDO.class})
public interface TaxExemptionMapping {

    TaxExemptionMapping MAPPING = Mappers.getMapper(TaxExemptionMapping.class);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "certificate", expression = "java(JsonUtil.writeValueAsString(metaDO.getCertificate()))")
    TaxExemptionPO toPO(TaxExemptionMetaDO metaDO);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "certificate", expression = "java(JsonUtil.readValue(po.getCertificate(), new TypeReference<List<CertificateMetaDO>>(){}))")
    TaxExemptionMetaDO toMetaDO(TaxExemptionPO po);

    List<TaxExemptionMetaDO> toMetaDOList(List<TaxExemptionPO> pos);

}
