package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxItemQuery {
    private Long id;

    private String name;

    private String code;

    private String description;

    private Integer type;

    private String itemTypeName;

    private Integer pageSize;

    private Integer pageNumber;
}
