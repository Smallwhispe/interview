package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryBindMetaDO;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/24
 **/
public interface TaxCategoryBindRepository {

    List<TaxCategoryBindMetaDO> queryByIds(List<Long> ids);
}
