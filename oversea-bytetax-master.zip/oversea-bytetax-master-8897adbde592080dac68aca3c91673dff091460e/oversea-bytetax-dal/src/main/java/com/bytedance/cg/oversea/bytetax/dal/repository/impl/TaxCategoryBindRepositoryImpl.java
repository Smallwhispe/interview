package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxCategoryBindMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCategoryBindRepository;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/24
 **/
@Repository
public class TaxCategoryBindRepositoryImpl implements TaxCategoryBindRepository {
    @Resource
    private TaxCategoryBindMapper taxCategoryBindMapper;

    @Override
    public List<TaxCategoryBindMetaDO> queryByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        TaxCategoryBindPOExample example = new TaxCategoryBindPOExample();
        example.createCriteria().andIdIn(ids);
        return TaxCategoryBindMapping.MAPPING.toMetaDOList(taxCategoryBindMapper.selectByExample(example));
    }
}
