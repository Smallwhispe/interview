package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxNoConfigPO {
    /**
     * 
     */
    private Long id;

    /**
     * 
     */
    private Long countryGeoId;

    /**
     * 
     */
    private String addressConfig;

    /**
     * 
     */
    private String taxInfoConfig;

    /**
     * 
     */
    private String versionConfig;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date modifyTime;

    /**
     * 
     */
    private Integer operatorId;

    /**
     * 
     */
    private Integer isActive;

    /**
     * 
     */
    private Integer isDelete;
}