package com.bytedance.cg.oversea.bytetax.dal.po;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class TransactionDetailPO {
    /**
     * 
     */
    private Long id;

    /**
     * 税种商品绑定id
     */
    private String taxCategoryBindIds;

    /**
     * 商品id
     */
    private Long itemId;

    /**
     * 数量
     */
    private Integer quantity;

    /**
     * 关联的交易
     */
    private Long transactionId;

    /**
     * 税基
     */
    private BigDecimal taxable;

    /**
     * 税额
     */
    private BigDecimal tax;

    /**
     * 折扣
     */
    private BigDecimal discount;

    /**
     * 扩展
     */
    private String extend;

    /**
     * 备注
     */
    private String remark;

    /**
     * 版本
     */
    private Integer version;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date modifyTime;

    /**
     * 
     */
    private Integer isDelete;
}