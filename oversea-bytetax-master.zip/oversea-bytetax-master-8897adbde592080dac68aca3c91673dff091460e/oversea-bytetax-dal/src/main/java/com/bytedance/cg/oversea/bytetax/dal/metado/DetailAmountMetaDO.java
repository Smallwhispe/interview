package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @Auther yangyl
 * @Date 2022/6/27
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DetailAmountMetaDO {

    /**
     * 税额（交易币种）
     */
    private BigDecimal transactionTax;

    /**
     * 命中税种
     */
    private Long categoryId;
}
