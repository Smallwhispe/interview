package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckRuleQuery;

public interface TaxNoCheckRuleRepository {

    Long save(TaxNoCheckRuleMetaDO metaDO);

    void updateByIdSelective(TaxNoCheckRuleMetaDO metaDO);

    TaxNoCheckRuleMetaDO getTaxNoCheckRuleById(Long id);

    PageResult<TaxNoCheckRuleMetaDO> queryTaxNoCheckRuleList(TaxNoCheckRuleQuery query);
}
