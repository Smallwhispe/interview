package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.*;

import java.util.List;

public interface TaxComplexRepository {
    TaxBizBindMetaDO queryTaxBiz(Long subjectId, Long countryGeoId, Long bizId);

    TaxBizContextMetaDO queryAllBizTaxContext();

    List<BaseRuleMetaDO> queryBizTaxContextByIds(List<Long> ruleIds);

    TaxContextMetaDO queryAllNoBizTaxContext();
}
