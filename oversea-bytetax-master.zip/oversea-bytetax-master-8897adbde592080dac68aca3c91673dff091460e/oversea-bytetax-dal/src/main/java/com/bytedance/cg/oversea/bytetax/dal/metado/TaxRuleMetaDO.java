package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxRuleMetaDO {
    /**
     *
     */
    private Long id;

    /**
     * 资金from
     */
    private AddressMetaDO billFrom;

    /**
     * 资金to
     */
    private AddressMetaDO billTo;

    /**
     * 物流from
     */
    private AddressMetaDO shipFrom;

    /**
     * 物流to
     */
    private AddressMetaDO shipTo;

    /**
     * from是否有税号
     */
    private EnumWithTaxNo fromWithTaxNo;

    /**
     * billFrom税号所在国家
     */
    private Long fromVatCountry;

    /**
     * to是否有税号
     */
    private EnumWithTaxNo toWithTaxNo;

    /**
     * billTo税号所在国家
     */
    private Long toTaxNoCountry;

    /**
     * 是否反向征收
     */
    private Boolean isReverseCharge;

    /**
     * 税种id
     */
    private Long taxCategoryId;

    /**
     * 税信息标签
     */
    private String taxTag;


    /**
     * 备注
     */
    private String remark;

    /**
     * 版本
     */
    private Integer version;

    /**
     * 是否最新版本
     */
    private EnumHead head;

    /**
     * 审批状态
     */
    private EnumApproveStatus approveStatus;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 我方主体
     */
    private Long itemId;

    /**
     * 规则描述
     */
    private String description;

    /**
     * 交易类型(仅查询)
     */
    private EnumTransactionType transactionType;

    /**
     * 额外字段
     */
    private TaxRuleExtend taxRuleExtend;

    public Long getDoubleTaxRuleId() {
        return doubleTaxRule() ? taxRuleExtend.getDoubleTaxInfoDTO().otherRuleId : null;
    }

    public TaxRuleExtend getOrGenTaxRuleExtend() {
        if (taxRuleExtend == null) {
            taxRuleExtend = new TaxRuleExtend();
        }
        return taxRuleExtend;
    }

    public boolean doubleTaxRule() {
        if (taxRuleExtend == null || taxRuleExtend.getDoubleTaxInfoDTO() == null) {
            return false;
        }
        return taxRuleExtend.getDoubleTaxInfoDTO().otherRuleId != null && taxRuleExtend.getDoubleTaxInfoDTO().otherRuleId != 0;
    }

    public Boolean mainDoubleTaxRule() {
        return doubleTaxRule() && taxRuleExtend.getDoubleTaxInfoDTO().mainRule;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TaxRuleExtend{

        private DoubleTaxInfoDTO doubleTaxInfoDTO;

        public static TaxRuleExtend getInstance(Long otherRuleId, Boolean mainRule) {
            return TaxRuleExtend.builder()
                    .doubleTaxInfoDTO(DoubleTaxInfoDTO.getInstance(otherRuleId, mainRule)).build();
        }

        @Data
        @NoArgsConstructor
        @AllArgsConstructor
        @Builder
        public static class DoubleTaxInfoDTO{

            private Long otherRuleId;

            private Boolean mainRule;

            public static DoubleTaxInfoDTO getInstance(Long otherRuleId, Boolean mainRule) {
                return TaxRuleMetaDO.TaxRuleExtend.DoubleTaxInfoDTO.builder()
                                .mainRule(mainRule)
                                .otherRuleId(otherRuleId).build();
            }
        }
    }
}