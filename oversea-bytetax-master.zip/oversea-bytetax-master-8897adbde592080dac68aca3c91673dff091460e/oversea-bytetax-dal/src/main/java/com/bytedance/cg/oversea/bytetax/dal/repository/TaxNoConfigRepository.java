package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumVersion;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoConfigQuery;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2023/8/22
 **/
public interface TaxNoConfigRepository {

    void save(TaxNoConfigMetaDO metaDO);

    void updateByIdSelective(TaxNoConfigMetaDO metaDO);

    void updateActiveById(Long id, EnumActiveStatus activeStatus);

    TaxNoConfigMetaDO queryById(Long id);

    TaxNoConfigMetaDO queryByGeoActive(Long geoId, EnumVersion version);

    List<TaxNoConfigMetaDO> queryIdsWithCache(List<Long> id);

    List<TaxNoConfigMetaDO> queryAllWithCache();

    PageResult<TaxNoConfigMetaDO> queryTaxConfig(TaxNoConfigQuery query);

}
