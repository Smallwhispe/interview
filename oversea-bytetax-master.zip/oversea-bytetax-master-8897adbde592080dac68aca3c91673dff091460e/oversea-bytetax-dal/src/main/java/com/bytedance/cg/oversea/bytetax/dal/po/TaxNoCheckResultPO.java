package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxNoCheckResultPO {
    /**
     * id
     */
    private Long id;

    /**
     * 税号
     */
    private String taxNo;

    /**
     * 对应枚举类EnumTaxIdentity
     */
    private Integer taxIdentity;

    /**
     * 税号校验规则 tax_no_check_rule 的id
     */
    private Long checkRuleId;

    /**
     * API校验规则, 对应 EnumTaxNoAPIRules
     */
    private Integer apiRuleId;

    /**
     * 外部校验记录的主键
     */
    private String apiPrimaryKey;

    /**
     * 格式校验校验结果，对应枚举类 EnumTaxNoCheckStatus
     */
    private Integer formatCheckResult;

    /**
     * API校验校验结果，对应枚举类 EnumTaxNoCheckStatus
     */
    private Integer apiCheckResult;

    /**
     * 异步source查询接口返回id，用于后续结果查询，如{"FONOA_API_SOURCE":"xxxxx"}
     */
    private String extraId;

    /**
     * 主体状态 对应枚举 EnumActiveStatus
     */
    private Integer businessStatus;

    /**
     * 公司名称
     */
    private String companyName;

    /**
     * 公司额外信息，以map的json字符串格式储存
     */
    private String companyExtraInfo;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 上游业务方主键
     */
    private String bizPrimaryId;

    /**
     * 上游业务方Id
     */
    private Long businessLineId;

    /**
     * 请求extend
     */
    private String requestExtend;

    /**
     * 结果extend
     */
    private String responseExtend;

    /**
     * 版本 对应枚举 EnumVersion
     */
    private Integer version;
}