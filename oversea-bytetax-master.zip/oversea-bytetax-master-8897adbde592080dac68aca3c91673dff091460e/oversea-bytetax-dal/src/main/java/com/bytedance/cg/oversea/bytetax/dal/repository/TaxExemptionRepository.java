package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxExemptionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxExemptionQuery;

public interface TaxExemptionRepository {
    void save(TaxExemptionMetaDO metaDO);

    void updateByIdSelective(TaxExemptionMetaDO metaDO);

    TaxExemptionMetaDO getTaxExemptionById(Long id);

    TaxExemptionMetaDO getTaxExemptionByCustomerId(Long id);

    PageResult<TaxExemptionMetaDO> queryTaxExemptionList(TaxExemptionQuery query);
}
