package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxCategoryQuery;

import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2022/4/21
 **/
public interface TaxCategoryRepository {

    TaxCategoryMetaDO save(TaxCategoryMetaDO metaDO);

    TaxCategoryMetaDO updateByIdSelective(TaxCategoryMetaDO metaDO);

    TaxCategoryMetaDO getTaxCategoryById(Long TaxCategoryId);

    Map<Long, TaxCategoryMetaDO> getTaxCategoriesByIds(List<Long> ids);

    PageResult<TaxCategoryMetaDO> queryTaxCategoryList(TaxCategoryQuery query);

    List<TaxCategoryMetaDO> queryByIds(List<Long> ids);

    List<TaxCategoryMetaDO> queryAllTaxRate();
}
