package com.bytedance.cg.oversea.bytetax.dal.metado.script;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * bytedance
 * 2022/5/26 12:05 下午
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaxAdminCategoryBindExcelMetaDO {

    String category;

    String description;

    Long countryGeoId;

    String taxAdminName;

    Long taxAdminId;

    String validTaxRate;

}
