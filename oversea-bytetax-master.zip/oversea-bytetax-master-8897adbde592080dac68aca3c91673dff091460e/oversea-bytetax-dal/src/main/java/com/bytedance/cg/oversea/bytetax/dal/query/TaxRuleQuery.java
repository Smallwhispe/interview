package com.bytedance.cg.oversea.bytetax.dal.query;

import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxRuleQuery {

    private Long id;

    private String taxTag;

    private AddressMetaDO billFrom;

    private AddressMetaDO billTo;

    private Long itemId;

    private Long taxAdminId;

    private Long taxCategoryId;

    private Integer transactionType;

    private Integer pageSize;

    private Integer pageNumber;

    public String generateBillFromCountrySql() {
        if (this.billFrom == null || this.billFrom.getLevelZero() == null) {
            return null;
        }
        return this.billFrom.getLevelZero() == 0L
                ? "(bill_from is null or bill_from like '%\"levelZero\":" + this.billFrom.getLevelZero()+ ",%')" :
                "(bill_from like '%\"levelZero\":" + this.billFrom.getLevelZero()+ ",%')";
    }

    public String generateBillFromRegionSql() {
        if (this.billFrom == null || this.billFrom.getLevelOne() == null) {
            return null;
        }
        return this.billFrom.getLevelOne() == 0L
                ? "(bill_from is null or bill_from like '%\"levelOne\":" + this.billFrom.getLevelOne() + ",%')" :
                "(bill_from like '%\"levelOne\":" + this.billFrom.getLevelOne() + ",%')";
    }

    public String generateBillToCountrySql() {
        if (this.billTo == null || this.billTo.getLevelZero() == null) {
            return null;
        }
        return billTo.getLevelZero() == 0L
                ? "(bill_to is null or bill_to like '%\"levelZero\":" + this.billTo.getLevelZero() + ",%')" :
                "(bill_to like '%\"levelZero\":" + this.billTo.getLevelZero() + ",%')";
    }

    public String generateBillToRegionSql() {
        if (this.billTo == null || this.billTo.getLevelOne() == null) {
            return null;
        }
        return this.billTo.getLevelOne() == 0L
                ? "(bill_to is null or bill_to like '%\"levelOne\":" + this.billTo.getLevelOne() + ",%')" :
                "(bill_to like '%\"levelOne\":" + this.billTo.getLevelOne() + ",%')";
    }
}
