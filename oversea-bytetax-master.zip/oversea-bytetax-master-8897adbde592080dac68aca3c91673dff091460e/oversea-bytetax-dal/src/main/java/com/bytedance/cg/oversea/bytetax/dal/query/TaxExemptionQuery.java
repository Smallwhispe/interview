package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxExemptionQuery {

    private Long customerId;

    private String customerName;

    private Long subjectId;

    private Integer pageSize;

    private Integer pageNumber;
}
