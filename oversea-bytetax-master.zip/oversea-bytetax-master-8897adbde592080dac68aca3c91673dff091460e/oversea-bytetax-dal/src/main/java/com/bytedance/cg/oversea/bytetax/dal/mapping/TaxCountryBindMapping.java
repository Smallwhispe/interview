package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, AddressMetaDO.class})
public interface TaxCountryBindMapping {

    TaxCountryBindMapping MAPPING = Mappers.getMapper(TaxCountryBindMapping.class);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "secondGeoId", source = "metaDO.address.levelOne")
    @Mapping(target = "countryGeoId", source = "metaDO.address.levelZero")
    TaxCountryBindPO toPO(TaxCountryBindMetaDO metaDO);

    @Mapping(target = "address",
            expression = "java(toAddressMetaDO(po))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    TaxCountryBindMetaDO toMetaDO(TaxCountryBindPO po);

    @Mapping(target = "levelOne", source = "secondGeoId")
    @Mapping(target = "levelZero", source = "countryGeoId")
    AddressMetaDO toAddressMetaDO(TaxCountryBindPO po);

    List<TaxCountryBindMetaDO> toMetaDOList(List<TaxCountryBindPO> pos);

}
