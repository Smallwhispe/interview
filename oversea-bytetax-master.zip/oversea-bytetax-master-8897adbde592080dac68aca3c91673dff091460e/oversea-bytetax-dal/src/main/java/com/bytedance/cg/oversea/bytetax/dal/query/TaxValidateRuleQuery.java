package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/08/23 11:23 AM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxValidateRuleQuery {

    private List<Long> ids;

    private Integer pageSize;

    private Integer pageNumber;

}
