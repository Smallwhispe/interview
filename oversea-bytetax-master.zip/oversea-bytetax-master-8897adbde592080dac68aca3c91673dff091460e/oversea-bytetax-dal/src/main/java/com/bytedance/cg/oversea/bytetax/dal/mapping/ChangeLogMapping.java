package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.ChangeLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * bytedance
 * 2022/7/22 11:30 上午
 */
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumChangeLogType.class, EnumChangeType.class})
public interface ChangeLogMapping {
    ChangeLogMapping MAPPING = Mappers.getMapper(ChangeLogMapping.class);

    @Mapping(target = "entityType", expression = "java(EnumUtils.getEnumByCode(EnumChangeLogType.values(), po.getEntityType()))")
    @Mapping(target = "changeType", expression = "java(EnumUtils.getEnumByCode(EnumChangeType.values(), po.getChangeType()))")
    ChangeLogMetaDO toMetaDO(ChangeLogPO po);

    List<ChangeLogMetaDO> toMetaDOList(List<ChangeLogPO> pos);
}
