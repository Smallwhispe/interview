package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.InterfaceLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPO;
import com.bytedance.cg.oversea.bytetax.dal.query.TransactionQuery;
import com.github.pagehelper.PageInfo;
import org.joda.time.DateTime;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/14
 **/
public interface InterfaceLogRepository {
    void saveSelectiveInterfaceLog(InterfaceLogMetaDO metaDO);
}