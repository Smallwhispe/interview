package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

/**
 * @author hanyuxiao
 * @date 2023/6/12
 **/
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class InterfaceLogMetaDO {

    private Long id;

    private String interfaceName;

    private String request;

    private String response;

    private Integer statusCode;

    private String tag;

    private DateTime createTime;
}
