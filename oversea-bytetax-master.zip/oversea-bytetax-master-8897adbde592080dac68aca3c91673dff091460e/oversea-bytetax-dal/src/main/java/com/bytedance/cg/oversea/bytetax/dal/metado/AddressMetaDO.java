package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @Auther yangyl
 * @Date 2021/11/26
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddressMetaDO {
    /**
     * 国家geo的id
     */
    private Long levelZero;
    private Long levelOne;
    private Long levelTwo;
    private Long levelThree;

    public List<Long> getAllGeoIds() {
        return Lists.newArrayList(levelOne, levelZero, levelTwo, levelThree).stream()
                .distinct().filter(Objects::nonNull).collect(Collectors.toList());
    }

}
