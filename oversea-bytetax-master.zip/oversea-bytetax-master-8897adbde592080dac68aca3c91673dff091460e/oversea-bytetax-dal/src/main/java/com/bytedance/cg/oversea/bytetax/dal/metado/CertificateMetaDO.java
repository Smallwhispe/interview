package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.Data;

/**
 * @Auther yangyl
 * @Date 2022/5/30
 **/
@Data
public class CertificateMetaDO {

    private Long id;

    private String name;

    private String url;
}

