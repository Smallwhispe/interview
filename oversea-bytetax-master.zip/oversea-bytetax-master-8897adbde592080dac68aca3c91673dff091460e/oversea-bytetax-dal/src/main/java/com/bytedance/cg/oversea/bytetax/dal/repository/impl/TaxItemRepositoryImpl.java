package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxItemMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxItemMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxItemMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxItemQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.ChangeLogRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxItemRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Repository
public class TaxItemRepositoryImpl implements TaxItemRepository {

    @Resource
    private TaxItemMapper taxItemMapper;

    @Resource
    @Lazy
    private TaxItemRepository taxItemRepository;

    @Override
    public void save(TaxItemMetaDO metaDO){
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        metaDO.setCode("to be generated");
        TaxItemPO taxItemPO = TaxItemMapping.MAPPING.toPO(metaDO);
        taxItemMapper.insert(taxItemPO);
        Long id = taxItemPO.getId();
        taxItemPO.setCode(genCode(id));
        taxItemMapper.updateByPrimaryKeySelective(taxItemPO);
    }

    @Override
    public void updateByIdSelective(TaxItemMetaDO metaDO){
        TaxItemPO taxItemPO = TaxItemMapping.MAPPING.toPO(metaDO);
        taxItemPO.setModifyTime(new Date());
        TaxItemPO org = TaxItemMapping.MAPPING.toPO(taxItemRepository.getTaxItemById(taxItemPO.getId()));
        if(org == null || EnumDeleteStatus.DELETED.getCode().equals(org.getIsDelete())) {
            throw new BizException(I18nConstants.WRONG_PARAMS);
        }
        taxItemMapper.updateByPrimaryKeySelective(taxItemPO);
    }

    @Override
    public TaxItemMetaDO getTaxItemById(Long id){
        if (id == null) {
            return null;
        }
        TaxItemPOExample taxItemPOExample = new TaxItemPOExample();
        taxItemPOExample.createCriteria().andIdEqualTo(id);
        List<TaxItemPO> taxItemPOS = taxItemMapper.selectByExample(taxItemPOExample);
        if (CollectionUtils.isEmpty(taxItemPOS)) {
            return null;
        }
        return TaxItemMapping.MAPPING.toMetaDO(taxItemPOS.get(ConstantValue.ZERO));
    }

    @Override
    public Map<Long, TaxItemMetaDO> getTaxItemsByIds(List<Long> ids){
        if (CollectionUtils.isEmpty(ids)) {
            return Maps.newHashMap();
        }
        TaxItemPOExample example = new TaxItemPOExample();
        example.createCriteria().andIdIn(ids);
        List<TaxItemMetaDO> taxItemMetaDOS = TaxItemMapping.MAPPING.toMetaDOList(taxItemMapper.selectByExample(example));
        return Optional.ofNullable(taxItemMetaDOS).orElse(Collections.emptyList()).
                stream().collect(Collectors.toMap(TaxItemMetaDO::getId, Function.identity()));
    }


    @Override
    public PageResult<TaxItemMetaDO> queryTaxItemList(TaxItemQuery query){

        TaxItemPOExample example = new TaxItemPOExample();
        example.setOrderByClause("code desc");
        TaxItemPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if(checkString(query.getName())){
            criteria.andNameLike("%"+validate(query.getName())+"%");
        }
        if(checkString(query.getCode())){
            criteria.andCodeEqualTo(validate(query.getCode()));
        }
        if(query.getType() != null){
            criteria.andTypeEqualTo(query.getType());
        }
        if(checkString(query.getDescription())){
            criteria.andDescriptionLike("%" + validate(query.getDescription()) + "%");
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxItemPO> taxItemPOPageInfo = new PageInfo<>(taxItemMapper.selectByExample(example));
        return new PageResult<>(taxItemPOPageInfo.getTotal(),
                TaxItemMapping.MAPPING.toMetaDOList(taxItemPOPageInfo.getList()));
    }

    private String genCode(Long id) {
        return String.format("%06d", id);
    }

    private String validate(String str){
        str = str.trim();
        StringBuilder ans = new StringBuilder();
        for(char c : str.toCharArray()){
            if(c == '_' || c == '%'){
                ans.append("\\");
            }
            ans.append(c);
        }
        return ans.toString();
    }

    private boolean checkString(String str){
        return !(str == null || str.trim().length() == 0);
    }


    @Override
    @Cacheable(value = ConstantValue.GUAVA_5M_CACHE, unless = "#result == null")
    public List<TaxItemMetaDO> queryAll(){
        TaxItemPOExample example = new TaxItemPOExample();
        TaxItemPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return TaxItemMapping.MAPPING.toMetaDOList(taxItemMapper.selectByExample(example));
    }

    @Override
    public String getTaxItemCodeById(Long id){
        List<TaxItemMetaDO> taxItemMetaDOS  = queryAll().stream().filter(e -> e.getId().equals(id)).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(taxItemMetaDOS)) {
            return null;
        }
        return taxItemMetaDOS.get(0).getCode();
    }
}
