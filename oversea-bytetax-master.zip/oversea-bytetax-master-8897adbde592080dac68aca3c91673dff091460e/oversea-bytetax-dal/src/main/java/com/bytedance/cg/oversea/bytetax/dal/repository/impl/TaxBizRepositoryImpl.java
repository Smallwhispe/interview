package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxBizMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxBizMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxBizQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.ChangeLogRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxBizRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * bytedance
 * 2021/12/6 11:21 上午
 */
@Repository
public class TaxBizRepositoryImpl implements TaxBizRepository {
    @Resource
    private TaxBizMapper taxBizMapper;

    @Resource
    @Lazy
    private TaxBizRepository taxBizRepository;

    @Resource
    private ChangeLogRepository changeLogRepository;

    @Override
    public void save(TaxBizMetaDO metaDO) {
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        taxBizMapper.insert(TaxBizMapping.MAPPING.toPO(metaDO));
    }
    @Override
    public void updateByIdSelective(TaxBizMetaDO metaDO) {
        TaxBizPO taxBizPO = TaxBizMapping.MAPPING.toPO(metaDO);
        taxBizPO.setModifyTime(new Date());
        TaxBizPO org = TaxBizMapping.MAPPING.toPO(taxBizRepository.getTaxBizByBizId(taxBizPO.getId()));
        if(org == null || EnumDeleteStatus.DELETED.getCode().equals(org.getIsDelete())) {
            throw new BizException(I18nConstants.WRONG_PARAMS);
        }
        taxBizMapper.updateByPrimaryKeySelective(taxBizPO);
    }

    @Override
    public TaxBizMetaDO getTaxBizByBizId(Long taxBizId) {
        if (taxBizId == null) {
            return null;
        }
        TaxBizPOExample taxBizPOExample = new TaxBizPOExample();
        taxBizPOExample.createCriteria().andIdEqualTo(taxBizId);
        List<TaxBizPO> taxBizPOS = taxBizMapper.selectByExample(taxBizPOExample);
        if (CollectionUtils.isEmpty(taxBizPOS)) {
            return null;
        }
        return TaxBizMapping.MAPPING.toMetaDO(taxBizPOS.get(ConstantValue.ZERO));
    }

    @Override
    public PageResult<TaxBizMetaDO>  queryTaxBizList(TaxBizQuery query){
        TaxBizPOExample example = new TaxBizPOExample();
        example.setOrderByClause("modify_time desc");
        TaxBizPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if(query.getId() != null){
            criteria.andIdEqualTo(query.getId());
        }
        if(checkString(query.getFuzzyName())){
            criteria.andNameLike("%" + validate(query.getFuzzyName()) + "%");
        }
        if(checkString(query.getExactName())) {
            criteria.andNameEqualTo(query.getExactName());
        }
        if(checkString(query.getDescription())){
            criteria.andCodeLike("%" + validate(query.getDescription()) + "%");
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxBizPO> taxBizPOPageInfo = new PageInfo<>(taxBizMapper.selectByExample(example));
        return new PageResult<>(taxBizPOPageInfo.getTotal(),
                TaxBizMapping.MAPPING.toMetaDOList(taxBizPOPageInfo.getList()));
    }

    private String validate(String str){
        str = str.trim();
        StringBuilder ans = new StringBuilder();
        for(char c : str.toCharArray()){
            if(c == '_' || c == '%'){
                ans.append("\\");
            }
            ans.append(c);
        }
        return ans.toString();
    }

    private boolean checkString(String str){
        return !(str == null || str.trim().length() == 0);
    }

    @Override
    public List<TaxBizMetaDO> getAll() {
        TaxBizPOExample example = new TaxBizPOExample();
        TaxBizPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxBizPO> taxBizPOS = taxBizMapper.selectByExample(example);
        return TaxBizMapping.MAPPING.toMetaDOList(taxBizPOS);
    }

    @Override
    public List<TaxBizMetaDO> getByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        TaxBizPOExample example = new TaxBizPOExample();
        TaxBizPOExample.Criteria criteria = example.createCriteria();
        criteria.andIdIn(ids);
        List<TaxBizPO> taxBizPOS = taxBizMapper.selectByExample(example);
        return TaxBizMapping.MAPPING.toMetaDOList(taxBizPOS);
    }

    @Override
    public Map<Long, TaxBizMetaDO> getTaxBizByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Maps.newHashMap();
        }
        TaxBizPOExample example = new TaxBizPOExample();
        TaxBizPOExample.Criteria criteria = example.createCriteria();
        criteria.andIdIn(ids);
        List<TaxBizMetaDO> taxBizMetaDOS = TaxBizMapping.MAPPING.toMetaDOList(taxBizMapper.selectByExample(example));
        return Optional.ofNullable(taxBizMetaDOS).orElse(Collections.emptyList()).stream().collect(Collectors.toMap(TaxBizMetaDO::getId, Function.identity()));
    }
}
