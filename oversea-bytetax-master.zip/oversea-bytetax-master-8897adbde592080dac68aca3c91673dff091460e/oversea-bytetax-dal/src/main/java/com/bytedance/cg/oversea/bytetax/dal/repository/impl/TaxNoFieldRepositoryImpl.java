package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.bsm.RequestContext;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoConfigMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoFieldMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxNoConfigMapping;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxNoFieldMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoFieldMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoConfigPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoFieldExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckRuleQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxNoFieldRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2023/8/22
 **/
@Repository
public class TaxNoFieldRepositoryImpl implements TaxNoFieldRepository {

    @Resource
    private TaxNoFieldMapper taxNoFieldMapper;

    @Autowired
    @Lazy
    private TaxNoFieldRepository taxNoFieldRepository;

    @Override
    public Map<Long, TaxNoFieldMetaDO> queryByIds(List<Long> ids) {
        return taxNoFieldRepository .queryAllWithCache().stream()
                .filter(metaDO -> ids.contains(metaDO.getId())).collect(Collectors.toMap(TaxNoFieldMetaDO::getId, Function.identity()));
    }

    @Cacheable(value = ConstantValue.GUAVA_5M_CACHE, unless = "#result == null")
    public List<TaxNoFieldMetaDO> queryAllWithCache() {
        TaxNoFieldExample taxNoFieldExample = new TaxNoFieldExample();
        taxNoFieldExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return TaxNoFieldMapping.MAPPING.toMetaDOList(taxNoFieldMapper.selectByExample(taxNoFieldExample));
    }
}
