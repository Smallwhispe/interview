package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/13
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionLineMetaDO {
    /**
     *
     */
    private Long id;

    /**
     * 商品id
     */
    private Long itemId;

    /**
     * 数量
     */
    private Integer quantity;


    /**
     * 关联的交易
     */
    private Long transactionId;

    /**
     * 税种商品绑定id
     */
    private List<Long> taxCategoryBindIds;

    /**
     * 税基
     */
    private BigDecimal taxable;

    /**
     * 税额
     */
    private BigDecimal tax;

    /**
     * 折扣
     */
    private BigDecimal discount;

    /**
     * 扩展
     */
    private List<DetailAmountMetaDO> extend;

    /**
     * 备注
     */
    private String remark;

    /**
     * 版本
     */
    private Integer version;

    /**
     *
     */
    private Date createTime;

    /**
     *
     */
    private Date modifyTime;

    /**
     *
     */
    private EnumDeleteStatus isDelete;
}
