package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.Data;

import java.util.Date;

@Data
public class TaxCountryMetaDO {
    /**
     * 国家id
     */
    private Long id;

    /**
     * 地理中台国家id
     */
    private Long countryGeoId;

    /**
     * 地理中台一级地址id
     */
    private Long levelOne;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;

    /**
     * 报税币种
     */
    private String taxReportCurrency;
}