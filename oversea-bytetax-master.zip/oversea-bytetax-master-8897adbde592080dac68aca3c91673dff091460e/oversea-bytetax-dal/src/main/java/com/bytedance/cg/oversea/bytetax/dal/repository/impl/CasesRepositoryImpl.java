package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.CasesMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.CasesMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.CasesMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.CasesPO;
import com.bytedance.cg.oversea.bytetax.dal.po.CasesPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.CasesRepository;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class CasesRepositoryImpl implements CasesRepository {

    @Resource
    private CasesMapper casesMapper;

    @Override
    public List<CasesMetaDO> selectAll() {
        CasesPOExample example = new CasesPOExample();
        CasesPOExample.Criteria criteria = example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return CasesMapping.MAPPING.toMetaDOList(casesMapper.selectByExample(example));
    }

    @Override
    public int save(CasesMetaDO  metaDO) {
        return casesMapper.insert(CasesMapping.MAPPING.toPO(metaDO));
    }

    @Override
    public int updateByIdSelective(CasesMetaDO metaDO) {
        CasesPO po = CasesMapping.MAPPING.toPO(metaDO);
        return casesMapper.updateByPrimaryKeySelective(po);
    }
}
