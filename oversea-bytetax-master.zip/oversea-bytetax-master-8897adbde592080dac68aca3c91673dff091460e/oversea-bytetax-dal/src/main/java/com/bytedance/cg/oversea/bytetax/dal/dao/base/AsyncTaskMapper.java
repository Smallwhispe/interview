package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPO;
import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AsyncTaskMapper {
    int insert(AsyncTaskPO record);

    int insertSelective(AsyncTaskPO record);

    List<AsyncTaskPO> selectByExample(AsyncTaskPOExample example);

    AsyncTaskPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(AsyncTaskPO record);

    int updateByPrimaryKey(AsyncTaskPO record);
}