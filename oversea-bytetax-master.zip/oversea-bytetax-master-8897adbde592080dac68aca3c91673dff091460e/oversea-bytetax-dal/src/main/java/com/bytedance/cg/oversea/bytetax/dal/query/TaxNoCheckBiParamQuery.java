package com.bytedance.cg.oversea.bytetax.dal.query;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxIdentity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: Cai Yuxin
 * @Date： 7/11/23 3:29 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoCheckBiParamQuery {

    private String countryCode;

    private EnumTaxIdentity taxIdentity;

}
