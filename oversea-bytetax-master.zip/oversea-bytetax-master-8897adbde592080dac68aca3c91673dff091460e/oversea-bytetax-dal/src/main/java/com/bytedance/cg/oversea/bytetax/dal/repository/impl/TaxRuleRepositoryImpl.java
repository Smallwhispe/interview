package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxRuleMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxRuleMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxRuleQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxRuleRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Auther yangyl
 * @Date 2021/11/24
 **/
@Repository
public class TaxRuleRepositoryImpl implements TaxRuleRepository {

    @Resource
    private TaxRuleMapper taxRuleMapper;

    @Resource
    private TaxCategoryMapper taxCategoryMapper;

    @Resource
    @Lazy
    private TaxRuleRepository taxRuleRepository;

    @Override
    public void save(TaxRuleMetaDO metaDO) {
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        TaxRulePO po = TaxRuleMapping.MAPPING.toPO(metaDO);
        taxRuleMapper.insert(po);
        metaDO.setId(po.getId());
    }

    @Override
    public void updateByIdSelective(TaxRuleMetaDO metaDO){
        TaxRulePO taxRulePO = TaxRuleMapping.MAPPING.toPO(metaDO);
        taxRulePO.setModifyTime(new Date());
        TaxRulePO org = TaxRuleMapping.MAPPING.toPO(taxRuleRepository.queryById(taxRulePO.getId()));
        if(org == null || EnumDeleteStatus.DELETED.getCode().equals(org.getIsDelete())) {
            throw new BizException(I18nConstants.WRONG_PARAMS);
        }
        taxRuleMapper.updateByPrimaryKeySelective(taxRulePO);
    }

    /**
     * 国家地区可能由空变为不空的情况，此时该字段不传。
     * 如果继续用updateByPrimaryKeySelective，就会默认该字段不更新，而不是该字段更新为空。
     * 所以这里需要全量更新。
     * */
    @Override
    public void updateById(TaxRuleMetaDO metaDO) {
        TaxRulePO taxRulePO = TaxRuleMapping.MAPPING.toPO(metaDO);
        TaxRulePO org = TaxRuleMapping.MAPPING.toPO(taxRuleRepository.queryById(taxRulePO.getId()));
        if(org == null || EnumDeleteStatus.DELETED.getCode().equals(org.getIsDelete())) {
            throw new BizException(I18nConstants.WRONG_PARAMS);
        }
        taxRuleMapper.updateByPrimaryKey(taxRulePO);
    }

    @Override
    public TaxRuleMetaDO queryById(Long id) {
        if (id == null) {
            return null;
        }
        TaxRulePOExample taxRulePOExample = new TaxRulePOExample();
        taxRulePOExample.createCriteria().andIdEqualTo(id);
        List<TaxRulePO> taxRulePOS = taxRuleMapper.selectByExample(taxRulePOExample);
        if (CollectionUtils.isEmpty(taxRulePOS)) {
            return null;
        }
        return TaxRuleMapping.MAPPING.toMetaDO(taxRulePOS.get(ConstantValue.ZERO));
    }

    @Override
    public PageResult<TaxRuleMetaDO> queryTaxRuleList(TaxRuleQuery query){
        TaxRulePOExample example = new TaxRulePOExample();
        example.setOrderByClause("modify_time desc");
        TaxRulePOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if(query.getId() != null) {
            criteria.andIdEqualTo(query.getId());
        }
        if(checkString(query.getTaxTag())) {
            criteria.andTaxTagLike("%"+validate(query.getTaxTag())+"%");
        }
        if(query.getBillFrom() != null && query.getBillFrom().getLevelZero() != null) {
            customQueryCriterion(criteria, query.generateBillFromCountrySql());
        }
        if(query.getBillFrom() != null && query.getBillFrom().getLevelOne() != null) {
            customQueryCriterion(criteria, query.generateBillFromRegionSql());
        }
        if(query.getBillTo() != null && query.getBillTo().getLevelZero() != null) {
            customQueryCriterion(criteria, query.generateBillToCountrySql());
        }
        if(query.getBillTo() != null && query.getBillTo().getLevelOne() != null) {
            customQueryCriterion(criteria, query.generateBillToRegionSql());
        }
        if(query.getItemId() != null){
            criteria.andItemIdEqualTo(query.getItemId());
        }
        if(query.getTaxCategoryId() != null){
            criteria.andTaxCategoryIdEqualTo(query.getTaxCategoryId());
        }
        if(query.getTaxAdminId() != null) {
            TaxCategoryPOExample taxCategoryPOExample = new TaxCategoryPOExample();
            TaxCategoryPOExample.Criteria categoryCriteria = taxCategoryPOExample.createCriteria();
            categoryCriteria.andTaxAdminIdEqualTo(query.getTaxAdminId());
            List<Long> categoryIds =  taxCategoryMapper.selectByExample(taxCategoryPOExample).stream()
                    .map(TaxCategoryPO::getId).collect(Collectors.toList());
            if (CollectionUtils.isEmpty(categoryIds)) {
                return new PageResult<>(ConstantValue.ZERO_LONG, Collections.emptyList());
            }
            criteria.andTaxCategoryIdIn(categoryIds);
        }
        if(query.getTransactionType() != null) {
            criteria.andTransactionTypeEqualTo(query.getTransactionType());
        }
        if(query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxRulePO> taxRulePOPageInfo = new PageInfo<>(taxRuleMapper.selectByExample(example));
        return new PageResult<>(taxRulePOPageInfo.getTotal(),
                TaxRuleMapping.MAPPING.toMetaDOList(taxRulePOPageInfo.getList()));
    }

    public String validate(String str){
        str = str.trim();
        StringBuilder ans = new StringBuilder();
        for(char c : str.toCharArray()){
            if(c == '_' || c == '%'){
                ans.append("\\");
            }
            ans.append(c);
        }
        return ans.toString();
    }

    public boolean checkString(String str){
        return !(str == null || str.trim().length() == 0);
    }


    @Override
    public List<TaxRuleMetaDO> queryByIds(List<Long> ids, boolean needActive) {
        if (CollectionUtils.isEmpty(ids)) {
            return Lists.newArrayList();
        }
        TaxRulePOExample example = new TaxRulePOExample();
        example.createCriteria().andIdIn(ids);
        if (needActive) {
            example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        }
        return TaxRuleMapping.MAPPING.toMetaDOList(taxRuleMapper.selectByExample(example));
    }

    @Override
    public List<TaxRuleMetaDO> queryAll() {
        TaxRulePOExample example = new TaxRulePOExample();
        example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return TaxRuleMapping.MAPPING.toMetaDOList(taxRuleMapper.selectByExample(example));
    }

    @Override
    public List<TaxRuleMetaDO> queryAllWithInactive() {
        TaxRulePOExample example = new TaxRulePOExample();
        return TaxRuleMapping.MAPPING.toMetaDOList(taxRuleMapper.selectByExample(example));
    }

    /**
     * 自定义查询条件
     * @param criteria
     * @param sql
     */
    private void customQueryCriterion(TaxRulePOExample.Criteria criteria, String sql) {
        try {
            Class clazz = TaxRulePOExample.Criteria.class;
            Method method = clazz.getSuperclass().getDeclaredMethod("addCriterion", String.class);
            method.setAccessible(true);
            method.invoke(criteria, sql);
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }
}
