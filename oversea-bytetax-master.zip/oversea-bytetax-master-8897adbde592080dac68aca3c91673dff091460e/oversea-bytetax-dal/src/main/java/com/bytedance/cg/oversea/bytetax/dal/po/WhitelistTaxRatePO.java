package com.bytedance.cg.oversea.bytetax.dal.po;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class WhitelistTaxRatePO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 客户ID
     */
    private Long accountId;

    /**
     * 主体ID
     */
    private Long subjectId;

    /**
     * 国家
     */
    private String country;

    /**
     * 生效时间
     */
    private Date validTime;

    /**
     * 失效时间
     */
    private Date invalidTime;

    /**
     * 版本号
     */
    private Integer version;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 税种
     */
    private String taxCategory;

    /**
     * 税率
     */
    private BigDecimal taxRate;

    /**
     * 生效状态：0=有效，1=失效
     */
    private Integer status;

    /**
     * 操作人ID
     */
    private Integer operatorId;

    /**
     * 1 流转税，2 预扣税
     */
    private Integer taxClassify;

    /**
     * 合同ID
     */
    private Long contractId;
}