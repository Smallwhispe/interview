package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskType;
import com.bytedance.cg.oversea.bytetax.dal.metado.AsyncTaskMetaDO;

/**
 * @author wangjian.2021
 * @date 2022/6/14
 **/
public interface AsyncTaskRepository {

    /**
     * 判断任务是否可执行，如可执行，将任务状态置为执行中
     * @param id
     * @return
     */
    boolean canProcess(Long id);

    /**
     * 查询任务信息
     * @param id
     * @return
     */
    AsyncTaskMetaDO queryById(Long id);

    void save(AsyncTaskMetaDO metaDO);

    /**
     * 创建新任务
     * @param type
     * @param argsObj
     * @param creatorId
     * @return
     */
    Long createNew(EnumAsyncTaskType type, Object argsObj, Long creatorId);

    void setSuccess(AsyncTaskMetaDO metaDO, Object resultObj);

    void setFail(AsyncTaskMetaDO metaDO);
}
