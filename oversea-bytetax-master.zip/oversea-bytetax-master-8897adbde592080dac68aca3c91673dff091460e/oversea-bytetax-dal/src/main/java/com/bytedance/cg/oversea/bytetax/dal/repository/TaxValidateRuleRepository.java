package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxValidateRuleMetaDO;

import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/08/17 4:40 PM
 */
public interface TaxValidateRuleRepository {

    List<TaxValidateRuleMetaDO> queryByIds(List<Long> ids);

    List<TaxValidateRuleMetaDO> queryAll();

}
