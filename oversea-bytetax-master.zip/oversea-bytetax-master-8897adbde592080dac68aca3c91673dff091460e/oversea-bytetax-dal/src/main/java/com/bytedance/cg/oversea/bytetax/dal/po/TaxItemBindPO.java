package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxItemBindPO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 商品id
     */
    private Long itemId;

    /**
     * 业务商品code
     */
    private String bizItemCode;

    /**
     * 业务线id
     */
    private Long bizLineId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private Integer isDelete;

    /**
     * avalaraTaxCode
     */
    private String taxCode;
}