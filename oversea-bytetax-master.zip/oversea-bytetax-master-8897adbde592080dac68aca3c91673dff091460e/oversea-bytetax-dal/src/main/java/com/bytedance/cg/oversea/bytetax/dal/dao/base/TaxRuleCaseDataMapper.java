package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxRuleCaseDataPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRuleCaseDataPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxRuleCaseDataMapper {
    int insert(TaxRuleCaseDataPO record);

    int insertSelective(TaxRuleCaseDataPO record);

    List<TaxRuleCaseDataPO> selectByExample(TaxRuleCaseDataPOExample example);

    TaxRuleCaseDataPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxRuleCaseDataPO record);

    int updateByPrimaryKey(TaxRuleCaseDataPO record);
}