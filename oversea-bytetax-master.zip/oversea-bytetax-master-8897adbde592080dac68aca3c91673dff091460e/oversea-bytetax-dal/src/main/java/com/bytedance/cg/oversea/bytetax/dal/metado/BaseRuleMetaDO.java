package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2021/11/26
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class BaseRuleMetaDO {
    /**
     * 税种
     */
    private TaxCategoryMetaDO taxCategoryMetaDO;

    /**
     * 规则信息
     */
    private TaxRuleMetaDO taxRuleMetaDO;

    /**
     * 商品信息
     * @return
     */
    private TaxItemMetaDO taxItemMetaDO;

    /**
     * 税务局
     * @return
     */
    private TaxAdminMetaDO taxAdminMetaDO;


    public List<ValidTaxRateMetaDO> generateValidTaxRates(boolean needCheckBizEffectiveTime, Map<Long, BizTaxRuleMetaDO> adminBizRuleMap) {
        if (!needCheckBizEffectiveTime) {
            return taxCategoryMetaDO.getValidTaxRate();
        }
        BizTaxRuleMetaDO aimBizRule = adminBizRuleMap.get(taxAdminMetaDO.getId());
        if (aimBizRule == null) {
            // 找不到指定税种 -> admin -> 业务线配置, 该税种不收税
            log.error("no find category admin biz config: admin: {}, adminBizRuleMap: {}", taxAdminMetaDO, adminBizRuleMap);
            CgMonitorMetricRecorder.exceptionOneMetrics("no_find_category_admin_biz_config", null, CgMetricsConstants.ServiceType.COMMON);
            return new ArrayList<>();
        }
        Date effectiveTime = aimBizRule.getTaxBizBindMetaDO().getEffectiveTime();
        if (effectiveTime == null) {
            // 业务线一直生效，返回税种原生效时间段
            return taxCategoryMetaDO.getValidTaxRate();
        }
        // 将该税种的生效时间段按照业务线生效时间截断，并重新生成生效时间段信息
        return taxCategoryMetaDO.getValidTaxRate().stream()
                .filter(cur -> (effectiveTime.compareTo(cur.getInvalidTime()) < 0)).map(cur -> {
                    Date curValidTime = effectiveTime.compareTo(cur.getValidTime()) <= 0 ? cur.getValidTime() : effectiveTime;
                    return ValidTaxRateMetaDO.builder().validTime(curValidTime).invalidTime(cur.getInvalidTime()).taxRate(cur.getTaxRate()).build();
                }).collect(Collectors.toList());
    }

}
