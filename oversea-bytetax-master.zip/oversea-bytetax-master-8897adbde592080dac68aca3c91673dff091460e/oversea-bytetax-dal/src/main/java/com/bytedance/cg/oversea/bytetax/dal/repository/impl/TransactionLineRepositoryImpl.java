package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TransactionDetailMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TransactionDetailMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionLineMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCategoryBindRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCategoryRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TransactionLineRepository;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
@Repository
public class TransactionLineRepositoryImpl implements TransactionLineRepository {
    @Resource
    private TransactionDetailMapper  transactionDetailMapper;

    @Resource
    private TaxCategoryRepository taxCategoryRepository;


    @Override
    public List<TransactionLineMetaDO> queryDetailByTransactionId(Long transactionId) {
        return queryDetailByTransactionIds(Lists.newArrayList(transactionId)).getOrDefault(transactionId, Lists.newArrayList());
    }

    @Override
    public Map<Long, List<TransactionLineMetaDO>> queryDetailByTransactionIds(List<Long> transactionIds) {
        if (CollectionUtils.isEmpty(transactionIds)) {
            return Maps.newHashMap();
        }
        TransactionDetailPOExample example = new TransactionDetailPOExample();
        example.createCriteria()
                .andTransactionIdIn(transactionIds)
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return transactionDetailMapper.selectByExample(example).stream()
                .map(TransactionDetailMapping.MAPPING::toTransactionLineMetaDO)
                .collect(Collectors.groupingBy(TransactionLineMetaDO::getTransactionId));
    }

    @Override
    public List<TaxCategoryMetaDO> queryByTranIdAndItemId(Long tranId, Long itemId) {
        TransactionLineMetaDO metaDO = queryDetailByTransactionId(tranId).stream()
                .filter(transactionLineMetaDO -> transactionLineMetaDO.getItemId().equals(itemId))
                .findFirst().orElse(null);
        if (metaDO == null) {
            return Lists.newArrayList();
        }
        return taxCategoryRepository.queryByIds(metaDO.getTaxCategoryBindIds());
    }

    @Override
    public int save(List<TransactionLineMetaDO> transactionLineMetaDOS) {
        List<TransactionDetailPO> transactionDetailPOS = transactionLineMetaDOS.stream()
                .map(TransactionDetailMapping.MAPPING::toTransactionDetailPO).collect(Collectors.toList());
        transactionDetailPOS.forEach(transactionDetailMapper::insertSelective);
        return 1;
    }
}
