package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.bsm.RequestContext;
import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumVersion;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoConfigMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxNoConfigMapping;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxRuleMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.VersionConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoConfigExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoConfigPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoFieldExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckRuleQuery;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoConfigQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxNoConfigRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2023/8/22
 **/
@Service
public class TaxNoConfigRepositoryImpl implements TaxNoConfigRepository {

    @Resource
    private TaxNoConfigMapper taxNoConfigMapper;

    @Autowired
    @Lazy
    private TaxNoConfigRepository taxNoConfigRepository;

    @Override
    public void save(TaxNoConfigMetaDO metaDO) {
        metaDO.setOperatorId(RequestContext.getEmployeeId().intValue());
        taxNoConfigMapper.insertSelective(TaxNoConfigMapping.MAPPING.toTaxNoConfigPO(metaDO));
    }

    @Override
    public void updateByIdSelective(TaxNoConfigMetaDO metaDO) {
        metaDO.setModifyTime(new Date());
        metaDO.setOperatorId(RequestContext.getEmployeeId().intValue());
        taxNoConfigMapper.updateByPrimaryKeySelective(TaxNoConfigMapping.MAPPING.toTaxNoConfigPO(metaDO));
    }

    @Override
    public void updateActiveById(Long id, EnumActiveStatus activeStatus) {
        TaxNoConfigPO po = new TaxNoConfigPO();
        po.setId(id);
        po.setIsActive(activeStatus.getCode());
        po.setModifyTime(new Date());
        po.setOperatorId(RequestContext.getEmployeeId().intValue());
        taxNoConfigMapper.updateByPrimaryKeySelective(po);
    }

    @Override
    public TaxNoConfigMetaDO queryById(Long id) {
        return TaxNoConfigMapping.MAPPING.toTaxNoConfigMetaDO(taxNoConfigMapper.selectByPrimaryKey(id));
    }

    @Override
    public TaxNoConfigMetaDO queryByGeoActive(Long geoId, EnumVersion version) {
        List<TaxNoConfigMetaDO> metas = taxNoConfigRepository.queryAllWithCache().stream()
                .filter(taxNoConfigMetaDO -> geoId.equals(taxNoConfigMetaDO.getCountryGeoId()))
                .filter(taxNoConfigMetaDO -> EnumActiveStatus.ACTIVE.equals(taxNoConfigMetaDO.getIsActive()))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(metas)) {
            return null;
        }
        if (metas.size() != 1){
            throw new RuntimeException("one country has two configs");
        }
        TaxNoConfigMetaDO metaDO = metas.get(0);
        List<VersionConfigMetaDO> filterVersion = metaDO.getVersionConfig().stream()
                .filter(versionConfig -> version.equals(versionConfig.getVersion()))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(filterVersion)) {
            return null;
        }
        if (filterVersion.size() != 1){
            throw new RuntimeException("one config has two same versions");
        }
        metaDO.setVersionConfig(Lists.newArrayList(filterVersion));
        return metaDO;
    }

    @Override
    public List<TaxNoConfigMetaDO> queryIdsWithCache(List<Long> id) {
        return taxNoConfigRepository.queryAllWithCache()
                .stream()
                .filter(taxNoConfigMetaDO -> id.contains(taxNoConfigMetaDO.getId()))
                .collect(Collectors.toList());
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1M_CACHE, unless = "#result == null")
    public List<TaxNoConfigMetaDO> queryAllWithCache() {
        TaxNoConfigExample taxNoConfigExample = new TaxNoConfigExample();
        taxNoConfigExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return TaxNoConfigMapping.MAPPING.toTaxNoConfigList(taxNoConfigMapper.selectByExample(taxNoConfigExample));
    }

    @Override
    public PageResult<TaxNoConfigMetaDO> queryTaxConfig(TaxNoConfigQuery query) {
        TaxNoConfigExample taxNoConfigExample = new TaxNoConfigExample();
        taxNoConfigExample.setOrderByClause("modify_time desc");
        TaxNoConfigExample.Criteria criteria = taxNoConfigExample.createCriteria();
        if (query.getId() != null) {
            criteria.andIdEqualTo(query.getId());
        }
        if (query.getCountryGeoId() != null) {
            criteria.andCountryGeoIdEqualTo(query.getCountryGeoId());
        }
        if (query.getActive() != null) {
            criteria.andIsActiveEqualTo(query.getActive() ? EnumActiveStatus.ACTIVE.getCode() : EnumActiveStatus.INACTIVE.getCode());
        }
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxNoConfigPO> pageInfo = new PageInfo<>(taxNoConfigMapper.selectByExample(taxNoConfigExample));
        return new PageResult<>(pageInfo.getTotal(),
                TaxNoConfigMapping.MAPPING.toTaxNoConfigList(pageInfo.getList()));
    }
}
