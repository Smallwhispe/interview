package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.*;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2022/1/13
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, EnumHead.class, JsonUtil.class, EnumTransactionCategory.class,
                EnumTransactionType.class, JsonUtil.class, AddressMetaDO.class, Map.class, EnumTaxCalculateType.class,
                EnumTaxReporterType.class, TaxRateMetaDO.class, TransactionInfoExtend.class})
public interface TransactionMapping {

    TransactionMapping MAPPING = Mappers.getMapper(TransactionMapping.class);
    @Mapping(target = "ruleIds", expression = "java(JsonUtil.writeValueAsString(metaDO.getRuleIds()))")
    @Mapping(target = "billingAddress", expression = "java(JsonUtil.writeValueAsString(metaDO.getBillingAddress()))")
    @Mapping(target = "extend", expression = "java(JsonUtil.writeValueAsString(metaDO.getExtend()))")
    @Mapping(target = "transactionType", expression = "java(EnumUtils.getCode(metaDO.getTransactionType()))")
    @Mapping(target = "transactionCategory", expression = "java(EnumUtils.getCode(metaDO.getTransactionCategory()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "taxCalculateType", expression = "java(EnumUtils.getCode(metaDO.getTaxCalculateType()))")
    @Mapping(target = "taxReporterType", expression = "java(EnumUtils.getCode(metaDO.getTaxReporterType()))")
    @Mapping(target = "customTax", expression = "java(JsonUtil.writeValueAsString(metaDO.getCustomTax()))")
    @Mapping(target = "transactionInfoExtend", expression = "java(JsonUtil.writeValueAsString(metaDO.getTransactionInfoExtend()))")
    TransactionPO  toTransactionMetaDO (TransactionMetaDO metaDO);


    @Mapping(target = "ruleIds", expression = "java(JsonUtil.unmarshalArray(po.getRuleIds(), Long.class))")
    @Mapping(target = "billingAddress", expression = "java(JsonUtil.readValue(po.getBillingAddress(), AddressMetaDO.class))")
    @Mapping(target = "extend", expression = "java(JsonUtil.readValue(po.getExtend(), Map.class))")
    @Mapping(target = "transactionType", expression = "java(EnumUtils.getEnumByCode(EnumTransactionType.values(), po.getTransactionType()))")
    @Mapping(target = "transactionCategory", expression = "java(EnumUtils.getEnumByCode(EnumTransactionCategory.values(), po.getTransactionCategory()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(),  po.getIsDelete()))")
    @Mapping(target = "taxCalculateType", expression = "java(EnumUtils.getEnumByCode(EnumTaxCalculateType.values(),  po.getTaxCalculateType()))")
    @Mapping(target = "taxReporterType", expression = "java(EnumUtils.getEnumByCode(EnumTaxReporterType.values(),  po.getTaxReporterType()))")
    @Mapping(target = "customTax", expression = "java(JsonUtil.unmarshalArray(po.getCustomTax(), TaxRateMetaDO.class))")
    @Mapping(target = "transactionInfoExtend", expression = "java(JsonUtil.readValue(po.getTransactionInfoExtend(), TransactionInfoExtend.class))")
    TransactionMetaDO toTransactionMetaDO (TransactionPO po);

    List<TransactionMetaDO> toMetaDOList(List<TransactionPO> pos);
//
//    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(),  transactionDataEsPO.getIsDelete()))")
//    @Mapping(target = "transactionCategory", expression = "java(EnumUtils.getEnumByCode(EnumTransactionCategory.values(), transactionDataEsPO.getTransactionCategory()))")
//    TransactionMetaDO transactionDataEsPoToTransactionMetaDO(TransactionDataEsPO transactionDataEsPO);

//    List<TransactionMetaDO> transactionDataEsPoToTransactionMetaList(List<TransactionDataEsPO> transactionDataEsPO);

}
