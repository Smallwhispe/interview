package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.ValidateUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminSubjectMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxAdminSubjectMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxAdminSubjectBindQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminSubjectRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
@Repository
public class TaxAdminSubjectRepositoryImpl implements TaxAdminSubjectRepository {

    @Resource
    private TaxAdminSubjectMapper taxAdminSubjectMapper;

    @Override
    public Map<Long, TaxAdminSubjectMetaDO> queryTaxAdminSubject(List<Long> ids, Long subjectId) {
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        TaxAdminSubjectPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        criteria.andTaxAdminIdIn(ids);
        criteria.andSubjectIdEqualTo(subjectId);
        return TaxAdminSubjectMapping.MAPPING.toMetaDOList(taxAdminSubjectMapper.selectByExample(example))
                .stream().collect(Collectors.toMap(TaxAdminSubjectMetaDO::getTaxAdminId, Function.identity()));
    }

    @Override
    public TaxAdminSubjectMetaDO getById(Long id) {
        return TaxAdminSubjectMapping.MAPPING.toMetaDO(taxAdminSubjectMapper.selectByPrimaryKey(id));
    }

    @Override
    public List<TaxAdminSubjectMetaDO> getByIds(List<Long> ids) {
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        TaxAdminSubjectPOExample.Criteria criteria = example.createCriteria();
        criteria.andIdIn(ids);
        return TaxAdminSubjectMapping.MAPPING.toMetaDOList(taxAdminSubjectMapper.selectByExample(example));
    }

    @Override
    public List<TaxAdminSubjectMetaDO> queryTaxAdminSubjectByAdminId(Long adminId) {
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        TaxAdminSubjectPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        criteria.andTaxAdminIdEqualTo(adminId);
        return TaxAdminSubjectMapping.MAPPING.toMetaDOList(taxAdminSubjectMapper.selectByExample(example));
    }

    @Override
    public void saveSelective(TaxAdminSubjectMetaDO metaDO) {
        if (!ValidateUtil.validLong(metaDO.getId())) {
            Date now = new Date();
            metaDO.setModifyTime(now);
            metaDO.setCreateTime(now);
            metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
            metaDO.setId(null);
            taxAdminSubjectMapper.insertSelective(TaxAdminSubjectMapping.MAPPING.toPO(metaDO));
        } else {
            taxAdminSubjectMapper.updateByPrimaryKeySelective(TaxAdminSubjectMapping.MAPPING.toPO(metaDO));
        }
    }

    @Override
    public void fullSave(TaxAdminSubjectMetaDO metaDO) {
        if (!ValidateUtil.validLong(metaDO.getId())) {
            saveSelective(metaDO);
        } else {
            taxAdminSubjectMapper.updateByPrimaryKey(TaxAdminSubjectMapping.MAPPING.toPO(metaDO));
        }
    }

    @Override
    public List<Long> queryTaxAdminSubjectBySubjectId(Long subjectId) {
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        TaxAdminSubjectPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        criteria.andSubjectIdEqualTo(subjectId);
        return Optional.ofNullable(TaxAdminSubjectMapping.MAPPING.toMetaDOList(taxAdminSubjectMapper.selectByExample(example)))
                .orElseGet(Collections::emptyList)
                .stream()
                .filter(Objects::nonNull)
                .map(TaxAdminSubjectMetaDO::getId)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
    }

    @Override
    public PageResult<TaxAdminSubjectMetaDO> query(TaxAdminSubjectBindQuery query) {
        if (!query.checkValid()) {
            return new PageResult<>(0L, Collections.emptyList());
        }
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        TaxAdminSubjectPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        example.setOrderByClause("modify_time asc");
        if (query.getId() != null) {
            criteria.andIdEqualTo(query.getId());
        }
        if (query.getTaxAdminId() != null) {
            criteria.andTaxAdminIdEqualTo(query.getTaxAdminId());
        }
        if(query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxAdminSubjectPO> poPageInfo = new PageInfo<>(taxAdminSubjectMapper.selectByExample(example));
        return new PageResult<>(poPageInfo.getTotal(), TaxAdminSubjectMapping.MAPPING.toMetaDOList(poPageInfo.getList()));
    }

    @Override
    public List<TaxAdminSubjectMetaDO> getAllTaxAdminSubjectByAdminId(Long adminId, boolean onlyNeedActive) {
        if (!ValidateUtil.validLong(adminId)) {
            Collections.emptyList();
        }
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        TaxAdminSubjectPOExample.Criteria criteria = example.createCriteria();
        criteria.andTaxAdminIdEqualTo(adminId);
        if (onlyNeedActive) {
            criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        }
        return TaxAdminSubjectMapping.MAPPING.toMetaDOList(taxAdminSubjectMapper.selectByExample(example));
    }

    @Override
    public TaxAdminSubjectMetaDO queryById(Long id, boolean onlyNeedActive) {
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        TaxAdminSubjectPOExample.Criteria criteria = example.createCriteria();
        criteria.andIdEqualTo(id);
        if (onlyNeedActive) {
            criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        }
        List<TaxAdminSubjectPO> res = taxAdminSubjectMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(res)) {
            return TaxAdminSubjectMapping.MAPPING.toMetaDO(res.get(0));
        }
        return null;
    }

    @Override
    public void deleteById(Long id) {
        TaxAdminSubjectMetaDO aimMetaDO = queryById(id, false);
        if (aimMetaDO == null) {
            return;
        }
        aimMetaDO.setIsDelete(EnumDeleteStatus.DELETED);
        taxAdminSubjectMapper.updateByPrimaryKeySelective(TaxAdminSubjectMapping.MAPPING.toPO(aimMetaDO));
    }
}