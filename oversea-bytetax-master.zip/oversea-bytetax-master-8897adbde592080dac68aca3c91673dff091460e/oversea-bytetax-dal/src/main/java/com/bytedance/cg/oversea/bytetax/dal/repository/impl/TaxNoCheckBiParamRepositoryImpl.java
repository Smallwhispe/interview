package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxIdentity;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoCheckBiParamMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxNoCheckBiParamMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckBiParamMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckBiParamPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckBiParamPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckBiParamQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxNoCheckBiParamRepository;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;

/**
 * @Author: Cai Yuxin
 * @Date： 7/11/23 3:13 PM
 */
@Repository
public class TaxNoCheckBiParamRepositoryImpl implements TaxNoCheckBiParamRepository {

    @Resource
    private TaxNoCheckBiParamMapper taxNoCheckBiParamMapper;

    @Override
    public TaxNoCheckBiParamMetaDO queryBiParam(TaxNoCheckBiParamQuery query) {
        TaxNoCheckBiParamPOExample example = new TaxNoCheckBiParamPOExample();
        TaxNoCheckBiParamPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if (checkString(query.getCountryCode())) {
            criteria.andCountryIsoEqualTo(query.getCountryCode());
        }
        if (query.getTaxIdentity() != null) {
            criteria.andTaxIdentityIn(Lists.newArrayList(Sets.newHashSet(query.getTaxIdentity().getCode(), EnumTaxIdentity.BOTH.getCode())));
        } else {
            criteria.andTaxIdentityEqualTo(EnumTaxIdentity.BOTH.getCode());
        }
        PageInfo<TaxNoCheckBiParamPO> taxNoCheckBiParamPOPageInfo = new PageInfo<>(taxNoCheckBiParamMapper.selectByExample(example));
        if (taxNoCheckBiParamPOPageInfo.getSize() != 1) {
            throw new BizException("queryBiParam get wrong result");
        }
        return TaxNoCheckBiParamMapping.MAPPING.toMetaDO(taxNoCheckBiParamPOPageInfo.getList().get(0));
    }

    private boolean checkString(String str){
        return !(str == null || str.trim().length() == 0);
    }

}
