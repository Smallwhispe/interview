package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxRuleCaseDataPO {
    /**
     * 
     */
    private Long id;

    /**
     * 
     */
    private String param;

    /**
     * 
     */
    private String result;

    /**
     * 
     */
    private String transactionType;

    /**
     * 
     */
    private String country;

    /**
     * 
     */
    private String transactionMethod;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Date modifyTime;

    /**
     * 
     */
    private Integer isDelete;

    /**
     * 
     */
    private Long taxRuleId;
}