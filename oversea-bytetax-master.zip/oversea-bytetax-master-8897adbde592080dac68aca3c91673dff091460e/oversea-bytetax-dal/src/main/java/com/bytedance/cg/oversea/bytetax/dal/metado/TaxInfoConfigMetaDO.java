package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxInfoConfigMetaDO {

    private Long id;

    /**
     * 格式校验的规则 外层为与 内层为或
     */
    private List<List<Long>> formatCheckRule;
}
