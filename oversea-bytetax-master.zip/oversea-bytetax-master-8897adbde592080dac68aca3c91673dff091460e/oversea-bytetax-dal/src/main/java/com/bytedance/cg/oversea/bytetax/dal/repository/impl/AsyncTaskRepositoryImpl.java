package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.IdGenerateService;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.AsyncTaskMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.ext.AsyncTaskDao;
import com.bytedance.cg.oversea.bytetax.dal.mapping.AsyncTaskMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.AsyncTaskMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPO;
import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.AsyncTaskRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;

/**
 * @author wangjian.2021
 * @date 2022/6/14
 **/
@Repository
public class AsyncTaskRepositoryImpl implements AsyncTaskRepository {

    @Resource
    private AsyncTaskMapper asyncTaskMapper;

    @Resource
    private AsyncTaskDao asyncTaskDao;

    @Resource
    private IdGenerateService idGenerateService;

    @Override
    public boolean canProcess(Long id) {
        return asyncTaskDao.setProcessingIfCan(id) > 0;
    }

    @Override
    public AsyncTaskMetaDO queryById(Long id) {
        AsyncTaskPOExample example = new AsyncTaskPOExample();
        example.createCriteria()
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode())
                .andIdEqualTo(id);
        List<AsyncTaskPO> list = asyncTaskMapper.selectByExample(example);

        return Optional.ofNullable(list).orElse(Collections.emptyList())
                .stream()
                .map(AsyncTaskMapping.MAPPING::toMetaDO)
                .findFirst()
                .orElse(null);
    }

    @Override
    public void save(AsyncTaskMetaDO metaDO) {
        AsyncTaskPO po = AsyncTaskMapping.MAPPING.toPO(metaDO);
        if (metaDO.getId() == null) {
            po.setId(idGenerateService.getId());
            po.setCreateTime(new Date());
            po.setUpdateTime(new Date());
            asyncTaskMapper.insert(po);
            return;
        }
        po.setUpdateTime(new Date());
        asyncTaskMapper.updateByPrimaryKey(po);
    }

    @Override
    public Long createNew(EnumAsyncTaskType type, Object argsObj, Long creatorId) {
        // 如果存在类型、参数、创建人相同且处于未执行/执行中，则返回对应任务ID
        String args = JsonUtil.writeValueAsString(argsObj);

        AsyncTaskPOExample example = new AsyncTaskPOExample();
        example.createCriteria()
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode())
                .andArgsEqualTo(args)
                .andTypeEqualTo(type.getCode())
                .andCreatorIdEqualTo(creatorId)
                .andStatusIn(Arrays.asList(EnumAsyncTaskStatus.INIT.getCode(), EnumAsyncTaskStatus.CALCULATING.getCode()));
        List<AsyncTaskPO> list = asyncTaskMapper.selectByExample(example);
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getId();
        }
        AsyncTaskPO po = new AsyncTaskPO();
        po.setId(idGenerateService.getId());
        po.setType(type.getCode());
        po.setStatus(EnumAsyncTaskStatus.INIT.getCode());
        po.setArgs(args);
        po.setCreatorId(creatorId);
        po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
        po.setCreateTime(new Date());
        po.setUpdateTime(new Date());
        asyncTaskMapper.insert(po);
        return po.getId();
    }

    @Override
    public void setSuccess(AsyncTaskMetaDO metaDO, Object resultObj) {
        metaDO.setResult(JsonUtil.writeValueAsString(resultObj));
        metaDO.setDoneTime(new Date());
        metaDO.setStatus(EnumAsyncTaskStatus.SUCCESS);
        save(metaDO);
    }

    @Override
    public void setFail(AsyncTaskMetaDO metaDO) {
        metaDO.setStatus(EnumAsyncTaskStatus.FAIL);
        save(metaDO);
    }
}
