package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxSubjectCompanyCodeBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxSubjectCompanyCodeBindPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class})
public interface TaxSubjectCompanyCodeBindMapping {

    TaxSubjectCompanyCodeBindMapping MAPPING = Mappers.getMapper(TaxSubjectCompanyCodeBindMapping.class);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    TaxSubjectCompanyCodeBindPO toPO(TaxSubjectCompanyCodeBindMetaDO metaDO);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    TaxSubjectCompanyCodeBindMetaDO toMetaDO(TaxSubjectCompanyCodeBindPO po);
}
