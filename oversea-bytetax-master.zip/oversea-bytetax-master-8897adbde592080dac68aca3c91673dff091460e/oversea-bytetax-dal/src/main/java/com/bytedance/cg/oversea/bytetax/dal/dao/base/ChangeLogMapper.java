package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPO;
import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ChangeLogMapper {
    int insert(ChangeLogPO record);

    int insertSelective(ChangeLogPO record);

    List<ChangeLogPO> selectByExample(ChangeLogPOExample example);

    ChangeLogPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(ChangeLogPO record);

    int updateByPrimaryKey(ChangeLogPO record);
}