package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TaxCategoryMetaDO {
    /**
     *
     */
    private Long id;

    /**
     * code
     */
    private String code;

    /**
     * 税种
     */
    private String category;

    /**
     * 税种类型
     */
    private EnumTaxClassify taxClassify;

    /**
     * 税种描述
     */
    private String description;

    /**
     * 地理中台国家id
     */
    private Long countryGeoId;

    /**
     * 默认税率
     */
    private BigDecimal defaultTaxRate;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;

    /**
     * 税务局id
     */
    private Long taxAdminId;

    /**
     * 生效税率
     */
    private List<ValidTaxRateMetaDO> validTaxRate;


    public ValidTaxRateMetaDO getTaxRate(Date time) {
        return validTaxRate.stream()
                .filter(validTaxRateMetaDO -> !validTaxRateMetaDO.getValidTime().after(time))
                .filter(validTaxRateMetaDO -> validTaxRateMetaDO.getInvalidTime().after(time))
                .findFirst().orElse(null);
    }
}
