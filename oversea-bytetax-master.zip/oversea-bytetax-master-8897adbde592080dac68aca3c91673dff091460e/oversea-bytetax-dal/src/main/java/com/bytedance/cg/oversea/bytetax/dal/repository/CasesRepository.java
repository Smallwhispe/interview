package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.CasesMetaDO;

import java.util.List;
import java.util.Map;

public interface CasesRepository {

    List<CasesMetaDO> selectAll();

    int save(CasesMetaDO casesMetaDO);

    int updateByIdSelective(CasesMetaDO metaDO);

}
