package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumCollectConfig;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author hanyuxiao
 * @date 2023/8/23
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoInfoCollectMetaDO {

    private Long id;

    private EnumCollectConfig collectConfig;
}
