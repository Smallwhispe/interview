package com.bytedance.cg.oversea.bytetax.dal.po;

import lombok.Data;

import java.util.Date;

@Data
public class TaxNoCheckRulePO {
    /**
     * 
     */
    private Long id;

    /**
     * 国家地理id
     */
    private Long countryGeoId;

    /**
     * 税号类型，如VAT，GST等，对应枚举类 EnumTaxType
     */
    private String taxInfoFields;

    /**
     * 格式校验规则集, 如[1,3]，对应 EnumTaxNoFormatRules
     */
    private String formatRules;

    /**
     * API校验规则集，如[1,3], 对应 EnumTaxNoAPIRules
     */
    private String apiRules;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 生效状态
     */
    private Integer isActive;
}