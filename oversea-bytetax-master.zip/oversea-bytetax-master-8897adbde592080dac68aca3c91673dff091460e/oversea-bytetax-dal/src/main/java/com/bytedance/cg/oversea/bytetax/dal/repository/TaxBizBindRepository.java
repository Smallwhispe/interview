package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPO;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/5/12
 **/
public interface TaxBizBindRepository {

    Long saveTaxBizBind(TaxBizBindMetaDO metaDO);

    List<TaxBizBindMetaDO> getTaxBizBind(List<Long> subCountryBindIds, boolean active);

    void deleteTaxBizBind(List<Long> ids);

    List<TaxBizBindMetaDO> queryAll();

    TaxBizBindPO getTaxBizBindById(Long id);
}
