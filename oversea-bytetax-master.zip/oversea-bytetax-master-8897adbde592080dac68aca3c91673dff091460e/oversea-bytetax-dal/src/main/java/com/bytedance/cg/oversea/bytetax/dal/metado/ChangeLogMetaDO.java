package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.formula.functions.T;

import java.util.Date;

/**
 * bytedance
 * 2022/7/22 10:51 上午
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChangeLogMetaDO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * adminId, bizId, categoryId, exemptionId, itemId, ruleId, bizBindId, subjectcountryBindId
     */
    private Long entityId;

    /**
     * adminId=1, bizId=2, categoryId=3, exemptionId=4, itemId=5, ruleId=6, bizBindId=7, subjectcountryBindId=8
     */
    private EnumChangeLogType entityType;

    /**
     * 更改前
     */
    private String originalPo;

    /**
     * 更改后
     */
    private String updatedPo;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 操作人
     */
    private Integer operatorId;

    /**
     *
     */
    private EnumChangeType changeType;
}
