package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxRuleMapper {
    int insert(TaxRulePO record);

    int insertSelective(TaxRulePO record);

    List<TaxRulePO> selectByExample(TaxRulePOExample example);

    TaxRulePO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxRulePO record);

    int updateByPrimaryKey(TaxRulePO record);
}