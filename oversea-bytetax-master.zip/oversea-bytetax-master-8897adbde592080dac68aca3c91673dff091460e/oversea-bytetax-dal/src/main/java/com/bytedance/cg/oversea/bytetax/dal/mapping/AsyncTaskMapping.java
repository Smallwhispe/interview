package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.AsyncTaskMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author wangjian.2021
 * @date 2022/6/14
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, EnumAsyncTaskType.class, EnumAsyncTaskStatus.class})
public interface AsyncTaskMapping {

    AsyncTaskMapping MAPPING = Mappers.getMapper(AsyncTaskMapping.class);


    @Mapping(target = "type", expression = "java(EnumUtils.getEnumByCode(EnumAsyncTaskType.values(), po.getType()))")
    @Mapping(target = "status", expression = "java(EnumUtils.getEnumByCode(EnumAsyncTaskStatus.values(), po.getStatus()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    AsyncTaskMetaDO toMetaDO(AsyncTaskPO po);

    @Mapping(target = "type", expression = "java(EnumUtils.getCode(metaDO.getType()))")
    @Mapping(target = "status", expression = "java(EnumUtils.getCode(metaDO.getStatus()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    AsyncTaskPO toPO(AsyncTaskMetaDO metaDO);
}
