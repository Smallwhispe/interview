package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author xieyufeng.hoha
 * @date 2021/7/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SingleRuleMetaDO {
    private String variable;

    private String operator;

    private String value;
}