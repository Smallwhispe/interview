package com.bytedance.cg.oversea.bytetax.dal.query;

import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoConfigQuery {

    private Long id;

    private Long countryGeoId;

    private Boolean active;

    private Integer pageSize;

    private Integer pageNumber;
}
