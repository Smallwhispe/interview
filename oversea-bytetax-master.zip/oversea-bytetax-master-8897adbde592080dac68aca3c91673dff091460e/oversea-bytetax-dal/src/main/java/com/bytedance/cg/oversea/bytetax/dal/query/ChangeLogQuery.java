package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * bytedance
 * 2022/7/22 10:16 上午
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChangeLogQuery {
    /**
     * 主键
     */
    private Long id;

    /**
     * 日志类型id
     */
    private Integer changeLogType;

    /**
     * 实体id
     */
    private Long entityId;

    /**
     * 每页数量
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNumber;
}
