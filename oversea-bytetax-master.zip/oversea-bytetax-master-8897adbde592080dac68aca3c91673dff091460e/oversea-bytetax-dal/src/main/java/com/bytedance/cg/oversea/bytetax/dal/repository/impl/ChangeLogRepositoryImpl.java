package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.ChangeLogMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.ChangeLogMapping;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxAdminMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.ChangeLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPO;
import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPO;
import com.bytedance.cg.oversea.bytetax.dal.query.ChangeLogQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.ChangeLogRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Repository
public class ChangeLogRepositoryImpl implements ChangeLogRepository {

    @Resource
    private ChangeLogMapper changeLogMapper;

    @Override
    public void save(Long entityId, Integer entityType, String originalPo, String updatedPo, Integer operatorId, Integer changeType) {
        ChangeLogPO changeLogPO = new ChangeLogPO();
        changeLogPO.setEntityId(entityId);
        changeLogPO.setEntityType((long) entityType);
        changeLogPO.setOriginalPo(originalPo);
        changeLogPO.setUpdatedPo(updatedPo);
        changeLogPO.setOperatorId(operatorId);
        changeLogPO.setCreateTime(new Date());
        changeLogPO.setChangeType(changeType);
        changeLogMapper.insertSelective(changeLogPO);
    }

    @Override
    public PageResult<ChangeLogMetaDO> queryChangeLogList(ChangeLogQuery query) {
        ChangeLogPOExample example = new ChangeLogPOExample();
        ChangeLogPOExample.Criteria criteria = example.createCriteria();
        example.setOrderByClause("create_time desc");
        if(query.getId() != null ) {
            criteria.andIdEqualTo(query.getId());
        }
        if(query.getChangeLogType() != null ) {
            criteria.andEntityTypeEqualTo((long)query.getChangeLogType());
        }
        if(query.getEntityId() != null ) {
            criteria.andEntityIdEqualTo(query.getEntityId());
        }
        if(query.getPageNumber() != null && query.getPageSize()!= null){
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<ChangeLogPO> changeLogPOPageInfo = new PageInfo<>(changeLogMapper.selectByExample(example));
        return new PageResult<>(
                changeLogPOPageInfo.getTotal(),
                ChangeLogMapping.MAPPING.toMetaDOList(changeLogPOPageInfo.getList())
        );
    }
}
