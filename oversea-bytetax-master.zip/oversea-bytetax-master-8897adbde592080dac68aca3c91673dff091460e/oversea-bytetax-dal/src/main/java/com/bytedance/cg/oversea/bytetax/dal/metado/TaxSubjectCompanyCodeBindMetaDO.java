package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.Data;

import java.util.Date;

@Data
public class TaxSubjectCompanyCodeBindMetaDO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 主体id
     */
    private Long subjectId;

    /**
     * 企业code
     */
    private String companyCode;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private EnumDeleteStatus isDelete;

    /**
     * 业务线id
     */
    private Long bizLineId;
}