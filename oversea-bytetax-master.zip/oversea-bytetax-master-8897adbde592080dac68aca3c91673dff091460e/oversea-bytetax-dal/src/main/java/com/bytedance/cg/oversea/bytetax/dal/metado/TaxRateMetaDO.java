package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumCategoryMatch;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @author hanyuxiao
 * @date 2022/8/23
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaxRateMetaDO {

    private Integer taxClassify;
    private String taxCategory;
    private Long taxCategoryId;
    private BigDecimal taxRate;
    private String taxSerial;
    private Long taxRuleId;
    private EnumCategoryMatch categoryMatch;
    private String taxTag;
    private Boolean isReverseCharge;
    private Long adminId;
}
