package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckBiParamMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckBiParamQuery;

/**
 * @Author: Cai Yuxin
 * @Date： 7/11/23 3:07 PM
 */
public interface TaxNoCheckBiParamRepository {

    TaxNoCheckBiParamMetaDO queryBiParam(TaxNoCheckBiParamQuery query);

}
