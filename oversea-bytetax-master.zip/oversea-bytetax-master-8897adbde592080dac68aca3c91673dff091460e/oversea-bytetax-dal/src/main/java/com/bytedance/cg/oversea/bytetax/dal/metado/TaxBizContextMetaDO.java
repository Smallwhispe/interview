package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * @Auther yangyl
 * @Date 2021/11/26
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
public class TaxBizContextMetaDO extends TaxContextMetaDO {

    /**
     * 业务线配置上下文
     */
    private List<BizTaxRuleMetaDO> bizTaxRuleMetaDOS;

}
