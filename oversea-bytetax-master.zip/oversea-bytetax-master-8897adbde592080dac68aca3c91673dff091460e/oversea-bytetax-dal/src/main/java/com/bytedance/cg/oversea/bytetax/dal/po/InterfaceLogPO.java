package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class InterfaceLogPO {
    /**
     * primary
     */
    private Long id;

    /**
     * interface name
     */
    private String interfaceName;

    /**
     * request
     */
    private String request;

    /**
     * response
     */
    private String response;

    /**
     * tag
     */
    private String tag;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 返回状态码
     */
    private Integer statusCode;
}