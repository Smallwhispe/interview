package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxRuleQuery;

import java.util.List;

public interface TaxRuleRepository {
    void save(TaxRuleMetaDO metaDO);

    void updateByIdSelective(TaxRuleMetaDO metaDO);

    void updateById(TaxRuleMetaDO metaDO);

    TaxRuleMetaDO queryById(Long id);

    PageResult<TaxRuleMetaDO> queryTaxRuleList(TaxRuleQuery query);

    List<TaxRuleMetaDO> queryByIds(List<Long> ids, boolean needActive);

    List<TaxRuleMetaDO> queryAll();

    List<TaxRuleMetaDO> queryAllWithInactive();
}
