package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.ChangeLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.InterfaceLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPO;
import com.bytedance.cg.oversea.bytetax.dal.po.InterfaceLogPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * bytedance
 * 2022/7/22 11:30 上午
 */
@Mapper
public interface InterfaceLogMapping {
    InterfaceLogMapping MAPPING = Mappers.getMapper(InterfaceLogMapping.class);

    InterfaceLogMetaDO toMetaDO(InterfaceLogPO po);

    InterfaceLogPO toPO(InterfaceLogMetaDO metaDO);
}
