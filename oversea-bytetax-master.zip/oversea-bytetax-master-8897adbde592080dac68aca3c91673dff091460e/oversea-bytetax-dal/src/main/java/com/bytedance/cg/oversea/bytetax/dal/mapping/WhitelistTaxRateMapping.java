package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.WhitelistTaxRateMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.WhitelistTaxRatePO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface WhitelistTaxRateMapping {

    WhitelistTaxRateMapping MAPPING = Mappers.getMapper(WhitelistTaxRateMapping.class);

    WhitelistTaxRatePO toPO(WhitelistTaxRateMetaDO metaDO);

    WhitelistTaxRateMetaDO toMetaDO(WhitelistTaxRatePO whitelistTaxRatePO);

    List<WhitelistTaxRateMetaDO> toMetaDOList(List<WhitelistTaxRatePO> whitelistTaxRatePOS);

    static Integer toStatusCode(EnumActiveStatus enumActiveStatus) {
        return EnumUtils.getCode(enumActiveStatus);
    }

    static EnumActiveStatus toStatus(Integer activeStatus) {
        return EnumUtils.getEnumByCode(EnumActiveStatus.values(), activeStatus);
    }

    static Integer toClassifyCode(EnumTaxClassify enumTaxClassify) {
        return EnumUtils.getCode(enumTaxClassify);
    }

    static EnumTaxClassify toClassify(Integer classifyCode) {
        return EnumUtils.getEnumByCode(EnumTaxClassify.values(), classifyCode);
    }
}
