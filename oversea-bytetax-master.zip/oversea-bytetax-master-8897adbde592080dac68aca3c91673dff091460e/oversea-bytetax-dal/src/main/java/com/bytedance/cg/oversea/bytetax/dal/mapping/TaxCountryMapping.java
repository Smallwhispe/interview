package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class})
public interface TaxCountryMapping {

    TaxCountryMapping MAPPING = Mappers.getMapper(TaxCountryMapping.class);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    TaxCountryPO toPO(TaxCountryMetaDO metaDO);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    TaxCountryMetaDO toMetaDO(TaxCountryPO po);

    List<TaxCountryMetaDO> toMetaDOList(List<TaxCountryPO> pos);

}
