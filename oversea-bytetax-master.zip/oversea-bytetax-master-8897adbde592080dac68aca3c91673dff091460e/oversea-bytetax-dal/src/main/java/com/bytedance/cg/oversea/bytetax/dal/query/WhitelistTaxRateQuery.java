package com.bytedance.cg.oversea.bytetax.dal.query;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WhitelistTaxRateQuery {

    /**
     * 客户ID
     */
    private Long accountId;

    private List<Long> accountIdList;

    /**
     * 合同ID
     */
    private Long contractId;

    /**
     * 国家
     */
    private String country;

    /**
     * 主体ID
     */
    private Long subjectId;

    private Integer pageSize;

    private Integer pageNumber;

}
