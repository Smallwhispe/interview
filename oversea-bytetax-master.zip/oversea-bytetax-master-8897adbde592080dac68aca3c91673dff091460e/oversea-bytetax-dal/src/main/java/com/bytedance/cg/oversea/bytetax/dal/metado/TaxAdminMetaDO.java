package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTimeType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author hanyuxiao
 * @date 2022/3/14
 **/

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaxAdminMetaDO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 备注
     */
    private String remark;

    /**
     * 报税币种
     */
    private String taxationCurrency;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private EnumDeleteStatus isDelete;

    /**
     * 申报周期类型(1-月/2-季度)
     */
    private Integer reportDateType;

    /**
     * 日期
     */
    private Integer reportDate;

    /**
     * 名称
     */
    private String name;

    /**
     * 国家名称
     */
    private String countryName;

    /**
     * 操作人id
     */
    private Integer operatorId;

    /**
     * 计税时点
     */
    private EnumTaxTimeType taxTimeType;

    /**
     * 税号类型
     */
    private EnumTaxNoType taxNoType;

    /**
     * 地理信息
     */
    private AddressMetaDO address;
}
