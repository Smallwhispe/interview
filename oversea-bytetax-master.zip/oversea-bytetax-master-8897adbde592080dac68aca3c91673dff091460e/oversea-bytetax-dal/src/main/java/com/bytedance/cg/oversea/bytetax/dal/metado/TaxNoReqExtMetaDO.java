package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @Author: Cai Yuxin
 * @Date： 7/11/23 5:35 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TaxNoReqExtMetaDO {

    private Map<String, String> bi;

    public void putBiParam(String key, String value) {
        if (bi == null) {
            bi = Maps.newHashMap();
        }
        bi.put(key, value);
    }
}
