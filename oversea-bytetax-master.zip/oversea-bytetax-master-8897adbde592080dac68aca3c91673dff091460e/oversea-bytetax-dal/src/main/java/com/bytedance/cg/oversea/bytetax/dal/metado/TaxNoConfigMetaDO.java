package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoConfigMetaDO {

    private Long id;

    private Long countryGeoId;

    private AddressConfigMetaDO addressConfig;

    private List<TaxInfoConfigMetaDO> taxInfoConfig;

    private List<VersionConfigMetaDO> versionConfig;

    private Integer operatorId;

    private Date createTime;

    private Date modifyTime;

    private EnumDeleteStatus isDelete;

    private EnumActiveStatus isActive;

}
