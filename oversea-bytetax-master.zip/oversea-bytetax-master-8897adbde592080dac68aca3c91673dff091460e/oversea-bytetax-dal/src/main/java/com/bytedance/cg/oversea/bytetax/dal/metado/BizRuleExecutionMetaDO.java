package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/7/12
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BizRuleExecutionMetaDO {
    private List<SingleRuleMetaDO> ruleList;

    private String operator;

    private String ruleDsl;
}
