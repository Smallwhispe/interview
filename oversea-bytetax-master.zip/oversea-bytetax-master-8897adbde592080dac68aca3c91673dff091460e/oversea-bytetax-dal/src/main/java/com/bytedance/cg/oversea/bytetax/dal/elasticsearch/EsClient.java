package com.bytedance.cg.oversea.bytetax.dal.elasticsearch;

import com.bytedance.cg.oversea.bytetax.common.utils.ElasticSearchClientUtil;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.sniff.ConsulNodesSniffer;
import org.elasticsearch.client.sniff.NodesSniffer;
import org.elasticsearch.client.sniff.SniffOnFailureListener;
import org.elasticsearch.client.sniff.Sniffer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * bytedance
 * 2022/9/28 3:49 下午
 */
//@Configuration
//@Profile({"prod-sg", "boe-va", "dev", "boe-prod"})
public class EsClient {

    @Value("${elasticsearch.psm}")
    private String esPsm;

    @Value("${elasticsearch.cluster}")
    private String esCluster;

    @Bean
    public RestHighLevelClient restHighLevelClient () {
        return ElasticSearchClientUtil.forConnectToNonSecurityCluster(esPsm, esCluster);
    }
}
