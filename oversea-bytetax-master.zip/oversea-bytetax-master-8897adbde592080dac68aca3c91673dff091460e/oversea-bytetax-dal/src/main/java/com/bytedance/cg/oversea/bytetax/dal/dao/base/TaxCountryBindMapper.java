package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxCountryBindMapper {
    int insert(TaxCountryBindPO record);

    int insertSelective(TaxCountryBindPO record);

    List<TaxCountryBindPO> selectByExample(TaxCountryBindPOExample example);

    TaxCountryBindPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxCountryBindPO record);

    int updateByPrimaryKey(TaxCountryBindPO record);
}