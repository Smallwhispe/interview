package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxAdminQuery;

import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2022/3/14
 **/
public interface TaxAdminRepository {

    void save(TaxAdminMetaDO metaDO);

    void updateByIdSelective(TaxAdminMetaDO metaDO);

    PageResult<TaxAdminMetaDO> queryTaxAdminList(TaxAdminQuery query);

    TaxAdminMetaDO getTaxAdminById(Long id);

    Map<Long, TaxAdminMetaDO> getTaxAdminsByIds(List<Long> ids);

    TaxAdminSubjectMetaDO getTaxAdminSubById(Long id);

    Map<Long, TaxAdminSubjectMetaDO> getTaxAdminSubsByIds(List<Long> ids);

    Long saveTaxAdminSub(TaxAdminSubjectMetaDO metaDO);

    List<TaxAdminMetaDO> getAllTaxAdmin(boolean active);

    List<TaxAdminSubjectMetaDO> getAllTaxAdminSubject(boolean active);

    Map<Long, TaxAdminSubjectMetaDO> getAllTaxAdminSubject(Long subjectId, boolean active);

    Map<Long, String> getAllTaxAdminSubjectTaxNo(Long subjectId, boolean active);
}
