package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.BizRuleExecutionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, JsonUtil.class, BizRuleExecutionMetaDO.class})
public interface TaxBizBindMapping {

    TaxBizBindMapping MAPPING = Mappers.getMapper(TaxBizBindMapping.class);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "rule", expression = "java(JsonUtil.writeValueAsString(metaDO.getRule()))")
    TaxBizBindPO toPO(TaxBizBindMetaDO metaDO);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "rule", expression = "java(JsonUtil.readValue(po.getRule(), BizRuleExecutionMetaDO.class))")
    TaxBizBindMetaDO toMetaDO(TaxBizBindPO po);

    List<TaxBizBindMetaDO> toMetaDOList(List<TaxBizBindPO> pos);

}
