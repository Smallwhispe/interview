package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTransactionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author hanyuxiao
 * @date 2022/3/14
 **/

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaxAdminSubjectMetaDO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 我方主体
     */
    private Long subjectId;

    /**
     * 税务局id
     */
    private Long taxAdminId;

    /**
     * 税号
     */
    private String taxNo;


    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private EnumDeleteStatus isDelete;

    /**
     * 计税方式
     */
    private EnumTaxTransactionType taxTransactionType;

    /**
     * 操作人ID
     */
    private Long operatorId;
}
