package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxInfoType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoFieldMetaDO {

    /**
     *
     */
    private Long id;

    /**
     *
     */
    private String name;

    /**
     *
     */
    private EnumTaxInfoType type;

    /**
     *
     */
    private Date createTime;

    /**
     *
     */
    private Date modifyTime;

    /**
     *
     */
    private EnumDeleteStatus isDelete;

}
