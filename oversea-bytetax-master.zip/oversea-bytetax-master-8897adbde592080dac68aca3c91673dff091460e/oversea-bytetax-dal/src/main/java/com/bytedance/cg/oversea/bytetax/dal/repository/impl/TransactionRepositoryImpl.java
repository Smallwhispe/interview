package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxReporterType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import com.bytedance.cg.oversea.bytetax.common.utils.StringUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TransactionMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TransactionMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.script.TaxAdminSubjectBindExcelMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TransactionQuery;
import com.bytedance.cg.oversea.bytetax.dal.query.elasticsearch.TransactionKeyDataEsQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminSubjectRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCountryBindRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TransactionRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

/**
 * @author hanyuxiao
 * @date 2022/1/14
 **/
@Repository
@Slf4j
public class TransactionRepositoryImpl implements TransactionRepository {

    @Resource
    private TransactionMapper transactionMapper;

    @Resource
    private TaxCountryBindRepository taxCountryBindRepository;

    @Resource
    private TaxAdminSubjectRepository taxAdminSubjectRepository;

    @Override
    public TransactionMetaDO queryTransactionById(Long id) {
        return TransactionMapping.MAPPING.toTransactionMetaDO(transactionMapper.selectByPrimaryKey(id));
    }

    @Override
    public TransactionMetaDO querySalesInvoiceByBizId(String bizTransactionId) {
        if (StringUtils.isBlank(bizTransactionId)) {
            return null;
        }
        TransactionPOExample example = new TransactionPOExample();
        example.createCriteria()
                .andInvoiceNoEqualTo(bizTransactionId)
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode())
                .andTransactionCategoryEqualTo(EnumTransactionCategory.SALES_INVOICE.getCode());
        List<TransactionPO> transactionPOS = transactionMapper.selectByExample(example);
        if (transactionPOS.size() > 1) {
            log.error("query by bizTransaction error number > 1");
            CgMonitorMetricRecorder.exceptionOneMetrics("query_by_bizTransaction_error_number", null, CgMetricsConstants.ServiceType.COMMON);
            return null;
        }
        return CollectionUtils.isEmpty(transactionPOS) ? null : TransactionMapping.MAPPING.toTransactionMetaDO(transactionPOS.get(0));
    }

    @Override
    public List<TransactionMetaDO> queryTransactionMetaDOS(Long adminId, Long offsetId, int limit, DateTime startTime, DateTime endTime) {
        TransactionPOExample example = new TransactionPOExample();
        example.setOrderByClause("id");
        example.limit(limit);
        example.createCriteria()
                .andIdGreaterThan(offsetId)
                .andInvoiceDateBetween(startTime.toDate(), endTime.toDate())
                .andTaxAdminIdEqualTo(adminId)
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode())
                .andTaxReporterTypeEqualTo(EnumTaxReporterType.GEN_REPORTER.getCode());
        return TransactionMapping.MAPPING.toMetaDOList(transactionMapper.selectByExample(example));
    }

    @Override
    public PageInfo<TransactionPO> queryTransactionMetaDOS(Long subjectId, List<Long> adminIds, Integer pageNumber, Integer pageSize, DateTime startTime, DateTime endTime) {
        TransactionPOExample example = new TransactionPOExample();
        example.setOrderByClause("id");
        TransactionPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if (pageNumber != null && pageSize != null) {
            PageHelper.startPage(pageNumber, pageSize);
        }
        if (subjectId != null) {
            List<Long> adminSubjectBindIds = taxAdminSubjectRepository.queryTaxAdminSubjectBySubjectId(subjectId);
            if (CollectionUtils.isEmpty(adminSubjectBindIds)) {
                return new PageInfo<>(Collections.emptyList());
            }
            criteria.andTaxAdminBindIdIn(adminSubjectBindIds);
        }
        if (startTime != null && endTime != null) {
            criteria.andInvoiceDateBetween(startTime.toDate(), endTime.toDate());
        }
        if (CollectionUtils.isNotEmpty(adminIds)) {
            criteria.andTaxAdminIdIn(adminIds);
        }
        return new PageInfo<>(transactionMapper.selectByExample(example));
    }

    @Override
    public Long queryTransactionCnt(List<Long> taxAdminIds, DateTime startTime, DateTime endTime) {
        TransactionPOExample example = new TransactionPOExample();
        example.createCriteria()
                .andInvoiceDateBetween(startTime.toDate(), endTime.toDate())
                .andTaxAdminIdIn(taxAdminIds)
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return transactionMapper.countByExample(example);
    }

    @Override
    public int save(TransactionMetaDO transactionMetaDO) {
        TransactionPO transactionPO = TransactionMapping.MAPPING.toTransactionMetaDO(transactionMetaDO);
        return transactionMapper.insertSelective(transactionPO);
    }

    @Override
    public int update(TransactionMetaDO transactionMetaDO) {
        return transactionMapper.updateByPrimaryKeySelective(TransactionMapping.MAPPING.toTransactionMetaDO(transactionMetaDO));
    }

    @Override
    public int delete(Long id) {
        TransactionPO transactionPO = new TransactionPO();
        transactionPO.setId(id);
        transactionPO.setIsDelete(EnumDeleteStatus.DELETED.getCode());
        return transactionMapper.updateByPrimaryKeySelective(transactionPO);
    }

    @Override
    public List<TransactionMetaDO> queryTaxReportTransaction(String invoiceNo, Long taxAdminId) {
        TransactionPOExample example = new TransactionPOExample();
        example.createCriteria()
                .andInvoiceNoEqualTo(invoiceNo)
                .andTaxAdminIdEqualTo(taxAdminId)
                .andTaxReporterTypeEqualTo(EnumTaxReporterType.GEN_REPORTER.getCode())
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return TransactionMapping.MAPPING.toMetaDOList(transactionMapper.selectByExample(example));
    }

    @Override
    public List<TransactionMetaDO> queryTaxReportTransactionByInvoice(String invoiceNo) {
        TransactionPOExample example = new TransactionPOExample();
        example.createCriteria()
                .andInvoiceNoEqualTo(invoiceNo)
                .andTransactionCategoryIn(EnumTransactionCategory.NEED_REPORT.stream().map(EnumTransactionCategory::getCode).collect(Collectors.toList()))
                .andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return TransactionMapping.MAPPING.toMetaDOList(transactionMapper.selectByExample(example));
    }

    @Override
    public PageResult<TransactionMetaDO> queryTransactionMetaDOS(TransactionQuery query) {
        TransactionPOExample example = new TransactionPOExample();
        example.setOrderByClause("invoice_date desc");

        TransactionPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());

        if (query.getSubjectId() != null) {
            List<Long> adminSubjectBindIds = taxAdminSubjectRepository.queryTaxAdminSubjectBySubjectId(query.getSubjectId());
            if (CollectionUtils.isEmpty(adminSubjectBindIds)) {
                return new PageResult<>(0L, Collections.emptyList());
            }
            criteria.andTaxAdminBindIdIn(adminSubjectBindIds);
        }

        if (query.getId() != null) {
            criteria.andIdEqualTo(query.getId());
        }
        if (query.getTransactionTimeBegin() != null) {
            criteria.andTransactionTimeGreaterThanOrEqualTo(query.getTransactionTimeBegin().toDate());
        }
        if (query.getTransactionTimeEnd() != null) {
            criteria.andTransactionTimeLessThanOrEqualTo(query.getTransactionTimeEnd().toDate());
        }
        if (query.getTransactionCategory() != null) {
            criteria.andTransactionCategoryEqualTo(query.getTransactionCategory().getCode());
        }
        if (StringUtils.isNotBlank(query.getAccountNameKw())) {
            criteria.andAccountNameLike("%" + query.getAccountNameKw().trim() + "%");
        }
        if (query.getBillingAddressIdL0() != null) {
            criteria.andBillingAddressLike("%" + "\"levelZero\":" + query.getBillingAddressIdL0() + "%");
        }
        if (query.getBillingAddressIdL1() != null) {
            criteria.andBillingAddressLike("%" + "\"levelOne\":" + query.getBillingAddressIdL1() + "%");
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TransactionPO> transactionPOPageInfos = new PageInfo<>(transactionMapper.selectByExample(example));
        return new PageResult<>(transactionPOPageInfos.getTotal(),
                TransactionMapping.MAPPING.toMetaDOList(transactionPOPageInfos.getList()));
    }

    @Override
    public PageResult<TransactionMetaDO> queryTransactionByIds(List<Long> ids) {
        // ES筛选完后直接根据主键id获取
        if (CollectionUtils.isEmpty(ids)) {
            return new PageResult<>(0L, new ArrayList<>());
        }
        TransactionPOExample example = new TransactionPOExample();
        TransactionPOExample.Criteria criteria = example.createCriteria();
        criteria.andIdIn(ids);
        PageInfo<TransactionPO> transactionPOPageInfos = new PageInfo<>(transactionMapper.selectByExample(example));
        List<TransactionPO> sortedTransactionPoList = transactionPOPageInfos.getList().stream().filter(Objects::nonNull).sorted(Comparator.comparing(TransactionPO::getInvoiceDate).reversed()).collect(Collectors.toList());
        return new PageResult<>(transactionPOPageInfos.getTotal(),
                TransactionMapping.MAPPING.toMetaDOList(sortedTransactionPoList));
    }

    @Override
    public Map<String, TransactionMetaDO> queryTransactionByInvoiceSerials(List<String> serials) {
        if(CollectionUtils.isEmpty(serials)) {
            return new HashMap<>();
        }
        // 因发票日增量可能达到5W+，所以为了降低查库时数据库的压力，分批次查询在库中的交易记录
        List<List<String>> serialList = Lists.partition(serials.stream().distinct().collect(Collectors.toList()), 100);
        List<TransactionMetaDO> transactionMetaDOS = serialList.stream().flatMap(oneBatchSerials ->
                batchQueryTransactionMetaDOBySerial(oneBatchSerials).stream()).collect(Collectors.toList());
        return transactionMetaDOS.stream().collect(Collectors.toMap(TransactionMetaDO::getInvoiceNo, Function.identity(), (o1, o2) -> o2));
    }

    private List<TransactionMetaDO> batchQueryTransactionMetaDOBySerial(List<String> serials) {
        if (CollectionUtils.isEmpty(serials)) {
            return Lists.newArrayList();
        }
        TransactionPOExample example = new TransactionPOExample();
        TransactionPOExample.Criteria criteria = example.createCriteria();
        log.info("one batch serials: {}" ,serials);
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        criteria.andInvoiceNoIn(serials);
        List<TransactionMetaDO> transactionMetaDOS = TransactionMapping.MAPPING.toMetaDOList(transactionMapper.selectByExample(example));
        log.info("find one batch serials {}", transactionMetaDOS.stream().map(TransactionMetaDO::getInvoiceNo).collect(Collectors.toList()));
        return transactionMetaDOS;
    }
}
