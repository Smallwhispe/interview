package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class ChangeLogPO {
    /**
     * 自增主键
     */
    private Long id;

    /**
     * adminId, bizId, categoryId, exemptionId, itemId, ruleId, bizBindId
     */
    private Long entityId;

    /**
     * adminId=1, bizId=2, categoryId=3, exemptionId=4, itemId=5, ruleId=6, bizBindId=7
     */
    private Long entityType;

    /**
     * 更改前
     */
    private String originalPo;

    /**
     * 更改后
     */
    private String updatedPo;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 操作人
     */
    private Integer operatorId;

    /**
     * 
     */
    private Integer changeType;
}