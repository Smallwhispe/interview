package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.WhitelistTaxRateMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.WhitelistTaxRateMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.WhitelistTaxRateMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.WhitelistTaxRatePO;
import com.bytedance.cg.oversea.bytetax.dal.po.WhitelistTaxRatePOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.WhitelistTaxRateQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.WhitelistTaxRateRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Repository
@Slf4j
public class WhitelistTaxRateRepositoryImpl implements WhitelistTaxRateRepository {

    @Resource
    private WhitelistTaxRateMapper mapper;

    WhitelistTaxRateMapping MAPPING = WhitelistTaxRateMapping.MAPPING;

    @Override
    public void save(WhitelistTaxRateMetaDO metaDO) {
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        mapper.insertSelective(MAPPING.toPO(metaDO));
    }

    @Override
    public void updateByIdSelective(WhitelistTaxRateMetaDO metaDO) {
        WhitelistTaxRatePO po = MAPPING.toPO(metaDO);
        po.setModifyTime(new Date());

        mapper.updateByPrimaryKeySelective(po);
    }

    @Override
    public WhitelistTaxRateMetaDO getById(Long id) {
        WhitelistTaxRatePO whitelistTaxRatePO = mapper.selectByPrimaryKey(id);
        if (whitelistTaxRatePO == null) {
            return null;
        }
        return MAPPING.toMetaDO(whitelistTaxRatePO);
    }

    @Override
    public PageResult<WhitelistTaxRateMetaDO> queryList(WhitelistTaxRateQuery query) {
        WhitelistTaxRatePOExample example = new WhitelistTaxRatePOExample();
        example.setOrderByClause("modify_time desc");
        WhitelistTaxRatePOExample.Criteria criteria = example.createCriteria();
        criteria.andStatusEqualTo(EnumActiveStatus.ACTIVE.getCode());
        if (query.getAccountId() != null) {
            criteria.andAccountIdEqualTo(query.getAccountId());
        }
        if (CollectionUtils.isNotEmpty(query.getAccountIdList())) {
            criteria.andAccountIdIn(query.getAccountIdList());
        }
        if (StringUtils.isNoneBlank(query.getCountry())) {
            criteria.andCountryEqualTo(query.getCountry());
        }
        if (query.getSubjectId() != null) {
            criteria.andSubjectIdEqualTo(query.getSubjectId());
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        List<WhitelistTaxRatePO> whitelistTaxRatePOS = mapper.selectByExample(example);
        PageInfo<WhitelistTaxRatePO> whitelistTaxRatePageInfo = new PageInfo<>(whitelistTaxRatePOS);
        return new PageResult<>(whitelistTaxRatePageInfo.getTotal(), MAPPING.toMetaDOList(whitelistTaxRatePOS));
    }
}
