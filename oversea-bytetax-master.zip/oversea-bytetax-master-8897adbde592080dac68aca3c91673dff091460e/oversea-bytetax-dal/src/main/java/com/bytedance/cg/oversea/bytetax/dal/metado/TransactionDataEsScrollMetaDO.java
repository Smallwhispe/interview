package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * bytedance
 * 2022/9/27 5:34 下午
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class TransactionDataEsScrollMetaDO {
    private List<TransactionDataEsPO> transactionDataEsPOS;

    private String scrollId;
}
