package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 4/12/23 3:31 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoCheckResultQuery {

    private List<Integer> apiRuleIds;

    private Date startTime;

    private Date endTime;

    private List<Integer> apiCheckResults;

    private String taskId;
}
