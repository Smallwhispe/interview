package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoCheckRuleMetaDO {
    /**
     *
     */
    private Long id;

    /**
     * 国家地理id
     */
    private Long countryGeoId;

    /**
     * 税号类型，如VAT，GST等，对应枚举类 EnumTaxType
     */
    private EnumTaxType taxInfoFields;

    /**
     * 格式校验规则集, 如[1,3]，对应 EnumTaxNoFormatRules
     */
    private List<EnumTaxNoFormatRules> formatRules;

    /**
     * API校验规则集，如[1,3], 对应 EnumTaxNoAPIRules
     */
    private List<EnumTaxNoAPIRules> apiRules;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;


    /**
     * 生效状态
     */
    private EnumActiveStatus isActive;
}
