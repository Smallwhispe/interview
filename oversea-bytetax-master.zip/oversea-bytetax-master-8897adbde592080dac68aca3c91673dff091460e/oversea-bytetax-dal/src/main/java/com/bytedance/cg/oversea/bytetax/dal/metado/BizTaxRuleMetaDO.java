package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2021/11/26
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BizTaxRuleMetaDO {
//    /**
//     * 上税地区
//     */
//    private TaxCountryMetaDO taxCountryMetaDO;

    /**
     * 国家主体绑定信息
     */
    private TaxCountryBindMetaDO taxCountryBindMetaDO;

    /**
     * 业务线信息
     */
    private TaxBizMetaDO taxBizMetaDO;
    /**
     * 业务线绑定信息
     */
    private TaxBizBindMetaDO taxBizBindMetaDO;

    /**
     * 和税务局的注册信息
     */
    private List<TaxAdminSubjectMetaDO> taxAdminSubjectMetaDO;

    private Boolean isRuleMatched;

    public Boolean isMatched(DateTime transactionTime) {
        if (!isRuleMatched) {
            return false;
        }
        if (taxBizBindMetaDO.getEffectiveTime() == null) {
            return true;
        }
        return !transactionTime.toDate().before(taxBizBindMetaDO.getEffectiveTime());
    }
}
