package com.bytedance.cg.oversea.bytetax.dal.query.elasticsearch;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;

/**
 * bytedance
 * 2022/9/27 2:50 下午
 * 用于ES交易列表和申报报表查询的核心字段
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionKeyDataEsQuery {

    /**
     * 交易时间开始时间
     */
    private DateTime transactionTimeBegin;

    /**
     * 交易时间结束时间
     */
    private DateTime transactionTimeEnd;

    /**
     * 交易类别
     */
    private EnumTransactionCategory transactionCategory;

    /**
     * 客户名称关键词
     */
    private String accountNameKw;

    /**
     * 客户Level0地址ID
     */
    private Long billingAddressIdL0;

    /**
     * 客户Level1地址ID
     */
    private Long billingAddressIdL1;

    /**
     * 主体对应的税务局ids
     */
    private List<Long> taxAdminSubjectBindIds;

    /**
     * 发票开始时间
     */
    private DateTime invoiceDateBegin;

    /**
     * 发票结束时间
     */
    private DateTime invoiceDateEnd;

    /**
     * 税务局ids
     */
    private List<Long> adminIds;

    /**
     * 单页大小
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNumber;
}
