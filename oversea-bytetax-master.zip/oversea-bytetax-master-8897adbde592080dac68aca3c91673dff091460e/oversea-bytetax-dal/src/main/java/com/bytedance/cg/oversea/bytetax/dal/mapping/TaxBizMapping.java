package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class})
public interface TaxBizMapping {

    TaxBizMapping MAPPING = Mappers.getMapper(TaxBizMapping.class);

    @Mapping(target = "code", source = "description")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    TaxBizPO toPO(TaxBizMetaDO metaDO);

    @Mapping(target = "description", source = "code")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    TaxBizMetaDO toMetaDO(TaxBizPO po);

    List<TaxBizMetaDO> toMetaDOList(List<TaxBizPO> pos);

}
