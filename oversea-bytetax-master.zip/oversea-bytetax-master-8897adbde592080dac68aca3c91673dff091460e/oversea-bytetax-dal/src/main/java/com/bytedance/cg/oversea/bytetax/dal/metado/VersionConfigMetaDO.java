package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumCollectConfig;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoAPIRules;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumVersion;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VersionConfigMetaDO {

    /**
     * 版本枚举名称
     */
    private EnumVersion version;


    /**
     * 是否需要搜集联系人姓名
     */
    private EnumCollectConfig contactName;

    /**
     * 是否需要搜集电话
     */
    private EnumCollectConfig telephoneNum;

    /**
     * 是否需要搜集邮箱
     */
    private EnumCollectConfig invoiceEmail;

    /**
     * 税号搜集情况
     */
    private List<TaxNoInfoCollectMetaDO> taxInfoCollectConfig;

    /**
     * 是否需要Api校验
     */
    private Boolean hasApiCheck;

    /**
     * Api校验是同步还是异步的
     */
    private EnumTaxNoAPIRules.EnumAsync apiAsync;

    /**
     * Api源的顺序
     */
    private List<EnumTaxNoAPIRules> apiSources;
}
