package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxBizPO {
    /**
     * 业务线ID
     */
    private Long id;

    /**
     * 业务线名称
     */
    private String name;

    /**
     * 业务线描述
     */
    private String code;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;
}