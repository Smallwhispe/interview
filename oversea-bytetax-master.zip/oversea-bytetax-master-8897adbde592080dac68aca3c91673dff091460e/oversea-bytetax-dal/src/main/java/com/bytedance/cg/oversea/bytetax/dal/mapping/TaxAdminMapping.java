package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTimeType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/3/14
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, JsonUtil.class, TaxAdminMapping.class, EnumTaxTimeType.class,
                EnumTaxNoType.class})
public interface TaxAdminMapping {

    TaxAdminMapping MAPPING = Mappers.getMapper(TaxAdminMapping.class);

    @Mapping(target = "levelOne", source = "metaDO.address.levelOne")
    @Mapping(target = "countryId", source = "metaDO.address.levelZero")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "taxTimeType", expression = "java(EnumUtils.getCode(metaDO.getTaxTimeType()))")
    @Mapping(target = "taxNoType",expression = "java(metaDO.getTaxNoType() == null ? \"\" : metaDO.getTaxNoType().getCode())")
    TaxAdminPO toPO(TaxAdminMetaDO metaDO);

    @Mapping(target = "address", expression = "java(toAddressMetaDO(po))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "taxTimeType", expression = "java(EnumUtils.getEnumByCode(EnumTaxTimeType.values(), po.getTaxTimeType()))")
    @Mapping(target = "taxNoType", expression = "java(EnumUtils.getEnumByCode(EnumTaxNoType.values(), po.getTaxNoType()))")
    TaxAdminMetaDO toMetaDO(TaxAdminPO po);

    @Mapping(target = "levelZero", source = "countryId")
    AddressMetaDO toAddressMetaDO(TaxAdminPO po);

    List<TaxAdminMetaDO> toMetaDOList(List<TaxAdminPO> pos);

}
