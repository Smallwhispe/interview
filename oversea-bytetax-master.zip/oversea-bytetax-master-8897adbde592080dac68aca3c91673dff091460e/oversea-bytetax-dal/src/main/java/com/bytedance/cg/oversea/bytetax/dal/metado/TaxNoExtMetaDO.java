package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxAuditRejectReason;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: Cai Yuxin
 * @Date： 7/11/23 5:35 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoExtMetaDO {

    private String customReasonRemarks;

    private EnumTaxAuditRejectReason reasonCode;
}
