package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxExemptionPO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 客户id
     */
    private Long customerId;

    /**
     * 客户名称
     */
    private String customerName;

    /**
     * 客户地址信息
     */
    private String address;

    /**
     * 税号
     */
    private String taxId;

    /**
     * 豁免原因
     */
    private String reason;

    /**
     * 豁免证书
     */
    private String certificate;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 国家
     */
    private Long country;

    /**
     * 主体id
     */
    private Long subjectId;

    /**
     * 非3M客户id
     */
    private String remark;
}