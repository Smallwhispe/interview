package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumHead;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.DetailAmountMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionLineMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPO;
import com.fasterxml.jackson.core.type.TypeReference;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/13
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, EnumHead.class, JsonUtil.class, EnumTransactionCategory.class, EnumTransactionType.class, DetailAmountMetaDO.class, List.class, TypeReference.class})
public interface TransactionDetailMapping {

    TransactionDetailMapping MAPPING = Mappers.getMapper(TransactionDetailMapping.class);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(),  po.getIsDelete()))")
    @Mapping(target = "taxCategoryBindIds", expression = "java(JsonUtil.unmarshalArray(po.getTaxCategoryBindIds(), Long.class))")
    @Mapping(target = "extend", expression = "java(JsonUtil.readValue(po.getExtend(), new TypeReference<List<DetailAmountMetaDO>>(){}))")
    TransactionLineMetaDO toTransactionLineMetaDO (TransactionDetailPO po);

    @Mapping(target = "taxCategoryBindIds", expression = "java(JsonUtil.writeValueAsString(metaDO.getTaxCategoryBindIds()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "extend", expression = "java(JsonUtil.writeValueAsString(metaDO.getExtend()))")
    TransactionDetailPO toTransactionDetailPO (TransactionLineMetaDO metaDO);
}
