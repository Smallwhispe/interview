package com.bytedance.cg.oversea.bytetax.dal.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class TransactionPO {
    /**
     * 
     */
    private Long id;

    /**
     * 发票编号
     */
    private String invoiceNo;

    /**
     * 
     */
    private Long taxAdminId;

    /**
     * 国家主体绑定表id
     */
    private Long taxCountryId;

    /**
     * 交易类型
     */
    private Integer transactionCategory;

    /**
     * 交易类型
     */
    private Integer transactionType;

    /**
     * 
     */
    private Long taxAdminBindId;

    /**
     * 规则id
     */
    private String ruleIds;

    /**
     * 总税基
     */
    private BigDecimal totalTaxable;

    /**
     * 总税额
     */
    private BigDecimal totalTax;

    /**
     * 报税币种税基
     */
    private BigDecimal totalTaxationTaxable;

    /**
     * 报税币种税额
     */
    private BigDecimal totalTaxationTax;

    /**
     * 用户id
     */
    private Long accountId;

    /**
     * 用户名字
     */
    private String accountName;

    /**
     * 
     */
    private String accountTaxNo;

    /**
     * 用户地址
     */
    private String billingAddress;

    /**
     * 交易币种
     */
    private String currencyCode;

    /**
     * 交易币种 到税务局所需币种的汇率
     */
    private BigDecimal exchangeRate;

    /**
     * 开票时间
     */
    private Date invoiceDate;

    /**
     * 折扣
     */
    private BigDecimal discount;

    /**
     * 扩展
     */
    private String extend;

    /**
     * 备注
     */
    private String remark;

    /**
     * 版本
     */
    private Integer version;

    /**
     * 
     */
    private Date modifyTime;

    /**
     * 
     */
    private Integer isDelete;

    /**
     * 
     */
    private Date createTime;

    /**
     * 
     */
    private Integer taxCalculateType;

    /**
     * 交易时间
     */
    private Date transactionTime;

    /**
     * 是否参与保税 1 是 2 否
     */
    private Integer taxReporterType;

    /**
     * 业务线ID
     */
    private Long taxBizId;

    /**
     * 自定义税率
     */
    private String customTax;

    /**
     * 
     */
    private Long subjectId;

    /**
     * 交易信息额外字段
     */
    private String transactionInfoExtend;

    /**
     * 报税币种
     */
    private String taxationCurrencyCode;
}