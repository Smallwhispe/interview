package com.bytedance.cg.oversea.bytetax.dal.repository;


import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryBindMetaDO;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/14
 **/
public interface TaxCountryBindRepository {

    List<TaxCountryBindMetaDO> queryAll(boolean needActive);

    List<TaxCountryBindMetaDO> queryBySubjectAndCountry(Long subjectId, Long countryId, boolean needActive);

    List<TaxCountryBindMetaDO> queryBySubjectExcludeCountry(Long subjectId, Long countryId, boolean needActive);

    List<TaxCountryBindMetaDO> queryBySubject(Long subjectId, boolean needActive);

    TaxCountryBindMetaDO queryById(Long id);

    Long save(TaxCountryBindMetaDO taxCountryBindMetaDO);

    boolean deleteById(Long id);

    boolean updateSelective(TaxCountryBindMetaDO metaDO);

    boolean fullUpdateById(TaxCountryBindMetaDO metaDO);

    List<TaxCountryBindMetaDO> queryBySubjectCountryRegion(Long subjectId, Long countryGeoId, Long secondGeoId);

    List<TaxCountryBindMetaDO> queryByCountryRegion(Long countryGeoId, Long secondGeoId);
}
