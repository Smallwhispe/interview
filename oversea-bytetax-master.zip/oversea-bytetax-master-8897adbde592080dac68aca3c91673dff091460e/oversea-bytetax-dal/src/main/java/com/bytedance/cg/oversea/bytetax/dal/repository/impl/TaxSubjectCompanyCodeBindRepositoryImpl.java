package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxSubjectCompanyCodeBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxSubjectCompanyCodeBindMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxSubjectCompanyCodeBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxSubjectCompanyCodeBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxSubjectCompanyCodeBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxSubjectCompanyCodeBindRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class TaxSubjectCompanyCodeBindRepositoryImpl implements TaxSubjectCompanyCodeBindRepository {

    @Resource
    private TaxSubjectCompanyCodeBindMapper taxSubjectCompanyCodeBindMapper;

    @Override
    @Cacheable(value = ConstantValue.GUAVA_5M_CACHE, unless = "#result == null")
    public TaxSubjectCompanyCodeBindMetaDO queryBySubjectId(Long subjectId, Long businessLineId) {
        if (subjectId == null) {
            return null;
        }
        TaxSubjectCompanyCodeBindPOExample example = new TaxSubjectCompanyCodeBindPOExample();
        example.createCriteria().andSubjectIdEqualTo(subjectId).andBizLineIdEqualTo(businessLineId).andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxSubjectCompanyCodeBindPO>  taxSubjectCompanyCodeBindPOS = taxSubjectCompanyCodeBindMapper.selectByExample(example);
        return CollectionUtils.isEmpty(taxSubjectCompanyCodeBindPOS) ? null : TaxSubjectCompanyCodeBindMapping.MAPPING.toMetaDO(taxSubjectCompanyCodeBindPOS.get(0));
    }
}
