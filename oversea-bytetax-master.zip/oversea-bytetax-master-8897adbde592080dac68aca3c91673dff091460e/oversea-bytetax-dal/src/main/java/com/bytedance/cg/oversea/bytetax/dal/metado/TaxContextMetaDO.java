package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * 目前只拉取有效的数据->绑定了业务线的国家和主体；绑定了规则的税种和商品
 * @Auther yangyl
 * @Date 2021/11/26
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
public class TaxContextMetaDO {

    /**
     * 四要素上下文
     */
    private List<BaseRuleMetaDO> baseRuleMetaDOS;

}
