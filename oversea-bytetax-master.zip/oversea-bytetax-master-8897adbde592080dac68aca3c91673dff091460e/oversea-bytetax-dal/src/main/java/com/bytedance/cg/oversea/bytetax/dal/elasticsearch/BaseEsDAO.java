package com.bytedance.cg.oversea.bytetax.dal.elasticsearch;

import com.bytedance.cg.common.exception.BizException;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.*;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.search.Scroll;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.IOException;

/**
 * bytedance
 * 2022/9/26 4:25 下午
 */
@Slf4j
//@Component
//@Profile({"prod-sg", "boe-va", "dev", "boe-prod"})
public class BaseEsDAO {
    @Resource
    private RestHighLevelClient client;
    // 判断索引是否存在
    public Boolean existIndex(String index) {
        GetIndexRequest getIndexRequest = new GetIndexRequest(index);
        try {
            return client.indices().exists(getIndexRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            e.printStackTrace();
            throw new BizException(e.getMessage());
        }
    }

    public SearchResponse searchHits(String indexName, SearchSourceBuilder searchSourceBuilder) {
        SearchRequest searchRequest = new SearchRequest(indexName);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = null;
        try {
            searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            return searchResponse;
        }catch (IOException e) {
            e.printStackTrace();;
            throw new BizException(e.getMessage());
        }
    }
    public SearchResponse searchWithScroll(String indexName, SearchSourceBuilder searchSourceBuilder) {
        final Scroll scroll = new Scroll(TimeValue.timeValueMinutes(1L));
        SearchRequest searchRequest = new SearchRequest(indexName);
        searchRequest.scroll(scroll);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = null;
        try {
            searchResponse = client.search(searchRequest, RequestOptions.DEFAULT);
            return searchResponse;
        } catch (IOException e) {
            e.printStackTrace();;
            throw new BizException(e.getMessage());
        }
    }

    public SearchResponse scrollEach(String scrollId) {
        SearchResponse searchResponse = null;
        final Scroll scroll = new Scroll(TimeValue.timeValueMinutes(1L));
        try {
            SearchScrollRequest scrollRequest = new SearchScrollRequest(scrollId);
            scrollRequest.scroll(scroll);
            searchResponse = client.scroll(scrollRequest, RequestOptions.DEFAULT);
            return searchResponse;
        } catch (IOException e) {
            e.printStackTrace();;
            throw new BizException(e.getMessage());
        }
    }

    public void clearScroll(String scrollId) {
        ClearScrollRequest clearScrollRequest = new ClearScrollRequest();
        clearScrollRequest.addScrollId(scrollId);
        try {
            ClearScrollResponse clearScrollResponse = client.clearScroll(clearScrollRequest, RequestOptions.DEFAULT);
            boolean succeeded = clearScrollResponse.isSucceeded();
            if (!succeeded) {
                log.error("[clearScroll]fail");
                CgMonitorMetricRecorder.exceptionOneMetrics("clearScroll_fail", null, CgMetricsConstants.ServiceType.COMMON);
                throw new BizException(clearScrollResponse.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new BizException(e.getMessage());
        }
    }

}
