package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckResultMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoExtMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoReqExtMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckResultPO;
import com.fasterxml.jackson.core.type.TypeReference;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Map;

@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, EnumTaxNoFormatRules.class, EnumTaxNoAPIRules.class,
                EnumTaxType.class, JsonUtil.class, EnumTaxNoCheckStatus.class, Map.class, TypeReference.class,
                EnumTaxIdentity.class, EnumActiveStatus.class, TaxNoExtMetaDO.class, TaxNoReqExtMetaDO.class,
                EnumVersion.class})
public interface TaxNoCheckResultMapping {

    TaxNoCheckResultMapping MAPPING = Mappers.getMapper(TaxNoCheckResultMapping.class);

    @Mapping(target = "businessStatus", expression = "java(metaDO.getBusinessStatus() == null? null : metaDO.getBusinessStatus().getCode())")
    @Mapping(target = "taxIdentity", expression = "java(metaDO.getTaxIdentity()==null? null : metaDO.getTaxIdentity().getCode())")
    @Mapping(target = "apiRuleId", expression = "java(metaDO.getApiRuleId() == null? null : metaDO.getApiRuleId().getCode())")
    @Mapping(target = "formatCheckResult", expression = "java(metaDO.getFormatCheckResult() == null? null : metaDO.getFormatCheckResult().getCode())")
    @Mapping(target = "apiCheckResult", expression = "java(metaDO.getApiCheckResult() == null? null : metaDO.getApiCheckResult().getCode())")
    @Mapping(target = "extraId", expression = "java(metaDO.getExtraId() == null? null : JsonUtil.writeValueAsString(metaDO.getExtraId()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "requestExtend", expression = "java(JsonUtil.writeValueAsString(metaDO.getRequestExtend()))")
    @Mapping(target = "responseExtend", expression = "java(JsonUtil.writeValueAsString(metaDO.getResponseExtend()))")
    @Mapping(target = "version", expression = "java(EnumUtils.getCode(metaDO.getVersion()))")
    TaxNoCheckResultPO toPO (TaxNoCheckResultMetaDO metaDO);

    @Mapping(target = "businessStatus", expression = "java(EnumUtils.getEnumByCode(EnumActiveStatus.values(), po.getBusinessStatus()))")
    @Mapping(target = "taxIdentity", expression = "java(EnumUtils.getEnumByCode(EnumTaxIdentity.values(), po.getTaxIdentity()))")
    @Mapping(target = "apiRuleId", expression = "java(EnumUtils.getEnumByCode(EnumTaxNoAPIRules.values(), po.getApiRuleId()))")
    @Mapping(target = "formatCheckResult", expression = "java(EnumUtils.getEnumByCode(EnumTaxNoCheckStatus.values(), po.getFormatCheckResult()))")
    @Mapping(target = "apiCheckResult", expression = "java(EnumUtils.getEnumByCode(EnumTaxNoCheckStatus.values(), po.getApiCheckResult()))")
    @Mapping(target = "extraId", expression = "java(po.getExtraId() == null? null : JsonUtil.readValue(po.getExtraId(), new TypeReference<Map<String, String>>(){}))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "requestExtend", expression = "java(po.getRequestExtend() == null? null : JsonUtil.readValue(po.getRequestExtend(), new TypeReference<Map<String, String>>(){}))")
    @Mapping(target = "responseExtend", expression = "java(JsonUtil.readValue(po.getResponseExtend(), TaxNoExtMetaDO.class))")
    @Mapping(target = "version", expression = "java(EnumUtils.getEnumByCode(EnumVersion.values(), po.getVersion()))")
    TaxNoCheckResultMetaDO toMetaDO (TaxNoCheckResultPO po);

    List<TaxNoCheckResultMetaDO> toMetaDOList (List<TaxNoCheckResultPO> pos);

}
