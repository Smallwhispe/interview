package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxCountryPO {
    /**
     * 
     */
    private Long id;

    /**
     * 地理中台国家id
     */
    private Long countryGeoId;

    /**
     * 地理中台一级地址id
     */
    private Long levelOne;

    /**
     * 报税币种
     */
    private String taxReportCurrency;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 
     */
    private String mark;
}