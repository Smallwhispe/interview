package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxRuleCaseDataMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxCountryMapping;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxRuleCaseDataMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleCaseDataMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRuleCaseDataPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRuleCaseDataPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxRuleCaseDataRepository;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class TaxRuleCaseDataRepositoryImpl implements TaxRuleCaseDataRepository {
    @Resource
    private TaxRuleCaseDataMapper taxRuleCaseDataMapper;

    @Override
    public void save(TaxRuleCaseDataMetaDO metaDO){
        taxRuleCaseDataMapper.insert(TaxRuleCaseDataMapping.MAPPING.toPO(metaDO));
    }

    @Override
    public void updateByIdSelective(TaxRuleCaseDataMetaDO metaDO) {
        TaxRuleCaseDataPO taxRuleCaseDataPO = TaxRuleCaseDataMapping.MAPPING.toPO(metaDO);
        taxRuleCaseDataPO.setModifyTime(new Date());
        taxRuleCaseDataMapper.updateByPrimaryKeySelective(taxRuleCaseDataPO);
    }
    @Override
    public List<TaxRuleCaseDataMetaDO> queryAll(){
        TaxRuleCaseDataPOExample example = new TaxRuleCaseDataPOExample();
        example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxRuleCaseDataPO> taxRuleCaseDataPOS = taxRuleCaseDataMapper.selectByExample(example);
        return taxRuleCaseDataPOS.stream()
                .map(e->TaxRuleCaseDataMapping.MAPPING.toMetaDO(e))
                .collect(Collectors.toList());
    }
}
