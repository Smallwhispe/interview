package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TaxRuleCaseDataMetaDO {
    private Long id;
    /**
     *
     */
    private String param;

    /**
     *
     */
    private String result;

    /**
     *
     */
    private String transactionType;


    /**
     *
     */
    private String transactionMethod;

    /**
     *
     */
    private String country;

    /**
     *
     */
    private Long taxRuleId;
}
