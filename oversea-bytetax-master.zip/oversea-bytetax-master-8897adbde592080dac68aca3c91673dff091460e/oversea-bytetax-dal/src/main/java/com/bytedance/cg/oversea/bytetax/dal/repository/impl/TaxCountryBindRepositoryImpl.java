package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCountryBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxCountryBindMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCountryBindRepository;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2022/1/14
 **/
@Repository
public class TaxCountryBindRepositoryImpl implements TaxCountryBindRepository {

    @Resource
    private TaxCountryBindMapper taxCountryBindMapper;

    @Resource
    @Lazy
    private TaxCountryBindRepository taxCountryBindRepository;

    @Override
    public List<TaxCountryBindMetaDO> queryAll(boolean needActive) {
        TaxCountryBindPOExample example = new TaxCountryBindPOExample();
        if (needActive) {
            example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        }
        return TaxCountryBindMapping.MAPPING.toMetaDOList(taxCountryBindMapper.selectByExample(example));
    }

    @Override
    public List<TaxCountryBindMetaDO> queryBySubjectAndCountry(Long subjectId, Long countryId, boolean needActive) {
        return taxCountryBindRepository.queryAll(needActive).stream()
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getSubjectId().equals(subjectId))
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getAddress().getLevelZero().equals(countryId))
                .collect(Collectors.toList());
    }

    @Override
    public List<TaxCountryBindMetaDO> queryBySubjectExcludeCountry(Long subjectId, Long countryId, boolean needActive) {
        return taxCountryBindRepository.queryAll(needActive).stream()
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getSubjectId().equals(subjectId))
                .filter(taxCountryBindMetaDO -> !taxCountryBindMetaDO.getAddress().getLevelZero().equals(countryId))
                .collect(Collectors.toList());
    }

    @Override
    public List<TaxCountryBindMetaDO> queryBySubject(Long subjectId, boolean needActive) {
        return taxCountryBindRepository.queryAll(needActive).stream()
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getSubjectId().equals(subjectId))
                .collect(Collectors.toList());
    }

    @Override
    public TaxCountryBindMetaDO queryById(Long id) {
        return taxCountryBindRepository.queryAll(false).stream()
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getId().equals(id))
                .findFirst().orElse(null);
    }

    @Override
    public Long save(TaxCountryBindMetaDO metaDO) {
        TaxCountryBindPO po = TaxCountryBindMapping.MAPPING.toPO(metaDO);
        taxCountryBindMapper.insertSelective(po);
        return po.getId();
    }

    @Override
    public boolean deleteById(Long id) {
        TaxCountryBindPO po = new TaxCountryBindPO();
        po.setId(id);
        po.setIsDelete(EnumDeleteStatus.DELETED.getCode());
        return taxCountryBindMapper.updateByPrimaryKeySelective(po) > 0;
    }

    @Override
    public boolean updateSelective(TaxCountryBindMetaDO metaDO) {
        TaxCountryBindPO po = TaxCountryBindMapping.MAPPING.toPO(metaDO);
        return taxCountryBindMapper.updateByPrimaryKeySelective(po) > 0;
    }

    @Override
    public boolean fullUpdateById(TaxCountryBindMetaDO metaDO) {
        TaxCountryBindPO po = TaxCountryBindMapping.MAPPING.toPO(metaDO);
        return taxCountryBindMapper.updateByPrimaryKey(po) > 0;
    }

    @Override
    public List<TaxCountryBindMetaDO> queryBySubjectCountryRegion(Long subjectId, Long countryGeoId, Long secondGeoId){
        return taxCountryBindRepository.queryAll(true).stream()
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getSubjectId().equals(subjectId))
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getAddress().getLevelZero().equals(countryGeoId))
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getAddress().getLevelOne().equals(secondGeoId))
                .collect(Collectors.toList());
    }

    @Override
    public List<TaxCountryBindMetaDO> queryByCountryRegion(Long countryGeoId, Long secondGeoId) {
        return taxCountryBindRepository.queryAll(true).stream()
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getAddress().getLevelZero().equals(countryGeoId))
                .filter(taxCountryBindMetaDO -> taxCountryBindMetaDO.getAddress().getLevelOne().equals(secondGeoId))
                .collect(Collectors.toList());
    }

}
