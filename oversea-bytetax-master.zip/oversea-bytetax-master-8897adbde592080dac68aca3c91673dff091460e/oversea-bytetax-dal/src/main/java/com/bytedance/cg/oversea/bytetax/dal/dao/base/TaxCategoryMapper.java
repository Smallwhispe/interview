package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxCategoryMapper {
    int insert(TaxCategoryPO record);

    int insertSelective(TaxCategoryPO record);

    List<TaxCategoryPO> selectByExample(TaxCategoryPOExample example);

    TaxCategoryPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxCategoryPO record);

    int updateByPrimaryKey(TaxCategoryPO record);
}