package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxBizBindPO {
    /**
     * 
     */
    private Long id;

    /**
     * 国家绑定id
     */
    private Long countryBindId;

    /**
     * 业务线id
     */
    private Long bizId;

    /**
     * 业务线规则
     */
    private String rule;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 生效时间
     */
    private Date effectiveTime;
}