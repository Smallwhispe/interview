package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.bsm.RequestContext;
import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.ValidateUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxBizBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxBizBindMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.ChangeLogRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxBizBindRepository;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2022/5/12
 **/
@Repository
public class TaxBizBindRepositoryImpl implements TaxBizBindRepository {

    @Resource
    private TaxBizBindMapper taxBizBindMapper;

    @Resource
    @Lazy
    private TaxBizBindRepository taxBizBindRepository;

    @Override
    public List<TaxBizBindMetaDO> queryAll() {
        TaxBizBindPOExample example = new TaxBizBindPOExample();
        example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        return taxBizBindMapper.selectByExample(example).stream().map(TaxBizBindMapping.MAPPING::toMetaDO).collect(Collectors.toList());
    }

    @Override
    public Long saveTaxBizBind(TaxBizBindMetaDO metaDO) {
        TaxBizBindPO po = TaxBizBindMapping.MAPPING.toPO(metaDO);
//        有id就更新 否则就新建
        if (ValidateUtil.validLong(metaDO.getId())) {
//            更新时生成操作日志
            TaxBizBindPO org = taxBizBindRepository.getTaxBizBindById(po.getId());
            if(org == null || EnumDeleteStatus.DELETED.getCode().equals(org.getIsDelete()))  {
                throw new BizException(I18nConstants.WRONG_PARAMS);
            }
            po.setModifyTime(new Date());
            taxBizBindMapper.updateByPrimaryKeySelective(po);
            TaxBizBindPO upt = taxBizBindRepository.getTaxBizBindById(po.getId());
//            if(!org.equals(upt)) {
//                changeLogRepository.saveSelective(org.getId(), EnumChangeLogType.BIZBIND_ID.getCode(),
//                        JsonUtil.writeValueAsString(org), JsonUtil.writeValueAsString(upt), RequestContext.getEmployeeId().intValue(), EnumChangeType.MODIFY.getCode());
//            }
            return metaDO.getId();
        }
        taxBizBindMapper.insertSelective(po);
        return po.getId();
    }

    @Override
    public List<TaxBizBindMetaDO> getTaxBizBind(List<Long> subCountryBindIds, boolean active) {
        if (CollectionUtils.isEmpty(subCountryBindIds)) {
            return Lists.newArrayList();
        }
        TaxBizBindPOExample example = new TaxBizBindPOExample();
        TaxBizBindPOExample.Criteria criteria = example.createCriteria()
                .andCountryBindIdIn(subCountryBindIds);
        if (active) {
            criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        }
        return taxBizBindMapper.selectByExample(example).stream()
                .map(TaxBizBindMapping.MAPPING::toMetaDO)
                .collect(Collectors.toList());
    }

    @Override
    public void deleteTaxBizBind(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return;
        }
        Date now = new Date();
        TaxBizBindPOExample example = new TaxBizBindPOExample();
        example.createCriteria().andIdIn(ids);
        TaxBizBindPO po = new TaxBizBindPO();
        po.setIsDelete(EnumDeleteStatus.DELETED.getCode());
        po.setModifyTime(now);
        taxBizBindMapper.updateByExampleSelective(po, example);
    }

    @Override
    public TaxBizBindPO getTaxBizBindById(Long id) {
        if(id == null) {
            return null;
        }
        TaxBizBindPOExample taxCategoryPOExample = new TaxBizBindPOExample();
        taxCategoryPOExample.createCriteria().andIdEqualTo(id);
        TaxBizBindPO taxBizBindPO = taxBizBindMapper.selectByPrimaryKey(id);
        return taxBizBindPO;
    }
}
