package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxItemBindMapper {
    int insert(TaxItemBindPO record);

    int insertSelective(TaxItemBindPO record);

    List<TaxItemBindPO> selectByExample(TaxItemBindPOExample example);

    TaxItemBindPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxItemBindPO record);

    int updateByPrimaryKey(TaxItemBindPO record);
}