package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxValidateRulePO {
    /**
     * 主键ID
     */
    private Long id;

    /**
     * 规则大类，1-正则，非1-其他 对应 EnumTaxNoFormatRuleType
     */
    private Integer ruleType;

    /**
     * 正则表达式,枚举描述（如有）
     */
    private String rule;

    /**
     * 页面展示的规则名称
     */
    private String ruleName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;
}