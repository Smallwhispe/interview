package com.bytedance.cg.oversea.bytetax.dal.po;


import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * bytedance
 * 2022/9/26 4:01 下午
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionDataEsPO {
    // 交易列表筛选
    private Long id;

    // 交易列表筛选
    private String accountName;

    // 交易列表筛选
    private AddressMetaDO billingAddress;

    // 交易列表/申报报表筛选
    private Integer isDelete;

    // 交易列表筛选
    private Long taxAdminBindId;

    // 交易列表筛选
    private Integer transactionCategory;

    // 交易列表筛选
    private Date transactionTime;

    // 申报报表筛选
    private Date invoiceDate;

    // 申报报表筛选
    private Long taxAdminId;
}
