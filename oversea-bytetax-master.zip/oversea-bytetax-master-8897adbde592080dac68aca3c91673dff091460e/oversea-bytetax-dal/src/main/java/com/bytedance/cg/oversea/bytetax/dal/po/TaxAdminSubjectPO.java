package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxAdminSubjectPO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 我方主体
     */
    private Long subjectId;

    /**
     * 税务局id
     */
    private Long taxAdminId;

    /**
     * 税号所在国家-已废弃
     */
    private Long taxNoCountry;

    /**
     * 税号
     */
    private String taxNo;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private Integer isDelete;

    /**
     * 
     */
    private Integer taxTransactionType;

    /**
     * 创建人
     */
    private Long operatorId;
}