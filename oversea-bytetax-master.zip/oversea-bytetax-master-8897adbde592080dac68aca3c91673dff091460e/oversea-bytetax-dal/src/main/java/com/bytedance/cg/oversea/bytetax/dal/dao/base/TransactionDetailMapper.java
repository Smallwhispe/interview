package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TransactionDetailMapper {
    int insert(TransactionDetailPO record);

    int insertSelective(TransactionDetailPO record);

    List<TransactionDetailPO> selectByExample(TransactionDetailPOExample example);

    TransactionDetailPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TransactionDetailPO record);

    int updateByPrimaryKey(TransactionDetailPO record);
}