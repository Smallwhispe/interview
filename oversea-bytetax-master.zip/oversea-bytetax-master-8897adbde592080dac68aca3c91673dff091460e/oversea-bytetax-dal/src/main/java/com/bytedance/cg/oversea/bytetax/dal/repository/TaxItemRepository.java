package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxItemMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxItemQuery;

import java.util.List;
import java.util.Map;

public interface TaxItemRepository {
    void save(TaxItemMetaDO metaDO);

    void updateByIdSelective(TaxItemMetaDO metaDO);

    TaxItemMetaDO getTaxItemById(Long id);

    Map<Long, TaxItemMetaDO> getTaxItemsByIds(List<Long> ids);

    PageResult<TaxItemMetaDO> queryTaxItemList(TaxItemQuery query);

    List<TaxItemMetaDO> queryAll();

    String getTaxItemCodeById(Long id);
}
