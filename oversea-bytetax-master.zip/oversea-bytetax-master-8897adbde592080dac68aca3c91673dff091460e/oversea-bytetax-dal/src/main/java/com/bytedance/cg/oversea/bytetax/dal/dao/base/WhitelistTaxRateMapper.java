package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.WhitelistTaxRatePO;
import com.bytedance.cg.oversea.bytetax.dal.po.WhitelistTaxRatePOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface WhitelistTaxRateMapper {
    int insert(WhitelistTaxRatePO record);

    int insertSelective(WhitelistTaxRatePO record);

    List<WhitelistTaxRatePO> selectByExample(WhitelistTaxRatePOExample example);

    WhitelistTaxRatePO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(WhitelistTaxRatePO record);

    int updateByPrimaryKey(WhitelistTaxRatePO record);
}