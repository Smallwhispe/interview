package com.bytedance.cg.oversea.bytetax.dal.query;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxCategoryQuery {
    /**
     * code
     */
    private Long id;

    /**
     * code
     */
    private String code;

    /**
     * 税种
     */
    private String category;

    /**
     * 税种类型
     */
    private EnumTaxClassify taxClassify;

    /**
     * 税种描述
     */
    private String description;

    /**
     * 税务局id
     */
    private Long taxAdminId;

    /**
     * 每页数量
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNumber;
}
