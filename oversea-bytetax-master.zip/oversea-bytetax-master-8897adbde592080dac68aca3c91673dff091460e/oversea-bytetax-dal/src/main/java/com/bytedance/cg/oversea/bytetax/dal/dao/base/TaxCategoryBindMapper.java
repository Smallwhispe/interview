package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryBindPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxCategoryBindMapper {
    int insert(TaxCategoryBindPO record);

    int insertSelective(TaxCategoryBindPO record);

    List<TaxCategoryBindPO> selectByExample(TaxCategoryBindPOExample example);

    TaxCategoryBindPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxCategoryBindPO record);

    int updateByPrimaryKey(TaxCategoryBindPO record);
}