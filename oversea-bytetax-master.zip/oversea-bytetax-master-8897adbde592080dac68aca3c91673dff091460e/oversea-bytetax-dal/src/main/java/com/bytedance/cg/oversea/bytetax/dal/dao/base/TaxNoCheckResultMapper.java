package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckResultPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckResultPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TaxNoCheckResultMapper {
    int insert(TaxNoCheckResultPO record);

    int insertSelective(TaxNoCheckResultPO record);

    List<TaxNoCheckResultPO> selectByExample(TaxNoCheckResultPOExample example);

    TaxNoCheckResultPO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") TaxNoCheckResultPO record, @Param("example") TaxNoCheckResultPOExample example);

    int updateByExample(@Param("record") TaxNoCheckResultPO record, @Param("example") TaxNoCheckResultPOExample example);

    int updateByPrimaryKeySelective(TaxNoCheckResultPO record);

    int updateByPrimaryKey(TaxNoCheckResultPO record);
}