package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.bsm.RequestContext;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoCheckRuleMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxNoCheckRuleMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckRulePOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckRuleQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxNoCheckRuleRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;

@Repository
public class TaxNoCheckRuleRepositoryImpl implements TaxNoCheckRuleRepository {

    @Resource
    private TaxNoCheckRuleMapper taxNoCheckRuleMapper;

    @Override
    public Long save(TaxNoCheckRuleMetaDO metaDO) {
        Date now = new Date();
        metaDO.setCreateTime(now);
        metaDO.setModifyTime(now);
        metaDO.setOperatorId(RequestContext.getEmployeeId().intValue());
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        metaDO.setIsActive(EnumActiveStatus.ACTIVE);
        TaxNoCheckRulePO po = TaxNoCheckRuleMapping.MAPPING.toPO(metaDO);
        taxNoCheckRuleMapper.insert(po);
        return po.getId();
    }

    @Override
    public void updateByIdSelective(TaxNoCheckRuleMetaDO metaDO) {
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setOperatorId(RequestContext.getEmployeeId().intValue());
        taxNoCheckRuleMapper.updateByPrimaryKeySelective(TaxNoCheckRuleMapping.MAPPING.toPO(metaDO));
    }

    @Override
    public TaxNoCheckRuleMetaDO getTaxNoCheckRuleById(Long id) {
        if (id == null) {
            return null;
        }
        TaxNoCheckRulePO po = taxNoCheckRuleMapper.selectByPrimaryKey(id);
        return TaxNoCheckRuleMapping.MAPPING.toMetaDO(po);
    }

    @Override
    public PageResult<TaxNoCheckRuleMetaDO> queryTaxNoCheckRuleList(TaxNoCheckRuleQuery query) {
        TaxNoCheckRulePOExample example = new TaxNoCheckRulePOExample();
        example.setOrderByClause("modify_time desc");
        TaxNoCheckRulePOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if(query.getId() != null) {
            criteria.andIdEqualTo(query.getId());
        }
        if(query.getCountryGeoId() != null) {
            criteria.andCountryGeoIdEqualTo(query.getCountryGeoId());
        }
        if(query.getIsActive() != null) {
            criteria.andIsActiveEqualTo(query.getIsActive());
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxNoCheckRulePO> taxNoCheckRulePOPageInfo = new PageInfo<>(taxNoCheckRuleMapper.selectByExample(example));
        return new PageResult<>(taxNoCheckRulePOPageInfo.getTotal(),
                TaxNoCheckRuleMapping.MAPPING.toMetaDOList(taxNoCheckRulePOPageInfo.getList()));
    }
}
