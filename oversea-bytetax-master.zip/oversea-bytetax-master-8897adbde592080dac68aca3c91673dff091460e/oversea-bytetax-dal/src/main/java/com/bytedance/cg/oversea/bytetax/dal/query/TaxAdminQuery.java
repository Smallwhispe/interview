package com.bytedance.cg.oversea.bytetax.dal.query;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTimeType;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxAdminQuery {

    /**
     * 主键
     */
    private Long id;

    /**
     * 名称（精确）
     */
    private String exactName;

    /**
     * 名称（模糊）
     */
    private String fuzzyName;

    /**
     * 主体id
     */
    private Long subjectId;

    /**
     * 四级地址 geoId
     */
    private AddressMetaDO address;

    /**
     * 计税时点
     */
    private EnumTaxTimeType taxTimeType;

    /**
     * 国家名称
     */
    private String countryName;

    /**
     * 每页数量
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNumber;
}
