package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoAPIRules;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoCheckStatus;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckResultMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckResultQuery;

import java.util.List;

public interface TaxNoCheckResultRepository {

    TaxNoCheckResultMetaDO save(TaxNoCheckResultMetaDO metaDO);

    void updateByIdSelective(TaxNoCheckResultMetaDO metaDO);

    TaxNoCheckResultMetaDO getTaxNoCheckResultById(Long id);

    TaxNoCheckResultMetaDO updateAPIRuleAndCheckResult(TaxNoCheckResultMetaDO resultMetaDO, EnumTaxNoAPIRules apiRules, EnumTaxNoCheckStatus checkStatus);

    boolean updatePrimaryKeyFromApi(EnumTaxNoAPIRules apiSource, String idFromApi, TaxNoCheckResultMetaDO resultMetaDO);

    TaxNoCheckResultMetaDO SelectByPrimaryKeyFromApi(EnumTaxNoAPIRules apiSource, String idFromApi);

    List<TaxNoCheckResultMetaDO> query(TaxNoCheckResultQuery query);
}

