package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class CasesPO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 四要素json
     */
    private String caseKey;

    /**
     * 结果ruleId
     */
    private String value;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private Integer isDelete;
}