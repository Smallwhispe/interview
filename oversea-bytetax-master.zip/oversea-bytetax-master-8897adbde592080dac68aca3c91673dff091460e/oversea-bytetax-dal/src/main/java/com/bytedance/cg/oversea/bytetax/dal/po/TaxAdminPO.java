package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxAdminPO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 
     */
    private String remark;

    /**
     * 报税币种
     */
    private String taxationCurrency;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private Integer isDelete;

    /**
     * 税务局所属国家
     */
    private Long countryId;

    /**
     * 
     */
    private Long levelOne;

    /**
     * 申报周期类型(1-月/2-季度)
     */
    private Integer reportDateType;

    /**
     * 日期
     */
    private Integer reportDate;

    /**
     * 
     */
    private String name;

    /**
     * 
     */
    private Integer operatorId;

    /**
     * 计税时点类型 1-消耗时点 2-账单生成时点
     */
    private Integer taxTimeType;

    /**
     * 国家名称
     */
    private String countryName;

    /**
     * 税务局对应税种
     */
    private String taxNoType;
}