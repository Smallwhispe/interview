package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryMetaDO;


/**
 * bytedance
 * 2021/12/3 6:52 下午
 */
public interface TaxCountryRepository {

    void save(TaxCountryMetaDO metaDO);

    void updateByIdSelective(TaxCountryMetaDO metaDO);

//    List<TaxCountryMetaDO> queryTaxCountryList(SubjectListQueryParam param);

    TaxCountryMetaDO getTaxCountryByCountryId(Long countryId);
}
