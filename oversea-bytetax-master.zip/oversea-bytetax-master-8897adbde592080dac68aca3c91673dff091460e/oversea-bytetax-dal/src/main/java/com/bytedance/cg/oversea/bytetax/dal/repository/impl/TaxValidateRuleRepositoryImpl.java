package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxValidateRuleMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxValidateRuleMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxValidateRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxValidateRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxValidateRulePOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxValidateRuleRepository;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/08/17 4:41 PM
 */
@Repository
public class TaxValidateRuleRepositoryImpl implements TaxValidateRuleRepository {

    @Resource
    private TaxValidateRuleMapper taxValidateRuleMapper;

    @Override
    public List<TaxValidateRuleMetaDO> queryByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return queryAll();
        }
        return queryAll().stream().filter(e->ids.contains(e.getId())).collect(Collectors.toList());
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1M_CACHE, unless = "#result == null")
    public List<TaxValidateRuleMetaDO> queryAll() {
        TaxValidateRulePOExample example = new TaxValidateRulePOExample();
        example.setOrderByClause("id asc");
        TaxValidateRulePOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        PageInfo<TaxValidateRulePO> taxValidateRulePOPageInfo = new PageInfo<>(taxValidateRuleMapper.selectByExample(example));
        return TaxValidateRuleMapping.MAPPING.toMetaDOList(taxValidateRulePOPageInfo.getList());
    }
}
