package com.bytedance.cg.oversea.bytetax.dal.elasticsearch;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.utils.JacksonUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsCommonMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsScrollMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * bytedance
 * 2022/9/26 4:58 下午
 */
//@Component
@Slf4j
//@Profile({"prod-sg",  "boe-va", "dev", "boe-prod"})
public class TransactionDataEsDAO extends BaseEsDAO{
    private static final String TRANSACTION_RECORD_INDEX = "cg_oversea_bytetax_transaction";
    public TransactionDataEsScrollMetaDO transactionSelectScroll(SearchSourceBuilder sourceBuilder) {
        Boolean exists = super.existIndex(TRANSACTION_RECORD_INDEX);
        // 判断是否存在对应索引
        if(!exists) {
            throw new BizException("找不到transaction表对应的索引");
        }
        SearchResponse response = super.searchWithScroll(TRANSACTION_RECORD_INDEX, sourceBuilder);
        SearchHit [] searchHits = response.getHits().getHits();
        if(searchHits != null && searchHits.length > 0) {
//            Arrays.stream(searchHits).filter(Objects::nonNull).forEach(it -> System.out.println(it.getSourceAsString()));
            return TransactionDataEsScrollMetaDO.builder().transactionDataEsPOS(Arrays.stream(searchHits).filter(Objects::nonNull).map(it -> JsonUtil.readValue(it.getSourceAsString(), TransactionDataEsPO.class))
                    .collect(Collectors.toList())).scrollId(response.getScrollId()).build();
        }
        return TransactionDataEsScrollMetaDO.builder().scrollId(response.getScrollId()).build();
    }

    public TransactionDataEsCommonMetaDO transactionSelect(SearchSourceBuilder searchSourceBuilder) {
        Boolean exists = super.existIndex(TRANSACTION_RECORD_INDEX);
        // 判断是否存在对应索引
        if (!exists) {
            throw new BizException("找不到transaction表对应的索引");
        }
        SearchResponse searchResponse = super.searchHits(TRANSACTION_RECORD_INDEX, searchSourceBuilder);
        if (searchResponse == null || searchResponse.getHits() == null || searchResponse.getHits().getHits() == null) {
            return  TransactionDataEsCommonMetaDO.builder().total(0L).build();
        }
        return TransactionDataEsCommonMetaDO.builder().transactionDataEsPOS(Arrays.stream(searchResponse.getHits().getHits()).filter(Objects::nonNull).
                map(it -> JsonUtil.readValue(it.getSourceAsString(), TransactionDataEsPO.class)).collect(Collectors.toList())).total(searchResponse.getHits().getTotalHits().value).build();
    }

    public TransactionDataEsScrollMetaDO scrollEachTag(String scrollId) {
        SearchResponse response = super.scrollEach(scrollId);
        SearchHit [] searchHits = response.getHits().getHits();
        if(searchHits != null && searchHits.length > 0) {
            return TransactionDataEsScrollMetaDO.builder().transactionDataEsPOS(Arrays.stream(searchHits).filter(Objects::nonNull).map(it -> JsonUtil.readValue(it.getSourceAsString(), TransactionDataEsPO.class))
                    .collect(Collectors.toList())).scrollId(response.getScrollId()).build();
        }
        return TransactionDataEsScrollMetaDO.builder().scrollId(response.getScrollId()).build();
    }

    @Override
    public void clearScroll(String scrollId) {
        super.clearScroll(scrollId);
    }

}
