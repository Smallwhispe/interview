package com.bytedance.cg.oversea.bytetax.dal.po;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class TaxCategoryPO {
    /**
     * 
     */
    private Long id;

    /**
     * code
     */
    private String code;

    /**
     * 税种
     */
    private String category;

    /**
     * 税种类型: 1 流转税 2 预扣税
     */
    private Integer classify;

    /**
     * 税种描述
     */
    private String description;

    /**
     * 地理中台国家id
     */
    private Long countryGeoId;

    /**
     * 默认税率
     */
    private BigDecimal defaultTaxRate;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 税务局id
     */
    private Long taxAdminId;

    /**
     * 生效税率
     */
    private String validTaxRate;
}