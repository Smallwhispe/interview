package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckRulePO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, EnumTaxNoFormatRules.class, EnumTaxNoAPIRules.class,
                EnumTaxType.class, EnumActiveStatus.class})
public interface TaxNoCheckRuleMapping {

    TaxNoCheckRuleMapping MAPPING = Mappers.getMapper(TaxNoCheckRuleMapping.class);

    @Mapping(target = "taxInfoFields", expression = "java(metaDO.getTaxInfoFields() == null? null : metaDO.getTaxInfoFields().getName())")
    @Mapping(target = "formatRules", expression = "java(metaDO.getFormatRules() == null? null : EnumUtils.getCodeListString(metaDO.getFormatRules()))")
    @Mapping(target = "apiRules", expression = "java(metaDO.getApiRules() == null? null : EnumUtils.getCodeListString(metaDO.getApiRules()))")
    @Mapping(target = "isDelete", expression = "java(metaDO.getIsDelete() == null? null : EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "isActive", expression = "java(metaDO.getIsActive() == null? null : EnumUtils.getCode(metaDO.getIsActive()))")
    TaxNoCheckRulePO toPO (TaxNoCheckRuleMetaDO metaDO);

    @Mapping(target = "taxInfoFields", expression = "java(EnumUtils.getEnumByName(EnumTaxType.values(), po.getTaxInfoFields()))")
    @Mapping(target = "formatRules", expression = "java(EnumUtils.getEnumList(EnumTaxNoFormatRules.values(), po.getFormatRules()))")
    @Mapping(target = "apiRules", expression = "java(EnumUtils.getEnumList(EnumTaxNoAPIRules.values(), po.getApiRules()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "isActive", expression = "java(EnumUtils.getEnumByCode(EnumActiveStatus.values(), po.getIsActive()))")
    TaxNoCheckRuleMetaDO toMetaDO (TaxNoCheckRulePO po);

    List<TaxNoCheckRuleMetaDO> toMetaDOList (List<TaxNoCheckRulePO> po);
}
