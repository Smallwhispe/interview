package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxCalculateType;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class TaxCategoryBindMetaDO {
    /**
     * 
     */
    private Long id;

    /**
     * 税种id
     */
    private Long taxCategoryId;

    /**
     * 商品id
     */
    private Long itemId;

    /**
     * 税率
     */
    private BigDecimal taxRate;

    /**
     * 是否含税价
     */
    private EnumTaxCalculateType taxCalculateType;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 生效时间
     */
    private Date validTime;

    /**
     * 失效时间
     */
    private Date invalidTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;
}