package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class, EnumHead.class, JsonUtil.class, AddressMetaDO.class,
                EnumTransactionType.class, EnumWithTaxNo.class, EnumApproveStatus.class, TaxRuleMetaDO.TaxRuleExtend.class})
public interface TaxRuleMapping {

    TaxRuleMapping MAPPING = Mappers.getMapper(TaxRuleMapping.class);

    @Mapping(target = "transactionType", expression = "java(EnumUtils.getCode(metaDO.getTransactionType()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "head", expression = "java(EnumUtils.getCode(metaDO.getHead()))")
    @Mapping(target = "billFrom", expression = "java(JsonUtil.writeValueAsString(metaDO.getBillFrom()))")
    @Mapping(target = "billTo", expression = "java(JsonUtil.writeValueAsString(metaDO.getBillTo()))")
    @Mapping(target = "shipFrom", expression = "java(JsonUtil.writeValueAsString(metaDO.getShipFrom()))")
    @Mapping(target = "shipTo", expression = "java(JsonUtil.writeValueAsString(metaDO.getShipTo()))")
    @Mapping(target = "fromWithTaxNo", expression = "java(EnumUtils.getCode(metaDO.getFromWithTaxNo()))")
    @Mapping(target = "toWithTaxNo", expression = "java(EnumUtils.getCode(metaDO.getToWithTaxNo()))")
    @Mapping(target = "approveStatus", expression = "java(EnumUtils.getCode(metaDO.getApproveStatus()))")
    @Mapping(target = "isReverseCharge",
            expression = "java(ConvertMethod.toIsReverseCharge(metaDO.getIsReverseCharge()))")
    @Mapping(target = "extend", expression = "java(JsonUtil.writeValueAsString(metaDO.getTaxRuleExtend()))")
    TaxRulePO toPO(TaxRuleMetaDO metaDO);

    @Mapping(target = "transactionType", expression = "java(EnumUtils.getEnumByCode(EnumTransactionType.values(), po.getTransactionType()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "head", expression = "java(EnumUtils.getEnumByCode(EnumHead.values(), po.getHead()))")
    @Mapping(target = "billFrom", expression = "java(JsonUtil.readValue(po.getBillFrom(), AddressMetaDO.class))")
    @Mapping(target = "billTo", expression = "java(JsonUtil.readValue(po.getBillTo(), AddressMetaDO.class))")
    @Mapping(target = "shipFrom", expression = "java(JsonUtil.readValue(po.getShipFrom(), AddressMetaDO.class))")
    @Mapping(target = "shipTo", expression = "java(JsonUtil.readValue(po.getShipTo(), AddressMetaDO.class))")
    @Mapping(target = "fromWithTaxNo", expression = "java(EnumUtils.getEnumByCode(EnumWithTaxNo.values(), po.getFromWithTaxNo()))")
    @Mapping(target = "toWithTaxNo", expression = "java(EnumUtils.getEnumByCode(EnumWithTaxNo.values(), po.getToWithTaxNo()))")
    @Mapping(target = "approveStatus", expression = "java(EnumUtils.getEnumByCode(EnumApproveStatus.values(),  po.getApproveStatus()))")
    @Mapping(target = "isReverseCharge", expression = "java(po.getIsReverseCharge() == 1)")
    @Mapping(target = "taxRuleExtend", expression = "java(JsonUtil.readValue(po.getExtend(), TaxRuleMetaDO.TaxRuleExtend.class))")
    TaxRuleMetaDO toMetaDO(TaxRulePO po);

    List<TaxRuleMetaDO> toMetaDOList(List<TaxRulePO> pos);

    class ConvertMethod{
        public static Integer toIsReverseCharge(Boolean isReverseCharge){
            //如果MetaDO此项为空 那么默认为false
            if(isReverseCharge == null){
                isReverseCharge = false;
            }
            return isReverseCharge? 1:0;
        }
    }
}
