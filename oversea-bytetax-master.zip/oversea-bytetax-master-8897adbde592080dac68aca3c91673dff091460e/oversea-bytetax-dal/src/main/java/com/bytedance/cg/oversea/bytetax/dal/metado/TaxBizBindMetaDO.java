package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaxBizBindMetaDO {
    /**
     * 
     */
    private Long id;

    /**
     * 国家绑定id
     */
    private Long countryBindId;

    /**
     * 业务线id
     */
    private Long bizId;

    /**
     * 业务线规则
     */
    private BizRuleExecutionMetaDO rule;

    /**
     * 创建人
     */
    private Long operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;

    /**
     * 生效时间
     */
    private Date effectiveTime;
}