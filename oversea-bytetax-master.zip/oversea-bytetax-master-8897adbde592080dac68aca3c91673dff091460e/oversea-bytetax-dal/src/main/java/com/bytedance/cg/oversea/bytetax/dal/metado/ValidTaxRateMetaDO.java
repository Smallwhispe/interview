package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Auther yangyl
 * @Date 2022/4/12
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ValidTaxRateMetaDO {
    private Date validTime;
    private Date invalidTime;
    private BigDecimal taxRate;
}
