package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxInfoConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.VersionConfigMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoConfigPO;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2023/8/22
 **/
@Mapper(imports = { JsonUtil.class, AddressConfigMetaDO.class, TaxInfoConfigMetaDO.class, VersionConfigMetaDO.class,
        EnumDeleteStatus.class, EnumUtils.class, StringUtils.class, Lists.class, EnumActiveStatus.class})
public interface TaxNoConfigMapping {

    TaxNoConfigMapping MAPPING = Mappers.getMapper(TaxNoConfigMapping.class);

    @Mapping(target = "addressConfig", expression = "java(StringUtils.isBlank(taxNoConfigPO.getAddressConfig())? null : JsonUtil.readValue(taxNoConfigPO.getAddressConfig(), AddressConfigMetaDO.class))")
    @Mapping(target = "taxInfoConfig", expression = "java(StringUtils.isBlank(taxNoConfigPO.getTaxInfoConfig())? Lists.newArrayList() : JsonUtil.unmarshalFromString2List(taxNoConfigPO.getTaxInfoConfig(), TaxInfoConfigMetaDO.class))")
    @Mapping(target = "versionConfig", expression = "java(StringUtils.isBlank(taxNoConfigPO.getVersionConfig())? Lists.newArrayList() : JsonUtil.unmarshalFromString2List(taxNoConfigPO.getVersionConfig(), VersionConfigMetaDO.class))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), taxNoConfigPO.getIsDelete()))")
    @Mapping(target = "isActive", expression = "java(EnumUtils.getEnumByCode(EnumActiveStatus.values(), taxNoConfigPO.getIsActive()))")
    TaxNoConfigMetaDO toTaxNoConfigMetaDO(TaxNoConfigPO taxNoConfigPO);

    List<TaxNoConfigMetaDO> toTaxNoConfigList(List<TaxNoConfigPO> taxNoConfigPO);

    @Mapping(target = "addressConfig", expression = "java(JsonUtil.writeValueAsString(taxNoConfigMetaDO.getAddressConfig()))")
    @Mapping(target = "taxInfoConfig", expression = "java(JsonUtil.writeValueAsString(taxNoConfigMetaDO.getTaxInfoConfig()))")
    @Mapping(target = "versionConfig", expression = "java(JsonUtil.writeValueAsString(taxNoConfigMetaDO.getVersionConfig()))")
    @Mapping(target = "isDelete", expression = "java(taxNoConfigMetaDO.getIsDelete() == null ? null : taxNoConfigMetaDO.getIsDelete().getCode())")
    @Mapping(target = "isActive", expression = "java(taxNoConfigMetaDO.getIsActive() == null ? null : taxNoConfigMetaDO.getIsActive().getCode())")
    TaxNoConfigPO toTaxNoConfigPO(TaxNoConfigMetaDO taxNoConfigMetaDO);
}
