package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCountryMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxCountryMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCountryRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * bytedance
 * 2021/12/3 6:56 下午
 */
@Repository
public class TaxCountryRepositoryImpl implements TaxCountryRepository {
    @Resource
    private TaxCountryMapper taxCountryMapper;

    @Override
    public void save(TaxCountryMetaDO metaDO) {
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        taxCountryMapper.insert(TaxCountryMapping.MAPPING.toPO(metaDO));
    }

    @Override
    public void updateByIdSelective(TaxCountryMetaDO metaDO) {
        TaxCountryPO taxCountryPO = TaxCountryMapping.MAPPING.toPO(metaDO);
        taxCountryPO.setModifyTime(new Date());
        taxCountryMapper.updateByPrimaryKeySelective(taxCountryPO);
    }


//    @Override
//    public List<SubjectMetaDO> querySubjectList(SubjectListQueryParam param) {
//        List<SubjectPO> queryResult = subjectDao.selectByFilterQueryParam(param);
//        PageInfo<SubjectPO> page = new PageInfo<>(queryResult);
//        List<SubjectMetaDO> data = queryResult.stream()
//                .map(SubjectMapping.MAPPING::toMetaDO)
//                .collect(Collectors.toList());
//
//        return data;
//    }

    @Override
    public TaxCountryMetaDO getTaxCountryByCountryId(Long id) {
        if (id == null) {
            return null;
        }
        TaxCountryPOExample taxCountryPOExample = new TaxCountryPOExample();
        taxCountryPOExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode()).andCountryGeoIdEqualTo(id);
        List<TaxCountryPO> taxCountryPOS = taxCountryMapper.selectByExample(taxCountryPOExample);
        if (CollectionUtils.isEmpty(taxCountryPOS)) {
            return null;
        }
        return TaxCountryMapping.MAPPING.toMetaDO(taxCountryPOS.get(ConstantValue.ZERO));
    }
}
