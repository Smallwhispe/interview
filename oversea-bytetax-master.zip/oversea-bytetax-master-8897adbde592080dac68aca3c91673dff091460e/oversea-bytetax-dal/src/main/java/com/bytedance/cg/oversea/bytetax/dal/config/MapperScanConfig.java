package com.bytedance.cg.oversea.bytetax.dal.config;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author zhuxiaoqiang
 * @date 2020-12-08 5:11 下午
 */
@Configuration
@MapperScan(basePackages = "com.bytedance.cg.oversea.bytetax.dal.dao")
public class MapperScanConfig {
}
