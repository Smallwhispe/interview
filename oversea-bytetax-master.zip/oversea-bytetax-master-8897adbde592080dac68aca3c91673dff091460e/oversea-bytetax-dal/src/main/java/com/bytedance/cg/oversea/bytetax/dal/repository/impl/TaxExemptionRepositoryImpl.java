package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxExemptionMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxExemptionMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxExemptionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxExemptionPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxExemptionPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxExemptionQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.ChangeLogRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxExemptionRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Repository
public class TaxExemptionRepositoryImpl implements TaxExemptionRepository {

    @Resource
    private TaxExemptionMapper taxExemptionMapper;

    @Resource
    @Lazy
    private TaxExemptionRepository taxExemptionRepository;

    @Override
    public void save(TaxExemptionMetaDO metaDO){
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        taxExemptionMapper.insert(TaxExemptionMapping.MAPPING.toPO(metaDO));
    }

    @Override
    public void updateByIdSelective(TaxExemptionMetaDO metaDO){
        TaxExemptionPO taxExemptionPO = TaxExemptionMapping.MAPPING.toPO(metaDO);
        taxExemptionPO.setModifyTime(new Date());
        TaxExemptionPO org = TaxExemptionMapping.MAPPING.toPO(taxExemptionRepository.getTaxExemptionById(taxExemptionPO.getId()));
        if(org == null || EnumDeleteStatus.DELETED.getCode().equals(org.getIsDelete())) {
            throw new BizException(I18nConstants.WRONG_PARAMS);
        }
        taxExemptionMapper.updateByPrimaryKeySelective(taxExemptionPO);
    }

    @Override
    public TaxExemptionMetaDO getTaxExemptionById(Long id){
        if (id == null) {
            return null;
        }
        TaxExemptionPOExample taxExemptionPOExample = new TaxExemptionPOExample();
        taxExemptionPOExample.createCriteria().andIdEqualTo(id);
        List<TaxExemptionPO> taxExemptionPOS = taxExemptionMapper.selectByExample(taxExemptionPOExample);
        if (CollectionUtils.isEmpty(taxExemptionPOS)) {
            return null;
        }
        return TaxExemptionMapping.MAPPING.toMetaDO(taxExemptionPOS.get(ConstantValue.ZERO));

    }

    @Override
    public TaxExemptionMetaDO getTaxExemptionByCustomerId(Long id) {
        if (id == null) {
            return null;
        }
        TaxExemptionPOExample taxExemptionPOExample = new TaxExemptionPOExample();
        taxExemptionPOExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode()).andCustomerIdEqualTo(id);
        List<TaxExemptionPO> taxExemptionPOS = taxExemptionMapper.selectByExample(taxExemptionPOExample);
        if (CollectionUtils.isEmpty(taxExemptionPOS)) {
            return null;
        }
        return TaxExemptionMapping.MAPPING.toMetaDO(taxExemptionPOS.get(ConstantValue.ZERO));
    }

    @Override
    public PageResult<TaxExemptionMetaDO> queryTaxExemptionList(TaxExemptionQuery query){
        TaxExemptionPOExample example = new TaxExemptionPOExample();
        example.setOrderByClause("modify_time desc");
        TaxExemptionPOExample.Criteria criteria = example.createCriteria();
        TaxExemptionPOExample.Criteria criteria2 = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        criteria2.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if(checkString(query.getCustomerName())){
            criteria.andCustomerNameLike("%" + validate(query.getCustomerName()) + "%");
            criteria2.andCustomerNameLike("%" + validate(query.getCustomerName()) + "%");
        }
        if(query.getSubjectId() != null){
            criteria.andSubjectIdEqualTo(query.getSubjectId());
            criteria2.andSubjectIdEqualTo(query.getSubjectId());
        }
        if(query.getCustomerId() != null){
            criteria.andCustomerIdEqualTo(query.getCustomerId());
            criteria2.andRemarkEqualTo(query.getCustomerId() + "");
            example.or(criteria2);
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxExemptionPO> taxExemptionPOPageInfo = new PageInfo<>(taxExemptionMapper.selectByExample(example));
        return new PageResult<>(taxExemptionPOPageInfo.getTotal(),
                TaxExemptionMapping.MAPPING.toMetaDOList(taxExemptionPOPageInfo.getList()));
    }

    private String validate(String str){
        str = str.trim();
        StringBuilder ans = new StringBuilder();
        for(char c : str.toCharArray()){
            if(c == '_' || c == '%'){
                ans.append("\\");
            }
            ans.append(c);
        }
        return ans.toString();
    }

    private boolean checkString(String str){
        return !(str == null || str.trim().length() == 0);
    }
}
