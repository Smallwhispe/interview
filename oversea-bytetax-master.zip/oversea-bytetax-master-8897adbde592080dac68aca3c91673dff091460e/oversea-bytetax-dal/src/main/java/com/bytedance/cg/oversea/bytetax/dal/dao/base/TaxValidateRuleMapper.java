package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxValidateRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxValidateRulePOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxValidateRuleMapper {
    int insert(TaxValidateRulePO record);

    int insertSelective(TaxValidateRulePO record);

    List<TaxValidateRulePO> selectByExample(TaxValidateRulePOExample example);

    TaxValidateRulePO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxValidateRulePO record);

    int updateByPrimaryKey(TaxValidateRulePO record);
}