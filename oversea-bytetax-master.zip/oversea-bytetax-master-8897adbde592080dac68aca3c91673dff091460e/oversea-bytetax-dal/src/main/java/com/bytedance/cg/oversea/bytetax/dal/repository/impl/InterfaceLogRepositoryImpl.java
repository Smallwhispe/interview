package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.ValidateUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.InterfaceLogMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminSubjectMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.InterfaceLogMapping;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxAdminSubjectMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.InterfaceLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxAdminSubjectBindQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.InterfaceLogRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminSubjectRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Repository
public class InterfaceLogRepositoryImpl implements InterfaceLogRepository {

    @Resource
    private InterfaceLogMapper interfaceLogMapper;

    @Override
    public void saveSelectiveInterfaceLog(InterfaceLogMetaDO metaDO) {
       interfaceLogMapper.insertSelective(InterfaceLogMapping.MAPPING.toPO(metaDO));
    }
}