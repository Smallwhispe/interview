package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxExemptionPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxExemptionPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxExemptionMapper {
    int insert(TaxExemptionPO record);

    int insertSelective(TaxExemptionPO record);

    List<TaxExemptionPO> selectByExample(TaxExemptionPOExample example);

    TaxExemptionPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxExemptionPO record);

    int updateByPrimaryKey(TaxExemptionPO record);
}