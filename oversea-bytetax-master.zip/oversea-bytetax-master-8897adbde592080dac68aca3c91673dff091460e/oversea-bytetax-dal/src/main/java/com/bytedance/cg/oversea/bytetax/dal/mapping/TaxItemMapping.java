package com.bytedance.cg.oversea.bytetax.dal.mapping;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxItemMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author yangyl
 * @date 2021/4/22
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumUtils.class, EnumDeleteStatus.class})
public interface TaxItemMapping {

    TaxItemMapping MAPPING = Mappers.getMapper(TaxItemMapping.class);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    TaxItemPO toPO(TaxItemMetaDO metaDO);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    TaxItemMetaDO toMetaDO(TaxItemPO po);

    List<TaxItemMetaDO> toMetaDOList(List<TaxItemPO> pos);

}
