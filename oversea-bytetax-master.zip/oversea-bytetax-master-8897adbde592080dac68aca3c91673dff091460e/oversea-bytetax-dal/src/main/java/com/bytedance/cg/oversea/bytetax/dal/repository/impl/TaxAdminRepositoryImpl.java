package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.ValidateUtil;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminSubjectMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxAdminMapping;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxAdminSubjectMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxAdminQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminRepository;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.google.common.collect.Maps;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;


/**
 * @author hanyuxiao
 * @date 2022/3/14
 **/
@Repository
public class TaxAdminRepositoryImpl implements TaxAdminRepository {

    @Resource
    private TaxAdminMapper taxAdminMapper;

    @Resource
    private TaxAdminSubjectMapper taxAdminSubjectMapper;

    @Resource
    @Lazy
    private TaxAdminRepository taxAdminRepository;

    @Override
    public void save(TaxAdminMetaDO metaDO) {
        Date now = new Date();
        metaDO.setModifyTime(now);
        metaDO.setCreateTime(now);
        metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
        TaxAdminPO taxAdminPO = TaxAdminMapping.MAPPING.toPO(metaDO);
        taxAdminMapper.insert(taxAdminPO);
    }
    @Override
    public void updateByIdSelective(TaxAdminMetaDO metaDO) {
        TaxAdminPO taxAdminPO = TaxAdminMapping.MAPPING.toPO(metaDO);
        taxAdminPO.setModifyTime(new Date());
        TaxAdminPO org = TaxAdminMapping.MAPPING.toPO(taxAdminRepository.getTaxAdminById(taxAdminPO.getId()));
        if (org == null || EnumDeleteStatus.DELETED.getCode().equals(org.getIsDelete())) {
            throw new BizException(I18nConstants.WRONG_PARAMS);
        }
        taxAdminMapper.updateByPrimaryKeySelective(taxAdminPO);
    }

    @Override
    public PageResult<TaxAdminMetaDO> queryTaxAdminList(TaxAdminQuery query) {
        TaxAdminPOExample example = new TaxAdminPOExample();
        example.setOrderByClause("modify_time desc");
        TaxAdminPOExample.Criteria criteria = example.createCriteria();
        criteria.andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        if (query.getId() != null) {
            criteria.andIdEqualTo(query.getId());
        }
        if (checkString(query.getFuzzyName()) && query.getId() == null) {
            criteria.andNameLike("%" + validate(query.getFuzzyName()) + "%");
        }
        if (checkString(query.getExactName()) && query.getId() == null) {
            criteria.andNameEqualTo(query.getExactName());
        }
        if (query.getAddress() != null && query.getAddress().getLevelZero() != null) {
            criteria.andCountryIdEqualTo(query.getAddress().getLevelZero());
        }
        if (query.getAddress() != null && query.getAddress().getLevelOne() != null) {
            criteria.andLevelOneEqualTo(query.getAddress().getLevelOne());
        }
        if (query.getSubjectId() != null) {
            query.setPageNumber(null);
            query.setPageSize(null);
        }
        if (query.getTaxTimeType() != null) {
            criteria.andTaxTimeTypeEqualTo(query.getTaxTimeType().getCode());
        }
        if (query.getCountryName() != null) {
            criteria.andCountryNameLike("%" + validate(query.getCountryName()) + "%");
        }
        if (query.getPageNumber() != null && query.getPageSize() != null) {
            PageHelper.startPage(query.getPageNumber(), query.getPageSize());
        }
        PageInfo<TaxAdminPO> taxAdminPOPageInfo = new PageInfo<>(taxAdminMapper.selectByExample(example));
        return new PageResult<>(taxAdminPOPageInfo.getTotal(),
                TaxAdminMapping.MAPPING.toMetaDOList(taxAdminPOPageInfo.getList()));
    }

    private String validate(String str) {
        str = str.trim();
        StringBuilder ans = new StringBuilder();
        for (char c : str.toCharArray()) {
            if (c == '_' || c == '%') {
                ans.append("\\");
            }
            ans.append(c);
        }
        return ans.toString();
    }

    private boolean checkString(String str) {
        return !(str == null || str.trim().length() == 0);
    }

    @Override
    public TaxAdminMetaDO getTaxAdminById(Long id) {
        return taxAdminRepository.getAllTaxAdmin(false).stream()
                .filter(taxAdminMetaDO -> taxAdminMetaDO.getId().equals(id))
                .findFirst().orElse(null);
    }

    @Override
    public Map<Long, TaxAdminMetaDO> getTaxAdminsByIds(List<Long> ids) {
        if (CollectionUtils.isEmpty(ids)) {
            return Maps.newHashMap();
        }
        TaxAdminPOExample example = new TaxAdminPOExample();
        example.createCriteria().andIdIn(ids);
        List<TaxAdminMetaDO> taxAdminMetaDOS = TaxAdminMapping.MAPPING.toMetaDOList(taxAdminMapper.selectByExample(example));
        return Optional.ofNullable(taxAdminMetaDOS).orElse(Collections.emptyList()).
                stream().collect(Collectors.toMap(TaxAdminMetaDO::getId, Function.identity()));
    }

    @Override
    public TaxAdminSubjectMetaDO getTaxAdminSubById(Long id) {
        return taxAdminRepository.getAllTaxAdminSubject(false).stream()
                .filter(taxAdminSubjectMetaDO -> taxAdminSubjectMetaDO.getId().equals(id))
                .findFirst().orElse(null);
    }

    @Override
    public Map<Long, TaxAdminSubjectMetaDO> getTaxAdminSubsByIds(List<Long> ids) {
        return taxAdminRepository.getAllTaxAdminSubject(false).stream().filter(e -> ids.contains(e.getId()))
                .collect(Collectors.toMap(TaxAdminSubjectMetaDO::getId, Function.identity()));
    }


    @Override
    public Long saveTaxAdminSub(TaxAdminSubjectMetaDO metaDO) {
        TaxAdminSubjectPO po = TaxAdminSubjectMapping.MAPPING.toPO(metaDO);
        if (ValidateUtil.validLong(metaDO.getId())) {
            taxAdminSubjectMapper.updateByPrimaryKeySelective(po);
        } else {
            taxAdminSubjectMapper.insertSelective(po);
        }
        return po.getId();
    }

    @Override
    public List<TaxAdminMetaDO> getAllTaxAdmin(boolean active) {
        TaxAdminPOExample example = new TaxAdminPOExample();
        if (active) {
            example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        }
        return TaxAdminMapping.MAPPING.toMetaDOList(taxAdminMapper.selectByExample(example));
    }

    @Override
    public List<TaxAdminSubjectMetaDO> getAllTaxAdminSubject(boolean active) {
        TaxAdminSubjectPOExample example = new TaxAdminSubjectPOExample();
        if (active) {
            example.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        }
        return TaxAdminSubjectMapping.MAPPING.toMetaDOList(taxAdminSubjectMapper.selectByExample(example));

    }

    @Override
    public Map<Long, TaxAdminSubjectMetaDO> getAllTaxAdminSubject(Long subjectId, boolean active) {
        return taxAdminRepository.getAllTaxAdminSubject(active).stream()
                .filter(taxAdminSubjectMetaDO -> subjectId.equals(taxAdminSubjectMetaDO.getSubjectId()))
                .collect(Collectors.toMap(TaxAdminSubjectMetaDO::getTaxAdminId, Function.identity()));
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public Map<Long, String> getAllTaxAdminSubjectTaxNo(Long subjectId, boolean active) {
        return taxAdminRepository.getAllTaxAdminSubject(active).stream()
                .filter(taxAdminSubjectMetaDO -> subjectId.equals(taxAdminSubjectMetaDO.getSubjectId()))
                .collect(Collectors.toMap(TaxAdminSubjectMetaDO::getTaxAdminId, TaxAdminSubjectMetaDO::getTaxNo));
    }
}
