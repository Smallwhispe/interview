package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleCaseDataMetaDO;

import java.util.List;

public interface TaxRuleCaseDataRepository {
    void save(TaxRuleCaseDataMetaDO metaDO);

    void updateByIdSelective(TaxRuleCaseDataMetaDO metaDO);

    List<TaxRuleCaseDataMetaDO> queryAll();
}
