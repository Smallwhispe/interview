package com.bytedance.cg.oversea.bytetax.dal.mapping;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/08/17 4:46 PM
 */

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoFormatRuleType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxValidateRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxValidateRulePO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(builder = @Builder(disableBuilder = true),
        imports = {EnumTaxNoFormatRuleType.class, EnumDeleteStatus.class, EnumUtils.class})
public interface TaxValidateRuleMapping {

    TaxValidateRuleMapping MAPPING = Mappers.getMapper(TaxValidateRuleMapping.class);

    @Mapping(target = "ruleType", expression = "java(EnumUtils.getCode(metaDO.getRuleType()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    TaxValidateRulePO toPO(TaxValidateRuleMetaDO metaDO);

    @Mapping(target = "ruleType", expression = "java(EnumUtils.getEnumByCode(EnumTaxNoFormatRuleType.values(), po.getRuleType()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    TaxValidateRuleMetaDO toMetaDO(TaxValidateRulePO po);

    List<TaxValidateRuleMetaDO> toMetaDOList(List<TaxValidateRulePO> po);
}
