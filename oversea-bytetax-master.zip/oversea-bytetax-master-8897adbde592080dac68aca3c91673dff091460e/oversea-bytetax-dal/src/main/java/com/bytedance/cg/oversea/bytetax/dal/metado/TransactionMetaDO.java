package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author hanyuxiao
 * @date 2022/1/13
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionMetaDO {
    /**
     *
     */
    private Long id;

    /**
     * 发票编号
     */
    private String invoiceNo;


    /**
     * 税务局Id
     */
    private Long taxAdminId;

    /**
     * 税务局注册Id
     */
    private Long taxAdminBindId;

    /**
     * 交易类型
     */
    private EnumTransactionType transactionType;

    /**
     * 交易类型
     */
    private EnumTransactionCategory transactionCategory;

    /**
     * 命中规则信息
     */
    private List<Long> ruleIds;

    /**
     * 国家主体绑定表id
     */
    private Long taxCountryId;

    /**
     * 总税基
     */
    private BigDecimal totalTaxable;

    /**
     * 总税额
     */
    private BigDecimal totalTax;

    /**
     * 总税基（报税币种）
     */
    private BigDecimal totalTaxationTaxable;

    /**
     * 总税额（报税币种）
     */
    private BigDecimal totalTaxationTax;

    /**
     * 用户id
     */
    private Long accountId;

    /**
     * 用户名字
     */
    private String accountName;

    /**
     * 用户税号
     */
    private String accountTaxNo;

    /**
     * 用户地址
     */
    private AddressMetaDO billingAddress;

    /**
     * 交易币种
     */
    private String currencyCode;

    /**
     * 报税币种
     */
    private String taxationCurrencyCode;

    /**
     * 交易币种 到税务局所需币种的汇率
     */
    private BigDecimal exchangeRate;

    /**
     * 开票时间
     */
    private Date invoiceDate;

    /**
     * 折扣
     */
    private BigDecimal discount;

    /**
     * 扩展
     */
    private Map<String, String> extend;

    /**
     * 备注
     */
    private String remark;

    /**
     * 版本
     */
    private Integer version;

    /**
     *
     */
    private Date createTime;

    /**
     *
     */
    private Date modifyTime;

    /**
     *
     */
    private EnumDeleteStatus isDelete;
    /**
     * 税费计算方式
     */
    private EnumTaxCalculateType taxCalculateType;

    /**
     * 交易时间
     */
    private Date transactionTime;

    /**
     * 是否参与保税
     */
    private EnumTaxReporterType taxReporterType;

    /**
     * 业务线ID
     */
    private Long taxBizId;

    /**
     * 自定义税率
     */
    private List<TaxRateMetaDO> customTax;

    /**
     * 主体ID
     */
    private Long subjectId;

    /**
     * 交易额外信息
     */
    private TransactionInfoExtend transactionInfoExtend;

    public List<Long> getAllTaxAdminIds() {
        List<Long> taxAdminIds = getOrGenTransactionInfoExtend().getOrGenTaxAdminInfo().stream()
                .map(TransactionInfoExtend.TaxAdminInfo::getTaxAdminId).collect(Collectors.toList());
        taxAdminIds.add(taxAdminId);
        return taxAdminIds.stream().filter(Objects::nonNull).distinct().collect(Collectors.toList());
    }

    public List<Long> getAllTaxAdminBindIds() {
        List<Long> taxAdminBindIds = getOrGenTransactionInfoExtend().getOrGenTaxAdminInfo().stream()
                .map(TransactionInfoExtend.TaxAdminInfo::getTaxAdminBindId).collect(Collectors.toList());
        taxAdminBindIds.add(taxAdminBindId);
        return taxAdminBindIds.stream().filter(Objects::nonNull).distinct().collect(Collectors.toList());
    }

    public TransactionInfoExtend getOrGenTransactionInfoExtend() {
        if (transactionInfoExtend == null) {
            transactionInfoExtend = new TransactionInfoExtend();
        }
        return transactionInfoExtend;
    }
}
