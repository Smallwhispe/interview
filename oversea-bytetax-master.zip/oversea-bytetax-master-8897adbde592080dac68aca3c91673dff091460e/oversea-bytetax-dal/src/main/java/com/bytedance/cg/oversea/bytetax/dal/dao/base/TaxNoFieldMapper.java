package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoFieldPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoFieldExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxNoFieldMapper {
    int insert(TaxNoFieldPO record);

    int insertSelective(TaxNoFieldPO record);

    List<TaxNoFieldPO> selectByExample(TaxNoFieldExample example);

    TaxNoFieldPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxNoFieldPO record);

    int updateByPrimaryKey(TaxNoFieldPO record);
}