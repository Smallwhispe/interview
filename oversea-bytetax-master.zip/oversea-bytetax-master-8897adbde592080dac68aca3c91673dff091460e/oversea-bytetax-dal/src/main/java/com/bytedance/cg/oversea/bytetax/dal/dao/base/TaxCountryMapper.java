package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxCountryMapper {
    int insert(TaxCountryPO record);

    int insertSelective(TaxCountryPO record);

    List<TaxCountryPO> selectByExampleWithBLOBs(TaxCountryPOExample example);

    List<TaxCountryPO> selectByExample(TaxCountryPOExample example);

    TaxCountryPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxCountryPO record);

    int updateByPrimaryKeyWithBLOBs(TaxCountryPO record);

    int updateByPrimaryKey(TaxCountryPO record);
}