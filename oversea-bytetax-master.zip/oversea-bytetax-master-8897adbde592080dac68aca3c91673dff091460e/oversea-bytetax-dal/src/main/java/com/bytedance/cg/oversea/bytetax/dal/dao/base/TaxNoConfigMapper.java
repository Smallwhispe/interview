package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoConfigPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoConfigExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxNoConfigMapper {
    int insert(TaxNoConfigPO record);

    int insertSelective(TaxNoConfigPO record);

    List<TaxNoConfigPO> selectByExample(TaxNoConfigExample example);

    TaxNoConfigPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxNoConfigPO record);

    int updateByPrimaryKey(TaxNoConfigPO record);
}