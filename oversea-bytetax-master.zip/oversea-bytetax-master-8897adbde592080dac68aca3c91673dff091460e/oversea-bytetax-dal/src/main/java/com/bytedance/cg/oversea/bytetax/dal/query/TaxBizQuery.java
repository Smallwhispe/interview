package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxBizQuery {
    /**
     * 业务线id
     */
    private Long id;

    /**
     * 业务线名称（精确）
     */
    private String exactName;

    /**
     * 业务线名称（模糊）
     */
    private String fuzzyName;

    /**
     * 业务线描述（模糊）
     */
    private String description;

    /**
     * 每页数量
     */
    private Integer pageSize;

    /**
     * 页码
     */
    private Integer pageNumber;
}
