package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTransactionType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Objects;

/**
 * @author hanyuxiao
 * @date 2022/3/14
 **/
@Mapper(builder = @Builder(disableBuilder = true),
        imports = {Objects.class, EnumUtils.class, EnumDeleteStatus.class, JsonUtil.class, TaxAdminSubjectMapping.class, EnumTaxTransactionType.class})
public interface TaxAdminSubjectMapping {

    TaxAdminSubjectMapping MAPPING = Mappers.getMapper(TaxAdminSubjectMapping.class);

    @Mapping(target = "isDelete", expression = "java(Objects.nonNull(metaDO.getIsDelete()) ? EnumUtils.getCode(metaDO.getIsDelete()) : null)")
    @Mapping(target = "taxTransactionType", expression = "java(EnumUtils.getCode(metaDO.getTaxTransactionType()))")
    TaxAdminSubjectPO toPO(TaxAdminSubjectMetaDO metaDO);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "taxTransactionType", expression = "java(EnumUtils.getEnumByCode(EnumTaxTransactionType.values(), po.getTaxTransactionType()))")
    TaxAdminSubjectMetaDO toMetaDO(TaxAdminSubjectPO po);

    List<TaxAdminSubjectMetaDO> toMetaDOList(List<TaxAdminSubjectPO> pos);


}
