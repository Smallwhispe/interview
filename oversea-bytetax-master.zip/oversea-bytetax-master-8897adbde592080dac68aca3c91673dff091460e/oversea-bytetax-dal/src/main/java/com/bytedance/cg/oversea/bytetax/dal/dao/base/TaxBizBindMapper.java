package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface TaxBizBindMapper {
    int insert(TaxBizBindPO record);

    int insertSelective(TaxBizBindPO record);

    List<TaxBizBindPO> selectByExample(TaxBizBindPOExample example);

    TaxBizBindPO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") TaxBizBindPO record, @Param("example") TaxBizBindPOExample example);

    int updateByExample(@Param("record") TaxBizBindPO record, @Param("example") TaxBizBindPOExample example);

    int updateByPrimaryKeySelective(TaxBizBindPO record);

    int updateByPrimaryKey(TaxBizBindPO record);
}