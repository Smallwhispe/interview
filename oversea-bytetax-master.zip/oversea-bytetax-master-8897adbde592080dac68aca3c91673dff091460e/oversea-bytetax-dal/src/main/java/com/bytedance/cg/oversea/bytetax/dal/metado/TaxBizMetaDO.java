package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.Data;

import java.util.Date;

@Data
public class TaxBizMetaDO {
    /**
     * 
     */
    private Long id;

    /**
     * 业务线名称
     */
    private String name;

    /**
     * 业务线描述
     */
    private String description;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;
}