package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.CasesMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.CasesPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(builder = @Builder(disableBuilder = true),
        imports = {com.fasterxml.jackson.core.type.TypeReference.class,
                Long.class, JsonUtil.class, EnumDeleteStatus.class, EnumUtils.class})
public interface CasesMapping {

    CasesMapping MAPPING = Mappers.getMapper(CasesMapping.class);


    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    @Mapping(target = "value", expression = "java(JsonUtil.readValue(po.getValue(), " +
            "new TypeReference<List<Long>>(){}))")
    @Mapping(target = "key", source = "caseKey")
    CasesMetaDO toMetaDO(CasesPO po);

    List<CasesMetaDO> toMetaDOList(List<CasesPO> po);

    @Mapping(target = "isDelete", expression = "java(EnumUtils.getCode(metaDO.getIsDelete()))")
    @Mapping(target = "value", expression = "java(JsonUtil.writeValueAsString(metaDO.getValue()))")
    @Mapping(target = "caseKey", source = "key")
    CasesPO toPO(CasesMetaDO metaDO);
}
