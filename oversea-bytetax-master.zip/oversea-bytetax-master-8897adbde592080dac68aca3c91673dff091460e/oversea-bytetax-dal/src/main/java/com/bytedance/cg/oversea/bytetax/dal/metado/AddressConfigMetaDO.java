package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumCollectConfig;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddressConfigMetaDO {


    /**
     * 是否需要搜集一级地址（不需要、可选、必须）
     */
    private EnumCollectConfig addressLevel1;

    /**
     * 是否需要搜集二级地址（不需要、可选、必须）
     */
    private EnumCollectConfig addressLevel2;

    /**
     * 是否需要搜集三级地址（不需要、可选、必须）
     */
    private EnumCollectConfig addressLevel3;

    /**
     * 是否需要搜集邮编
     */
    private EnumCollectConfig zipcode;

    /**
     * 是否需要搜集详细地址
     */
    private EnumCollectConfig billingAddress;
}
