package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxInfoType;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.dal.metado.*;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoConfigPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoFieldPO;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2023/8/22
 **/
@Mapper(imports = {EnumDeleteStatus.class, EnumTaxInfoType.class, EnumUtils.class})
public interface TaxNoFieldMapping {

    TaxNoFieldMapping MAPPING = Mappers.getMapper(TaxNoFieldMapping.class);
    @Mapping(target = "type", expression = "java(EnumUtils.getEnumByCode(EnumTaxInfoType.values(), po.getType()))")
    @Mapping(target = "isDelete", expression = "java(EnumUtils.getEnumByCode(EnumDeleteStatus.values(), po.getIsDelete()))")
    TaxNoFieldMetaDO toMetaDO(TaxNoFieldPO po);

    List<TaxNoFieldMetaDO> toMetaDOList(List<TaxNoFieldPO> po);



}
