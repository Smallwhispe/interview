package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumApproveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumHead;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.*;
import com.bytedance.cg.oversea.bytetax.dal.mapping.*;
import com.bytedance.cg.oversea.bytetax.dal.metado.*;
import com.bytedance.cg.oversea.bytetax.dal.po.*;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxComplexRepository;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @Auther yangyl
 * @Date 2021/11/29
 **/
@Repository
@Slf4j
public class TaxBizComplexRepositoryImpl implements TaxComplexRepository {

    @Resource
    private TaxCountryBindMapper taxCountryBindMapper;

    @Resource
    private TaxBizBindMapper taxBizBindMapper;

    @Resource
    private TaxBizMapper taxBizMapper;

    @Resource
    private TaxRuleMapper taxRuleMapper;

    @Resource
    private TaxCategoryMapper taxCategoryMapper;

    @Resource
    private TaxItemMapper taxItemMapper;

    @Resource
    private TaxAdminRepository taxAdminRepository;

    @Autowired
    @Lazy
    private TaxBizComplexRepositoryImpl taxBizComplexRepository;

    private volatile TaxBizContextMetaDO taxBizContextMetaDO = null;

    @Override
    public TaxBizBindMetaDO queryTaxBiz(Long subjectId, Long countryGeoId, Long bizId) {
        if (subjectId == null || countryGeoId == null || bizId == null) {
            return null;
        }
        TaxCountryBindPOExample taxCountryBindPOExample = new TaxCountryBindPOExample();
        taxCountryBindPOExample.createCriteria().andSubjectIdEqualTo(subjectId).andCountryGeoIdEqualTo(countryGeoId).andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());

        List<TaxCountryBindPO> taxCountryBindPOS = taxCountryBindMapper.selectByExample(taxCountryBindPOExample);
        if (CollectionUtils.isNotEmpty(taxCountryBindPOS)) {
            TaxCountryBindPO countryBind = taxCountryBindPOS.get(ConstantValue.ZERO);
            TaxBizBindPOExample taxBizBindPOExample = new TaxBizBindPOExample();
            taxBizBindPOExample.createCriteria().andBizIdEqualTo(bizId).andCountryBindIdEqualTo(countryBind.getId()).andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
            List<TaxBizBindPO> taxBizBindPOS = taxBizBindMapper.selectByExample(taxBizBindPOExample);
            return CollectionUtils.isEmpty(taxBizBindPOS) ? null : TaxBizBindMapping.MAPPING.toMetaDO(taxBizBindPOS.get(ConstantValue.ZERO));
        }
        return null;
    }

    @Override
    public TaxBizContextMetaDO queryAllBizTaxContext() {
        if (taxBizContextMetaDO == null) {
            throw new BizException("data error");
        }
        return taxBizContextMetaDO;
    }

    @Override
    public List<BaseRuleMetaDO> queryBizTaxContextByIds(List<Long> ruleIds) {
       return taxBizComplexRepository.queryAllBizTaxContext().getBaseRuleMetaDOS().stream()
                .filter(rule -> ruleIds.contains(rule.getTaxRuleMetaDO().getId()))
                .collect(Collectors.toList());
    }

    @Override
    public TaxContextMetaDO queryAllNoBizTaxContext(){
        List<BaseRuleMetaDO> baseRuleMetaDOS = queryTaxRuleContext();
        return TaxContextMetaDO.builder().baseRuleMetaDOS(baseRuleMetaDOS).build();
    }

    public List<BaseRuleMetaDO> queryTaxRuleContext() {
        TaxRulePOExample taxRulePOExample = new TaxRulePOExample();
        taxRulePOExample.createCriteria().andHeadEqualTo(EnumHead.HEAD_FIRST.getCode()).andApproveStatusEqualTo(EnumApproveStatus.APPROVED.getCode()).andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxRulePO> taxRulePOS = taxRuleMapper.selectByExample(taxRulePOExample);
        Map<Long, TaxAdminMetaDO> taxAdminMap = taxAdminRepository.getAllTaxAdmin(true).stream().collect(Collectors.toMap(TaxAdminMetaDO::getId, Function.identity()));
        TaxCategoryPOExample taxCategoryPOExample = new TaxCategoryPOExample();
        taxCategoryPOExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxCategoryPO> taxCategoryPOS = taxCategoryMapper.selectByExample(taxCategoryPOExample);
        Map<Long, TaxCategoryPO> taxCategoryPOMap = Optional.ofNullable(taxCategoryPOS).orElse(Collections.emptyList()).stream().collect(Collectors.toMap(TaxCategoryPO::getId, Function.identity()));
        TaxItemPOExample taxItemPOExample = new TaxItemPOExample();
        taxItemPOExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxItemPO> taxItemPOS = taxItemMapper.selectByExample(taxItemPOExample);
        Map<Long, TaxItemPO> taxItemPOMap = Optional.ofNullable(taxItemPOS).orElse(Collections.emptyList()).stream().collect(Collectors.toMap(TaxItemPO::getId, Function.identity()));
        TaxCategoryPO defaultFailCategory = new TaxCategoryPO();
        defaultFailCategory.setTaxAdminId(-1L);
        if (CollectionUtils.isNotEmpty(taxRulePOS)) {
            return taxRulePOS.stream().map(e -> {
                BaseRuleMetaDO baseRuleMetaDO = new BaseRuleMetaDO();
                baseRuleMetaDO.setTaxRuleMetaDO(TaxRuleMapping.MAPPING.toMetaDO(e));
                baseRuleMetaDO.setTaxCategoryMetaDO(TaxCategoryMapping.MAPPING.toMetaDO(taxCategoryPOMap.getOrDefault(e.getTaxCategoryId(), defaultFailCategory)));
                baseRuleMetaDO.setTaxAdminMetaDO(taxAdminMap.get(taxCategoryPOMap.getOrDefault(e.getTaxCategoryId(), new TaxCategoryPO()).getTaxAdminId()));
                baseRuleMetaDO.setTaxItemMetaDO(TaxItemMapping.MAPPING.toMetaDO(taxItemPOMap.get(e.getItemId())));
                return baseRuleMetaDO;
            }).collect(Collectors.toList());
        }
        return null;
    }

    public List<BizTaxRuleMetaDO> queryBizContext() {
        TaxBizBindPOExample taxBizBindPOExample = new TaxBizBindPOExample();
        taxBizBindPOExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxBizBindPO> taxBizBindPOS = taxBizBindMapper.selectByExample(taxBizBindPOExample);

        Map<Long, List<TaxAdminSubjectMetaDO>> taxAdminBySubjectId = taxAdminRepository.getAllTaxAdminSubject(true)
                .stream().collect(Collectors.groupingBy(TaxAdminSubjectMetaDO::getSubjectId));

        TaxBizPOExample taxBizPOExample = new TaxBizPOExample();
        taxBizPOExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxBizPO> taxBizPOS = taxBizMapper.selectByExample(taxBizPOExample);
        Map<Long, TaxBizPO> taxBizPOMap = Optional.ofNullable(taxBizPOS).orElse(Collections.emptyList()).stream().collect(Collectors.toMap(TaxBizPO::getId, Function.identity()));

        TaxCountryBindPOExample taxCountryBindPOExample = new TaxCountryBindPOExample();
        taxCountryBindPOExample.createCriteria().andIsDeleteEqualTo(EnumDeleteStatus.ACTIVE.getCode());
        List<TaxCountryBindPO> taxCountryBindPOS = taxCountryBindMapper.selectByExample(taxCountryBindPOExample);
        Map<Long, TaxCountryBindPO> taxCountryBindPOMap = Optional.ofNullable(taxCountryBindPOS).orElse(Collections.emptyList()).stream().collect(Collectors.toMap(TaxCountryBindPO::getId, Function.identity()));
        TaxCountryBindPO defaultFailCountryBind = new TaxCountryBindPO();
        defaultFailCountryBind.setSubjectId(-1L);
        defaultFailCountryBind.setCountryGeoId(-1L);
        TaxBizPO defaultFailBiz = new TaxBizPO();
        defaultFailBiz.setId(-1L);
        if (CollectionUtils.isNotEmpty(taxBizBindPOS)) {
            return taxBizBindPOS.stream().map(e -> {
                BizTaxRuleMetaDO bizTaxRuleMetaDO = new BizTaxRuleMetaDO();
                bizTaxRuleMetaDO.setTaxBizBindMetaDO(TaxBizBindMapping.MAPPING.toMetaDO(e));
                bizTaxRuleMetaDO.setTaxBizMetaDO(TaxBizMapping.MAPPING.toMetaDO(taxBizPOMap.getOrDefault(e.getBizId(), defaultFailBiz)));
                TaxCountryBindPO taxCountryBindPO = taxCountryBindPOMap.getOrDefault(e.getCountryBindId(), defaultFailCountryBind);
                bizTaxRuleMetaDO.setTaxCountryBindMetaDO(TaxCountryBindMapping.MAPPING.toMetaDO(taxCountryBindPO));
                if (taxCountryBindPO != null) {
                    bizTaxRuleMetaDO.setTaxAdminSubjectMetaDO(taxAdminBySubjectId.getOrDefault(taxCountryBindPO.getSubjectId(), Lists.newArrayList()));
                }
                return bizTaxRuleMetaDO;
            }).collect(Collectors.toList());
        }

        return null;
    }

    @PostConstruct
    public void init() {
        log.info("首次初始化TaxBizContextMetaDO");
        refresh();
    }

    @Scheduled(fixedRate = 5 * 60 * 1000)
    public void refreshSchedule() {
        log.info("定时初始化TaxBizContextMetaDO");
        refresh();
    }

    private void refresh() {
        List<BizTaxRuleMetaDO> bizTaxRuleMetaDOS = queryBizContext();
        List<BaseRuleMetaDO> baseRuleMetaDOS = queryTaxRuleContext();
        taxBizContextMetaDO = TaxBizContextMetaDO.builder().baseRuleMetaDOS(baseRuleMetaDOS).bizTaxRuleMetaDOS(bizTaxRuleMetaDOS).build();
    }
}
