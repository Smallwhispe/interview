package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxSubjectCompanyCodeBindPO {
    /**
     * 主键
     */
    private Long id;

    /**
     * 主体id
     */
    private Long subjectId;

    /**
     * 企业code
     */
    private String companyCode;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 是否删除
     */
    private Integer isDelete;

    /**
     * 业务线id
     */
    private Long bizLineId;
}