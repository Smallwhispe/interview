package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaxAdminMapper {
    int insert(TaxAdminPO record);

    int insertSelective(TaxAdminPO record);

    List<TaxAdminPO> selectByExample(TaxAdminPOExample example);

    TaxAdminPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(TaxAdminPO record);

    int updateByPrimaryKey(TaxAdminPO record);
}