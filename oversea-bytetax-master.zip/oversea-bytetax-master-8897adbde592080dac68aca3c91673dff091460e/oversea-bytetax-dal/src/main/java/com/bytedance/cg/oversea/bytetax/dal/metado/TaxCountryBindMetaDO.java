package com.bytedance.cg.oversea.bytetax.dal.metado;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TaxCountryBindMetaDO {
    /**
     * 
     */
    private Long id;

    /**
     * 主体id
     */
    private Long subjectId;

    /**
     * 税号
     */
    private String taxNo;

    /**
     * 创建人
     */
    private Long operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private EnumDeleteStatus isDelete;

    /**
     * 税号所在国家
     */
    private Long taxNoCountry;

    /**
     * taxAdminId
     */
    private Long taxAdminId;

    /**
     * 地理信息
     */
    private AddressMetaDO address;
}