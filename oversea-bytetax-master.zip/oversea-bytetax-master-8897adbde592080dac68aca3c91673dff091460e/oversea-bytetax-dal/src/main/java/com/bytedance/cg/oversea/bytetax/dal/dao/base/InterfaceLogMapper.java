package com.bytedance.cg.oversea.bytetax.dal.dao.base;

import com.bytedance.cg.oversea.bytetax.dal.po.InterfaceLogPO;
import com.bytedance.cg.oversea.bytetax.dal.po.InterfaceLogPOExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface InterfaceLogMapper {
    int insert(InterfaceLogPO record);

    int insertSelective(InterfaceLogPO record);

    List<InterfaceLogPO> selectByExample(InterfaceLogPOExample example);

    InterfaceLogPO selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(InterfaceLogPO record);

    int updateByPrimaryKey(InterfaceLogPO record);
}