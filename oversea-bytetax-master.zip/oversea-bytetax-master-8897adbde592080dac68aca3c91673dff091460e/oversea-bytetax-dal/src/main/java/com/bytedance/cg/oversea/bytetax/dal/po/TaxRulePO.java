package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class TaxRulePO {
    /**
     * 
     */
    private Long id;

    /**
     * 资金from
     */
    private String billFrom;

    /**
     * 资金to
     */
    private String billTo;

    /**
     * 物流from
     */
    private String shipFrom;

    /**
     * 物流to
     */
    private String shipTo;

    /**
     * from是否有税号
     */
    private Integer fromWithTaxNo;

    /**
     * billFrom税号所在国家
     */
    private Long fromVatCountry;

    /**
     * to是否有税号
     */
    private Integer toWithTaxNo;

    /**
     * billTo税号所在国家
     */
    private Long toTaxNoCountry;

    /**
     * 税种id
     */
    private Long taxCategoryId;

    /**
     * 税务局id
     */
    private Long taxAdminId;

    /**
     * taxTag标记
     */
    private String taxTag;

    /**
     * 0: 否 1: 是
     */
    private Integer isReverseCharge;

    /**
     * 备注
     */
    private String remark;

    /**
     * 版本
     */
    private Integer version;

    /**
     * 是否最新版本
     */
    private Integer head;

    /**
     * 审批状态
     */
    private Integer approveStatus;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 我方主体
     */
    private Long itemId;

    /**
     * 描述
     */
    private String description;

    /**
     * 交易类型（仅记录）
     */
    private Integer transactionType;

    /**
     * 额外字段
     */
    private String extend;
}