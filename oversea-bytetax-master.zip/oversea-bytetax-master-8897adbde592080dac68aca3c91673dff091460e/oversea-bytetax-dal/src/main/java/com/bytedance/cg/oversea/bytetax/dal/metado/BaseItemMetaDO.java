package com.bytedance.cg.oversea.bytetax.dal.metado;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 这儿不放税种信息，因为税种信息放在了规则上下文中;
 * 规则配置税种，但税种不一定会绑定商品，所以取绑定表中记录对于税种会不全。
 * @author hanyuxiao
 * @date 2021/11/26
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BaseItemMetaDO {

    /**
     * 税种绑定
     */
    private TaxCategoryBindMetaDO taxCategoryBindMetaDO;

    /**
     * 商品信息
     */
    private TaxItemMetaDO taxItemMetaDO;

}
