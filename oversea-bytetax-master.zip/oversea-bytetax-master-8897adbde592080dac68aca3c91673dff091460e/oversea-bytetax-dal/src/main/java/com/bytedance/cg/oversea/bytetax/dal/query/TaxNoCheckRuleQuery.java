package com.bytedance.cg.oversea.bytetax.dal.query;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxNoCheckRuleQuery {

    private Long id;

    private Long countryGeoId;

    private String taxInfoFields;

    private Integer isActive;

    private Integer pageSize;

    private Integer pageNumber;
}
