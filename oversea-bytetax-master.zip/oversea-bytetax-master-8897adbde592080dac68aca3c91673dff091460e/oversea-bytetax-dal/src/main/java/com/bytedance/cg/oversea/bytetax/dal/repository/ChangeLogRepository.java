package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.metado.ChangeLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.query.ChangeLogQuery;

import java.util.List;

public interface ChangeLogRepository {

    void save(Long entityId, Integer entityType, String originalPo, String updatedPo, Integer operatorId, Integer changeType);

    PageResult<ChangeLogMetaDO> queryChangeLogList(ChangeLogQuery changeLogQuery);
}
