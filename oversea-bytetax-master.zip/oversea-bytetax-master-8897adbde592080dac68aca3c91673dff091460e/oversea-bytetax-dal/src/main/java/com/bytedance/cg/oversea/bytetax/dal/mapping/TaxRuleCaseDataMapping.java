package com.bytedance.cg.oversea.bytetax.dal.mapping;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleCaseDataMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRuleCaseDataPO;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Date;

@Mapper(builder = @Builder(disableBuilder = true),
        imports = {Date.class})
public interface TaxRuleCaseDataMapping {

    TaxRuleCaseDataMapping MAPPING = Mappers.getMapper(TaxRuleCaseDataMapping.class);

    TaxRuleCaseDataMetaDO toMetaDO(TaxRuleCaseDataPO PO);

    @Mapping(target = "createTime", expression = "java(new Date())")
    @Mapping(target = "modifyTime", expression = "java(new Date())")
    @Mapping(target = "isDelete", expression = "java(new Integer(\"0\"))")
    TaxRuleCaseDataPO toPO(TaxRuleCaseDataMetaDO metaDO);
}
