package com.bytedance.cg.oversea.bytetax.dal.repository;

import com.bytedance.cg.oversea.bytetax.dal.metado.TaxSubjectCompanyCodeBindMetaDO;

public interface TaxSubjectCompanyCodeBindRepository {

    TaxSubjectCompanyCodeBindMetaDO queryBySubjectId(Long subjectId, Long businessLineId);

}
