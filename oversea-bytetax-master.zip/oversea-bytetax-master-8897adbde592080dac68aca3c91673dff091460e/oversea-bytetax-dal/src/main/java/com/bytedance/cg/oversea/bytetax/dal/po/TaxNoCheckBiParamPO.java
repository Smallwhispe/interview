package com.bytedance.cg.oversea.bytetax.dal.po;

import lombok.Data;

import java.util.Date;

@Data
public class TaxNoCheckBiParamPO {
    /**
     * id
     */
    private Long id;

    /**
     * 国家二字iso码
     */
    private String countryIso;

    /**
     * 税务身份，对应枚举类EnumTaxIdentity
     */
    private Integer taxIdentity;

    /**
     * 入参列表，字符串列表的JSON字符串
     */
    private String paramList;

    /**
     * 创建人
     */
    private Integer operatorId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 修改时间
     */
    private Date modifyTime;

    /**
     * 逻辑删除标志
     */
    private Integer isDelete;
}