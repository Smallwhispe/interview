package com.bytedance.cg.oversea.bytetax.dal.po;

import java.util.Date;
import lombok.Data;

@Data
public class AsyncTaskPO {
    /**
     * 主键id
     */
    private Long id;

    /**
     * 任务类型
     */
    private Integer type;

    /**
     * 任务状态 1-初始化 2-计算中 3-成功 4-失败
     */
    private Integer status;

    /**
     * 任务参数
     */
    private String args;

    /**
     * 执行结果
     */
    private String result;

    /**
     * 任务完成时间
     */
    private Date doneTime;

    /**
     * 创建人id
     */
    private Long creatorId;

    /**
     * 逻辑删除标志 0-未删除 1-删除
     */
    private Integer isDelete;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 更新时间
     */
    private Date updateTime;
}