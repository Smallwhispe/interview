package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxType;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoCheckRuleMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckRulePOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckRuleQuery;
import java.util.Collections;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxNoCheckRuleRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckRuleRepositoryImplQueryTaxNoCheckRuleListTest {

    @Mock private TaxNoCheckRuleMapper mockTaxNoCheckRuleMapper;

    @InjectMocks private TaxNoCheckRuleRepositoryImpl repository;

    @Test
    public void testQueryTaxNoCheckRuleList_MapperReturnsNoItems() {
      when(mockTaxNoCheckRuleMapper.selectByExample(any(TaxNoCheckRulePOExample.class)))
          .thenReturn(Collections.emptyList());
      TaxNoCheckRuleQuery query = new TaxNoCheckRuleQuery();

      PageResult<TaxNoCheckRuleMetaDO> result = repository.queryTaxNoCheckRuleList(query);

      assertEquals(Collections.emptyList(), result.getData());
      verify(mockTaxNoCheckRuleMapper).selectByExample(any(TaxNoCheckRulePOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckRuleRepositoryImplSaveTest {

    @Mock private TaxNoCheckRuleMapper mockTaxNoCheckRuleMapper;

    @InjectMocks private TaxNoCheckRuleRepositoryImpl taxNoCheckRuleRepositoryImplUnderTest;

    @Test(expected = NullPointerException.class)
    public void testSave_RequestContextIsNull_ThrowsNPE() {
      TaxNoCheckRuleMetaDO metaDO =
          TaxNoCheckRuleMetaDO.builder().countryGeoId(100L).taxInfoFields(EnumTaxType.VAT).build();

      taxNoCheckRuleRepositoryImplUnderTest.save(metaDO);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckRuleRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxNoCheckRuleMapper mockTaxNoCheckRuleMapper;

    @InjectMocks private TaxNoCheckRuleRepositoryImpl taxNoCheckRuleRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective_NullEmployeeIdThrowsNPE() {
      final TaxNoCheckRuleMetaDO metaDO = new TaxNoCheckRuleMetaDO();
      metaDO.setId(1L);
      metaDO.setCountryGeoId(2L);
      metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      metaDO.setIsActive(EnumActiveStatus.ACTIVE);

      try {
        taxNoCheckRuleRepositoryImplUnderTest.updateByIdSelective(metaDO);
        fail("Expected NullPointerException");
      } catch (NullPointerException e) {
        // expected
      }

      verify(mockTaxNoCheckRuleMapper, never()).updateByPrimaryKeySelective(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckRuleRepositoryImplGetTaxNoCheckRuleByIdTest {

    @Mock private TaxNoCheckRuleMapper mockTaxNoCheckRuleMapper;

    @InjectMocks private TaxNoCheckRuleRepositoryImpl taxNoCheckRuleRepositoryImplUnderTest;

    @Test
    public void testGetTaxNoCheckRuleById_NullId() {
      final TaxNoCheckRuleMetaDO result =
          taxNoCheckRuleRepositoryImplUnderTest.getTaxNoCheckRuleById(null);
      assertNull(result);
      verify(mockTaxNoCheckRuleMapper, never()).selectByPrimaryKey(anyLong());
    }

    @Test
    public void testGetTaxNoCheckRuleById_Found() {
      final TaxNoCheckRulePO po = new TaxNoCheckRulePO();
      po.setId(1L);
      po.setIsActive(EnumActiveStatus.ACTIVE.getCode());
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setFormatRules("[0]");
      po.setApiRules("[0]");
      po.setTaxInfoFields("");
      when(mockTaxNoCheckRuleMapper.selectByPrimaryKey(1L)).thenReturn(po);

      final TaxNoCheckRuleMetaDO result =
          taxNoCheckRuleRepositoryImplUnderTest.getTaxNoCheckRuleById(1L);

      assertEquals(1L, result.getId().longValue());
      assertEquals(EnumActiveStatus.ACTIVE, result.getIsActive());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
      verify(mockTaxNoCheckRuleMapper).selectByPrimaryKey(1L);
    }

    @Test
    public void testGetTaxNoCheckRuleById_NotFound() {
      when(mockTaxNoCheckRuleMapper.selectByPrimaryKey(2L)).thenReturn(null);

      final TaxNoCheckRuleMetaDO result =
          taxNoCheckRuleRepositoryImplUnderTest.getTaxNoCheckRuleById(2L);

      assertNull(result);
      verify(mockTaxNoCheckRuleMapper).selectByPrimaryKey(2L);
    }
  }
}
