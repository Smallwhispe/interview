package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxRuleCaseDataMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleCaseDataMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRuleCaseDataPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRuleCaseDataPOExample;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxRuleCaseDataRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleCaseDataRepositoryImplQueryAllTest {

    @Mock private TaxRuleCaseDataMapper mockTaxRuleCaseDataMapper;

    @InjectMocks private TaxRuleCaseDataRepositoryImpl taxRuleCaseDataRepositoryImplUnderTest;

    @Test
    public void testQueryAll() {
      // Setup
      TaxRuleCaseDataPO po1 = new TaxRuleCaseDataPO();
      po1.setId(1L);
      po1.setParam("p1");
      po1.setResult("r1");
      po1.setTransactionType("type1");
      po1.setTransactionMethod("method1");
      po1.setCountry("US");
      po1.setTaxRuleId(101L);

      TaxRuleCaseDataPO po2 = new TaxRuleCaseDataPO();
      po2.setId(2L);
      po2.setParam("p2");
      po2.setResult("r2");
      po2.setTransactionType("type2");
      po2.setTransactionMethod("method2");
      po2.setCountry("GB");
      po2.setTaxRuleId(202L);

      when(mockTaxRuleCaseDataMapper.selectByExample(any(TaxRuleCaseDataPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      List<TaxRuleCaseDataMetaDO> result = taxRuleCaseDataRepositoryImplUnderTest.queryAll();

      // Verify the results
      verify(mockTaxRuleCaseDataMapper).selectByExample(any(TaxRuleCaseDataPOExample.class));
      assertEquals(2, result.size());

      TaxRuleCaseDataMetaDO meta1 = result.get(0);
      assertEquals(po1.getId(), meta1.getId());
      assertEquals(po1.getParam(), meta1.getParam());
      assertEquals(po1.getResult(), meta1.getResult());
      assertEquals(po1.getTransactionType(), meta1.getTransactionType());
      assertEquals(po1.getTransactionMethod(), meta1.getTransactionMethod());
      assertEquals(po1.getCountry(), meta1.getCountry());
      assertEquals(po1.getTaxRuleId(), meta1.getTaxRuleId());

      TaxRuleCaseDataMetaDO meta2 = result.get(1);
      assertEquals(po2.getId(), meta2.getId());
      assertEquals(po2.getParam(), meta2.getParam());
      assertEquals(po2.getResult(), meta2.getResult());
      assertEquals(po2.getTransactionType(), meta2.getTransactionType());
      assertEquals(po2.getTransactionMethod(), meta2.getTransactionMethod());
      assertEquals(po2.getCountry(), meta2.getCountry());
      assertEquals(po2.getTaxRuleId(), meta2.getTaxRuleId());
    }

    @Test
    public void testQueryAll_TaxRuleCaseDataMapperReturnsNoItems() {
      // Setup
      when(mockTaxRuleCaseDataMapper.selectByExample(any(TaxRuleCaseDataPOExample.class)))
          .thenReturn(Collections.<TaxRuleCaseDataPO>emptyList());

      // Run the test
      List<TaxRuleCaseDataMetaDO> result = taxRuleCaseDataRepositoryImplUnderTest.queryAll();

      // Verify the results
      verify(mockTaxRuleCaseDataMapper).selectByExample(any(TaxRuleCaseDataPOExample.class));
      assertEquals(0, result.size());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleCaseDataRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxRuleCaseDataMapper mockTaxRuleCaseDataMapper;

    @InjectMocks private TaxRuleCaseDataRepositoryImpl taxRuleCaseDataRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective() {
      when(mockTaxRuleCaseDataMapper.updateByPrimaryKeySelective(any())).thenReturn(0);

      TaxRuleCaseDataMetaDO metaDO = new TaxRuleCaseDataMetaDO();
      metaDO.setId(1L);
      metaDO.setParam("param");
      metaDO.setResult("result");
      metaDO.setTransactionType("transactionType");
      metaDO.setTransactionMethod("transactionMethod");
      metaDO.setCountry("country");
      metaDO.setTaxRuleId(2L);

      taxRuleCaseDataRepositoryImplUnderTest.updateByIdSelective(metaDO);

      ArgumentCaptor<TaxRuleCaseDataPO> captor = ArgumentCaptor.forClass(TaxRuleCaseDataPO.class);
      verify(mockTaxRuleCaseDataMapper).updateByPrimaryKeySelective(captor.capture());

      TaxRuleCaseDataPO sent = captor.getValue();
      assertEquals(metaDO.getId(), sent.getId());
      assertEquals(metaDO.getParam(), sent.getParam());
      assertEquals(metaDO.getResult(), sent.getResult());
      assertEquals(metaDO.getTransactionType(), sent.getTransactionType());
      assertEquals(metaDO.getTransactionMethod(), sent.getTransactionMethod());
      assertEquals(metaDO.getCountry(), sent.getCountry());
      assertEquals(metaDO.getTaxRuleId(), sent.getTaxRuleId());
      assertNotNull(sent.getCreateTime());
      assertNotNull(sent.getModifyTime());
      assertEquals(Integer.valueOf(0), sent.getIsDelete());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleCaseDataRepositoryImplSaveTest {

    @Mock private TaxRuleCaseDataMapper mockTaxRuleCaseDataMapper;

    @InjectMocks private TaxRuleCaseDataRepositoryImpl taxRuleCaseDataRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      final TaxRuleCaseDataMetaDO metaDO = new TaxRuleCaseDataMetaDO();
      metaDO.setId(1L);
      metaDO.setParam("param");
      metaDO.setResult("result");
      metaDO.setTransactionType("transactionType");
      metaDO.setTransactionMethod("transactionMethod");
      metaDO.setCountry("country");
      metaDO.setTaxRuleId(2L);
      when(mockTaxRuleCaseDataMapper.insert(any())).thenReturn(0);

      // Run the test
      taxRuleCaseDataRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      verify(mockTaxRuleCaseDataMapper).insert(any());
    }
  }
}
