package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxItemMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxItemMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxItemQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxItemRepository;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxItemRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemRepositoryImplQueryTaxItemListTest {

    @Mock private TaxItemMapper mockTaxItemMapper;

    @InjectMocks private TaxItemRepositoryImpl taxItemRepositoryImplUnderTest;

    @Test
    public void testQueryTaxItemList_Basic() {
      // Setup
      TaxItemQuery query = new TaxItemQuery();
      TaxItemPO po = new TaxItemPO();
      po.setId(1L);
      po.setName("name1");
      po.setCode("CODE1");
      po.setDescription("desc");
      po.setType(1);
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run
      PageResult<TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.queryTaxItemList(query);

      // Verify
      assertEquals(1L, result.getTotal().longValue());
      List<TaxItemMetaDO> dataList =
          result.getData() instanceof List
              ? (List<TaxItemMetaDO>) result.getData()
              : new ArrayList<TaxItemMetaDO>(result.getData());
      assertEquals(1, dataList.size());
      assertEquals(1L, dataList.get(0).getId().longValue());
      assertEquals("CODE1", dataList.get(0).getCode());
      verify(mockTaxItemMapper).selectByExample(any(TaxItemPOExample.class));
    }

    @Test
    public void testQueryTaxItemList_WithFiltersAndPagination() {
      // Setup
      TaxItemQuery query = new TaxItemQuery();
      query.setName("abc_def%ghi");
      query.setCode("C_%");
      query.setType(3);
      query.setDescription("desc_%");
      query.setPageNumber(1);
      query.setPageSize(10);

      TaxItemPO po = new TaxItemPO();
      po.setId(2L);
      po.setName("name2");
      po.setCode("CODE2");
      po.setDescription("desc2");
      po.setType(3);
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(po));

      ArgumentCaptor<TaxItemPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxItemPOExample.class);

      // Run
      PageResult<TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.queryTaxItemList(query);

      // Verify example settings
      verify(mockTaxItemMapper).selectByExample(exampleCaptor.capture());
      TaxItemPOExample usedExample = exampleCaptor.getValue();
      assertEquals("code desc", usedExample.getOrderByClause());

      // Verify result data
      assertEquals(1L, result.getTotal().longValue());
      List<TaxItemMetaDO> dataList =
          result.getData() instanceof List
              ? (List<TaxItemMetaDO>) result.getData()
              : new ArrayList<TaxItemMetaDO>(result.getData());
      assertEquals(1, dataList.size());
      assertEquals(2L, dataList.get(0).getId().longValue());
      assertEquals("CODE2", dataList.get(0).getCode());
    }

    @Test
    public void testQueryTaxItemList_MapperReturnsNoItems() {
      // Setup
      TaxItemQuery query = new TaxItemQuery();
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Collections.<TaxItemPO>emptyList());

      // Run
      PageResult<TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.queryTaxItemList(query);

      // Verify
      assertEquals(0L, result.getTotal().longValue());
      assertEquals(Collections.<TaxItemMetaDO>emptyList(), result.getData());
      verify(mockTaxItemMapper).selectByExample(any(TaxItemPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemRepositoryImplSaveTest {

    @Mock private TaxItemMapper mockTaxItemMapper;

    @InjectMocks private TaxItemRepositoryImpl taxItemRepositoryImplUnderTest;

    @Test
    public void testSave_success_insertThenUpdateWithGeneratedCode() {
      // Setup
      doAnswer(
              invocation -> {
                Object arg0 = invocation.getArguments()[0];
                if (arg0 instanceof com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO) {
                  com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO po =
                      (com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO) arg0;
                  // Before insert, code should be placeholder
                  assertEquals("to be generated", po.getCode());
                  // simulate DB generated id
                  po.setId(15L);
                }
                return 1;
              })
          .when(mockTaxItemMapper)
          .insert(any());

      // Run the test
      TaxItemMetaDO metaDO = new TaxItemMetaDO();
      metaDO.setName("name");
      taxItemRepositoryImplUnderTest.save(metaDO);

      // Verify insert called
      verify(mockTaxItemMapper, times(1)).insert(any());

      // Capture and verify update call with generated code
      ArgumentCaptor<com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO> updateCaptor =
          ArgumentCaptor.forClass(com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO.class);
      verify(mockTaxItemMapper, times(1)).updateByPrimaryKeySelective(updateCaptor.capture());
      com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO updated = updateCaptor.getValue();
      assertEquals(Long.valueOf(15L), updated.getId());
      assertEquals("000015", updated.getCode());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemRepositoryImplGetTaxItemByIdTest {

    @Mock private TaxItemMapper mockTaxItemMapper;

    @InjectMocks private TaxItemRepositoryImpl taxItemRepositoryImplUnderTest;

    @Test
    public void testGetTaxItemById() {
      // Setup
      final TaxItemPO taxItemPO = new TaxItemPO();
      taxItemPO.setId(1L);
      taxItemPO.setName("name");
      taxItemPO.setCode("code");
      taxItemPO.setDescription("description");
      taxItemPO.setOperatorId(10);
      Date createTime = new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime();
      Date modifyTime = new GregorianCalendar(2020, Calendar.JANUARY, 2).getTime();
      taxItemPO.setCreateTime(createTime);
      taxItemPO.setModifyTime(modifyTime);
      taxItemPO.setIsDelete(0);
      taxItemPO.setType(2);
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(taxItemPO));

      final TaxItemMetaDO expected =
          new TaxItemMetaDO(
              1L,
              "name",
              "code",
              "description",
              10,
              createTime,
              modifyTime,
              EnumDeleteStatus.ACTIVE,
              2);

      // Run the test
      final TaxItemMetaDO result = taxItemRepositoryImplUnderTest.getTaxItemById(1L);

      // Verify the results
      verify(mockTaxItemMapper).selectByExample(any(TaxItemPOExample.class));
      assertEquals(expected, result);
    }

    @Test
    public void testGetTaxItemById_TaxItemMapperReturnsNoItems() {
      // Setup
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Collections.<TaxItemPO>emptyList());

      // Run the test
      final TaxItemMetaDO result = taxItemRepositoryImplUnderTest.getTaxItemById(1L);

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGetTaxItemById_NullId() {
      // Run the test
      final TaxItemMetaDO result = taxItemRepositoryImplUnderTest.getTaxItemById(null);

      // Verify the results
      assertNull(result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxItemMapper mockTaxItemMapper;

    @Mock private TaxItemRepository mockTaxItemRepository;

    @InjectMocks private TaxItemRepositoryImpl taxItemRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective_Success() {
      // Setup
      TaxItemMetaDO metaToUpdate = new TaxItemMetaDO();
      metaToUpdate.setId(1L);
      metaToUpdate.setName("name");
      metaToUpdate.setCode("code");

      TaxItemMetaDO existing = new TaxItemMetaDO();
      existing.setId(1L);
      existing.setIsDelete(EnumDeleteStatus.ACTIVE);

      when(mockTaxItemRepository.getTaxItemById(1L)).thenReturn(existing);
      when(mockTaxItemMapper.updateByPrimaryKeySelective(any(TaxItemPO.class))).thenReturn(1);

      // Run the test
      taxItemRepositoryImplUnderTest.updateByIdSelective(metaToUpdate);

      // Verify the results
      ArgumentCaptor<TaxItemPO> captor = ArgumentCaptor.forClass(TaxItemPO.class);
      verify(mockTaxItemMapper).updateByPrimaryKeySelective(captor.capture());
      TaxItemPO passedPO = captor.getValue();
      assertEquals(Long.valueOf(1L), passedPO.getId());
      assertNotNull(passedPO.getModifyTime());
    }

    @Test
    public void testUpdateByIdSelective_OrgNull_ThrowsBizException() {
      // Setup
      TaxItemMetaDO metaToUpdate = new TaxItemMetaDO();
      metaToUpdate.setId(2L);
      when(mockTaxItemRepository.getTaxItemById(2L)).thenReturn(null);

      // Run the test
      try {
        taxItemRepositoryImplUnderTest.updateByIdSelective(metaToUpdate);
      } catch (BizException ex) {
        // Verify the results
        verify(mockTaxItemMapper, never()).updateByPrimaryKeySelective(any(TaxItemPO.class));
        return;
      }
      // Should not reach here
      verify(mockTaxItemMapper, never()).updateByPrimaryKeySelective(any(TaxItemPO.class));
    }

    @Test
    public void testUpdateByIdSelective_OrgDeleted_ThrowsBizException() {
      // Setup
      TaxItemMetaDO metaToUpdate = new TaxItemMetaDO();
      metaToUpdate.setId(3L);

      TaxItemMetaDO existing = new TaxItemMetaDO();
      existing.setId(3L);
      existing.setIsDelete(EnumDeleteStatus.DELETED);
      when(mockTaxItemRepository.getTaxItemById(3L)).thenReturn(existing);

      // Run the test
      try {
        taxItemRepositoryImplUnderTest.updateByIdSelective(metaToUpdate);
      } catch (BizException ex) {
        // Verify the results
        verify(mockTaxItemMapper, never()).updateByPrimaryKeySelective(any(TaxItemPO.class));
        return;
      }
      // Should not reach here
      verify(mockTaxItemMapper, never()).updateByPrimaryKeySelective(any(TaxItemPO.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemRepositoryImplGetTaxItemsByIdsTest {

    @Mock private TaxItemMapper mockTaxItemMapper;

    @InjectMocks private TaxItemRepositoryImpl taxItemRepositoryImplUnderTest;

    @Test
    public void testGetTaxItemsByIds() {
      // Setup
      List<Long> ids = Arrays.asList(1L, 2L);

      TaxItemPO po1 = new TaxItemPO();
      po1.setId(1L);
      po1.setName("name1");
      po1.setCode("code1");
      po1.setIsDelete(0);

      TaxItemPO po2 = new TaxItemPO();
      po2.setId(2L);
      po2.setName("name2");
      po2.setCode("code2");
      po2.setIsDelete(0);

      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      Map<Long, TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.getTaxItemsByIds(ids);

      // Verify the results
      assertEquals(2, result.size());
      assertTrue(result.containsKey(1L));
      assertTrue(result.containsKey(2L));
      assertEquals(Long.valueOf(1L), result.get(1L).getId());
      assertEquals("code1", result.get(1L).getCode());
      assertEquals(Long.valueOf(2L), result.get(2L).getId());
      assertEquals("code2", result.get(2L).getCode());
    }

    @Test
    public void testGetTaxItemsByIds_IdsEmpty() {
      // Setup
      List<Long> ids = Collections.emptyList();

      // Run the test
      Map<Long, TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.getTaxItemsByIds(ids);

      // Verify the results
      assertTrue(result.isEmpty());
    }

    @Test
    public void testGetTaxItemsByIds_MapperReturnsNoItems() {
      // Setup
      List<Long> ids = Arrays.asList(1L, 2L);
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Collections.<TaxItemPO>emptyList());

      // Run the test
      Map<Long, TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.getTaxItemsByIds(ids);

      // Verify the results
      assertTrue(result.isEmpty());
    }

    @Test
    public void testGetTaxItemsByIds_MapperReturnsNull() {
      // Setup
      List<Long> ids = Arrays.asList(1L, 2L);
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class))).thenReturn(null);

      // Run the test
      Map<Long, TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.getTaxItemsByIds(ids);

      // Verify the results
      assertTrue(result.isEmpty());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemRepositoryImplGetTaxItemCodeByIdTest {

    @Spy @InjectMocks private TaxItemRepositoryImpl taxItemRepositoryImplUnderTest;

    @Test
    public void testGetTaxItemCodeById() {
      // Setup
      List<TaxItemMetaDO> allItems = new ArrayList<TaxItemMetaDO>();
      TaxItemMetaDO a = new TaxItemMetaDO();
      a.setId(1L);
      a.setCode("CODE001");
      TaxItemMetaDO b = new TaxItemMetaDO();
      b.setId(2L);
      b.setCode("CODE002");
      allItems.add(a);
      allItems.add(b);
      doReturn(allItems).when(taxItemRepositoryImplUnderTest).queryAll();

      // Run the test
      final String result = taxItemRepositoryImplUnderTest.getTaxItemCodeById(2L);

      // Verify the results
      assertEquals("CODE002", result);
    }

    @Test
    public void testGetTaxItemCodeById_ReturnsNullWhenNotFound() {
      // Setup
      doReturn(Collections.<TaxItemMetaDO>emptyList())
          .when(taxItemRepositoryImplUnderTest)
          .queryAll();

      // Run the test
      final String result = taxItemRepositoryImplUnderTest.getTaxItemCodeById(99L);

      // Verify the results
      assertEquals(null, result);
    }

    @Test
    public void testGetTaxItemCodeById_NullId() {
      // Setup
      List<TaxItemMetaDO> allItems = new ArrayList<TaxItemMetaDO>();
      TaxItemMetaDO a = new TaxItemMetaDO();
      a.setId(1L);
      a.setCode("CODE001");
      allItems.add(a);
      doReturn(allItems).when(taxItemRepositoryImplUnderTest).queryAll();

      // Run the test
      final String result = taxItemRepositoryImplUnderTest.getTaxItemCodeById(null);

      // Verify the results
      assertEquals(null, result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemRepositoryImplQueryAllTest {

    @Mock private TaxItemMapper mockTaxItemMapper;

    @InjectMocks private TaxItemRepositoryImpl taxItemRepositoryImplUnderTest;

    @Test
    public void testQueryAll() {
      // Setup
      TaxItemPO po1 = new TaxItemPO();
      po1.setId(1L);
      po1.setName("name1");
      po1.setCode("000001");
      po1.setDescription("desc1");
      po1.setOperatorId(11);
      po1.setCreateTime(new Date());
      po1.setModifyTime(new Date());
      po1.setIsDelete(0);
      po1.setType(1);

      TaxItemPO po2 = new TaxItemPO();
      po2.setId(2L);
      po2.setName("name2");
      po2.setCode("000002");
      po2.setDescription("desc2");
      po2.setOperatorId(22);
      po2.setCreateTime(new Date());
      po2.setModifyTime(new Date());
      po2.setIsDelete(0);
      po2.setType(2);

      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      final List<TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.queryAll();

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());
      assertEquals("000001", result.get(0).getCode());
      assertEquals("name1", result.get(0).getName());
      assertEquals(EnumDeleteStatus.ACTIVE, result.get(0).getIsDelete());

      assertEquals(Long.valueOf(2L), result.get(1).getId());
      assertEquals("000002", result.get(1).getCode());
      assertEquals("name2", result.get(1).getName());
      assertEquals(EnumDeleteStatus.ACTIVE, result.get(1).getIsDelete());

      verify(mockTaxItemMapper).selectByExample(any(TaxItemPOExample.class));
    }

    @Test
    public void testQueryAll_TaxItemMapperReturnsNoItems() {
      // Setup
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Collections.<TaxItemPO>emptyList());

      // Run the test
      final List<TaxItemMetaDO> result = taxItemRepositoryImplUnderTest.queryAll();

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxItemMapper).selectByExample(any(TaxItemPOExample.class));
    }
  }
}
