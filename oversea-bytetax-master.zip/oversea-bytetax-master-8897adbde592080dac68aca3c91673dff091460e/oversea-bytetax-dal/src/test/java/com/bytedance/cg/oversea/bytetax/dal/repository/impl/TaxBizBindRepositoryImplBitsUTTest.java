package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxBizBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxBizBindRepository;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxBizBindRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizBindRepositoryImplSaveTaxBizBindTest {

    @Mock private TaxBizBindMapper mockTaxBizBindMapper;

    @Mock private TaxBizBindRepository mockTaxBizBindRepository;

    @InjectMocks private TaxBizBindRepositoryImpl taxBizBindRepositoryImplUnderTest;

    @Test
    public void testSaveTaxBizBind_UpdateSuccess() {
      // Setup
      TaxBizBindMetaDO metaDO = new TaxBizBindMetaDO();
      metaDO.setId(1L);

      TaxBizBindPO orgPO = new TaxBizBindPO();
      orgPO.setId(1L);
      orgPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTaxBizBindRepository.getTaxBizBindById(1L)).thenReturn(orgPO, orgPO);
      when(mockTaxBizBindMapper.updateByPrimaryKeySelective(any(TaxBizBindPO.class))).thenReturn(1);

      // Run the test
      Long result = taxBizBindRepositoryImplUnderTest.saveTaxBizBind(metaDO);

      // Verify the results
      assertEquals(Long.valueOf(1L), result);
      verify(mockTaxBizBindMapper).updateByPrimaryKeySelective(any(TaxBizBindPO.class));
    }

    @Test
    public void testSaveTaxBizBind_InsertSuccess_ReturnNullId() {
      // Setup
      TaxBizBindMetaDO metaDO = new TaxBizBindMetaDO();
      metaDO.setId(null);
      when(mockTaxBizBindMapper.insertSelective(any(TaxBizBindPO.class))).thenReturn(1);

      // Run the test
      Long result = taxBizBindRepositoryImplUnderTest.saveTaxBizBind(metaDO);

      // Verify the results
      assertNull(result);
      verify(mockTaxBizBindMapper).insertSelective(any(TaxBizBindPO.class));
    }

    @Test(expected = BizException.class)
    public void testSaveTaxBizBind_UpdateThrowsWhenOrgNull() {
      // Setup
      TaxBizBindMetaDO metaDO = new TaxBizBindMetaDO();
      metaDO.setId(2L);

      when(mockTaxBizBindRepository.getTaxBizBindById(2L)).thenReturn(null);

      // Run the test
      taxBizBindRepositoryImplUnderTest.saveTaxBizBind(metaDO);
    }

    @Test(expected = BizException.class)
    public void testSaveTaxBizBind_UpdateThrowsWhenOrgDeleted() {
      // Setup
      TaxBizBindMetaDO metaDO = new TaxBizBindMetaDO();
      metaDO.setId(3L);

      TaxBizBindPO orgPO = new TaxBizBindPO();
      orgPO.setId(3L);
      orgPO.setIsDelete(EnumDeleteStatus.DELETED.getCode());

      when(mockTaxBizBindRepository.getTaxBizBindById(3L)).thenReturn(orgPO);

      // Run the test
      taxBizBindRepositoryImplUnderTest.saveTaxBizBind(metaDO);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizBindRepositoryImplGetTaxBizBindTest {

    @Mock private TaxBizBindMapper mockTaxBizBindMapper;

    @InjectMocks private TaxBizBindRepositoryImpl taxBizBindRepositoryImplUnderTest;

    @Test
    public void testGetTaxBizBind_EmptyIds() {
      // Setup

      // Run the test
      final List<TaxBizBindMetaDO> result =
          taxBizBindRepositoryImplUnderTest.getTaxBizBind(Collections.<Long>emptyList(), true);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizBindMapper, never()).selectByExample(any(TaxBizBindPOExample.class));
    }

    @Test
    public void testGetTaxBizBind_NullIds() {
      // Setup

      // Run the test
      final List<TaxBizBindMetaDO> result =
          taxBizBindRepositoryImplUnderTest.getTaxBizBind(null, false);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizBindMapper, never()).selectByExample(any(TaxBizBindPOExample.class));
    }

    @Test
    public void testGetTaxBizBind_ActiveTrue() {
      // Setup
      final TaxBizBindPO po1 = new TaxBizBindPO();
      po1.setId(1L);
      po1.setCountryBindId(10L);
      po1.setBizId(100L);
      po1.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      final TaxBizBindPO po2 = new TaxBizBindPO();
      po2.setId(2L);
      po2.setCountryBindId(20L);
      po2.setBizId(200L);
      po2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTaxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      final List<TaxBizBindMetaDO> result =
          taxBizBindRepositoryImplUnderTest.getTaxBizBind(Arrays.asList(10L, 20L), true);

      // Verify the results
      assertEquals(2, result.size());
      verify(mockTaxBizBindMapper).selectByExample(any(TaxBizBindPOExample.class));
    }

    @Test
    public void testGetTaxBizBind_ActiveFalse() {
      // Setup
      final TaxBizBindPO po1 = new TaxBizBindPO();
      po1.setId(3L);
      po1.setCountryBindId(30L);
      po1.setBizId(300L);
      po1.setIsDelete(EnumDeleteStatus.DELETED.getCode());

      final TaxBizBindPO po2 = new TaxBizBindPO();
      po2.setId(4L);
      po2.setCountryBindId(40L);
      po2.setBizId(400L);
      po2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTaxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      final List<TaxBizBindMetaDO> result =
          taxBizBindRepositoryImplUnderTest.getTaxBizBind(Arrays.asList(30L, 40L), false);

      // Verify the results
      assertEquals(2, result.size());
      verify(mockTaxBizBindMapper).selectByExample(any(TaxBizBindPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizBindRepositoryImplGetTaxBizBindByIdTest {

    @Mock private TaxBizBindMapper mockTaxBizBindMapper;

    @InjectMocks private TaxBizBindRepositoryImpl taxBizBindRepositoryImplUnderTest;

    @Test
    public void testGetTaxBizBindById_NullId() {
      // Run the test
      final TaxBizBindPO result = taxBizBindRepositoryImplUnderTest.getTaxBizBindById(null);

      // Verify the results
      assertNull(result);
      verify(mockTaxBizBindMapper, never()).selectByPrimaryKey(anyLong());
    }

    @Test
    public void testGetTaxBizBindById_Found() {
      // Setup
      TaxBizBindPO po = new TaxBizBindPO();
      po.setId(1L);
      po.setBizId(100L);
      po.setCountryBindId(200L);
      po.setRule("rule-json");
      po.setIsDelete(0);

      when(mockTaxBizBindMapper.selectByPrimaryKey(1L)).thenReturn(po);

      // Run the test
      final TaxBizBindPO result = taxBizBindRepositoryImplUnderTest.getTaxBizBindById(1L);

      // Verify the results
      assertEquals(po, result);
      verify(mockTaxBizBindMapper).selectByPrimaryKey(1L);
    }

    @Test
    public void testGetTaxBizBindById_NotFound() {
      // Setup
      when(mockTaxBizBindMapper.selectByPrimaryKey(2L)).thenReturn(null);

      // Run the test
      final TaxBizBindPO result = taxBizBindRepositoryImplUnderTest.getTaxBizBindById(2L);

      // Verify the results
      assertNull(result);
      verify(mockTaxBizBindMapper).selectByPrimaryKey(2L);
    }
  }
}
