package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.IdGenerateService;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.AsyncTaskMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.ext.AsyncTaskDao;
import com.bytedance.cg.oversea.bytetax.dal.mapping.AsyncTaskMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.AsyncTaskMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPO;
import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPOExample;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class AsyncTaskRepositoryImplTest {

    @Mock
    private AsyncTaskMapper mockAsyncTaskMapper;
    @Mock
    private AsyncTaskDao mockAsyncTaskDao;
    @Mock
    private IdGenerateService idGenerateService;

    @InjectMocks
    private AsyncTaskRepositoryImpl asyncTaskRepositoryImplUnderTest;

    @Test
    public void testCanProcess() {
        // Setup
        when(mockAsyncTaskDao.setProcessingIfCan(0L)).thenReturn(1);

        // Run the test
        final boolean result = asyncTaskRepositoryImplUnderTest.canProcess(0L);

        // Verify the results
        assertTrue(result);
    }

    @Test
    public void testQueryById() {
        // Setup
        final AsyncTaskMetaDO expectedResult = new AsyncTaskMetaDO(0L, EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD, EnumAsyncTaskStatus.INIT, "args", "result", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0L, EnumDeleteStatus.ACTIVE, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());

        // Configure AsyncTaskMapper.selectByExample(...).
        final AsyncTaskPO asyncTaskPO = new AsyncTaskPO();
        asyncTaskPO.setId(0L);
        asyncTaskPO.setType(1);
        asyncTaskPO.setStatus(1);
        asyncTaskPO.setArgs("args");
        asyncTaskPO.setResult("result");
        asyncTaskPO.setDoneTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        asyncTaskPO.setCreatorId(0L);
        asyncTaskPO.setIsDelete(0);
        asyncTaskPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        asyncTaskPO.setUpdateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        final List<AsyncTaskPO> asyncTaskPOS = Arrays.asList(asyncTaskPO);
        when(mockAsyncTaskMapper.selectByExample(any(AsyncTaskPOExample.class))).thenReturn(asyncTaskPOS);

        // Run the test
        final AsyncTaskMetaDO result = asyncTaskRepositoryImplUnderTest.queryById(0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testQueryById_AsyncTaskMapperReturnsNoItems() {
        // Setup
        when(mockAsyncTaskMapper.selectByExample(any(AsyncTaskPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final AsyncTaskMetaDO result = asyncTaskRepositoryImplUnderTest.queryById(0L);

        // Verify the results
        assertNull(result);
    }

    @Test
    public void testSave() {
        // Setup
        final AsyncTaskMetaDO metaDO = new AsyncTaskMetaDO(0L, EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD, EnumAsyncTaskStatus.INIT, "args", "result", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0L, EnumDeleteStatus.ACTIVE, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        when(mockAsyncTaskMapper.updateByPrimaryKey(any())).thenReturn(0);
        AsyncTaskPO po = AsyncTaskMapping.MAPPING.toPO(metaDO);

        // Run the test
        asyncTaskRepositoryImplUnderTest.save(metaDO);

        // Verify the results
        verify(mockAsyncTaskMapper).updateByPrimaryKey(any());
    }

    @Test
    public void testCreateNew() {
        // Setup
        // Configure AsyncTaskMapper.selectByExample(...).
        final AsyncTaskPO asyncTaskPO = new AsyncTaskPO();
        asyncTaskPO.setId(0L);
        asyncTaskPO.setType(0);
        asyncTaskPO.setStatus(0);
        asyncTaskPO.setArgs("args");
        asyncTaskPO.setResult("result");
        asyncTaskPO.setDoneTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        asyncTaskPO.setCreatorId(0L);
        asyncTaskPO.setIsDelete(0);
        asyncTaskPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        asyncTaskPO.setUpdateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        final List<AsyncTaskPO> asyncTaskPOS = Arrays.asList(asyncTaskPO);
        when(mockAsyncTaskMapper.selectByExample(any(AsyncTaskPOExample.class))).thenReturn(asyncTaskPOS);

//        when(mockAsyncTaskMapper.insert(new AsyncTaskPO())).thenReturn(0);

        // Run the test
        final Long result = asyncTaskRepositoryImplUnderTest.createNew(EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD, "argsObj", 0L);

        // Verify the results
        Long expected = 0L;
        assertEquals(expected, result);
        verify(mockAsyncTaskMapper).selectByExample(any(AsyncTaskPOExample.class));
    }

    @Test
    public void testCreateNew_AsyncTaskMapperSelectByExampleReturnsNoItems() {
        // Setup
        when(idGenerateService.getId()).thenReturn(1L);
        when(mockAsyncTaskMapper.selectByExample(any(AsyncTaskPOExample.class))).thenReturn(Collections.emptyList());
        when(mockAsyncTaskMapper.insert(any())).thenReturn(0);

        // Run the test
        final Long result = asyncTaskRepositoryImplUnderTest.createNew(EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD, "argsObj", 0L);

        // Verify the results
        verify(mockAsyncTaskMapper).insert(any());
    }

    @Test
    public void testSetSuccess() {
        // Setup
        final AsyncTaskMetaDO metaDO = new AsyncTaskMetaDO(0L, EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD, EnumAsyncTaskStatus.INIT, "args", "result", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0L, EnumDeleteStatus.ACTIVE, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
//        when(mockAsyncTaskMapper.insert(any())).thenReturn(0);
        when(mockAsyncTaskMapper.updateByPrimaryKey(any())).thenReturn(0);

        // Run the test
        asyncTaskRepositoryImplUnderTest.setSuccess(metaDO, "resultObj");

        // Verify the results
        verify(mockAsyncTaskMapper).updateByPrimaryKey(any());
    }

    @Test
    public void testSetFail() {
        // Setup
        final AsyncTaskMetaDO metaDO = new AsyncTaskMetaDO(0L, EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD, EnumAsyncTaskStatus.INIT, "args", "result", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0L, EnumDeleteStatus.ACTIVE, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
//        when(mockAsyncTaskMapper.insert(new AsyncTaskPO())).thenReturn(0);
        when(mockAsyncTaskMapper.updateByPrimaryKey(any())).thenReturn(0);

        // Run the test
        asyncTaskRepositoryImplUnderTest.setFail(metaDO);

        // Verify the results
        verify(mockAsyncTaskMapper).updateByPrimaryKey(any());
    }
}
