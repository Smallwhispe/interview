package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.dal.dao.base.InterfaceLogMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.InterfaceLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.InterfaceLogPO;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class InterfaceLogRepositoryImplTest {

    @Mock
    private InterfaceLogMapper mockInterfaceLogMapper;

    @InjectMocks
    private InterfaceLogRepositoryImpl interfaceLogRepositoryImplUnderTest;

    @Test
    public void testSaveSelectiveInterfaceLog() {
        // Setup
        final InterfaceLogMetaDO metaDO = new InterfaceLogMetaDO(0L, "interfaceName", "request", "response", 0, "tag", new DateTime(2020, 1, 1, 1, 0, 0, 0));
        when(mockInterfaceLogMapper.insertSelective(any())).thenReturn(0);

        // Run the test
        interfaceLogRepositoryImplUnderTest.saveSelectiveInterfaceLog(metaDO);

        // Verify the results
        verify(mockInterfaceLogMapper).insertSelective(any());
    }
}
