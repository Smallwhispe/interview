package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxIdentity;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoAPIRules;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoCheckStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoCheckResultMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckResultMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckResultPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckResultPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckResultQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxNoCheckResultRepository;
import java.util.*;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxNoCheckResultRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckResultRepositoryImplQueryTest {

    @Mock private TaxNoCheckResultMapper mockTaxNoCheckResultMapper;

    @InjectMocks private TaxNoCheckResultRepositoryImpl taxNoCheckResultRepositoryImplUnderTest;

    @Test
    public void testQuery_WithAllFilters_ReturnsMappedList() {
      // Setup
      Date start = new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime();
      Date end = new GregorianCalendar(2020, Calendar.JANUARY, 2).getTime();
      final TaxNoCheckResultQuery query =
          TaxNoCheckResultQuery.builder()
              .apiRuleIds(Arrays.asList(EnumTaxNoAPIRules.EU_API_SOURCE.getCode()))
              .startTime(start)
              .endTime(end)
              .apiCheckResults(Arrays.asList(EnumTaxNoCheckStatus.PASS.getCode()))
              .taskId("task123")
              .build();

      TaxNoCheckResultPO po = new TaxNoCheckResultPO();
      po.setId(1L);
      po.setApiRuleId(EnumTaxNoAPIRules.EU_API_SOURCE.getCode());
      po.setApiCheckResult(EnumTaxNoCheckStatus.PASS.getCode());
      po.setApiPrimaryKey("task123");
      po.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1, 10, 0, 0).getTime());
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTaxNoCheckResultMapper.selectByExample(any(TaxNoCheckResultPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      final List<TaxNoCheckResultMetaDO> result =
          taxNoCheckResultRepositoryImplUnderTest.query(query);

      // Verify
      verify(mockTaxNoCheckResultMapper).selectByExample(any(TaxNoCheckResultPOExample.class));
      assertEquals(1, result.size());
      TaxNoCheckResultMetaDO meta = result.get(0);
      assertEquals(1L, meta.getId().longValue());
      assertEquals(EnumTaxNoAPIRules.EU_API_SOURCE, meta.getApiRuleId());
      assertEquals(EnumTaxNoCheckStatus.PASS, meta.getApiCheckResult());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());
    }

    @Test
    public void testQuery_MapperReturnsEmptyList() {
      // Setup
      final TaxNoCheckResultQuery query = new TaxNoCheckResultQuery();
      when(mockTaxNoCheckResultMapper.selectByExample(any(TaxNoCheckResultPOExample.class)))
          .thenReturn(Collections.<TaxNoCheckResultPO>emptyList());

      // Run the test
      final List<TaxNoCheckResultMetaDO> result =
          taxNoCheckResultRepositoryImplUnderTest.query(query);

      // Verify
      verify(mockTaxNoCheckResultMapper).selectByExample(any(TaxNoCheckResultPOExample.class));
      assertTrue(result.isEmpty());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckResultRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxNoCheckResultMapper mockTaxNoCheckResultMapper;

    @InjectMocks private TaxNoCheckResultRepositoryImpl taxNoCheckResultRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective() {
      final TaxNoCheckResultMetaDO metaDO = new TaxNoCheckResultMetaDO();
      metaDO.setId(1L);

      taxNoCheckResultRepositoryImplUnderTest.updateByIdSelective(metaDO);

      verify(mockTaxNoCheckResultMapper).updateByPrimaryKeySelective(any());
      assertNotNull(metaDO.getModifyTime());
    }

    @Test
    public void testUpdateByIdSelective_UpdateModifyTime() {
      final TaxNoCheckResultMetaDO metaDO = new TaxNoCheckResultMetaDO();
      metaDO.setId(1L);
      final java.util.Date oldDate = new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime();
      metaDO.setModifyTime(oldDate);

      taxNoCheckResultRepositoryImplUnderTest.updateByIdSelective(metaDO);

      assertNotNull(metaDO.getModifyTime());
      assertTrue(metaDO.getModifyTime().after(oldDate));
      verify(mockTaxNoCheckResultMapper).updateByPrimaryKeySelective(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckResultRepositoryImplSaveTest {

    @Mock private TaxNoCheckResultMapper mockTaxNoCheckResultMapper;

    @InjectMocks private TaxNoCheckResultRepositoryImpl taxNoCheckResultRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      TaxNoCheckResultMetaDO metaDO = new TaxNoCheckResultMetaDO();
      metaDO.setTaxNo("VAT123");
      metaDO.setTaxIdentity(EnumTaxIdentity.BUSINESS);
      metaDO.setApiRuleId(EnumTaxNoAPIRules.EU_API_SOURCE);
      metaDO.setFormatCheckResult(EnumTaxNoCheckStatus.PASS);
      metaDO.setApiCheckResult(EnumTaxNoCheckStatus.FAILURE);

      when(mockTaxNoCheckResultMapper.insertSelective(any(TaxNoCheckResultPO.class))).thenReturn(1);

      // Run the test
      TaxNoCheckResultMetaDO result = taxNoCheckResultRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      verify(mockTaxNoCheckResultMapper).insertSelective(any(TaxNoCheckResultPO.class));
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
      Assert.assertNotNull(result.getCreateTime());
      Assert.assertNotNull(result.getModifyTime());
      assertEquals(result.getCreateTime(), result.getModifyTime());

      assertEquals("VAT123", result.getTaxNo());
      assertEquals(EnumTaxIdentity.BUSINESS, result.getTaxIdentity());
      assertEquals(EnumTaxNoAPIRules.EU_API_SOURCE, result.getApiRuleId());
      assertEquals(EnumTaxNoCheckStatus.PASS, result.getFormatCheckResult());
      assertEquals(EnumTaxNoCheckStatus.FAILURE, result.getApiCheckResult());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckResultRepositoryImplSelectByPrimaryKeyFromApiTest {

    @Mock private TaxNoCheckResultMapper mockTaxNoCheckResultMapper;

    @InjectMocks private TaxNoCheckResultRepositoryImpl taxNoCheckResultRepositoryImplUnderTest;

    @Test
    public void testSelectByPrimaryKeyFromApi_ReturnsMetaDO() {
      // Setup
      TaxNoCheckResultPO po = new TaxNoCheckResultPO();
      po.setApiRuleId(EnumTaxNoAPIRules.EU_API_SOURCE.getCode());
      po.setApiPrimaryKey("task_123");
      List<TaxNoCheckResultPO> poList = Arrays.asList(po);
      when(mockTaxNoCheckResultMapper.selectByExample(any(TaxNoCheckResultPOExample.class)))
          .thenReturn(poList);

      // Run the test
      TaxNoCheckResultMetaDO result =
          taxNoCheckResultRepositoryImplUnderTest.SelectByPrimaryKeyFromApi(
              EnumTaxNoAPIRules.EU_API_SOURCE, "task_123");

      // Verify the results
      assertNotNull(result);
      assertEquals(EnumTaxNoAPIRules.EU_API_SOURCE, result.getApiRuleId());
      assertEquals("task_123", result.getApiPrimaryKey());
      verify(mockTaxNoCheckResultMapper).selectByExample(any(TaxNoCheckResultPOExample.class));
    }

    @Test
    public void testSelectByPrimaryKeyFromApi_ReturnsNullWhenNoItems() {
      // Setup
      when(mockTaxNoCheckResultMapper.selectByExample(any(TaxNoCheckResultPOExample.class)))
          .thenReturn(Collections.emptyList());

      // Run the test
      TaxNoCheckResultMetaDO result =
          taxNoCheckResultRepositoryImplUnderTest.SelectByPrimaryKeyFromApi(
              EnumTaxNoAPIRules.EU_API_SOURCE, "task_not_exist");

      // Verify the results
      assertNull(result);
      verify(mockTaxNoCheckResultMapper).selectByExample(any(TaxNoCheckResultPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckResultRepositoryImplUpdatePrimaryKeyFromApiTest {

    @Mock private TaxNoCheckResultMapper mockTaxNoCheckResultMapper;

    @InjectMocks private TaxNoCheckResultRepositoryImpl repository;

    @Test
    public void testUpdatePrimaryKeyFromApi_Success() {
      EnumTaxNoAPIRules apiSource = EnumTaxNoAPIRules.GB_API_SOURCE;
      String idFromApi = "task-123";
      TaxNoCheckResultMetaDO resultMetaDO =
          TaxNoCheckResultMetaDO.builder().id(1L).apiPrimaryKey("new-key").build();

      when(mockTaxNoCheckResultMapper.updateByExampleSelective(
              any(TaxNoCheckResultPO.class), any(TaxNoCheckResultPOExample.class)))
          .thenReturn(1);

      boolean result = repository.updatePrimaryKeyFromApi(apiSource, idFromApi, resultMetaDO);

      assertEquals(true, result);

      ArgumentCaptor<TaxNoCheckResultPO> recordCaptor =
          ArgumentCaptor.forClass(TaxNoCheckResultPO.class);
      ArgumentCaptor<TaxNoCheckResultPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxNoCheckResultPOExample.class);
      verify(mockTaxNoCheckResultMapper)
          .updateByExampleSelective(recordCaptor.capture(), exampleCaptor.capture());

      TaxNoCheckResultPO record = recordCaptor.getValue();
      assertEquals("new-key", record.getApiPrimaryKey());

      TaxNoCheckResultPOExample example = exampleCaptor.getValue();
      assertEquals(true, example.getOredCriteria() != null && !example.getOredCriteria().isEmpty());
    }

    @Test
    public void testUpdatePrimaryKeyFromApi_NoUpdate() {
      EnumTaxNoAPIRules apiSource = EnumTaxNoAPIRules.EU_API_SOURCE;
      String idFromApi = "task-456";
      TaxNoCheckResultMetaDO resultMetaDO =
          TaxNoCheckResultMetaDO.builder().id(2L).apiPrimaryKey("another-key").build();

      when(mockTaxNoCheckResultMapper.updateByExampleSelective(
              any(TaxNoCheckResultPO.class), any(TaxNoCheckResultPOExample.class)))
          .thenReturn(0);

      boolean result = repository.updatePrimaryKeyFromApi(apiSource, idFromApi, resultMetaDO);

      assertEquals(false, result);

      ArgumentCaptor<TaxNoCheckResultPO> recordCaptor =
          ArgumentCaptor.forClass(TaxNoCheckResultPO.class);
      ArgumentCaptor<TaxNoCheckResultPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxNoCheckResultPOExample.class);
      verify(mockTaxNoCheckResultMapper)
          .updateByExampleSelective(recordCaptor.capture(), exampleCaptor.capture());

      TaxNoCheckResultPO record = recordCaptor.getValue();
      assertEquals("another-key", record.getApiPrimaryKey());

      TaxNoCheckResultPOExample example = exampleCaptor.getValue();
      assertEquals(true, example.getOredCriteria() != null && !example.getOredCriteria().isEmpty());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckResultRepositoryImplGetTaxNoCheckResultByIdTest {

    @Mock private TaxNoCheckResultMapper mockTaxNoCheckResultMapper;

    @InjectMocks private TaxNoCheckResultRepositoryImpl taxNoCheckResultRepositoryImplUnderTest;

    @Test
    public void testGetTaxNoCheckResultById() {
      // Setup
      TaxNoCheckResultPO po = new TaxNoCheckResultPO();
      po.setId(1L);
      when(mockTaxNoCheckResultMapper.selectByPrimaryKey(1L)).thenReturn(po);

      // Run the test
      TaxNoCheckResultMetaDO result =
          taxNoCheckResultRepositoryImplUnderTest.getTaxNoCheckResultById(1L);

      // Verify the results
      assertEquals(Long.valueOf(1L), result.getId());
      verify(mockTaxNoCheckResultMapper).selectByPrimaryKey(1L);
    }

    @Test
    public void testGetTaxNoCheckResultById_IdIsNull() {
      // Setup

      // Run the test
      TaxNoCheckResultMetaDO result =
          taxNoCheckResultRepositoryImplUnderTest.getTaxNoCheckResultById(null);

      // Verify the results
      assertNull(result);
      verify(mockTaxNoCheckResultMapper, never()).selectByPrimaryKey(anyLong());
    }

    @Test
    public void testGetTaxNoCheckResultById_MapperReturnsNull() {
      // Setup
      when(mockTaxNoCheckResultMapper.selectByPrimaryKey(2L)).thenReturn(null);

      // Run the test
      TaxNoCheckResultMetaDO result =
          taxNoCheckResultRepositoryImplUnderTest.getTaxNoCheckResultById(2L);

      // Verify the results
      assertNull(result);
      verify(mockTaxNoCheckResultMapper).selectByPrimaryKey(2L);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckResultRepositoryImplUpdateAPIRuleAndCheckResultTest {

    @Mock private TaxNoCheckResultRepository mockTaxNoCheckResultRepository;

    @InjectMocks private TaxNoCheckResultRepositoryImpl repositoryImplUnderTest;

    @Test
    public void testUpdateAPIRuleAndCheckResult_updatesFieldsAndCallsRepository() {
      // Setup
      TaxNoCheckResultMetaDO original =
          TaxNoCheckResultMetaDO.builder()
              .id(123L)
              .apiRuleId(EnumTaxNoAPIRules.GB_API_SOURCE)
              .apiCheckResult(EnumTaxNoCheckStatus.FAILURE)
              .build();

      EnumTaxNoAPIRules newRule = EnumTaxNoAPIRules.EU_API_SOURCE;
      EnumTaxNoCheckStatus newStatus = EnumTaxNoCheckStatus.PASS;

      // Run
      TaxNoCheckResultMetaDO result =
          repositoryImplUnderTest.updateAPIRuleAndCheckResult(original, newRule, newStatus);

      // Verify returned object fields are updated
      assertEquals(newRule, result.getApiRuleId());
      assertEquals(newStatus, result.getApiCheckResult());
      assertEquals(Long.valueOf(123L), result.getId());

      // Verify repository call with correct argument
      ArgumentCaptor<TaxNoCheckResultMetaDO> captor =
          ArgumentCaptor.forClass(TaxNoCheckResultMetaDO.class);
      verify(mockTaxNoCheckResultRepository).updateByIdSelective(captor.capture());

      TaxNoCheckResultMetaDO updatedArg = captor.getValue();
      assertEquals(Long.valueOf(123L), updatedArg.getId());
      assertEquals(newRule, updatedArg.getApiRuleId());
      assertEquals(newStatus, updatedArg.getApiCheckResult());
      assertNotSame(
          "Should pass a new built object to repository, not the original reference",
          original,
          updatedArg);
    }
  }
}
