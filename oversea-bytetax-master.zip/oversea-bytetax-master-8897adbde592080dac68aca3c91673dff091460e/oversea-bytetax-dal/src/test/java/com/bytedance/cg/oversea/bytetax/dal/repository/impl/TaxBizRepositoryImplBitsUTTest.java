package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxBizMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxBizMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxBizQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.ChangeLogRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxBizRepository;
import java.util.*;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxBizRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizRepositoryImplQueryTaxBizListTest {

    @Mock private TaxBizMapper mockTaxBizMapper;

    @InjectMocks private TaxBizRepositoryImpl taxBizRepositoryImplUnderTest;

    @Test
    public void testQueryTaxBizList_Basic() {
      // Setup
      TaxBizPO po = new TaxBizPO();
      po.setId(1L);
      po.setName("name1");
      po.setCode("code1");
      po.setIsDelete(0);
      List<TaxBizPO> list = Arrays.asList(po);
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class))).thenReturn(list);

      TaxBizQuery query = new TaxBizQuery(null, null, null, null, 10, 1);

      // Run
      PageResult<?> result = taxBizRepositoryImplUnderTest.queryTaxBizList(query);

      // Verify
      assertEquals(1, result.getData().size());
      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testQueryTaxBizList_WithFilters() {
      // Setup
      TaxBizPO po1 = new TaxBizPO();
      po1.setId(2L);
      po1.setName("ExactName");
      po1.setCode("desc");
      po1.setIsDelete(0);

      TaxBizPO po2 = new TaxBizPO();
      po2.setId(3L);
      po2.setName("ExactName");
      po2.setCode("desc2");
      po2.setIsDelete(0);

      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      TaxBizQuery query = new TaxBizQuery(2L, "ExactName", "Exa", "desc", 20, 1);

      // Run
      PageResult<?> result = taxBizRepositoryImplUnderTest.queryTaxBizList(query);

      // Verify
      assertEquals(2, result.getData().size());
      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testQueryTaxBizList_MapperReturnsNoItems() {
      // Setup
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Collections.emptyList());
      TaxBizQuery query = new TaxBizQuery(null, null, null, null, 10, 1);

      // Run
      PageResult<?> result = taxBizRepositoryImplUnderTest.queryTaxBizList(query);

      // Verify
      assertEquals(0, result.getData().size());
      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testQueryTaxBizList_NoPagingParams() {
      // Setup
      TaxBizPO po = new TaxBizPO();
      po.setId(10L);
      po.setName("n");
      po.setCode("c");
      po.setIsDelete(0);
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Arrays.asList(po));

      TaxBizQuery query = new TaxBizQuery(null, null, "fuzzy%", "desc_", null, null);

      // Run
      PageResult<?> result = taxBizRepositoryImplUnderTest.queryTaxBizList(query);

      // Verify
      assertEquals(1, result.getData().size());
      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizRepositoryImplGetTaxBizByBizIdTest {

    @Mock private TaxBizMapper mockTaxBizMapper;

    @InjectMocks private TaxBizRepositoryImpl taxBizRepositoryImplUnderTest;

    @Test
    public void testGetTaxBizByBizId_NullId() {
      // Run the test
      final TaxBizMetaDO result = taxBizRepositoryImplUnderTest.getTaxBizByBizId(null);

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGetTaxBizByBizId_ReturnsMeta() {
      // Setup
      final TaxBizPO taxBizPO = new TaxBizPO();
      taxBizPO.setId(1L);
      taxBizPO.setName("biz-name");
      taxBizPO.setCode("biz-code");
      taxBizPO.setOperatorId(100);
      taxBizPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
      taxBizPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 2).getTime());
      taxBizPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Arrays.asList(taxBizPO));

      // Run the test
      final TaxBizMetaDO result = taxBizRepositoryImplUnderTest.getTaxBizByBizId(1L);

      // Verify the results
      assertNotNull(result);
      assertEquals(Long.valueOf(1L), result.getId());
      assertEquals("biz-name", result.getName());
      assertEquals("biz-code", result.getDescription());
      assertEquals(Integer.valueOf(100), result.getOperatorId());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
    }

    @Test
    public void testGetTaxBizByBizId_EmptyList() {
      // Setup
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Collections.<TaxBizPO>emptyList());

      // Run the test
      final TaxBizMetaDO result = taxBizRepositoryImplUnderTest.getTaxBizByBizId(2L);

      // Verify the results
      assertNull(result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizRepositoryImplGetTaxBizByIdsTest {

    @Mock private TaxBizMapper mockTaxBizMapper;

    @InjectMocks private TaxBizRepositoryImpl taxBizRepositoryImplUnderTest;

    @Test
    public void testGetTaxBizByIds() {
      // Setup
      List<Long> ids = Arrays.asList(1L, 2L);
      TaxBizPO po1 = new TaxBizPO();
      po1.setId(1L);
      po1.setName("name1");
      po1.setCode("desc1");
      po1.setIsDelete(0);

      TaxBizPO po2 = new TaxBizPO();
      po2.setId(2L);
      po2.setName("name2");
      po2.setCode("desc2");
      po2.setIsDelete(0);

      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      Map<Long, TaxBizMetaDO> result = taxBizRepositoryImplUnderTest.getTaxBizByIds(ids);

      // Verify the results
      assertEquals(2, result.size());
      TaxBizMetaDO meta1 = result.get(1L);
      TaxBizMetaDO meta2 = result.get(2L);
      assertEquals(Long.valueOf(1L), meta1.getId());
      assertEquals("name1", meta1.getName());
      assertEquals("desc1", meta1.getDescription());
      assertEquals(EnumDeleteStatus.ACTIVE, meta1.getIsDelete());

      assertEquals(Long.valueOf(2L), meta2.getId());
      assertEquals("name2", meta2.getName());
      assertEquals("desc2", meta2.getDescription());
      assertEquals(EnumDeleteStatus.ACTIVE, meta2.getIsDelete());

      verify(mockTaxBizMapper, times(1)).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testGetTaxBizByIds_EmptyIds() {
      // Setup
      List<Long> ids = Collections.emptyList();

      // Run the test
      Map<Long, TaxBizMetaDO> result = taxBizRepositoryImplUnderTest.getTaxBizByIds(ids);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizMapper, times(0)).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testGetTaxBizByIds_MapperReturnsEmpty() {
      // Setup
      List<Long> ids = Arrays.asList(3L, 4L);
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Collections.<TaxBizPO>emptyList());

      // Run the test
      Map<Long, TaxBizMetaDO> result = taxBizRepositoryImplUnderTest.getTaxBizByIds(ids);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizMapper, times(1)).selectByExample(any(TaxBizPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizRepositoryImplGetByIdsTest {

    @Mock private TaxBizMapper mockTaxBizMapper;

    @InjectMocks private TaxBizRepositoryImpl taxBizRepositoryImplUnderTest;

    @Test
    public void testGetByIds() {
      // Setup
      TaxBizPO po1 = new TaxBizPO();
      po1.setId(1L);
      po1.setName("biz1");
      po1.setCode("desc1");
      po1.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      TaxBizPO po2 = new TaxBizPO();
      po2.setId(2L);
      po2.setName("biz2");
      po2.setCode("desc2");
      po2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      List<TaxBizPO> pos = Arrays.asList(po1, po2);
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class))).thenReturn(pos);

      List<Long> ids = Arrays.asList(1L, 2L);

      // Run the test
      List<TaxBizMetaDO> result = taxBizRepositoryImplUnderTest.getByIds(ids);

      // Verify the results
      List<TaxBizMetaDO> expected = TaxBizMapping.MAPPING.toMetaDOList(pos);
      assertEquals(expected, result);
      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testGetByIds_TaxBizMapperReturnsNoItems() {
      // Setup
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Collections.<TaxBizPO>emptyList());

      // Run the test
      List<TaxBizMetaDO> result =
          taxBizRepositoryImplUnderTest.getByIds(Collections.singletonList(1L));

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testGetByIds_IdsIsEmpty() {
      // Run the test
      List<TaxBizMetaDO> result =
          taxBizRepositoryImplUnderTest.getByIds(Collections.<Long>emptyList());

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizMapper, never()).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testGetByIds_IdsIsNull() {
      // Run the test
      List<TaxBizMetaDO> result = taxBizRepositoryImplUnderTest.getByIds(null);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizMapper, never()).selectByExample(any(TaxBizPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxBizMapper taxBizMapper;

    @Mock private TaxBizRepository taxBizRepository;

    @Mock private ChangeLogRepository changeLogRepository;

    @InjectMocks private TaxBizRepositoryImpl taxBizRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective_Success() {
      // Setup
      TaxBizMetaDO input = new TaxBizMetaDO();
      input.setId(123L);
      input.setName("name");
      input.setDescription("desc");
      input.setIsDelete(EnumDeleteStatus.ACTIVE);

      TaxBizMetaDO existed = new TaxBizMetaDO();
      existed.setId(123L);
      existed.setIsDelete(EnumDeleteStatus.ACTIVE);

      when(taxBizRepository.getTaxBizByBizId(123L)).thenReturn(existed);
      when(taxBizMapper.updateByPrimaryKeySelective(any(TaxBizPO.class))).thenReturn(1);

      // Run the test
      taxBizRepositoryImplUnderTest.updateByIdSelective(input);

      // Verify the results
      ArgumentCaptor<TaxBizPO> captor = ArgumentCaptor.forClass(TaxBizPO.class);
      verify(taxBizMapper, times(1)).updateByPrimaryKeySelective(captor.capture());
      TaxBizPO updated = captor.getValue();
      assertEquals(123L, updated.getId().longValue());
      assertNotNull(updated.getModifyTime());
    }

    @Test
    public void testUpdateByIdSelective_OrgNull_Throws() {
      // Setup
      TaxBizMetaDO input = new TaxBizMetaDO();
      input.setId(1L);
      input.setIsDelete(EnumDeleteStatus.ACTIVE);

      when(taxBizRepository.getTaxBizByBizId(1L)).thenReturn(null);

      // Run the test
      try {
        taxBizRepositoryImplUnderTest.updateByIdSelective(input);
        fail("Expected BizException to be thrown");
      } catch (BizException ex) {
        // Verify the results
        verify(taxBizMapper, never()).updateByPrimaryKeySelective(any(TaxBizPO.class));
      }
    }

    @Test
    public void testUpdateByIdSelective_OrgDeleted_Throws() {
      // Setup
      TaxBizMetaDO input = new TaxBizMetaDO();
      input.setId(2L);
      input.setIsDelete(EnumDeleteStatus.ACTIVE);

      TaxBizMetaDO existed = new TaxBizMetaDO();
      existed.setId(2L);
      existed.setIsDelete(EnumDeleteStatus.DELETED);

      when(taxBizRepository.getTaxBizByBizId(2L)).thenReturn(existed);

      // Run the test
      try {
        taxBizRepositoryImplUnderTest.updateByIdSelective(input);
        fail("Expected BizException to be thrown");
      } catch (BizException ex) {
        // Verify the results
        verify(taxBizMapper, never()).updateByPrimaryKeySelective(any(TaxBizPO.class));
      }
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizRepositoryImplSaveTest {

    @Mock private TaxBizMapper mockTaxBizMapper;

    @InjectMocks private TaxBizRepositoryImpl taxBizRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      final TaxBizMetaDO metaDO = new TaxBizMetaDO();
      metaDO.setId(1L);
      metaDO.setName("biz-name");
      metaDO.setDescription("desc");
      when(mockTaxBizMapper.insert(any())).thenReturn(0);

      // Run the test
      taxBizRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      verify(mockTaxBizMapper).insert(any());
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertEquals(metaDO.getCreateTime(), metaDO.getModifyTime());
      assertEquals(EnumDeleteStatus.ACTIVE, metaDO.getIsDelete());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizRepositoryImplGetAllTest {

    @Mock private TaxBizMapper mockTaxBizMapper;

    @InjectMocks private TaxBizRepositoryImpl taxBizRepositoryImplUnderTest;

    @Test
    public void testGetAll() {
      // Setup
      final GregorianCalendar cal = new GregorianCalendar(2020, Calendar.JANUARY, 1);
      final GregorianCalendar cal2 = new GregorianCalendar(2020, Calendar.FEBRUARY, 2);

      final TaxBizPO po1 = new TaxBizPO();
      po1.setId(1L);
      po1.setName("name1");
      po1.setCode("code1");
      po1.setOperatorId(11);
      po1.setCreateTime(cal.getTime());
      po1.setModifyTime(cal2.getTime());
      po1.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      final TaxBizPO po2 = new TaxBizPO();
      po2.setId(2L);
      po2.setName("name2");
      po2.setCode("code2");
      po2.setOperatorId(22);
      po2.setCreateTime(cal.getTime());
      po2.setModifyTime(cal2.getTime());
      po2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      final List<TaxBizMetaDO> result = taxBizRepositoryImplUnderTest.getAll();

      // Verify the results
      assertEquals(2, result.size());

      final TaxBizMetaDO meta1 = result.get(0);
      assertEquals(Long.valueOf(1L), meta1.getId());
      assertEquals("name1", meta1.getName());
      assertEquals("code1", meta1.getDescription());
      assertEquals(Integer.valueOf(11), meta1.getOperatorId());
      assertEquals(cal.getTime(), meta1.getCreateTime());
      assertEquals(cal2.getTime(), meta1.getModifyTime());
      assertEquals(EnumDeleteStatus.ACTIVE, meta1.getIsDelete());

      final TaxBizMetaDO meta2 = result.get(1);
      assertEquals(Long.valueOf(2L), meta2.getId());
      assertEquals("name2", meta2.getName());
      assertEquals("code2", meta2.getDescription());
      assertEquals(Integer.valueOf(22), meta2.getOperatorId());
      assertEquals(cal.getTime(), meta2.getCreateTime());
      assertEquals(cal2.getTime(), meta2.getModifyTime());
      assertEquals(EnumDeleteStatus.ACTIVE, meta2.getIsDelete());

      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }

    @Test
    public void testGetAll_TaxBizMapperReturnsNoItems() {
      // Setup
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Collections.emptyList());

      // Run the test
      final List<TaxBizMetaDO> result = taxBizRepositoryImplUnderTest.getAll();

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxBizMapper).selectByExample(any(TaxBizPOExample.class));
    }
  }
}
