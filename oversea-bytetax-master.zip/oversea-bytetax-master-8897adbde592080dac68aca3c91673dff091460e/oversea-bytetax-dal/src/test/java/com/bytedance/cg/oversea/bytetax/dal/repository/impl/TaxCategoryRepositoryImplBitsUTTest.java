package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxCategoryQuery;
import java.util.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxCategoryRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplQueryTaxCategoryListTest {

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxCategoryRepositoryImpl taxCategoryRepositoryImplUnderTest;

    @Test
    public void testQueryTaxCategoryList_ReturnsMappedResult() {
      TaxCategoryPO po = new TaxCategoryPO();
      po.setId(1L);
      po.setCode("VAT00001");
      po.setCategory("VAT");
      po.setClassify(EnumTaxClassify.TURNOVER.getCode());
      po.setDescription("desc");
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setTaxAdminId(100L);
      po.setCreateTime(new Date());
      po.setModifyTime(new Date());
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Arrays.asList(po));

      TaxCategoryQuery query = new TaxCategoryQuery();
      PageResult<TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.queryTaxCategoryList(query);

      assertEquals(1L, result.getTotal().longValue());
      assertEquals(1, result.getData().size());
      TaxCategoryMetaDO meta = result.getData().iterator().next();
      assertEquals(Long.valueOf(1L), meta.getId());
      assertEquals("VAT00001", meta.getCode());
      assertEquals("VAT", meta.getCategory());
      assertEquals(EnumTaxClassify.TURNOVER, meta.getTaxClassify());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());

      ArgumentCaptor<TaxCategoryPOExample> captor =
          ArgumentCaptor.forClass(TaxCategoryPOExample.class);
      verify(mockTaxCategoryMapper).selectByExample(captor.capture());
      TaxCategoryPOExample exampleUsed = captor.getValue();
      assertEquals("modify_time desc", exampleUsed.getOrderByClause());
    }

    @Test
    public void testQueryTaxCategoryList_WithFiltersAndPagination() {
      TaxCategoryPO po = new TaxCategoryPO();
      po.setId(2L);
      po.setCode("WHT00002");
      po.setCategory("WHT");
      po.setClassify(EnumTaxClassify.WITHHOLDING.getCode());
      po.setDescription("withholding tax");
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setTaxAdminId(200L);
      po.setCreateTime(new Date());
      po.setModifyTime(new Date());
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Arrays.asList(po));

      TaxCategoryQuery query = new TaxCategoryQuery();
      query.setId(2L);
      query.setCode("WHT_02%");
      query.setCategory("WHT");
      query.setTaxClassify(EnumTaxClassify.WITHHOLDING);
      query.setDescription("withholding");
      query.setTaxAdminId(200L);
      query.setPageNumber(1);
      query.setPageSize(10);

      PageResult<TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.queryTaxCategoryList(query);

      assertEquals(1L, result.getTotal().longValue());
      assertEquals(1, result.getData().size());
      TaxCategoryMetaDO meta = result.getData().iterator().next();
      assertEquals(Long.valueOf(2L), meta.getId());
      assertEquals("WHT00002", meta.getCode());
      assertEquals("WHT", meta.getCategory());
      assertEquals(EnumTaxClassify.WITHHOLDING, meta.getTaxClassify());

      ArgumentCaptor<TaxCategoryPOExample> captor =
          ArgumentCaptor.forClass(TaxCategoryPOExample.class);
      verify(mockTaxCategoryMapper).selectByExample(captor.capture());
      TaxCategoryPOExample exampleUsed = captor.getValue();
      assertEquals("modify_time desc", exampleUsed.getOrderByClause());
    }

    @Test
    public void testQueryTaxCategoryList_MapperReturnsEmpty() {
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Collections.<TaxCategoryPO>emptyList());

      TaxCategoryQuery query = new TaxCategoryQuery();
      PageResult<TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.queryTaxCategoryList(query);

      assertEquals(0L, result.getTotal().longValue());
      assertEquals(Collections.emptyList(), result.getData());
    }
  }

  @RunWith(org.mockito.junit.MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplSaveTest {

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxCategoryRepositoryImpl taxCategoryRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      TaxCategoryMetaDO metaDO = new TaxCategoryMetaDO();
      metaDO.setCategory("CAT");

      // insert 时模拟数据库回写主键
      doAnswer(
              invocation -> {
                TaxCategoryPO po = invocation.getArgument(0);
                po.setId(42L);
                return 1;
              })
          .when(mockTaxCategoryMapper)
          .insert(any(TaxCategoryPO.class));
      when(mockTaxCategoryMapper.updateByPrimaryKeySelective(any(TaxCategoryPO.class)))
          .thenReturn(1);

      // Run
      TaxCategoryMetaDO result = taxCategoryRepositoryImplUnderTest.save(metaDO);

      // Verify mapper 调用
      verify(mockTaxCategoryMapper).insert(any(TaxCategoryPO.class));
      ArgumentCaptor<TaxCategoryPO> updateCaptor = ArgumentCaptor.forClass(TaxCategoryPO.class);
      verify(mockTaxCategoryMapper).updateByPrimaryKeySelective(updateCaptor.capture());

      // 校验 update 时的 code 已按规则生成
      TaxCategoryPO updatedPO = updateCaptor.getValue();
      assertEquals("CAT00042", updatedPO.getCode());

      // 校验返回值
      assertEquals(Long.valueOf(42L), result.getId());
      assertEquals("CAT00042", result.getCode());
      assertEquals("CAT", result.getCategory());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
      assertNotNull(result.getCreateTime());
      assertNotNull(result.getModifyTime());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplGetTaxCategoryByIdTest {

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxCategoryRepositoryImpl taxCategoryRepositoryImplUnderTest;

    @Test
    public void testGetTaxCategoryById_NullId() {
      final TaxCategoryMetaDO result = taxCategoryRepositoryImplUnderTest.getTaxCategoryById(null);
      assertNull(result);
    }

    @Test
    public void testGetTaxCategoryById_NotFound() {
      final Long id = 1L;
      when(mockTaxCategoryMapper.selectByPrimaryKey(id)).thenReturn(null);

      final TaxCategoryMetaDO result = taxCategoryRepositoryImplUnderTest.getTaxCategoryById(id);

      assertNull(result);
      verify(mockTaxCategoryMapper).selectByPrimaryKey(id);
    }

    @Test
    public void testGetTaxCategoryById_Success() {
      final Long id = 2L;
      final TaxCategoryPO taxCategoryPO = new TaxCategoryPO();
      taxCategoryPO.setId(id);
      taxCategoryPO.setCode("CODE123");
      taxCategoryPO.setCategory("CATEGORY_A");
      when(mockTaxCategoryMapper.selectByPrimaryKey(id)).thenReturn(taxCategoryPO);

      final TaxCategoryMetaDO result = taxCategoryRepositoryImplUnderTest.getTaxCategoryById(id);

      assertNotNull(result);
      assertEquals(id, result.getId());
      assertEquals("CODE123", result.getCode());
      assertEquals("CATEGORY_A", result.getCategory());
      verify(mockTaxCategoryMapper).selectByPrimaryKey(id);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplGetTaxCategoriesByIdsTest {

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxCategoryRepositoryImpl taxCategoryRepositoryImplUnderTest;

    @Test
    public void testGetTaxCategoriesByIds_EmptyIdsReturnsEmptyMap() {
      // Run
      final Map<Long, TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.getTaxCategoriesByIds(Collections.<Long>emptyList());

      // Verify
      assertEquals(0, result.size());
    }

    @Test
    public void testGetTaxCategoriesByIds_Normal() {
      // Setup
      final TaxCategoryPO po1 = new TaxCategoryPO();
      po1.setId(1L);
      po1.setCategory("CAT_A");
      final TaxCategoryPO po2 = new TaxCategoryPO();
      po2.setId(2L);
      po2.setCategory("CAT_B");
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run
      final Map<Long, TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.getTaxCategoriesByIds(Arrays.asList(1L, 2L));

      // Verify
      verify(mockTaxCategoryMapper).selectByExample(any(TaxCategoryPOExample.class));
      assertEquals(2, result.size());
      assertTrue(result.containsKey(1L));
      assertTrue(result.containsKey(2L));
      assertEquals(Long.valueOf(1L), result.get(1L).getId());
      assertEquals(Long.valueOf(2L), result.get(2L).getId());
    }

    @Test
    public void testGetTaxCategoriesByIds_MapperReturnsNull() {
      // Setup
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class))).thenReturn(null);

      // Run
      final Map<Long, TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.getTaxCategoriesByIds(Arrays.asList(10L));

      // Verify
      assertEquals(0, result.size());
    }

    @Test
    public void testGetTaxCategoriesByIds_NullIdsReturnsEmptyMap() {
      // Run
      final Map<Long, TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.getTaxCategoriesByIds(null);

      // Verify
      assertEquals(0, result.size());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplQueryAllTaxRateTest {

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxCategoryRepositoryImpl taxCategoryRepositoryImplUnderTest;

    @Test
    public void testQueryAllTaxRate_ReturnsMappedList() {
      // Setup
      TaxCategoryPO po = new TaxCategoryPO();
      po.setId(1L);
      po.setCode("CODE001");
      po.setCategory("CAT");
      po.setClassify(EnumTaxClassify.TURNOVER.getCode());
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setValidTaxRate("[]");
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      List<TaxCategoryMetaDO> result = taxCategoryRepositoryImplUnderTest.queryAllTaxRate();

      // Verify the results
      assertEquals(1, result.size());
      TaxCategoryMetaDO meta = result.get(0);
      assertEquals(Long.valueOf(1L), meta.getId());
      assertEquals("CODE001", meta.getCode());
      assertEquals("CAT", meta.getCategory());
      assertEquals(EnumTaxClassify.TURNOVER, meta.getTaxClassify());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());

      // Verify mapper invocation and example criteria
      ArgumentCaptor<TaxCategoryPOExample> captor =
          ArgumentCaptor.forClass(TaxCategoryPOExample.class);
      verify(mockTaxCategoryMapper).selectByExample(captor.capture());
      TaxCategoryPOExample usedExample = captor.getValue();
      assertEquals(1, usedExample.getOredCriteria().size());
      boolean hasIsDeleteActive = false;
      for (Object c : usedExample.getOredCriteria().get(0).getAllCriteria()) {
        TaxCategoryPOExample.Criterion criterion = (TaxCategoryPOExample.Criterion) c;
        if ("is_delete =".equals(criterion.getCondition())
            && EnumDeleteStatus.ACTIVE.getCode().equals(criterion.getValue())) {
          hasIsDeleteActive = true;
          break;
        }
      }
      assertEquals(true, hasIsDeleteActive);
    }

    @Test
    public void testQueryAllTaxRate_EmptyList() {
      // Setup
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Collections.<TaxCategoryPO>emptyList());

      // Run the test
      List<TaxCategoryMetaDO> result = taxCategoryRepositoryImplUnderTest.queryAllTaxRate();

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxCategoryMapper).selectByExample(any(TaxCategoryPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplQueryByIdsTest {

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxCategoryRepositoryImpl taxCategoryRepositoryImplUnderTest;

    @Test
    public void testQueryByIds_EmptyIds() {
      // Setup
      // Run the test
      final List<TaxCategoryMetaDO> result =
          taxCategoryRepositoryImplUnderTest.queryByIds(Collections.<Long>emptyList());

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxCategoryMapper, never()).selectByExample(any(TaxCategoryPOExample.class));
    }

    @Test
    public void testQueryByIds_NullIds() {
      // Setup
      // Run the test
      final List<TaxCategoryMetaDO> result = taxCategoryRepositoryImplUnderTest.queryByIds(null);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxCategoryMapper, never()).selectByExample(any(TaxCategoryPOExample.class));
    }

    @Test
    public void testQueryByIds_NonEmptyIdsBuildsCorrectExampleAndCallsMapper() {
      // Setup
      final List<Long> ids = Arrays.asList(1L, 2L, 3L);
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Collections.<TaxCategoryPO>emptyList());

      // Run the test
      final List<TaxCategoryMetaDO> result = taxCategoryRepositoryImplUnderTest.queryByIds(ids);

      // Verify the results
      assertEquals(0, result.size());

      ArgumentCaptor<TaxCategoryPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxCategoryPOExample.class);
      verify(mockTaxCategoryMapper).selectByExample(exampleCaptor.capture());
      TaxCategoryPOExample captured = exampleCaptor.getValue();

      // Verify criteria contains "id in" with the provided ids
      boolean hasIdIn = false;
      for (TaxCategoryPOExample.Criteria c : captured.getOredCriteria()) {
        List<TaxCategoryPOExample.Criterion> criteria = c.getAllCriteria();
        for (TaxCategoryPOExample.Criterion criterion : criteria) {
          if ("id in".equals(criterion.getCondition())) {
            hasIdIn = true;
            Object value = criterion.getValue();
            if (value instanceof List) {
              List listValue = (List) value;
              assertEquals(ids.size(), listValue.size());
              // Verify elements
              for (int i = 0; i < ids.size(); i++) {
                assertEquals(ids.get(i), listValue.get(i));
              }
            }
          }
        }
      }
      assertEquals(true, hasIdIn);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxCategoryRepositoryImpl taxCategoryRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective() {
      // Setup
      when(mockTaxCategoryMapper.updateByPrimaryKeySelective(any())).thenReturn(1);
      TaxCategoryMetaDO input = new TaxCategoryMetaDO();
      input.setId(123L);
      input.setCategory("CAT");

      // Run the test
      TaxCategoryMetaDO result = taxCategoryRepositoryImplUnderTest.updateByIdSelective(input);

      // Verify mapper invocation and capture argument
      ArgumentCaptor<TaxCategoryPO> captor = ArgumentCaptor.forClass(TaxCategoryPO.class);
      verify(mockTaxCategoryMapper).updateByPrimaryKeySelective(captor.capture());
      TaxCategoryPO passedPO = captor.getValue();

      // Verify metaDO was updated with modifyTime and propagated to PO
      assertNotNull(input.getModifyTime());
      assertEquals(input.getModifyTime(), passedPO.getModifyTime());

      // Verify fields mapped correctly to PO
      assertEquals(input.getId(), passedPO.getId());
      assertEquals(input.getCategory(), passedPO.getCategory());

      // Verify return value is mapped back from PO
      assertNotNull(result);
      assertEquals(passedPO.getId(), result.getId());
      assertEquals(passedPO.getCategory(), result.getCategory());
      assertEquals(passedPO.getModifyTime(), result.getModifyTime());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryRepositoryImplGenCodeTest {

    @Test
    public void testGenCode_Normal() {
      TaxCategoryRepositoryImpl repo = new TaxCategoryRepositoryImpl();
      String result = repo.genCode("VAT", 12L);
      assertEquals("VAT00012", result);
    }

    @Test
    public void testGenCode_LargeId() {
      TaxCategoryRepositoryImpl repo = new TaxCategoryRepositoryImpl();
      String result = repo.genCode("VAT", 123456L);
      assertEquals("VAT123456", result);
    }

    @Test
    public void testGenCode_ZeroId() {
      TaxCategoryRepositoryImpl repo = new TaxCategoryRepositoryImpl();
      String result = repo.genCode("VAT", 0L);
      assertEquals("VAT00000", result);
    }

    @Test
    public void testGenCode_NullCategory() {
      TaxCategoryRepositoryImpl repo = new TaxCategoryRepositoryImpl();
      String result = repo.genCode(null, 12L);
      assertEquals("null00012", result);
    }

    @Test
    public void testGenCode_NegativeId() {
      TaxCategoryRepositoryImpl repo = new TaxCategoryRepositoryImpl();
      String result = repo.genCode("VAT", -12L);
      assertEquals("VAT-0012", result);
    }
  }
}
