package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxItemBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxItemBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPOExample.Criteria;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemBindPOExample.Criterion;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxItemBindRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemBindRepositoryImplQueryByPlatformItemCodeTest {

    @Mock private TaxItemBindMapper mockTaxItemBindMapper;

    @InjectMocks private TaxItemBindRepositoryImpl taxItemBindRepositoryImplUnderTest;

    @Test
    public void testQueryByPlatformItemCode_Success() {
      when(mockTaxItemBindMapper.selectByExample(any(TaxItemBindPOExample.class)))
          .thenReturn(Arrays.asList(new TaxItemBindPO()));

      TaxItemBindMetaDO result =
          taxItemBindRepositoryImplUnderTest.queryByPlatformItemCode("123", 10L);

      assertNotNull(result);
      verify(mockTaxItemBindMapper).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByPlatformItemCode_ReturnsNullWhenEmptyList() {
      when(mockTaxItemBindMapper.selectByExample(any(TaxItemBindPOExample.class)))
          .thenReturn(Collections.emptyList());

      TaxItemBindMetaDO result =
          taxItemBindRepositoryImplUnderTest.queryByPlatformItemCode("123", 10L);

      assertNull(result);
      verify(mockTaxItemBindMapper).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByPlatformItemCode_ReturnsNullWhenInvalidArgs() {
      TaxItemBindMetaDO result1 =
          taxItemBindRepositoryImplUnderTest.queryByPlatformItemCode("", 10L);
      assertNull(result1);
      verify(mockTaxItemBindMapper, never()).selectByExample(any(TaxItemBindPOExample.class));

      TaxItemBindMetaDO result2 =
          taxItemBindRepositoryImplUnderTest.queryByPlatformItemCode("123", null);
      assertNull(result2);
      verify(mockTaxItemBindMapper, never()).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByPlatformItemCode_ThrowsNumberFormatExceptionForNonNumeric() {
      try {
        taxItemBindRepositoryImplUnderTest.queryByPlatformItemCode("abc", 10L);
        fail("Expected NumberFormatException to be thrown");
      } catch (NumberFormatException e) {
        // expected
      }
      verify(mockTaxItemBindMapper, never()).selectByExample(any(TaxItemBindPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemBindRepositoryImplQueryByBizItemCodeTest {

    @Mock private TaxItemBindMapper mockTaxItemBindMapper;

    @InjectMocks private TaxItemBindRepositoryImpl taxItemBindRepositoryImplUnderTest;

    @Test
    public void testQueryByBizItemCode() {
      // Setup
      final TaxItemBindPO po = new TaxItemBindPO();
      try {
        // avoid NPE in mapping for isDelete
        TaxItemBindPO.class.getMethod("setIsDelete", Integer.class).invoke(po, 0);
      } catch (Exception ignored) {
      }
      final List<TaxItemBindPO> list = Arrays.asList(po);
      when(mockTaxItemBindMapper.selectByExample(any(TaxItemBindPOExample.class))).thenReturn(list);

      // Run the test
      final TaxItemBindMetaDO result =
          taxItemBindRepositoryImplUnderTest.queryByBizItemCode("ITEM_CODE", 1L);

      // Verify the results
      assertNotNull(result);
      verify(mockTaxItemBindMapper).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByBizItemCode_TaxItemBindMapperReturnsNoItems() {
      // Setup
      when(mockTaxItemBindMapper.selectByExample(any(TaxItemBindPOExample.class)))
          .thenReturn(Collections.emptyList());

      // Run the test
      final TaxItemBindMetaDO result =
          taxItemBindRepositoryImplUnderTest.queryByBizItemCode("ITEM_CODE", 1L);

      // Verify the results
      assertNull(result);
      verify(mockTaxItemBindMapper).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByBizItemCode_ItemCodeEmpty() {
      // Run the test
      final TaxItemBindMetaDO result =
          taxItemBindRepositoryImplUnderTest.queryByBizItemCode("", 1L);

      // Verify the results
      assertNull(result);
      verify(mockTaxItemBindMapper, never()).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByBizItemCode_ItemCodeNull() {
      // Run the test
      final TaxItemBindMetaDO result =
          taxItemBindRepositoryImplUnderTest.queryByBizItemCode(null, 1L);

      // Verify the results
      assertNull(result);
      verify(mockTaxItemBindMapper, never()).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByBizItemCode_BizLineIdNull() {
      // Run the test
      final TaxItemBindMetaDO result =
          taxItemBindRepositoryImplUnderTest.queryByBizItemCode("ITEM_CODE", null);

      // Verify the results
      assertNull(result);
      verify(mockTaxItemBindMapper, never()).selectByExample(any(TaxItemBindPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxItemBindRepositoryImplQueryByItemIdTest {

    @Mock private TaxItemBindMapper mockTaxItemBindMapper;

    @InjectMocks private TaxItemBindRepositoryImpl taxItemBindRepositoryImplUnderTest;

    @Test
    public void testQueryByItemId_NullParam() {
      // Run the test
      final TaxItemBindMetaDO result = taxItemBindRepositoryImplUnderTest.queryByItemId(null);

      // Verify the results
      assertNull(result);
      verify(mockTaxItemBindMapper, never()).selectByExample(any(TaxItemBindPOExample.class));
    }

    @Test
    public void testQueryByItemId_Found() {
      // Setup
      Long itemId = 123L;
      TaxItemBindPO po = new TaxItemBindPO();
      // 由于映射中会用到isDelete字段，至少设置isDelete为ACTIVE
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      // 设置itemId以符合查询条件
      try {
        po.getClass().getMethod("setItemId", Long.class).invoke(po, itemId);
      } catch (Exception ignore) {
        // 如果PO没有该setter也不影响本用例
      }
      when(mockTaxItemBindMapper.selectByExample(any(TaxItemBindPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      final TaxItemBindMetaDO result = taxItemBindRepositoryImplUnderTest.queryByItemId(itemId);

      // Verify the results
      assertNotNull(result);

      ArgumentCaptor<TaxItemBindPOExample> captor =
          ArgumentCaptor.forClass(TaxItemBindPOExample.class);
      verify(mockTaxItemBindMapper).selectByExample(captor.capture());
      TaxItemBindPOExample example = captor.getValue();
      assertNotNull(example);
      assertTrue(example.getOredCriteria() != null && !example.getOredCriteria().isEmpty());

      Criteria criteria = example.getOredCriteria().get(0);
      List<Criterion> criterionList = criteria.getAllCriteria();
      assertTrue(containsEqualCondition(criterionList, "item_id =", itemId));
      assertTrue(
          containsEqualCondition(criterionList, "is_delete =", EnumDeleteStatus.ACTIVE.getCode()));
    }

    @Test
    public void testQueryByItemId_EmptyResult() {
      // Setup
      when(mockTaxItemBindMapper.selectByExample(any(TaxItemBindPOExample.class)))
          .thenReturn(Collections.<TaxItemBindPO>emptyList());

      // Run the test
      final TaxItemBindMetaDO result = taxItemBindRepositoryImplUnderTest.queryByItemId(1L);

      // Verify the results
      assertNull(result);
      verify(mockTaxItemBindMapper).selectByExample(any(TaxItemBindPOExample.class));
    }

    // helper
    private boolean containsEqualCondition(List<Criterion> list, String condition, Object value) {
      if (list == null) {
        return false;
      }
      for (Criterion c : list) {
        if (condition.equals(c.getCondition())) {
          Object v = c.getValue();
          if (v == null && value == null) {
            return true;
          }
          if (v != null && v.equals(value)) {
            return true;
          }
        }
      }
      return false;
    }
  }
}
