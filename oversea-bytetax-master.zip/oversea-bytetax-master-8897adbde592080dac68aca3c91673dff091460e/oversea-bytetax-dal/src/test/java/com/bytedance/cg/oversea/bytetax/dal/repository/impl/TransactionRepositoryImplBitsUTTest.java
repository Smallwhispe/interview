package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxCalculateType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxReporterType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionType;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TransactionMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TransactionQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminSubjectRepository;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCountryBindRepository;
import java.math.BigDecimal;
import java.util.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TransactionRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTransactionMetaDOSHaeb9bTest {

    @Mock private TransactionMapper mockTransactionMapper;
    @Mock private TaxAdminSubjectRepository mockTaxAdminSubjectRepository;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTransactionMetaDOS_SubjectBindIdsEmpty() {
      TransactionQuery query = new TransactionQuery();
      query.setSubjectId(1L);
      query.setPageNumber(1);
      query.setPageSize(10);
      when(mockTaxAdminSubjectRepository.queryTaxAdminSubjectBySubjectId(1L))
          .thenReturn(Collections.<Long>emptyList());

      PageResult<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionMetaDOS(query);

      assertEquals(0L, result.getTotal().longValue());
      assertEquals(Collections.emptyList(), result.getData());
    }

    @Test
    public void testQueryTransactionMetaDOS_ReturnsDataFromMapper() {
      TransactionQuery query = new TransactionQuery();
      query.setSubjectId(2L);
      query.setPageNumber(1);
      query.setPageSize(10);
      when(mockTaxAdminSubjectRepository.queryTaxAdminSubjectBySubjectId(2L))
          .thenReturn(Arrays.asList(100L, 101L));

      TransactionPO po1 = new TransactionPO();
      po1.setId(10L);
      po1.setInvoiceNo("INV-001");
      po1.setIsDelete(0);
      TransactionPO po2 = new TransactionPO();
      po2.setId(11L);
      po2.setInvoiceNo("INV-002");
      po2.setIsDelete(0);
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      PageResult<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionMetaDOS(query);

      assertEquals(2L, result.getTotal().longValue());
      assertEquals(2, result.getData().size());
      Set<String> invoiceNos = new HashSet<String>();
      for (TransactionMetaDO m : result.getData()) {
        invoiceNos.add(m.getInvoiceNo());
      }
      Set<String> expected = new HashSet<String>(Arrays.asList("INV-001", "INV-002"));
      assertEquals(expected, invoiceNos);
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQueryTransactionMetaDOS_FiltersAndPagination_NoException() {
      TransactionQuery query = new TransactionQuery();
      query.setId(99L);
      query.setTransactionTimeBegin(new DateTime(2020, 1, 1, 0, 0));
      query.setTransactionTimeEnd(new DateTime(2020, 1, 31, 23, 59));
      query.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE);
      query.setAccountNameKw(" Alice ");
      query.setBillingAddressIdL0(123L);
      query.setBillingAddressIdL1(456L);
      query.setPageNumber(2);
      query.setPageSize(5);

      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.<TransactionPO>emptyList());

      PageResult<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionMetaDOS(query);

      assertEquals(0L, result.getTotal().longValue());
      assertEquals(Collections.emptyList(), result.getData());
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTransactionMetaDOSH088e8Test {

    @Mock private TransactionMapper transactionMapper;

    @Mock private TaxAdminSubjectRepository taxAdminSubjectRepository;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTransactionMetaDOS_ReturnsEmptyWhenNoAdminBindIds() {
      // Setup
      Long subjectId = 100L;
      when(taxAdminSubjectRepository.queryTaxAdminSubjectBySubjectId(subjectId))
          .thenReturn(Collections.<Long>emptyList());

      // Run the test
      final List<TransactionPO> resultList =
          transactionRepositoryImplUnderTest
              .queryTransactionMetaDOS(subjectId, null, 1, 10, null, null)
              .getList();

      // Verify the results
      assertTrue(resultList.isEmpty());
      verify(taxAdminSubjectRepository).queryTaxAdminSubjectBySubjectId(subjectId);
      verify(transactionMapper, never()).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQueryTransactionMetaDOS_WithSubjectTimeAdminIdsAndPaging() {
      // Setup
      Long subjectId = 200L;
      List<Long> adminBindIds = Arrays.asList(11L, 12L);
      List<Long> adminIds = Arrays.asList(1L, 2L);
      DateTime startTime = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      DateTime endTime = new DateTime(2020, 1, 31, 0, 0, 0, 0);

      when(taxAdminSubjectRepository.queryTaxAdminSubjectBySubjectId(subjectId))
          .thenReturn(adminBindIds);

      TransactionPO po1 = new TransactionPO();
      po1.setId(1L);
      po1.setInvoiceNo("INV-1");
      po1.setTotalTaxable(new BigDecimal("10"));

      TransactionPO po2 = new TransactionPO();
      po2.setId(2L);
      po2.setInvoiceNo("INV-2");
      po2.setTotalTaxable(new BigDecimal("20"));

      when(transactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run the test
      final List<TransactionPO> resultList =
          transactionRepositoryImplUnderTest
              .queryTransactionMetaDOS(subjectId, adminIds, 1, 20, startTime, endTime)
              .getList();

      // Verify the results
      assertEquals(2, resultList.size());
      assertEquals(Long.valueOf(1L), resultList.get(0).getId());
      assertEquals(Long.valueOf(2L), resultList.get(1).getId());

      verify(taxAdminSubjectRepository).queryTaxAdminSubjectBySubjectId(subjectId);
      ArgumentCaptor<TransactionPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TransactionPOExample.class);
      verify(transactionMapper).selectByExample(exampleCaptor.capture());

      TransactionPOExample usedExample = exampleCaptor.getValue();
      assertEquals("id", usedExample.getOrderByClause());
    }

    @Test
    public void testQueryTransactionMetaDOS_NoSubjectWithAdminIdsAndTime() {
      // Setup
      Long subjectId = null;
      List<Long> adminIds = Arrays.asList(100L, 200L);
      DateTime startTime = new DateTime(2021, 5, 1, 0, 0, 0, 0);
      DateTime endTime = new DateTime(2021, 5, 31, 23, 59, 59, 0);

      TransactionPO po = new TransactionPO();
      po.setId(10L);
      po.setInvoiceNo("INV-10");

      when(transactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.singletonList(po));

      // Run the test
      final List<TransactionPO> resultList =
          transactionRepositoryImplUnderTest
              .queryTransactionMetaDOS(subjectId, adminIds, null, null, startTime, endTime)
              .getList();

      // Verify the results
      assertEquals(1, resultList.size());
      assertEquals(Long.valueOf(10L), resultList.get(0).getId());

      ArgumentCaptor<TransactionPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TransactionPOExample.class);
      verify(transactionMapper).selectByExample(exampleCaptor.capture());
      assertEquals("id", exampleCaptor.getValue().getOrderByClause());
      verify(taxAdminSubjectRepository, never()).queryTaxAdminSubjectBySubjectId(any(Long.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQuerySalesInvoiceByBizIdTest {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQuerySalesInvoiceByBizId_Blank() {
      // Run the test
      final TransactionMetaDO result =
          transactionRepositoryImplUnderTest.querySalesInvoiceByBizId("");

      // Verify the results
      assertNull(result);
      verify(mockTransactionMapper, never()).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQuerySalesInvoiceByBizId_MapperReturnsEmpty() {
      // Setup
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.<TransactionPO>emptyList());

      // Run the test
      final TransactionMetaDO result =
          transactionRepositoryImplUnderTest.querySalesInvoiceByBizId("INV-001");

      // Verify the results
      assertNull(result);
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQuerySalesInvoiceByBizId_MultipleResults() {
      // Setup
      TransactionPO po1 = new TransactionPO();
      po1.setId(1L);
      po1.setInvoiceNo("INV-001");
      po1.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE.getCode());
      po1.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      TransactionPO po2 = new TransactionPO();
      po2.setId(2L);
      po2.setInvoiceNo("INV-001");
      po2.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE.getCode());
      po2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      List<TransactionPO> pos = Arrays.asList(po1, po2);
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class))).thenReturn(pos);

      // Run the test
      final TransactionMetaDO result =
          transactionRepositoryImplUnderTest.querySalesInvoiceByBizId("INV-001");

      // Verify the results
      assertNull(result);
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQuerySalesInvoiceByBizId_SingleResult() {
      // Setup
      TransactionPO po = new TransactionPO();
      po.setId(100L);
      po.setInvoiceNo("INV-100");
      po.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE.getCode());
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      final TransactionMetaDO result =
          transactionRepositoryImplUnderTest.querySalesInvoiceByBizId("INV-100");

      // Verify the results
      assertNotNull(result);
      assertEquals("INV-100", result.getInvoiceNo());
      assertEquals(EnumTransactionCategory.SALES_INVOICE, result.getTransactionCategory());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTransactionMetaDOSH24951Test {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTransactionMetaDOS_ReturnsMappedListAndSetsExampleFields() {
      // 准备数据
      Long adminId = 123L;
      Long offsetId = 456L;
      int limit = 10;
      DateTime startTime = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      DateTime endTime = new DateTime(2020, 12, 31, 23, 59, 59, 0);

      TransactionPO po = new TransactionPO();
      po.setId(789L);
      po.setInvoiceNo("INV-1");
      po.setTaxAdminId(adminId);
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setTaxReporterType(EnumTaxReporterType.GEN_REPORTER.getCode());
      po.setInvoiceDate(new GregorianCalendar(2020, Calendar.JUNE, 1).getTime());

      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.singletonList(po));

      // 执行
      List<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionMetaDOS(
              adminId, offsetId, limit, startTime, endTime);

      // 断言映射结果
      assertEquals(1, result.size());
      TransactionMetaDO meta = result.get(0);
      assertEquals(Long.valueOf(789L), meta.getId());
      assertEquals("INV-1", meta.getInvoiceNo());
      assertEquals(adminId, meta.getTaxAdminId());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());
      assertEquals(EnumTaxReporterType.GEN_REPORTER, meta.getTaxReporterType());
      assertTrue(meta.getInvoiceDate() != null);

      // 捕获并断言Example设置
      ArgumentCaptor<TransactionPOExample> captor =
          ArgumentCaptor.forClass(TransactionPOExample.class);
      verify(mockTransactionMapper).selectByExample(captor.capture());
      TransactionPOExample exampleUsed = captor.getValue();
      assertEquals("id", exampleUsed.getOrderByClause());
      assertEquals(Integer.valueOf(limit), exampleUsed.getRows());
    }

    @Test
    public void testQueryTransactionMetaDOS_EmptyResult() {
      // 准备数据
      Long adminId = 1L;
      Long offsetId = 0L;
      int limit = 5;
      DateTime startTime = new DateTime(2021, 1, 1, 0, 0, 0, 0);
      DateTime endTime = new DateTime(2021, 2, 1, 0, 0, 0, 0);

      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.emptyList());

      // 执行
      List<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionMetaDOS(
              adminId, offsetId, limit, startTime, endTime);

      // 断言
      assertEquals(0, result.size());

      // 验证调用
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTransactionByIdsTest {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTransactionByIds_SortedByInvoiceDateDescAndFilterNull() {
      TransactionPO poOld = new TransactionPO();
      poOld.setId(1L);
      poOld.setInvoiceNo("INV-OLD");
      poOld.setInvoiceDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());

      TransactionPO poNew = new TransactionPO();
      poNew.setId(2L);
      poNew.setInvoiceNo("INV-NEW");
      poNew.setInvoiceDate(new GregorianCalendar(2021, Calendar.JANUARY, 1).getTime());

      List<TransactionPO> returnedList = Arrays.asList(poOld, null, poNew);
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(returnedList);

      PageResult<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionByIds(Arrays.asList(1L, 2L));

      assertEquals(3L, result.getTotal().longValue());
      List<TransactionMetaDO> dataList = new ArrayList<TransactionMetaDO>(result.getData());
      assertEquals(2, dataList.size());
      Date firstDate = dataList.get(0).getInvoiceDate();
      Date secondDate = dataList.get(1).getInvoiceDate();
      assertTrue(firstDate.after(secondDate));
    }

    @Test
    public void testQueryTransactionByIds_EmptyIds() {
      PageResult<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionByIds(Collections.<Long>emptyList());

      assertEquals(0L, result.getTotal().longValue());
      assertEquals(0, result.getData().size());
    }

    @Test
    public void testQueryTransactionByIds_NoRecordsFound() {
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.<TransactionPO>emptyList());

      PageResult<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionByIds(Arrays.asList(10L, 20L));

      assertEquals(0L, result.getTotal().longValue());
      assertEquals(0, result.getData().size());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTaxReportTransactionTest {

    @Mock private TransactionMapper mockTransactionMapper;
    @Mock private TaxCountryBindRepository taxCountryBindRepository;
    @Mock private TaxAdminSubjectRepository taxAdminSubjectRepository;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTaxReportTransaction_Empty() {
      // Setup
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.<TransactionPO>emptyList());
      String invoiceNo = "INV-001";
      Long taxAdminId = 123L;

      // Run the test
      List<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTaxReportTransaction(invoiceNo, taxAdminId);

      // Verify the results
      assertEquals(0, result.size());

      // Verify mapper interaction
      ArgumentCaptor<TransactionPOExample> captor =
          ArgumentCaptor.forClass(TransactionPOExample.class);
      verify(mockTransactionMapper).selectByExample(captor.capture());
      // Just ensure an example object was built and passed
      TransactionPOExample example = captor.getValue();
      assertEquals(true, example != null);
    }

    @Test
    public void testQueryTaxReportTransaction_NonEmpty() {
      // Setup
      TransactionPO po = new TransactionPO();
      po.setId(1L);
      po.setInvoiceNo("INV-002");
      po.setTaxAdminId(456L);
      po.setTaxReporterType(EnumTaxReporterType.GEN_REPORTER.getCode());
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      List<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTaxReportTransaction("INV-002", 456L);

      // Verify the results
      assertEquals(1, result.size());
      TransactionMetaDO meta = result.get(0);
      assertEquals("INV-002", meta.getInvoiceNo());
      assertEquals(Long.valueOf(456L), meta.getTaxAdminId());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTransactionCntTest {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTransactionCnt() {
      when(mockTransactionMapper.countByExample(any(TransactionPOExample.class))).thenReturn(12L);
      final DateTime startTime = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      final DateTime endTime = new DateTime(2020, 2, 1, 0, 0, 0, 0);

      final Long result =
          transactionRepositoryImplUnderTest.queryTransactionCnt(
              Arrays.asList(1L, 2L), startTime, endTime);

      assertEquals(Long.valueOf(12L), result);
      ArgumentCaptor<TransactionPOExample> captor =
          ArgumentCaptor.forClass(TransactionPOExample.class);
      verify(mockTransactionMapper).countByExample(captor.capture());
      TransactionPOExample example = captor.getValue();
      assertEquals(1, example.getOredCriteria().size());
      assertEquals(true, example.getOredCriteria().get(0).isValid());
    }

    @Test
    public void testQueryTransactionCnt_ReturnsZero() {
      when(mockTransactionMapper.countByExample(any(TransactionPOExample.class))).thenReturn(0L);
      final DateTime startTime = new DateTime(2021, 3, 1, 0, 0, 0, 0);
      final DateTime endTime = new DateTime(2021, 3, 31, 23, 59, 59, 0);

      final Long result =
          transactionRepositoryImplUnderTest.queryTransactionCnt(
              Arrays.asList(10L), startTime, endTime);

      assertEquals(Long.valueOf(0L), result);
      verify(mockTransactionMapper).countByExample(any(TransactionPOExample.class));
    }

    @Test(expected = RuntimeException.class)
    public void testQueryTransactionCnt_NullAdminIds() {
      final DateTime startTime = new DateTime(2022, 1, 1, 0, 0, 0, 0);
      final DateTime endTime = new DateTime(2022, 1, 31, 23, 59, 59, 0);

      transactionRepositoryImplUnderTest.queryTransactionCnt(null, startTime, endTime);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTaxReportTransactionByInvoiceTest {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTaxReportTransactionByInvoice() {
      // Setup
      final TransactionPO po = new TransactionPO();
      po.setInvoiceNo("INV-001");
      po.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE.getCode());
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      final List<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTaxReportTransactionByInvoice("INV-001");

      // Verify the results
      assertEquals(1, result.size());
      assertEquals("INV-001", result.get(0).getInvoiceNo());
      assertEquals(EnumTransactionCategory.SALES_INVOICE, result.get(0).getTransactionCategory());
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQueryTaxReportTransactionByInvoice_ReturnsEmpty() {
      // Setup
      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Collections.<TransactionPO>emptyList());

      // Run the test
      final List<TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTaxReportTransactionByInvoice("INV-EMPTY");

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTransactionMapper).selectByExample(any(TransactionPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTransactionByInvoiceSerialsTest {

    @Mock private TransactionMapper mockTransactionMapper;
    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;
    @Mock private TaxAdminSubjectRepository mockTaxAdminSubjectRepository;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTransactionByInvoiceSerials_EmptyInput() {
      // Run the test
      final Map<String, TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionByInvoiceSerials(
              Collections.<String>emptyList());

      // Verify the results
      assertTrue(result.isEmpty());
      verify(mockTransactionMapper, never()).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQueryTransactionByInvoiceSerials_PartitionAggregation() {
      // Setup
      List<String> serials = new ArrayList<String>();
      for (int i = 0; i < 150; i++) {
        serials.add("SER-" + i);
      }

      final List<TransactionPO> firstBatchReturn =
          Arrays.asList(buildTransactionPO("SER-0", 10L), buildTransactionPO("SER-99", 11L));
      final List<TransactionPO> secondBatchReturn =
          Arrays.asList(buildTransactionPO("SER-100", 20L), buildTransactionPO("SER-149", 21L));

      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(firstBatchReturn, secondBatchReturn);

      // Run the test
      final Map<String, TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionByInvoiceSerials(serials);

      // Verify the results
      assertEquals(4, result.size());
      assertTrue(result.containsKey("SER-0"));
      assertTrue(result.containsKey("SER-99"));
      assertTrue(result.containsKey("SER-100"));
      assertTrue(result.containsKey("SER-149"));

      assertEquals("SER-0", result.get("SER-0").getInvoiceNo());
      assertEquals("SER-99", result.get("SER-99").getInvoiceNo());
      assertEquals("SER-100", result.get("SER-100").getInvoiceNo());
      assertEquals("SER-149", result.get("SER-149").getInvoiceNo());

      assertEquals(10L, result.get("SER-0").getTaxAdminId().longValue());
      assertEquals(11L, result.get("SER-99").getTaxAdminId().longValue());
      assertEquals(20L, result.get("SER-100").getTaxAdminId().longValue());
      assertEquals(21L, result.get("SER-149").getTaxAdminId().longValue());

      verify(mockTransactionMapper, times(2)).selectByExample(any(TransactionPOExample.class));
    }

    @Test
    public void testQueryTransactionByInvoiceSerials_DuplicateInvoiceMergeWithinBatch() {
      // Setup
      final List<String> serials = Arrays.asList("DUP-1", "OTHER-2");

      final TransactionPO dupFirst = buildTransactionPO("DUP-1", 111L);
      final TransactionPO dupSecond = buildTransactionPO("DUP-1", 222L);
      final TransactionPO other = buildTransactionPO("OTHER-2", 333L);

      when(mockTransactionMapper.selectByExample(any(TransactionPOExample.class)))
          .thenReturn(Arrays.asList(dupFirst, dupSecond, other));

      // Run the test
      final Map<String, TransactionMetaDO> result =
          transactionRepositoryImplUnderTest.queryTransactionByInvoiceSerials(serials);

      // Verify the results
      assertEquals(2, result.size());
      assertTrue(result.containsKey("DUP-1"));
      assertTrue(result.containsKey("OTHER-2"));

      // Merge function should keep the latter one
      assertEquals(222L, result.get("DUP-1").getTaxAdminId().longValue());
      assertEquals(333L, result.get("OTHER-2").getTaxAdminId().longValue());

      verify(mockTransactionMapper, times(1)).selectByExample(any(TransactionPOExample.class));
    }

    private TransactionPO buildTransactionPO(String invoiceNo, Long taxAdminId) {
      TransactionPO po = new TransactionPO();
      po.setInvoiceNo(invoiceNo);
      po.setTaxAdminId(taxAdminId);
      return po;
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplDeleteTest {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testDelete() {
      // Setup
      when(mockTransactionMapper.updateByPrimaryKeySelective(any())).thenReturn(1);
      Long id = 123L;

      // Run the test
      int result = transactionRepositoryImplUnderTest.delete(id);

      // Verify the results
      assertEquals(1, result);
      ArgumentCaptor<TransactionPO> captor = ArgumentCaptor.forClass(TransactionPO.class);
      verify(mockTransactionMapper).updateByPrimaryKeySelective(captor.capture());
      TransactionPO po = captor.getValue();
      assertEquals(id, po.getId());
      assertEquals(EnumDeleteStatus.DELETED.getCode(), po.getIsDelete());
      assertEquals(null, po.getInvoiceNo());
    }

    @Test
    public void testDelete_ReturnsZero() {
      // Setup
      when(mockTransactionMapper.updateByPrimaryKeySelective(any())).thenReturn(0);
      Long id = 456L;

      // Run the test
      int result = transactionRepositoryImplUnderTest.delete(id);

      // Verify the results
      assertEquals(0, result);
      verify(mockTransactionMapper).updateByPrimaryKeySelective(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplSaveTest {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      final TransactionMetaDO metaDO = new TransactionMetaDO();
      metaDO.setId(1L);
      metaDO.setInvoiceNo("INV-001");
      metaDO.setTaxAdminId(100L);
      metaDO.setTransactionType(EnumTransactionType.SALE);
      metaDO.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE);
      metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      metaDO.setTaxReporterType(EnumTaxReporterType.GEN_REPORTER);

      when(mockTransactionMapper.insertSelective(any(TransactionPO.class))).thenReturn(1);

      // Run the test
      final int result = transactionRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      assertEquals(1, result);
      verify(mockTransactionMapper).insertSelective(any(TransactionPO.class));
    }

    @Test
    public void testSave_NullMetaDO_ReturnsZeroAndInvokeMapper() {
      // Run the test
      final int result = transactionRepositoryImplUnderTest.save(null);

      // Verify the results
      assertEquals(0, result);
      verify(mockTransactionMapper)
          .insertSelective(org.mockito.ArgumentMatchers.isNull(TransactionPO.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplUpdateTest {

    @Mock private TransactionMapper transactionMapper;

    @Mock private TaxCountryBindRepository taxCountryBindRepository;

    @Mock private TaxAdminSubjectRepository taxAdminSubjectRepository;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testUpdate() {
      // Setup
      when(transactionMapper.updateByPrimaryKeySelective(any())).thenReturn(1);
      TransactionMetaDO metaDO = new TransactionMetaDO();
      metaDO.setId(123L);
      metaDO.setInvoiceNo("INV-001");
      metaDO.setTransactionType(EnumTransactionType.SALE);
      metaDO.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE);
      metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      metaDO.setTaxCalculateType(EnumTaxCalculateType.NET);
      metaDO.setTaxReporterType(EnumTaxReporterType.GEN_REPORTER);

      // Run the test
      int result = transactionRepositoryImplUnderTest.update(metaDO);

      // Verify the results
      assertEquals(1, result);
      ArgumentCaptor<TransactionPO> captor = ArgumentCaptor.forClass(TransactionPO.class);
      verify(transactionMapper).updateByPrimaryKeySelective(captor.capture());
      TransactionPO po = captor.getValue();
      assertEquals(Long.valueOf(123L), po.getId());
      assertEquals("INV-001", po.getInvoiceNo());
      assertEquals(EnumTransactionType.SALE.getCode(), po.getTransactionType());
      assertEquals(EnumTransactionCategory.SALES_INVOICE.getCode(), po.getTransactionCategory());
      assertEquals(EnumDeleteStatus.ACTIVE.getCode(), po.getIsDelete());
      assertEquals(EnumTaxCalculateType.NET.getCode(), po.getTaxCalculateType());
      assertEquals(EnumTaxReporterType.GEN_REPORTER.getCode(), po.getTaxReporterType());
    }

    @Test
    public void testUpdate_ReturnValue() {
      // Setup
      when(transactionMapper.updateByPrimaryKeySelective(any())).thenReturn(0);
      TransactionMetaDO metaDO = new TransactionMetaDO();
      metaDO.setId(1L);
      metaDO.setInvoiceNo("A");

      // Run the test
      int result = transactionRepositoryImplUnderTest.update(metaDO);

      // Verify the results
      assertEquals(0, result);
      verify(transactionMapper).updateByPrimaryKeySelective(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionRepositoryImplQueryTransactionByIdTest {

    @Mock private TransactionMapper mockTransactionMapper;

    @InjectMocks private TransactionRepositoryImpl transactionRepositoryImplUnderTest;

    @Test
    public void testQueryTransactionById() {
      // Setup
      final Long id = 1L;
      final TransactionPO transactionPO = new TransactionPO();
      transactionPO.setId(id);
      transactionPO.setInvoiceNo("INV-001");
      transactionPO.setTaxAdminId(11L);
      transactionPO.setTransactionCategory(EnumTransactionCategory.SALES_INVOICE.getCode());
      transactionPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      transactionPO.setAccountName("accountName");
      when(mockTransactionMapper.selectByPrimaryKey(id)).thenReturn(transactionPO);

      // Run the test
      final TransactionMetaDO result = transactionRepositoryImplUnderTest.queryTransactionById(id);

      // Verify the results
      assertNotNull(result);
      assertEquals(id.longValue(), result.getId().longValue());
      assertEquals("INV-001", result.getInvoiceNo());
      assertEquals(11L, result.getTaxAdminId().longValue());
      assertEquals("accountName", result.getAccountName());
      assertEquals(EnumTransactionCategory.SALES_INVOICE, result.getTransactionCategory());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
      verify(mockTransactionMapper).selectByPrimaryKey(id);
    }

    @Test
    public void testQueryTransactionById_MapperReturnsNull() {
      // Setup
      when(mockTransactionMapper.selectByPrimaryKey(2L)).thenReturn(null);

      // Run the test
      final TransactionMetaDO result = transactionRepositoryImplUnderTest.queryTransactionById(2L);

      // Verify the results
      assertNull(result);
      verify(mockTransactionMapper).selectByPrimaryKey(2L);
    }
  }
}
