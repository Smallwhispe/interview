package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxValidateRuleMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxValidateRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxValidateRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxValidateRulePOExample;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxValidateRuleRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxValidateRuleRepositoryImplQueryAllTest {

    @Mock private TaxValidateRuleMapper mockTaxValidateRuleMapper;

    @InjectMocks private TaxValidateRuleRepositoryImpl taxValidateRuleRepositoryImplUnderTest;

    @Test
    public void testQueryAll_ReturnsMappedList() {
      // Setup
      final TaxValidateRulePO po = new TaxValidateRulePO();
      po.setId(1L);
      po.setRule("rule");
      po.setRuleName("name");
      po.setRuleType(1);
      po.setIsDelete(0);
      po.setCreateTime(new Date());
      po.setModifyTime(new Date());
      when(mockTaxValidateRuleMapper.selectByExample(any(TaxValidateRulePOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      final List<TaxValidateRuleMetaDO> result = taxValidateRuleRepositoryImplUnderTest.queryAll();

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());

      ArgumentCaptor<TaxValidateRulePOExample> captor =
          ArgumentCaptor.forClass(TaxValidateRulePOExample.class);
      verify(mockTaxValidateRuleMapper).selectByExample(captor.capture());
      TaxValidateRulePOExample exampleUsed = captor.getValue();
      assertEquals("id asc", exampleUsed.getOrderByClause());
    }

    @Test
    public void testQueryAll_MapperReturnsEmpty() {
      // Setup
      when(mockTaxValidateRuleMapper.selectByExample(any(TaxValidateRulePOExample.class)))
          .thenReturn(Collections.<TaxValidateRulePO>emptyList());

      // Run the test
      final List<TaxValidateRuleMetaDO> result = taxValidateRuleRepositoryImplUnderTest.queryAll();

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxValidateRuleMapper).selectByExample(any(TaxValidateRulePOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxValidateRuleRepositoryImplQueryByIdsTest {

    @Mock private TaxValidateRuleMapper mockTaxValidateRuleMapper;

    @Spy @InjectMocks private TaxValidateRuleRepositoryImpl taxValidateRuleRepositoryImplUnderTest;

    @Test
    public void testQueryByIds_NullIds() {
      // Setup
      TaxValidateRuleMetaDO a = new TaxValidateRuleMetaDO();
      a.setId(1L);
      TaxValidateRuleMetaDO b = new TaxValidateRuleMetaDO();
      b.setId(2L);
      List<TaxValidateRuleMetaDO> all = Arrays.asList(a, b);
      doReturn(all).when(taxValidateRuleRepositoryImplUnderTest).queryAll();

      // Run the test
      List<TaxValidateRuleMetaDO> result = taxValidateRuleRepositoryImplUnderTest.queryByIds(null);

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());
      assertEquals(Long.valueOf(2L), result.get(1).getId());
    }

    @Test
    public void testQueryByIds_EmptyIds() {
      // Setup
      TaxValidateRuleMetaDO a = new TaxValidateRuleMetaDO();
      a.setId(1L);
      TaxValidateRuleMetaDO b = new TaxValidateRuleMetaDO();
      b.setId(2L);
      List<TaxValidateRuleMetaDO> all = Arrays.asList(a, b);
      doReturn(all).when(taxValidateRuleRepositoryImplUnderTest).queryAll();

      // Run the test
      List<TaxValidateRuleMetaDO> result =
          taxValidateRuleRepositoryImplUnderTest.queryByIds(Collections.<Long>emptyList());

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());
      assertEquals(Long.valueOf(2L), result.get(1).getId());
    }

    @Test
    public void testQueryByIds_FilterIds() {
      // Setup
      TaxValidateRuleMetaDO m1 = new TaxValidateRuleMetaDO();
      m1.setId(1L);
      TaxValidateRuleMetaDO m2 = new TaxValidateRuleMetaDO();
      m2.setId(2L);
      TaxValidateRuleMetaDO m3 = new TaxValidateRuleMetaDO();
      m3.setId(3L);
      List<TaxValidateRuleMetaDO> all = Arrays.asList(m1, m2, m3);
      doReturn(all).when(taxValidateRuleRepositoryImplUnderTest).queryAll();

      // Run the test
      List<TaxValidateRuleMetaDO> result =
          taxValidateRuleRepositoryImplUnderTest.queryByIds(Arrays.asList(2L, 4L));

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(Long.valueOf(2L), result.get(0).getId());
    }
  }
}
