package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTimeType;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminSubjectMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminRepository;
import java.util.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxAdminRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxAdminRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxAdminMapper mockTaxAdminMapper;
    @Mock private TaxAdminSubjectMapper mockTaxAdminSubjectMapper;
    @Mock private TaxAdminRepository mockTaxAdminRepository;

    @InjectMocks private TaxAdminRepositoryImpl taxAdminRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective() {
      // Setup
      TaxAdminMetaDO input = new TaxAdminMetaDO();
      input.setId(1L);
      input.setIsDelete(EnumDeleteStatus.ACTIVE);
      input.setAddress(new AddressMetaDO());

      TaxAdminMetaDO existed = new TaxAdminMetaDO();
      existed.setId(1L);
      existed.setIsDelete(EnumDeleteStatus.ACTIVE);
      existed.setAddress(new AddressMetaDO());

      when(mockTaxAdminRepository.getTaxAdminById(1L)).thenReturn(existed);
      when(mockTaxAdminMapper.updateByPrimaryKeySelective(any(TaxAdminPO.class))).thenReturn(1);

      // Run the test
      taxAdminRepositoryImplUnderTest.updateByIdSelective(input);

      // Verify
      ArgumentCaptor<TaxAdminPO> captor = ArgumentCaptor.forClass(TaxAdminPO.class);
      verify(mockTaxAdminMapper).updateByPrimaryKeySelective(captor.capture());
      TaxAdminPO updated = captor.getValue();
      assertEquals(1L, updated.getId().longValue());
      assertNotNull(updated.getModifyTime());
      verify(mockTaxAdminRepository).getTaxAdminById(1L);
    }

    @Test(expected = BizException.class)
    public void testUpdateByIdSelective_OrgNull() {
      // Setup
      TaxAdminMetaDO input = new TaxAdminMetaDO();
      input.setId(2L);
      input.setIsDelete(EnumDeleteStatus.ACTIVE);
      input.setAddress(new AddressMetaDO());

      when(mockTaxAdminRepository.getTaxAdminById(2L)).thenReturn(null);

      // Run the test
      taxAdminRepositoryImplUnderTest.updateByIdSelective(input);
    }

    @Test(expected = BizException.class)
    public void testUpdateByIdSelective_OrgDeleted() {
      // Setup
      TaxAdminMetaDO input = new TaxAdminMetaDO();
      input.setId(3L);
      input.setIsDelete(EnumDeleteStatus.ACTIVE);
      input.setAddress(new AddressMetaDO());

      TaxAdminMetaDO existed = new TaxAdminMetaDO();
      existed.setId(3L);
      existed.setIsDelete(EnumDeleteStatus.DELETED);
      existed.setAddress(new AddressMetaDO());

      when(mockTaxAdminRepository.getTaxAdminById(3L)).thenReturn(existed);

      // Run the test
      taxAdminRepositoryImplUnderTest.updateByIdSelective(input);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxAdminRepositoryImplGetAllTaxAdminSubjectHc5bb0Test {

    @Mock private TaxAdminMapper mockTaxAdminMapper;
    @Mock private TaxAdminSubjectMapper mockTaxAdminSubjectMapper;
    @Mock private TaxAdminRepository mockTaxAdminRepository;

    @InjectMocks private TaxAdminRepositoryImpl taxAdminRepositoryImplUnderTest;

    @Test
    public void testGetAllTaxAdminSubject_ActiveTrue() {
      // Setup
      TaxAdminSubjectPO po1 = new TaxAdminSubjectPO();
      po1.setId(1L);
      po1.setSubjectId(10L);
      po1.setTaxAdminId(100L);
      po1.setTaxNo("TN1");
      po1.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      TaxAdminSubjectPO po2 = new TaxAdminSubjectPO();
      po2.setId(2L);
      po2.setSubjectId(20L);
      po2.setTaxAdminId(200L);
      po2.setTaxNo("TN2");
      po2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      List<TaxAdminSubjectPO> poList = Arrays.asList(po1, po2);
      when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class)))
          .thenReturn(poList);

      // Run
      List<TaxAdminSubjectMetaDO> result =
          taxAdminRepositoryImplUnderTest.getAllTaxAdminSubject(true);

      // Verify mapper called and capture example to assert criteria
      ArgumentCaptor<TaxAdminSubjectPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxAdminSubjectPOExample.class);
      verify(mockTaxAdminSubjectMapper, times(1)).selectByExample(exampleCaptor.capture());

      TaxAdminSubjectPOExample passedExample = exampleCaptor.getValue();
      // 应该包含一条有效的条件（is_delete = ACTIVE）
      assertEquals(1, passedExample.getOredCriteria().size());
      TaxAdminSubjectPOExample.Criteria criteria = passedExample.getOredCriteria().get(0);
      // 断言条件内包含 is_delete = ACTIVE
      boolean hasIsDeleteActive = false;
      for (Object c : criteria.getAllCriteria()) {
        TaxAdminSubjectPOExample.Criterion ct = (TaxAdminSubjectPOExample.Criterion) c;
        if ("is_delete =".equals(ct.getCondition())
            && EnumDeleteStatus.ACTIVE.getCode().equals(ct.getValue())) {
          hasIsDeleteActive = true;
          break;
        }
      }
      assertTrue(hasIsDeleteActive);

      // 校验返回结果映射尺寸与主要字段
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());
      assertEquals(Long.valueOf(2L), result.get(1).getId());
    }

    @Test
    public void testGetAllTaxAdminSubject_ActiveFalse() {
      // Setup
      TaxAdminSubjectPO po = new TaxAdminSubjectPO();
      po.setId(3L);
      po.setSubjectId(30L);
      po.setTaxAdminId(300L);
      po.setTaxNo("TN3");
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class)))
          .thenReturn(Collections.singletonList(po));

      // Run
      List<TaxAdminSubjectMetaDO> result =
          taxAdminRepositoryImplUnderTest.getAllTaxAdminSubject(false);

      // Verify mapper called and capture example to assert no criteria added
      ArgumentCaptor<TaxAdminSubjectPOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxAdminSubjectPOExample.class);
      verify(mockTaxAdminSubjectMapper, times(1)).selectByExample(exampleCaptor.capture());

      TaxAdminSubjectPOExample passedExample = exampleCaptor.getValue();
      // 未开启active过滤，不应添加任何条件
      assertEquals(0, passedExample.getOredCriteria().size());

      // 校验返回结果
      assertEquals(1, result.size());
      assertEquals(Long.valueOf(3L), result.get(0).getId());
      assertEquals(Long.valueOf(30L), result.get(0).getSubjectId());
      assertEquals(Long.valueOf(300L), result.get(0).getTaxAdminId());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxAdminRepositoryImplGetAllTaxAdminTest {

    @Mock private TaxAdminMapper mockTaxAdminMapper;

    @InjectMocks private TaxAdminRepositoryImpl taxAdminRepositoryImplUnderTest;

    @Test
    public void testGetAllTaxAdmin_ActiveTrue() {
      // Setup
      final TaxAdminPO taxAdminPO = new TaxAdminPO();
      taxAdminPO.setId(1L);
      taxAdminPO.setName("name1");
      taxAdminPO.setCountryId(99L);
      taxAdminPO.setIsDelete(0);
      taxAdminPO.setTaxTimeType(1);
      taxAdminPO.setCountryName("country1");
      when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class)))
          .thenReturn(Arrays.asList(taxAdminPO));

      // Run the test
      final List<TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdmin(true);

      // Verify the results
      assertEquals(1, result.size());
      TaxAdminMetaDO meta = result.get(0);
      assertEquals(Long.valueOf(1L), meta.getId());
      assertEquals("name1", meta.getName());
      assertEquals("country1", meta.getCountryName());
      assertNotNull(meta.getAddress());
      assertEquals(Long.valueOf(99L), meta.getAddress().getLevelZero());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());
      assertEquals(EnumTaxTimeType.CONSUME_TIME, meta.getTaxTimeType());
      verify(mockTaxAdminMapper).selectByExample(any(TaxAdminPOExample.class));
    }

    @Test
    public void testGetAllTaxAdmin_ActiveFalse() {
      // Setup
      final TaxAdminPO taxAdminPO = new TaxAdminPO();
      taxAdminPO.setId(2L);
      taxAdminPO.setName("name2");
      taxAdminPO.setCountryId(100L);
      taxAdminPO.setIsDelete(0);
      taxAdminPO.setTaxTimeType(1);
      taxAdminPO.setCountryName("country2");
      when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class)))
          .thenReturn(Arrays.asList(taxAdminPO));

      // Run the test
      final List<TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdmin(false);

      // Verify the results
      assertEquals(1, result.size());
      TaxAdminMetaDO meta = result.get(0);
      assertEquals(Long.valueOf(2L), meta.getId());
      assertEquals("name2", meta.getName());
      assertEquals("country2", meta.getCountryName());
      assertNotNull(meta.getAddress());
      assertEquals(Long.valueOf(100L), meta.getAddress().getLevelZero());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());
      assertEquals(EnumTaxTimeType.CONSUME_TIME, meta.getTaxTimeType());
      verify(mockTaxAdminMapper).selectByExample(any(TaxAdminPOExample.class));
    }

    @Test
    public void testGetAllTaxAdmin_TaxAdminMapperReturnsNoItems() {
      // Setup
      when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class)))
          .thenReturn(Collections.<TaxAdminPO>emptyList());

      // Run the test
      final List<TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdmin(true);

      // Verify the results
      assertEquals(Collections.emptyList(), result);
      verify(mockTaxAdminMapper).selectByExample(any(TaxAdminPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxAdminRepositoryImplSaveTaxAdminSubTest {

    @Mock private TaxAdminSubjectMapper mockTaxAdminSubjectMapper;

    @InjectMocks private TaxAdminRepositoryImpl taxAdminRepositoryImplUnderTest;

    @Test
    public void testSaveTaxAdminSub_UpdatePath() {
      TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO();
      metaDO.setId(1L);
      Mockito.when(
              mockTaxAdminSubjectMapper.updateByPrimaryKeySelective(any(TaxAdminSubjectPO.class)))
          .thenReturn(1);

      Long result = taxAdminRepositoryImplUnderTest.saveTaxAdminSub(metaDO);

      verify(mockTaxAdminSubjectMapper).updateByPrimaryKeySelective(any(TaxAdminSubjectPO.class));
      assertEquals(Long.valueOf(1L), result);
    }

    @Test
    public void testSaveTaxAdminSub_InsertPath_IdIsNull_ReturnsGeneratedId() {
      TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO();
      metaDO.setId(null);
      Mockito.doAnswer(
              invocation -> {
                TaxAdminSubjectPO arg = (TaxAdminSubjectPO) invocation.getArguments()[0];
                arg.setId(100L);
                return 1;
              })
          .when(mockTaxAdminSubjectMapper)
          .insertSelective(any(TaxAdminSubjectPO.class));

      Long result = taxAdminRepositoryImplUnderTest.saveTaxAdminSub(metaDO);

      verify(mockTaxAdminSubjectMapper).insertSelective(any(TaxAdminSubjectPO.class));
      assertEquals(Long.valueOf(100L), result);
    }

    @Test
    public void testSaveTaxAdminSub_InsertPath_IdIsZero_ReturnsZeroWhenMapperNotSetId() {
      TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO();
      metaDO.setId(0L);
      Mockito.when(mockTaxAdminSubjectMapper.insertSelective(any(TaxAdminSubjectPO.class)))
          .thenReturn(1);

      Long result = taxAdminRepositoryImplUnderTest.saveTaxAdminSub(metaDO);

      verify(mockTaxAdminSubjectMapper).insertSelective(any(TaxAdminSubjectPO.class));
      assertEquals(Long.valueOf(0L), result);
    }
  }
}
