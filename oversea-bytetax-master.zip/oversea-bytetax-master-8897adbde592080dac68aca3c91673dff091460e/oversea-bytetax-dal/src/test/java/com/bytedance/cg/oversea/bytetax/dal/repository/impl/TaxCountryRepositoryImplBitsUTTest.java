package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCountryMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryPOExample;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxCountryRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryRepositoryImplGetTaxCountryByCountryIdTest {

    @Mock private TaxCountryMapper mockTaxCountryMapper;

    @InjectMocks private TaxCountryRepositoryImpl taxCountryRepositoryImplUnderTest;

    @Test
    public void testGetTaxCountryByCountryId_Success() {
      Long queryId = 100L;
      TaxCountryPO po = new TaxCountryPO();
      po.setId(1L);
      po.setCountryGeoId(queryId);
      po.setLevelOne(10L);
      po.setTaxReportCurrency("USD");
      po.setOperatorId(7);
      Date now = new Date();
      po.setCreateTime(now);
      po.setModifyTime(now);
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(mockTaxCountryMapper.selectByExample(any(TaxCountryPOExample.class)))
          .thenReturn(Arrays.asList(po));

      TaxCountryMetaDO result = taxCountryRepositoryImplUnderTest.getTaxCountryByCountryId(queryId);

      assertNotNull(result);
      assertEquals(po.getId(), result.getId());
      assertEquals(po.getCountryGeoId(), result.getCountryGeoId());
      assertEquals(po.getLevelOne(), result.getLevelOne());
      assertEquals(po.getOperatorId(), result.getOperatorId());
      assertEquals(po.getCreateTime(), result.getCreateTime());
      assertEquals(po.getModifyTime(), result.getModifyTime());
      assertEquals("USD", result.getTaxReportCurrency());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
      verify(mockTaxCountryMapper).selectByExample(any(TaxCountryPOExample.class));
    }

    @Test
    public void testGetTaxCountryByCountryId_MapperReturnsEmpty() {
      when(mockTaxCountryMapper.selectByExample(any(TaxCountryPOExample.class)))
          .thenReturn(Collections.emptyList());

      TaxCountryMetaDO result = taxCountryRepositoryImplUnderTest.getTaxCountryByCountryId(123L);

      assertNull(result);
      verify(mockTaxCountryMapper).selectByExample(any(TaxCountryPOExample.class));
    }

    @Test
    public void testGetTaxCountryByCountryId_IdIsNull() {
      TaxCountryMetaDO result = taxCountryRepositoryImplUnderTest.getTaxCountryByCountryId(null);

      assertNull(result);
      verify(mockTaxCountryMapper, Mockito.never()).selectByExample(any(TaxCountryPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryRepositoryImplSaveTest {

    @Mock private TaxCountryMapper mockTaxCountryMapper;

    @InjectMocks private TaxCountryRepositoryImpl taxCountryRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      when(mockTaxCountryMapper.insert(any())).thenReturn(1);
      TaxCountryMetaDO metaDO = new TaxCountryMetaDO();

      // Pre-check
      Date before = new Date();
      // Run
      taxCountryRepositoryImplUnderTest.save(metaDO);
      Date after = new Date();

      // Verify mapper call
      verify(mockTaxCountryMapper).insert(any());

      // Verify time fields are set and equal
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertEquals(metaDO.getCreateTime(), metaDO.getModifyTime());
      assertTrue(!metaDO.getCreateTime().before(before));
      assertTrue(!metaDO.getCreateTime().after(after));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxCountryMapper mockTaxCountryMapper;

    @InjectMocks private TaxCountryRepositoryImpl taxCountryRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective() {
      // Setup
      TaxCountryMetaDO metaDO = new TaxCountryMetaDO();
      metaDO.setId(100L);
      metaDO.setCountryGeoId(200L);
      metaDO.setLevelOne(300L);
      metaDO.setOperatorId(400);
      metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      metaDO.setTaxReportCurrency("USD");
      Date createTime = new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime();
      Date oldModifyTime = new GregorianCalendar(2019, Calendar.DECEMBER, 31).getTime();
      metaDO.setCreateTime(createTime);
      metaDO.setModifyTime(oldModifyTime);

      when(mockTaxCountryMapper.updateByPrimaryKeySelective(any(TaxCountryPO.class))).thenReturn(1);

      long before = System.currentTimeMillis();
      // Run
      taxCountryRepositoryImplUnderTest.updateByIdSelective(metaDO);
      long after = System.currentTimeMillis();

      // Verify
      ArgumentCaptor<TaxCountryPO> captor = ArgumentCaptor.forClass(TaxCountryPO.class);
      verify(mockTaxCountryMapper).updateByPrimaryKeySelective(captor.capture());
      TaxCountryPO po = captor.getValue();

      assertEquals(metaDO.getId(), po.getId());
      assertEquals(metaDO.getCountryGeoId(), po.getCountryGeoId());
      assertEquals(metaDO.getLevelOne(), po.getLevelOne());
      assertEquals(metaDO.getOperatorId(), po.getOperatorId());
      assertEquals(metaDO.getTaxReportCurrency(), po.getTaxReportCurrency());
      assertEquals(EnumDeleteStatus.ACTIVE.getCode(), po.getIsDelete());

      assertNotNull(po.getModifyTime());
      long modifyTs = po.getModifyTime().getTime();
      assertTrue(modifyTs >= before && modifyTs <= after);

      assertEquals(createTime, po.getCreateTime());
    }
  }
}
