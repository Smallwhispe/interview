package com.bytedance.cg.oversea.bytetax.dal.mapping;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumActiveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxClassify;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class WhitelistTaxRateMappingBitsUTTest {
  public static class WhitelistTaxRateMappingToClassifyCodeTest {

    @Test
    public void testToClassifyCode_Turnover() {
      // Setup
      final EnumTaxClassify input = EnumTaxClassify.TURNOVER;

      // Run the test
      final Integer result = WhitelistTaxRateMapping.toClassifyCode(input);

      // Verify the results
      assertEquals(Integer.valueOf(1), result);
    }

    @Test
    public void testToClassifyCode_Withholding() {
      // Setup
      final EnumTaxClassify input = EnumTaxClassify.WITHHOLDING;

      // Run the test
      final Integer result = WhitelistTaxRateMapping.toClassifyCode(input);

      // Verify the results
      assertEquals(Integer.valueOf(2), result);
    }

    @Test
    public void testToClassifyCode_Null() {
      // Setup
      final EnumTaxClassify input = null;

      // Run the test
      final Integer result = WhitelistTaxRateMapping.toClassifyCode(input);

      // Verify the results
      assertNull(result);
    }
  }

  public static class WhitelistTaxRateMappingToStatusTest {

    @Test
    public void testToStatus_ReturnsActive() {
      // Setup
      Integer code = 0;

      // Run the test
      EnumActiveStatus result = WhitelistTaxRateMapping.toStatus(code);

      // Verify the results
      assertEquals(EnumActiveStatus.ACTIVE, result);
    }

    @Test
    public void testToStatus_ReturnsInactive() {
      // Setup
      Integer code = 1;

      // Run the test
      EnumActiveStatus result = WhitelistTaxRateMapping.toStatus(code);

      // Verify the results
      assertEquals(EnumActiveStatus.INACTIVE, result);
    }

    @Test
    public void testToStatus_NullInput() {
      // Setup
      Integer code = null;

      // Run the test
      EnumActiveStatus result = WhitelistTaxRateMapping.toStatus(code);

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testToStatus_InvalidCode() {
      // Setup
      Integer code = 999;

      // Run the test
      EnumActiveStatus result = WhitelistTaxRateMapping.toStatus(code);

      // Verify the results
      assertNull(result);
    }
  }

  public static class WhitelistTaxRateMappingToClassifyTest {

    @Test
    public void testToClassify_Turnover() {
      final EnumTaxClassify result = WhitelistTaxRateMapping.toClassify(1);
      assertEquals(EnumTaxClassify.TURNOVER, result);
    }

    @Test
    public void testToClassify_Withholding() {
      final EnumTaxClassify result = WhitelistTaxRateMapping.toClassify(2);
      assertEquals(EnumTaxClassify.WITHHOLDING, result);
    }

    @Test
    public void testToClassify_NullInput() {
      final EnumTaxClassify result = WhitelistTaxRateMapping.toClassify(null);
      assertNull(result);
    }

    @Test
    public void testToClassify_InvalidCode() {
      final EnumTaxClassify result = WhitelistTaxRateMapping.toClassify(999);
      assertNull(result);
    }
  }

  public static class WhitelistTaxRateMappingToStatusCodeTest {

    @Test
    public void testToStatusCode_Null() {
      Integer result = WhitelistTaxRateMapping.toStatusCode(null);
      assertNull(result);
    }

    @Test
    public void testToStatusCode_Active() {
      Integer result = WhitelistTaxRateMapping.toStatusCode(EnumActiveStatus.ACTIVE);
      assertEquals(Integer.valueOf(0), result);
    }

    @Test
    public void testToStatusCode_Inactive() {
      Integer result = WhitelistTaxRateMapping.toStatusCode(EnumActiveStatus.INACTIVE);
      assertEquals(Integer.valueOf(1), result);
    }
  }
}
