package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxBizBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.BizRuleExecutionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.SingleRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxBizBindRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TaxBizBindRepositoryImplTest {

    @Mock
    private TaxBizBindMapper mockTaxBizBindMapper;
    @Mock
    private TaxBizBindRepository mockTaxBizBindRepository;

    @InjectMocks
    private TaxBizBindRepositoryImpl taxBizBindRepositoryImplUnderTest;

    @Test
    public void testQueryAll() {
        // Setup
        final List<TaxBizBindMetaDO> expectedResult = Arrays.asList(new TaxBizBindMetaDO(0L, 0L, 0L, null, 0L, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime()));

        // Configure TaxBizBindMapper.selectByExample(...).
        final TaxBizBindPO taxBizBindPO = new TaxBizBindPO();
        taxBizBindPO.setId(0L);
        taxBizBindPO.setCountryBindId(0L);
        taxBizBindPO.setBizId(0L);
        taxBizBindPO.setRule("");
        taxBizBindPO.setOperatorId(0);
        taxBizBindPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setIsDelete(0);
        taxBizBindPO.setEffectiveTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        final List<TaxBizBindPO> taxBizBindPOS = Arrays.asList(taxBizBindPO);
        when(mockTaxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class))).thenReturn(taxBizBindPOS);

        // Run the test
        final List<TaxBizBindMetaDO> result = taxBizBindRepositoryImplUnderTest.queryAll();

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testQueryAll_TaxBizBindMapperReturnsNoItems() {
        // Setup
        when(mockTaxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<TaxBizBindMetaDO> result = taxBizBindRepositoryImplUnderTest.queryAll();

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testSaveTaxBizBind() {
        // Setup
        final TaxBizBindMetaDO metaDO = new TaxBizBindMetaDO(0L, 0L, 0L, new BizRuleExecutionMetaDO(Arrays.asList(new SingleRuleMetaDO("variable", "operator", "value")), "operator", "ruleDsl"), 0L, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());

        // Configure TaxBizBindRepository.getTaxBizBindById(...).
        final TaxBizBindPO taxBizBindPO = new TaxBizBindPO();
        taxBizBindPO.setId(0L);
        taxBizBindPO.setCountryBindId(0L);
        taxBizBindPO.setBizId(0L);
        taxBizBindPO.setRule("rule");
        taxBizBindPO.setOperatorId(0);
        taxBizBindPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setIsDelete(0);
        taxBizBindPO.setEffectiveTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());

        when(mockTaxBizBindMapper.insertSelective(any(TaxBizBindPO.class))).thenReturn(0);

        // Run the test
        final Long result = taxBizBindRepositoryImplUnderTest.saveTaxBizBind(metaDO);

        // Verify the results
        verify(mockTaxBizBindMapper).insertSelective(any(TaxBizBindPO.class));
    }

    @Test
    public void testGetTaxBizBind() {
        // Setup
        final List<TaxBizBindMetaDO> expectedResult = Arrays.asList(new TaxBizBindMetaDO(0L, 0L, 0L, null, 0L, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime()));

        // Configure TaxBizBindMapper.selectByExample(...).
        final TaxBizBindPO taxBizBindPO = new TaxBizBindPO();
        taxBizBindPO.setId(0L);
        taxBizBindPO.setCountryBindId(0L);
        taxBizBindPO.setBizId(0L);
        taxBizBindPO.setRule("");
        taxBizBindPO.setOperatorId(0);
        taxBizBindPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setIsDelete(0);
        taxBizBindPO.setEffectiveTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        final List<TaxBizBindPO> taxBizBindPOS = Arrays.asList(taxBizBindPO);
        when(mockTaxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class))).thenReturn(taxBizBindPOS);

        // Run the test
        final List<TaxBizBindMetaDO> result = taxBizBindRepositoryImplUnderTest.getTaxBizBind(Arrays.asList(0L), false);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetTaxBizBind_TaxBizBindMapperReturnsNoItems() {
        // Setup
        when(mockTaxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<TaxBizBindMetaDO> result = taxBizBindRepositoryImplUnderTest.getTaxBizBind(Arrays.asList(0L), false);

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testDeleteTaxBizBind() {
        // Setup
        when(mockTaxBizBindMapper.updateByExampleSelective(any(TaxBizBindPO.class), any(TaxBizBindPOExample.class))).thenReturn(0);

        // Run the test
        taxBizBindRepositoryImplUnderTest.deleteTaxBizBind(Arrays.asList(0L));

        // Verify the results
        verify(mockTaxBizBindMapper).updateByExampleSelective(any(TaxBizBindPO.class), any(TaxBizBindPOExample.class));
    }

    @Test
    public void testGetTaxBizBindById() {
        // Setup
        final TaxBizBindPO expectedResult = new TaxBizBindPO();
        expectedResult.setId(0L);
        expectedResult.setCountryBindId(0L);
        expectedResult.setBizId(0L);
        expectedResult.setRule("rule");
        expectedResult.setOperatorId(0);
        expectedResult.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        expectedResult.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        expectedResult.setIsDelete(0);
        expectedResult.setEffectiveTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());

        // Configure TaxBizBindMapper.selectByPrimaryKey(...).
        final TaxBizBindPO taxBizBindPO = new TaxBizBindPO();
        taxBizBindPO.setId(0L);
        taxBizBindPO.setCountryBindId(0L);
        taxBizBindPO.setBizId(0L);
        taxBizBindPO.setRule("rule");
        taxBizBindPO.setOperatorId(0);
        taxBizBindPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxBizBindPO.setIsDelete(0);
        taxBizBindPO.setEffectiveTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        when(mockTaxBizBindMapper.selectByPrimaryKey(0L)).thenReturn(taxBizBindPO);

        // Run the test
        final TaxBizBindPO result = taxBizBindRepositoryImplUnderTest.getTaxBizBindById(0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }
}
