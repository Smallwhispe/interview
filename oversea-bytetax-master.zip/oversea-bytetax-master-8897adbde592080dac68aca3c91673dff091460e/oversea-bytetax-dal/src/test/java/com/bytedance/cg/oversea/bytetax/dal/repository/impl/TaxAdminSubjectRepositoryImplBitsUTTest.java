package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminSubjectMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxAdminSubjectRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxAdminSubjectRepositoryImplFullSaveTest {

    @Mock private TaxAdminSubjectMapper mockTaxAdminSubjectMapper;

    @InjectMocks private TaxAdminSubjectRepositoryImpl taxAdminSubjectRepositoryImplUnderTest;

    @Test
    public void testFullSave_IdNull_InsertSelectiveAndSetFields() {
      when(mockTaxAdminSubjectMapper.insertSelective(any())).thenReturn(1);
      TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO();
      metaDO.setId(null);

      taxAdminSubjectRepositoryImplUnderTest.fullSave(metaDO);

      verify(mockTaxAdminSubjectMapper).insertSelective(any());
      assertEquals(EnumDeleteStatus.ACTIVE, metaDO.getIsDelete());
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertNull(metaDO.getId());
    }

    @Test
    public void testFullSave_IdValid_UpdateByPrimaryKey() {
      when(mockTaxAdminSubjectMapper.updateByPrimaryKey(any())).thenReturn(1);
      TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO();
      metaDO.setId(1L);

      taxAdminSubjectRepositoryImplUnderTest.fullSave(metaDO);

      verify(mockTaxAdminSubjectMapper).updateByPrimaryKey(any());
    }

    @Test
    public void testFullSave_IdZero_InsertSelectiveAndSetFields() {
      when(mockTaxAdminSubjectMapper.insertSelective(any())).thenReturn(1);
      TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO();
      metaDO.setId(0L);

      taxAdminSubjectRepositoryImplUnderTest.fullSave(metaDO);

      verify(mockTaxAdminSubjectMapper).insertSelective(any());
      assertEquals(EnumDeleteStatus.ACTIVE, metaDO.getIsDelete());
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertNull(metaDO.getId());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxAdminSubjectRepositoryImplDeleteByIdTest {

    @Mock private TaxAdminSubjectMapper mockTaxAdminSubjectMapper;

    @InjectMocks @Spy private TaxAdminSubjectRepositoryImpl taxAdminSubjectRepositoryImplUnderTest;

    @Test
    public void testDeleteById_AimMetaNull() {
      // Setup
      doReturn(null).when(taxAdminSubjectRepositoryImplUnderTest).queryById(1L, false);

      // Run the test
      taxAdminSubjectRepositoryImplUnderTest.deleteById(1L);

      // Verify the results
      verify(mockTaxAdminSubjectMapper, never()).updateByPrimaryKeySelective(any());
    }

    @Test
    public void testDeleteById_AimMetaExists() {
      // Setup
      TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO();
      metaDO.setId(1L);
      metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      doReturn(metaDO).when(taxAdminSubjectRepositoryImplUnderTest).queryById(1L, false);
      when(mockTaxAdminSubjectMapper.updateByPrimaryKeySelective(any())).thenReturn(1);

      // Run the test
      taxAdminSubjectRepositoryImplUnderTest.deleteById(1L);

      // Verify the results
      verify(mockTaxAdminSubjectMapper, times(1)).updateByPrimaryKeySelective(any());
    }
  }
}
