package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumAsyncTaskType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.IdGenerateService;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.AsyncTaskMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.ext.AsyncTaskDao;
import com.bytedance.cg.oversea.bytetax.dal.metado.AsyncTaskMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.AsyncTaskPO;
import java.util.Calendar;
import java.util.GregorianCalendar;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class AsyncTaskRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class AsyncTaskRepositoryImplSaveTest {

    @Mock private AsyncTaskMapper mockAsyncTaskMapper;
    @Mock private AsyncTaskDao mockAsyncTaskDao;
    @Mock private IdGenerateService idGenerateService;

    @InjectMocks private AsyncTaskRepositoryImpl asyncTaskRepositoryImplUnderTest;

    @Test
    public void testSave_InsertWhenIdNull() {
      // Setup
      AsyncTaskMetaDO metaDO =
          new AsyncTaskMetaDO(
              null,
              EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD,
              EnumAsyncTaskStatus.INIT,
              "args",
              "result",
              new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(),
              11L,
              EnumDeleteStatus.ACTIVE,
              new GregorianCalendar(2020, Calendar.JANUARY, 2).getTime(),
              new GregorianCalendar(2020, Calendar.JANUARY, 3).getTime());
      when(idGenerateService.getId()).thenReturn(123L);
      when(mockAsyncTaskMapper.insert(any())).thenReturn(1);

      // Run
      asyncTaskRepositoryImplUnderTest.save(metaDO);

      // Verify
      ArgumentCaptor<AsyncTaskPO> captor = ArgumentCaptor.forClass(AsyncTaskPO.class);
      verify(mockAsyncTaskMapper).insert(captor.capture());
      AsyncTaskPO inserted = captor.getValue();
      assertEquals(123L, inserted.getId().longValue());
      assertNotNull(inserted.getCreateTime());
      assertNotNull(inserted.getUpdateTime());
      verify(idGenerateService).getId();
    }

    @Test
    public void testSave_UpdateWhenIdNotNull() {
      // Setup
      AsyncTaskMetaDO metaDO =
          new AsyncTaskMetaDO(
              9L,
              EnumAsyncTaskType.TAX_REPORTER_DOWNLOAD,
              EnumAsyncTaskStatus.CALCULATING,
              "args2",
              "result2",
              new GregorianCalendar(2020, Calendar.JANUARY, 5).getTime(),
              22L,
              EnumDeleteStatus.ACTIVE,
              new GregorianCalendar(2020, Calendar.JANUARY, 6).getTime(),
              new GregorianCalendar(2020, Calendar.JANUARY, 7).getTime());
      when(mockAsyncTaskMapper.updateByPrimaryKey(any())).thenReturn(1);

      // Run
      asyncTaskRepositoryImplUnderTest.save(metaDO);

      // Verify
      ArgumentCaptor<AsyncTaskPO> captor = ArgumentCaptor.forClass(AsyncTaskPO.class);
      verify(mockAsyncTaskMapper).updateByPrimaryKey(captor.capture());
      AsyncTaskPO updated = captor.getValue();
      assertEquals(9L, updated.getId().longValue());
      assertNotNull(updated.getUpdateTime());
    }
  }
}
