package com.bytedance.cg.oversea.bytetax.dal.elasticsearch;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import java.io.IOException;
import org.elasticsearch.action.search.ClearScrollRequest;
import org.elasticsearch.action.search.ClearScrollResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchScrollRequest;
import org.elasticsearch.client.IndicesClient;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.GetIndexRequest;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class BaseEsDAOBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class BaseEsDAOClearScrollTest {

    @Mock private RestHighLevelClient mockClient;

    @InjectMocks private BaseEsDAO baseEsDAOUnderTest;

    @Test
    public void testClearScroll_Success() throws Exception {
      // Setup
      ClearScrollResponse response = new ClearScrollResponse(true, 1);
      when(mockClient.clearScroll(any(ClearScrollRequest.class), any(RequestOptions.class)))
          .thenReturn(response);

      // Run
      baseEsDAOUnderTest.clearScroll("scrollId-123");
    }

    @Test(expected = BizException.class)
    public void testClearScroll_FailNotSucceeded() throws Exception {
      // Setup
      ClearScrollResponse response = new ClearScrollResponse(false, 0);
      when(mockClient.clearScroll(any(ClearScrollRequest.class), any(RequestOptions.class)))
          .thenReturn(response);

      // Run
      baseEsDAOUnderTest.clearScroll("scrollId-456");
    }

    @Test
    public void testClearScroll_IOException() throws Exception {
      // Setup
      when(mockClient.clearScroll(any(ClearScrollRequest.class), any(RequestOptions.class)))
          .thenThrow(new IOException("io error"));

      // Run
      try {
        baseEsDAOUnderTest.clearScroll("scrollId-789");
      } catch (BizException e) {
        // Verify
        org.junit.Assert.assertEquals("io error", e.getMessage());
      }
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class BaseEsDAOSearchWithScrollTest {

    @Mock private RestHighLevelClient mockClient;

    @InjectMocks private BaseEsDAO baseEsDAOUnderTest;

    @Test
    public void testSearchWithScroll_success() throws Exception {
      // Setup
      final String indexName = "test_index";
      final SearchSourceBuilder builder = new SearchSourceBuilder();
      builder.size(10);

      when(mockClient.search(any(SearchRequest.class), any(RequestOptions.class))).thenReturn(null);

      // Run the test
      final SearchResponse result = baseEsDAOUnderTest.searchWithScroll(indexName, builder);

      // Verify the results
      assertNull(result);

      ArgumentCaptor<SearchRequest> requestCaptor = ArgumentCaptor.forClass(SearchRequest.class);
      ArgumentCaptor<RequestOptions> optionsCaptor = ArgumentCaptor.forClass(RequestOptions.class);
      verify(mockClient).search(requestCaptor.capture(), optionsCaptor.capture());

      SearchRequest captured = requestCaptor.getValue();
      // 验证source被正确设置
      assertSame(builder, captured.source());
      // 验证使用了默认的RequestOptions
      assertSame(RequestOptions.DEFAULT, optionsCaptor.getValue());
    }

    @Test(expected = BizException.class)
    public void testSearchWithScroll_ioException() throws Exception {
      // Setup
      final String indexName = "test_index";
      final SearchSourceBuilder builder = new SearchSourceBuilder();

      when(mockClient.search(any(SearchRequest.class), any(RequestOptions.class)))
          .thenThrow(new IOException("io"));

      // Run the test (expect BizException)
      try {
        baseEsDAOUnderTest.searchWithScroll(indexName, builder);
      } finally {
        // Verify the client.search was invoked
        verify(mockClient).search(any(SearchRequest.class), any(RequestOptions.class));
      }
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class BaseEsDAOScrollEachTest {

    @Mock private RestHighLevelClient mockClient;

    @InjectMocks private BaseEsDAO baseEsDAOUnderTest;

    @Test
    public void testScrollEach_success() throws Exception {
      final SearchResponse mockResponse = mock(SearchResponse.class);
      when(mockClient.scroll(any(SearchScrollRequest.class), any(RequestOptions.class)))
          .thenReturn(mockResponse);

      final String scrollId = "test-scroll-id";
      final SearchResponse result = baseEsDAOUnderTest.scrollEach(scrollId);

      assertSame(mockResponse, result);
      final ArgumentCaptor<SearchScrollRequest> captor =
          ArgumentCaptor.forClass(SearchScrollRequest.class);
      verify(mockClient).scroll(captor.capture(), eq(RequestOptions.DEFAULT));
      assertNotNull(captor.getValue());
    }

    @Test
    public void testScrollEach_IOException() throws Exception {
      when(mockClient.scroll(any(SearchScrollRequest.class), any(RequestOptions.class)))
          .thenThrow(new java.io.IOException("io error"));

      try {
        baseEsDAOUnderTest.scrollEach("err-scroll-id");
        fail("Expected BizException to be thrown");
      } catch (BizException ex) {
        assertEquals("io error", ex.getMessage());
      }
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class BaseEsDAOSearchHitsTest {

    @Mock private RestHighLevelClient mockClient;

    @InjectMocks private BaseEsDAO baseEsDAOUnderTest;

    @Test
    public void testSearchHits_Success() throws Exception {
      // Setup
      final String indexName = "test_index";
      final SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
      final SearchResponse mockResponse = org.mockito.Mockito.mock(SearchResponse.class);
      when(mockClient.search(
              any(SearchRequest.class), org.mockito.ArgumentMatchers.eq(RequestOptions.DEFAULT)))
          .thenReturn(mockResponse);

      // Run the test
      final SearchResponse result = baseEsDAOUnderTest.searchHits(indexName, sourceBuilder);

      // Verify the call to client with expected parameters
      final ArgumentCaptor<SearchRequest> requestCaptor =
          ArgumentCaptor.forClass(SearchRequest.class);
      verify(mockClient)
          .search(requestCaptor.capture(), org.mockito.ArgumentMatchers.eq(RequestOptions.DEFAULT));
      final SearchRequest captured = requestCaptor.getValue();
      assertEquals(indexName, captured.indices()[0]);
      assertSame(sourceBuilder, captured.source());

      // Verify the results
      assertSame(mockResponse, result);
    }

    @Test(expected = BizException.class)
    public void testSearchHits_IOException() throws Exception {
      // Setup
      final String indexName = "test_index";
      final SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
      when(mockClient.search(
              any(SearchRequest.class), org.mockito.ArgumentMatchers.eq(RequestOptions.DEFAULT)))
          .thenThrow(new IOException("io error"));

      // Run the test (expect BizException)
      baseEsDAOUnderTest.searchHits(indexName, sourceBuilder);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class BaseEsDAOExistIndexTest {

    @Mock private RestHighLevelClient mockClient;

    @Mock private IndicesClient mockIndicesClient;

    @InjectMocks private BaseEsDAO baseEsDAOUnderTest;

    @Before
    public void setUp() {
      when(mockClient.indices()).thenReturn(mockIndicesClient);
    }

    @Test
    public void testExistIndex_ReturnsTrue() throws Exception {
      // Setup
      when(mockIndicesClient.exists(any(GetIndexRequest.class), any(RequestOptions.class)))
          .thenReturn(true);

      // Run the test
      final Boolean result = baseEsDAOUnderTest.existIndex("my_index");

      // Verify the results
      assertEquals(true, result.booleanValue());
      ArgumentCaptor<GetIndexRequest> captor = ArgumentCaptor.forClass(GetIndexRequest.class);
      verify(mockIndicesClient).exists(captor.capture(), any(RequestOptions.class));
      final GetIndexRequest captured = captor.getValue();
      assertEquals("my_index", captured.indices()[0]);
    }

    @Test
    public void testExistIndex_ReturnsFalse() throws Exception {
      // Setup
      when(mockIndicesClient.exists(any(GetIndexRequest.class), any(RequestOptions.class)))
          .thenReturn(false);

      // Run the test
      final Boolean result = baseEsDAOUnderTest.existIndex("another_index");

      // Verify the results
      assertEquals(false, result.booleanValue());
      verify(mockIndicesClient).exists(any(GetIndexRequest.class), any(RequestOptions.class));
    }

    @Test(expected = BizException.class)
    public void testExistIndex_ThrowsBizExceptionOnIOException() throws Exception {
      // Setup
      when(mockIndicesClient.exists(any(GetIndexRequest.class), any(RequestOptions.class)))
          .thenThrow(new IOException("IO error"));

      // Run the test
      baseEsDAOUnderTest.existIndex("error_index");
    }
  }
}
