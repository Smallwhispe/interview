package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoFieldMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoFieldMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoFieldExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoFieldPO;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxNoFieldRepository;
import java.util.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxNoFieldRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoFieldRepositoryImplQueryAllWithCacheTest {

    @Mock private TaxNoFieldMapper mockTaxNoFieldMapper;

    @InjectMocks private TaxNoFieldRepositoryImpl taxNoFieldRepositoryImplUnderTest;

    @Test
    public void testQueryAllWithCache() {
      // Setup
      TaxNoFieldPO po = new TaxNoFieldPO();
      po.setId(1L);
      po.setName("name-1");
      po.setIsDelete(0);

      when(mockTaxNoFieldMapper.selectByExample(any(TaxNoFieldExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      final List<TaxNoFieldMetaDO> result = taxNoFieldRepositoryImplUnderTest.queryAllWithCache();

      // Verify the results
      assertEquals(1, result.size());
      TaxNoFieldMetaDO meta = result.get(0);
      assertEquals(Long.valueOf(1L), meta.getId());
      assertEquals("name-1", meta.getName());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());
      verify(mockTaxNoFieldMapper).selectByExample(any(TaxNoFieldExample.class));
    }

    @Test
    public void testQueryAllWithCache_MapperReturnsEmptyList() {
      // Setup
      when(mockTaxNoFieldMapper.selectByExample(any(TaxNoFieldExample.class)))
          .thenReturn(Collections.<TaxNoFieldPO>emptyList());

      // Run the test
      final List<TaxNoFieldMetaDO> result = taxNoFieldRepositoryImplUnderTest.queryAllWithCache();

      // Verify the results
      assertEquals(Collections.emptyList(), result);
      verify(mockTaxNoFieldMapper).selectByExample(any(TaxNoFieldExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoFieldRepositoryImplQueryByIdsTest {

    @Mock private TaxNoFieldRepository mockTaxNoFieldRepository;

    @InjectMocks private TaxNoFieldRepositoryImpl taxNoFieldRepositoryImplUnderTest;

    @Test
    public void testQueryByIds() {
      // Setup
      TaxNoFieldMetaDO meta1 = new TaxNoFieldMetaDO();
      meta1.setId(1L);
      TaxNoFieldMetaDO meta2 = new TaxNoFieldMetaDO();
      meta2.setId(2L);
      TaxNoFieldMetaDO meta4 = new TaxNoFieldMetaDO();
      meta4.setId(4L);
      List<TaxNoFieldMetaDO> all = Arrays.asList(meta1, meta2, meta4);
      when(mockTaxNoFieldRepository.queryAllWithCache()).thenReturn(all);

      List<Long> ids = Arrays.asList(1L, 2L, 3L);

      // Run the test
      Map<Long, TaxNoFieldMetaDO> result = taxNoFieldRepositoryImplUnderTest.queryByIds(ids);

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(meta1, result.get(1L));
      assertEquals(meta2, result.get(2L));
      assertTrue(!result.containsKey(3L));
      assertTrue(!result.containsKey(4L));
    }

    @Test
    public void testQueryByIds_QueryAllWithCacheReturnsNoItems() {
      // Setup
      when(mockTaxNoFieldRepository.queryAllWithCache())
          .thenReturn(Collections.<TaxNoFieldMetaDO>emptyList());
      List<Long> ids = Arrays.asList(10L, 20L);

      // Run the test
      Map<Long, TaxNoFieldMetaDO> result = taxNoFieldRepositoryImplUnderTest.queryByIds(ids);

      // Verify the results
      assertTrue(result.isEmpty());
    }

    @Test
    public void testQueryByIds_IdsListEmpty() {
      // Setup
      TaxNoFieldMetaDO meta1 = new TaxNoFieldMetaDO();
      meta1.setId(1L);
      when(mockTaxNoFieldRepository.queryAllWithCache()).thenReturn(Arrays.asList(meta1));

      // Run the test
      Map<Long, TaxNoFieldMetaDO> result =
          taxNoFieldRepositoryImplUnderTest.queryByIds(Collections.<Long>emptyList());

      // Verify the results
      assertTrue(result.isEmpty());
    }
  }
}
