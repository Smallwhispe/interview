package com.bytedance.cg.oversea.bytetax.dal.elasticsearch;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsCommonMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsScrollMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import java.util.List;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TransactionDataEsDAOBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionDataEsDAOTransactionSelectScrollTest {

    @Test
    public void testTransactionSelectScroll_IndexNotExist_ThrowBizException() {
      TransactionDataEsDAO spyDao = Mockito.spy(new TransactionDataEsDAO());
      doReturn(false).when(spyDao).existIndex(anyString());

      try {
        spyDao.transactionSelectScroll(new SearchSourceBuilder());
      } catch (BizException e) {
        assertEquals("找不到transaction表对应的索引", e.getMessage());
        return;
      }
      throw new AssertionError("Expected BizException to be thrown");
    }

    @Test
    public void testTransactionSelectScroll_EmptyHits_ReturnScrollOnly() {
      TransactionDataEsDAO spyDao = Mockito.spy(new TransactionDataEsDAO());
      doReturn(true).when(spyDao).existIndex(anyString());

      SearchResponse mockResponse = Mockito.mock(SearchResponse.class, Mockito.RETURNS_DEEP_STUBS);
      when(mockResponse.getHits().getHits()).thenReturn(new SearchHit[0]);
      when(mockResponse.getScrollId()).thenReturn("scroll-id-empty");
      doReturn(mockResponse)
          .when(spyDao)
          .searchWithScroll(anyString(), any(SearchSourceBuilder.class));

      TransactionDataEsScrollMetaDO result =
          spyDao.transactionSelectScroll(new SearchSourceBuilder());

      assertEquals("scroll-id-empty", result.getScrollId());
      assertEquals(null, result.getTransactionDataEsPOS());
    }

    @Test
    public void testTransactionSelectScroll_WithHits_ReturnListAndScrollId() {
      TransactionDataEsDAO spyDao = Mockito.spy(new TransactionDataEsDAO());
      doReturn(true).when(spyDao).existIndex(anyString());

      SearchResponse mockResponse = Mockito.mock(SearchResponse.class, Mockito.RETURNS_DEEP_STUBS);

      SearchHit hit1 = Mockito.mock(SearchHit.class);
      SearchHit hit2 = Mockito.mock(SearchHit.class);
      when(hit1.getSourceAsString()).thenReturn("{\"id\":1,\"accountName\":\"acc1\"}");
      when(hit2.getSourceAsString()).thenReturn("{\"id\":2,\"accountName\":\"acc2\"}");

      when(mockResponse.getHits().getHits()).thenReturn(new SearchHit[] {hit1, hit2});
      when(mockResponse.getScrollId()).thenReturn("scroll-id-2");
      doReturn(mockResponse)
          .when(spyDao)
          .searchWithScroll(anyString(), any(SearchSourceBuilder.class));

      TransactionDataEsScrollMetaDO result =
          spyDao.transactionSelectScroll(new SearchSourceBuilder());

      assertEquals("scroll-id-2", result.getScrollId());
      assertEquals(2, result.getTransactionDataEsPOS().size());
      TransactionDataEsPO po1 = result.getTransactionDataEsPOS().get(0);
      TransactionDataEsPO po2 = result.getTransactionDataEsPOS().get(1);
      assertEquals(Long.valueOf(1L), po1.getId());
      assertEquals("acc1", po1.getAccountName());
      assertEquals(Long.valueOf(2L), po2.getId());
      assertEquals("acc2", po2.getAccountName());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionDataEsDAOScrollEachTagTest {

    @Spy private TransactionDataEsDAO transactionDataEsDAOUnderTest = new TransactionDataEsDAO();

    @Test
    public void testScrollEachTag_WithHits() {
      String scrollId = "scroll-123";

      SearchHit hit1 = mock(SearchHit.class);
      when(hit1.getSourceAsString()).thenReturn("{\"id\":123,\"accountName\":\"acc1\"}");

      SearchHit hit2 = mock(SearchHit.class);
      when(hit2.getSourceAsString()).thenReturn("{\"id\":456,\"accountName\":\"acc2\"}");

      SearchHit[] hitsArray = new SearchHit[] {hit1, null, hit2};

      SearchHits searchHits = mock(SearchHits.class);
      when(searchHits.getHits()).thenReturn(hitsArray);

      SearchResponse response = mock(SearchResponse.class);
      when(response.getHits()).thenReturn(searchHits);
      when(response.getScrollId()).thenReturn(scrollId);

      doReturn(response).when(transactionDataEsDAOUnderTest).scrollEach(scrollId);

      TransactionDataEsScrollMetaDO result = transactionDataEsDAOUnderTest.scrollEachTag(scrollId);

      assertEquals(scrollId, result.getScrollId());
      List<TransactionDataEsPO> pos = result.getTransactionDataEsPOS();
      assertEquals(2, pos.size());
      assertEquals(123L, pos.get(0).getId().longValue());
      assertEquals("acc1", pos.get(0).getAccountName());
      assertEquals(456L, pos.get(1).getId().longValue());
      assertEquals("acc2", pos.get(1).getAccountName());
    }

    @Test
    public void testScrollEachTag_NoHits() {
      String scrollId = "scroll-456";

      SearchHit[] hitsArray = new SearchHit[] {};

      SearchHits searchHits = mock(SearchHits.class);
      when(searchHits.getHits()).thenReturn(hitsArray);

      SearchResponse response = mock(SearchResponse.class);
      when(response.getHits()).thenReturn(searchHits);
      when(response.getScrollId()).thenReturn(scrollId);

      doReturn(response).when(transactionDataEsDAOUnderTest).scrollEach(scrollId);

      TransactionDataEsScrollMetaDO result = transactionDataEsDAOUnderTest.scrollEachTag(scrollId);

      assertEquals(scrollId, result.getScrollId());
      assertEquals(null, result.getTransactionDataEsPOS());
    }
  }

  public static class TransactionDataEsDAOTransactionSelectTest {

    class FakeTransactionDataEsDAO extends TransactionDataEsDAO {
      private boolean existsReturn;
      private boolean returnNullResponse;
      private long totalReturn;

      FakeTransactionDataEsDAO(boolean existsReturn, boolean returnNullResponse, long totalReturn) {
        this.existsReturn = existsReturn;
        this.returnNullResponse = returnNullResponse;
        this.totalReturn = totalReturn;
      }

      @Override
      public TransactionDataEsCommonMetaDO transactionSelect(
          SearchSourceBuilder searchSourceBuilder) {
        Boolean exists = existsReturn;
        if (!exists) {
          throw new BizException("找不到transaction表对应的索引");
        }
        if (returnNullResponse) {
          return TransactionDataEsCommonMetaDO.builder().total(0L).build();
        }
        return TransactionDataEsCommonMetaDO.builder().total(totalReturn).build();
      }
    }

    @Test
    public void testTransactionSelect_IndexNotExist_ThrowsBizException() {
      FakeTransactionDataEsDAO dao = new FakeTransactionDataEsDAO(false, true, 0L);
      try {
        dao.transactionSelect(new SearchSourceBuilder());
      } catch (BizException e) {
        assertEquals("找不到transaction表对应的索引", e.getMessage());
      }
    }

    @Test
    public void testTransactionSelect_NullSearchResponse_ReturnsTotalZero() {
      FakeTransactionDataEsDAO dao = new FakeTransactionDataEsDAO(true, true, 0L);
      TransactionDataEsCommonMetaDO result = dao.transactionSelect(new SearchSourceBuilder());
      assertEquals(0L, result.getTotal().longValue());
      assertEquals(null, result.getTransactionDataEsPOS());
    }
  }

  public static class TransactionDataEsDAOClearScrollTest {

    @Test(expected = NullPointerException.class)
    public void testClearScrollThrowsNPE() {
      TransactionDataEsDAO dao = new TransactionDataEsDAO();
      dao.clearScroll("test-scroll-id");
    }

    @Test(expected = NullPointerException.class)
    public void testClearScrollWithNullIdThrowsNPE() {
      TransactionDataEsDAO dao = new TransactionDataEsDAO();
      dao.clearScroll(null);
    }
  }
}
