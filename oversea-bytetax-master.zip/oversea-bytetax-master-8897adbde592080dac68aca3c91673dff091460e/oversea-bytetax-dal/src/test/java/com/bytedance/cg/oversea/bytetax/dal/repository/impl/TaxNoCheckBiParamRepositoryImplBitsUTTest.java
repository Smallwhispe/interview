package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxIdentity;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxNoCheckBiParamMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxNoCheckBiParamMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckBiParamPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxNoCheckBiParamPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxNoCheckBiParamQuery;
import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxNoCheckBiParamRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxNoCheckBiParamRepositoryImplQueryBiParamTest {

    @Mock private TaxNoCheckBiParamMapper mockTaxNoCheckBiParamMapper;

    @InjectMocks private TaxNoCheckBiParamRepositoryImpl taxNoCheckBiParamRepositoryImplUnderTest;

    @Test
    public void testQueryBiParam_Success_WithTaxIdentity() {
      // Setup
      TaxNoCheckBiParamQuery query = new TaxNoCheckBiParamQuery();
      query.setCountryCode("US");
      query.setTaxIdentity(EnumTaxIdentity.INDIVIDUAL);

      TaxNoCheckBiParamPO po = new TaxNoCheckBiParamPO();
      // 准备必要字段，确保映射不抛错
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setTaxIdentity(EnumTaxIdentity.INDIVIDUAL.getCode());
      po.setCountryIso("US");
      po.setParamList("[]");

      when(mockTaxNoCheckBiParamMapper.selectByExample(any(TaxNoCheckBiParamPOExample.class)))
          .thenReturn(Collections.singletonList(po));

      // Run
      TaxNoCheckBiParamMetaDO result = taxNoCheckBiParamRepositoryImplUnderTest.queryBiParam(query);

      // Verify
      assertNotNull(result);
      verify(mockTaxNoCheckBiParamMapper).selectByExample(any(TaxNoCheckBiParamPOExample.class));
    }

    @Test
    public void testQueryBiParam_Success_TaxIdentityNull() {
      // Setup
      TaxNoCheckBiParamQuery query = new TaxNoCheckBiParamQuery();
      query.setCountryCode(null);
      query.setTaxIdentity(null);

      TaxNoCheckBiParamPO po = new TaxNoCheckBiParamPO();
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setTaxIdentity(EnumTaxIdentity.BOTH.getCode());
      po.setCountryIso("ANY");
      po.setParamList("[]");

      when(mockTaxNoCheckBiParamMapper.selectByExample(any(TaxNoCheckBiParamPOExample.class)))
          .thenReturn(Collections.singletonList(po));

      // Run
      TaxNoCheckBiParamMetaDO result = taxNoCheckBiParamRepositoryImplUnderTest.queryBiParam(query);

      // Verify
      assertNotNull(result);
      verify(mockTaxNoCheckBiParamMapper).selectByExample(any(TaxNoCheckBiParamPOExample.class));
    }

    @Test(expected = BizException.class)
    public void testQueryBiParam_EmptyResult_ThrowsBizException() {
      // Setup
      TaxNoCheckBiParamQuery query = new TaxNoCheckBiParamQuery();
      query.setCountryCode("US");
      query.setTaxIdentity(EnumTaxIdentity.INDIVIDUAL);

      when(mockTaxNoCheckBiParamMapper.selectByExample(any(TaxNoCheckBiParamPOExample.class)))
          .thenReturn(Collections.emptyList());

      // Run
      taxNoCheckBiParamRepositoryImplUnderTest.queryBiParam(query);
    }

    @Test(expected = BizException.class)
    public void testQueryBiParam_MultipleResults_ThrowsBizException() {
      // Setup
      TaxNoCheckBiParamQuery query = new TaxNoCheckBiParamQuery();
      query.setCountryCode("US");
      query.setTaxIdentity(EnumTaxIdentity.BUSINESS);

      TaxNoCheckBiParamPO po1 = new TaxNoCheckBiParamPO();
      po1.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po1.setTaxIdentity(EnumTaxIdentity.BUSINESS.getCode());
      po1.setCountryIso("US");
      po1.setParamList("[]");

      TaxNoCheckBiParamPO po2 = new TaxNoCheckBiParamPO();
      po2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po2.setTaxIdentity(EnumTaxIdentity.BOTH.getCode());
      po2.setCountryIso("US");
      po2.setParamList("[]");

      when(mockTaxNoCheckBiParamMapper.selectByExample(any(TaxNoCheckBiParamPOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      // Run
      taxNoCheckBiParamRepositoryImplUnderTest.queryBiParam(query);
    }
  }
}
