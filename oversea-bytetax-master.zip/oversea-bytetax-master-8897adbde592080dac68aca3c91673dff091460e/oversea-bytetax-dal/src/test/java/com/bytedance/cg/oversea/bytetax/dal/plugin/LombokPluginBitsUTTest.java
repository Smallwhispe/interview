package com.bytedance.cg.oversea.bytetax.dal.plugin;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyZeroInteractions;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.Plugin.ModelClassType;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.api.dom.java.Method;
import org.mybatis.generator.api.dom.java.TopLevelClass;

@RunWith(Enclosed.class)
public class LombokPluginBitsUTTest {
  public static class LombokPluginSetPropertiesTest {

    @Test
    public void testSetProperties_DefaultDataAdded() {
      LombokPlugin plugin = new LombokPlugin();
      Properties props = new Properties();

      plugin.setProperties(props);

      TopLevelClass top = new TopLevelClass(new FullyQualifiedJavaType("com.example.Demo"));
      boolean result = plugin.modelBaseRecordClassGenerated(top, null);

      Assert.assertEquals(true, result);

      List<String> annotations = top.getAnnotations();
      Assert.assertTrue(annotations.contains("@Data"));

      Set<FullyQualifiedJavaType> imports = top.getImportedTypes();
      Assert.assertTrue(imports.contains(new FullyQualifiedJavaType("lombok.Data")));
    }

    @Test
    public void testSetProperties_EnableAccessorsAndAllArgsConstructorWithOptions() {
      LombokPlugin plugin = new LombokPlugin();
      Properties props = new Properties();

      // enable accessors with options
      props.setProperty("accessors", "true");
      props.setProperty("accessors.chain", "true");
      props.setProperty("accessors.prefix", "a,b");

      // enable allArgsConstructor with option, which should also add dependency noArgsConstructor
      props.setProperty("allArgsConstructor", "true");
      props.setProperty("allArgsConstructor.staticName", "of");

      plugin.setProperties(props);

      TopLevelClass top = new TopLevelClass(new FullyQualifiedJavaType("com.example.Demo"));
      boolean result = plugin.modelBaseRecordClassGenerated(top, null);
      Assert.assertEquals(true, result);

      List<String> annos = top.getAnnotations();

      // always contains Data
      Assert.assertTrue(annos.contains("@Data"));

      // contains Accessors with both options (order of options is not guaranteed)
      String accessorsAnno = findAnnotation(annos, "@Accessors");
      Assert.assertNotNull(accessorsAnno);
      Assert.assertTrue(accessorsAnno.contains("chain=true"));
      Assert.assertTrue(accessorsAnno.contains("prefix={\"a\",\"b\"}"));

      // contains AllArgsConstructor with option
      String allArgsAnno = findAnnotation(annos, "@AllArgsConstructor");
      Assert.assertNotNull(allArgsAnno);
      Assert.assertTrue(allArgsAnno.contains("staticName=\"of\""));

      // contains dependency NoArgsConstructor (no options)
      Assert.assertTrue(annos.contains("@NoArgsConstructor"));

      // verify imports
      Set<FullyQualifiedJavaType> imports = top.getImportedTypes();
      Assert.assertTrue(imports.contains(new FullyQualifiedJavaType("lombok.Data")));
      Assert.assertTrue(
          imports.contains(new FullyQualifiedJavaType("lombok.experimental.Accessors")));
      Assert.assertTrue(imports.contains(new FullyQualifiedJavaType("lombok.AllArgsConstructor")));
      Assert.assertTrue(imports.contains(new FullyQualifiedJavaType("lombok.NoArgsConstructor")));
    }

    @Test
    public void testSetProperties_DisableAnnotationByFlag() {
      LombokPlugin plugin = new LombokPlugin();
      Properties props = new Properties();

      // explicitly disabled builder; even if options exist they should be ignored
      props.setProperty("builder", "false");
      props.setProperty("builder.toBuilder", "true");

      plugin.setProperties(props);

      TopLevelClass top = new TopLevelClass(new FullyQualifiedJavaType("com.example.Demo"));
      boolean result = plugin.modelBaseRecordClassGenerated(top, null);
      Assert.assertEquals(true, result);

      List<String> annos = top.getAnnotations();

      // default DATA should exist
      Assert.assertTrue(annos.contains("@Data"));

      // builder should not be added
      Assert.assertNull(findAnnotation(annos, "@Builder"));

      // import for builder should not exist
      Set<FullyQualifiedJavaType> imports = top.getImportedTypes();
      Assert.assertFalse(imports.contains(new FullyQualifiedJavaType("lombok.Builder")));
    }

    private String findAnnotation(List<String> annotations, String namePrefix) {
      for (String a : annotations) {
        if (a.startsWith(namePrefix)) {
          return a;
        }
      }
      return null;
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class LombokPluginClientGeneratedTest {

    @Mock private Interface mockInterface;

    @Mock private TopLevelClass mockTopLevelClass;

    @Mock private IntrospectedTable mockIntrospectedTable;

    private LombokPlugin lombokPlugin;

    @Before
    public void setUp() {
      lombokPlugin = new LombokPlugin();
    }

    @Test
    public void testClientGenerated() {
      // Run the test
      final boolean result =
          lombokPlugin.clientGenerated(mockInterface, mockTopLevelClass, mockIntrospectedTable);

      // Verify the results
      verify(mockInterface)
          .addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.Mapper"));
      verify(mockInterface).addAnnotation("@Mapper");
      assertEquals(true, result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class LombokPluginModelRecordWithBLOBsClassGeneratedTest {

    @Test
    public void testModelRecordWithBLOBsClassGenerated_DefaultDataAnnotation() {
      LombokPlugin plugin = new LombokPlugin();
      Properties properties = new Properties();
      plugin.setProperties(properties);

      TopLevelClass topLevelClass = Mockito.mock(TopLevelClass.class);
      IntrospectedTable introspectedTable = Mockito.mock(IntrospectedTable.class);

      boolean result = plugin.modelRecordWithBLOBsClassGenerated(topLevelClass, introspectedTable);

      verify(topLevelClass).addImportedType(new FullyQualifiedJavaType("lombok.Data"));
      verify(topLevelClass).addAnnotation("@Data");
      assertEquals(true, result);
    }
  }

  public static class LombokPluginModelPrimaryKeyClassGeneratedTest {

    @Test
    public void testModelPrimaryKeyClassGenerated_DefaultDataAnnotation() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();
      Properties properties = new Properties();
      plugin.setProperties(properties);

      TopLevelClass topLevelClass = new TopLevelClass(new FullyQualifiedJavaType("com.example.PK"));

      // Run the test
      boolean result =
          plugin.modelPrimaryKeyClassGenerated(topLevelClass, (IntrospectedTable) null);

      // Verify the results
      assertTrue(result);

      List<String> annotations = topLevelClass.getAnnotations();
      Set<FullyQualifiedJavaType> imports = topLevelClass.getImportedTypes();

      // should contain @Data
      assertTrue(annotations.contains("@Data"));
      // should import lombok.Data
      assertTrue(imports.contains(new FullyQualifiedJavaType("lombok.Data")));
    }

    @Test
    public void testModelPrimaryKeyClassGenerated_WithAdditionalAccessorsAnnotation() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();
      Properties properties = new Properties();
      // enable accessors and provide one option so that it gets added
      properties.setProperty("accessors", "true");
      properties.setProperty("accessors.chain", "true");
      plugin.setProperties(properties);

      TopLevelClass topLevelClass = new TopLevelClass("com.example.PK2");

      // Run the test
      boolean result =
          plugin.modelPrimaryKeyClassGenerated(topLevelClass, (IntrospectedTable) null);

      // Verify the results
      assertTrue(result);

      List<String> annotations = topLevelClass.getAnnotations();
      Set<FullyQualifiedJavaType> imports = topLevelClass.getImportedTypes();

      // should always have @Data by default
      assertTrue(annotations.contains("@Data"));
      assertTrue(imports.contains(new FullyQualifiedJavaType("lombok.Data")));

      // should also have @Accessors when configured with options
      boolean hasAccessors = false;
      for (String ann : annotations) {
        if (ann.startsWith("@Accessors")) {
          hasAccessors = true;
          break;
        }
      }
      assertTrue(hasAccessors);
      assertTrue(imports.contains(new FullyQualifiedJavaType("lombok.experimental.Accessors")));
    }
  }

  public static class LombokPluginModelBaseRecordClassGeneratedTest {

    @Test
    public void testModelBaseRecordClassGenerated_DefaultDataAnnotation() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();
      Properties properties = new Properties();
      plugin.setProperties(properties);

      TopLevelClass topLevelClass =
          new TopLevelClass(new FullyQualifiedJavaType("com.example.TestModel"));

      // Run
      boolean result = plugin.modelBaseRecordClassGenerated(topLevelClass, null);

      // Verify
      assertEquals(true, result);

      Set<FullyQualifiedJavaType> importedTypes = topLevelClass.getImportedTypes();
      assertTrue(importedTypes.contains(new FullyQualifiedJavaType("lombok.Data")));

      List<String> annotations = topLevelClass.getAnnotations();
      assertTrue(annotations.contains("@Data"));
    }

    @Test
    public void testModelBaseRecordClassGenerated_EnableMultipleAnnotations() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();
      Properties properties = new Properties();
      properties.setProperty("builder", "true");
      properties.setProperty("allArgsConstructor", "true");
      properties.setProperty("noArgsConstructor", "true");
      properties.setProperty("accessors", "true");
      properties.setProperty(
          "accessors.chain",
          "true"); // only accessors has an option, so only it will be added besides default @Data
      plugin.setProperties(properties);

      TopLevelClass topLevelClass =
          new TopLevelClass(new FullyQualifiedJavaType("com.example.TestModel2"));

      // Run
      boolean result = plugin.modelBaseRecordClassGenerated(topLevelClass, null);

      // Verify
      assertEquals(true, result);

      Set<FullyQualifiedJavaType> importedTypes = topLevelClass.getImportedTypes();
      // default @Data
      assertTrue(importedTypes.contains(new FullyQualifiedJavaType("lombok.Data")));
      // only accessors is expected to be added because it has options provided
      assertTrue(
          importedTypes.contains(new FullyQualifiedJavaType("lombok.experimental.Accessors")));

      List<String> annotations = topLevelClass.getAnnotations();
      assertTrue(annotations.contains("@Data"));

      boolean hasAccessors = false;
      for (String ann : annotations) {
        if (ann.startsWith("@Accessors")) {
          hasAccessors = true;
          break;
        }
      }
      assertTrue(hasAccessors);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class LombokPluginModelSetterMethodGeneratedTest {

    @Mock private Method method;

    @Mock private TopLevelClass topLevelClass;

    @Mock private IntrospectedColumn introspectedColumn;

    @Mock private IntrospectedTable introspectedTable;

    @Test
    public void testModelSetterMethodGenerated_BaseRecord() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();

      // Run the test
      boolean result =
          plugin.modelSetterMethodGenerated(
              method,
              topLevelClass,
              introspectedColumn,
              introspectedTable,
              ModelClassType.BASE_RECORD);

      // Verify the results
      assertEquals(false, result);
      verifyZeroInteractions(method, topLevelClass, introspectedColumn, introspectedTable);
    }

    @Test
    public void testModelSetterMethodGenerated_PrimaryKey() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();

      // Run the test
      boolean result =
          plugin.modelSetterMethodGenerated(
              method,
              topLevelClass,
              introspectedColumn,
              introspectedTable,
              ModelClassType.PRIMARY_KEY);

      // Verify the results
      assertEquals(false, result);
      verifyZeroInteractions(method, topLevelClass, introspectedColumn, introspectedTable);
    }

    @Test
    public void testModelSetterMethodGenerated_RecordWithBlobs() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();

      // Run the test
      boolean result =
          plugin.modelSetterMethodGenerated(
              method,
              topLevelClass,
              introspectedColumn,
              introspectedTable,
              ModelClassType.RECORD_WITH_BLOBS);

      // Verify the results
      assertEquals(false, result);
      verifyZeroInteractions(method, topLevelClass, introspectedColumn, introspectedTable);
    }
  }

  public static class LombokPluginValidateTest {

    @Test
    public void testValidate_WithEmptyWarnings() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();
      List<String> warnings = new ArrayList<String>();

      // Run
      boolean result = plugin.validate(warnings);

      // Verify
      assertEquals(true, result);
      assertEquals(0, warnings.size());
    }

    @Test
    public void testValidate_WithNonEmptyWarnings_Unchanged() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();
      List<String> warnings = new ArrayList<String>();
      warnings.add("warn1");
      warnings.add("warn2");

      // Run
      boolean result = plugin.validate(warnings);

      // Verify
      assertEquals(true, result);
      assertEquals(2, warnings.size());
      assertEquals("warn1", warnings.get(0));
      assertEquals("warn2", warnings.get(1));
    }

    @Test
    public void testValidate_WithNullWarnings() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();

      // Run
      boolean result = plugin.validate(null);

      // Verify
      assertEquals(true, result);
    }
  }

  public static class LombokPluginModelGetterMethodGeneratedTest {

    @Test
    public void testModelGetterMethodGenerated_ReturnsFalse_WithNullArgs() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();

      // Run the test
      boolean result = plugin.modelGetterMethodGenerated(null, null, null, null, null);

      // Verify the results
      assertEquals(false, result);
    }

    @Test
    public void testModelGetterMethodGenerated_ReturnsFalse_WithMethodAndModelClassType() {
      // Setup
      LombokPlugin plugin = new LombokPlugin();
      Method method = new Method("getField");

      // Run the test
      boolean result =
          plugin.modelGetterMethodGenerated(method, null, null, null, ModelClassType.BASE_RECORD);

      // Verify the results
      assertEquals(false, result);
    }
  }
}
