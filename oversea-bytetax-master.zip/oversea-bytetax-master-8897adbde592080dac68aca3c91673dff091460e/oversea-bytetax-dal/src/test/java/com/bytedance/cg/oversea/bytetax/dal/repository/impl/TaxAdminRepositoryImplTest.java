package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTimeType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTransactionType;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminSubjectMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxAdminMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxAdminQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TaxAdminRepositoryImplTest {

    @Mock
    private TaxAdminMapper mockTaxAdminMapper;
    @Mock
    private TaxAdminSubjectMapper mockTaxAdminSubjectMapper;
    @Mock
    private TaxAdminRepository mockTaxAdminRepository;

    @InjectMocks
    private TaxAdminRepositoryImpl taxAdminRepositoryImplUnderTest;

    @Test
    public void testSave() {
        // Setup
        final TaxAdminMetaDO metaDO = new TaxAdminMetaDO(0L, "remark", "taxationCurrency", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, 0, 0, "name", "countryName", 0, EnumTaxTimeType.CONSUME_TIME, EnumTaxNoType.GST_HST, new AddressMetaDO(0L, 0L, 0L, 0L));
        when(mockTaxAdminMapper.insert(any())).thenReturn(0);

        // Run the test
        taxAdminRepositoryImplUnderTest.save(metaDO);

        // Verify the results
        verify(mockTaxAdminMapper).insert(any());
    }

    @Test
    public void testQueryTaxAdminList() {
        // Setup
        final TaxAdminQuery query = new TaxAdminQuery(0L, "exactName", "fuzzyName", 0L, new AddressMetaDO(0L, 0L, 0L, 0L), EnumTaxTimeType.CONSUME_TIME, "countryName", 0, 0);
        final PageResult<TaxAdminMetaDO> expectedResult = new PageResult<>(1L, Arrays.asList(new TaxAdminMetaDO(0L, "remark", "taxationCurrency", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, 0, 0, "name", "countryName", 0, EnumTaxTimeType.CONSUME_TIME, EnumTaxNoType.GST_HST, new AddressMetaDO(0L, 0L, null, null))));

        // Configure TaxAdminMapper.selectByExample(...).
        final TaxAdminPO taxAdminPO = new TaxAdminPO();
        taxAdminPO.setId(0L);
        taxAdminPO.setRemark("remark");
        taxAdminPO.setTaxationCurrency("taxationCurrency");
        taxAdminPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminPO.setIsDelete(0);
        taxAdminPO.setCountryId(0L);
        taxAdminPO.setLevelOne(0L);
        taxAdminPO.setReportDateType(0);
        taxAdminPO.setReportDate(0);
        taxAdminPO.setName("name");
        taxAdminPO.setCountryName("countryName");
        taxAdminPO.setOperatorId(0);
        taxAdminPO.setTaxTimeType(1);
        taxAdminPO.setTaxNoType("GST/HST");
        final List<TaxAdminPO> taxAdminPOS = Arrays.asList(taxAdminPO);
        when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class))).thenReturn(taxAdminPOS);

        // Run the test
        final PageResult<TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.queryTaxAdminList(query);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testQueryTaxAdminList_TaxAdminMapperReturnsNoItems() {
        // Setup
        final TaxAdminQuery query = new TaxAdminQuery(0L, "exactName", "fuzzyName", 0L, new AddressMetaDO(0L, 0L, 0L, 0L), EnumTaxTimeType.CONSUME_TIME, "countryName", 0, 0);
        when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final PageResult<TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.queryTaxAdminList(query);

        // Verify the results
        assertEquals(Collections.emptyList(), result.getData());
    }

    @Test
    public void testGetTaxAdminById() {
        // Setup
        final TaxAdminMetaDO expectedResult = new TaxAdminMetaDO(0L, "remark", "taxationCurrency", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, 0, 0, "name", "countryName", 0, EnumTaxTimeType.CONSUME_TIME, EnumTaxNoType.GST_HST, new AddressMetaDO(0L, 0L, 0L, 0L));

        // Configure TaxAdminRepository.getAllTaxAdmin(...).
        final List<TaxAdminMetaDO> taxAdminMetaDOS = Arrays.asList(new TaxAdminMetaDO(0L, "remark", "taxationCurrency", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, 0, 0, "name", "countryName", 0, EnumTaxTimeType.CONSUME_TIME, EnumTaxNoType.GST_HST, new AddressMetaDO(0L, 0L, 0L, 0L)));
        when(mockTaxAdminRepository.getAllTaxAdmin(false)).thenReturn(taxAdminMetaDOS);

        // Run the test
        final TaxAdminMetaDO result = taxAdminRepositoryImplUnderTest.getTaxAdminById(0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetTaxAdminById_TaxAdminRepositoryReturnsNoItems() {
        // Setup
        when(mockTaxAdminRepository.getAllTaxAdmin(false)).thenReturn(Collections.emptyList());

        // Run the test
        final TaxAdminMetaDO result = taxAdminRepositoryImplUnderTest.getTaxAdminById(0L);

        // Verify the results
        assertNull(result);
    }

    @Test
    public void testGetTaxAdminsByIds() {
        // Setup
        final Map<Long, TaxAdminMetaDO> expectedResult = new HashMap<>();

        // Configure TaxAdminMapper.selectByExample(...).
        final TaxAdminPO taxAdminPO = new TaxAdminPO();
        taxAdminPO.setId(0L);
        taxAdminPO.setRemark("remark");
        taxAdminPO.setTaxationCurrency("taxationCurrency");
        taxAdminPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminPO.setIsDelete(0);
        taxAdminPO.setCountryId(0L);
        taxAdminPO.setLevelOne(0L);
        taxAdminPO.setReportDateType(0);
        taxAdminPO.setReportDate(0);
        final List<TaxAdminPO> taxAdminPOS = Arrays.asList(taxAdminPO);
        expectedResult.put(taxAdminPO.getId(), TaxAdminMapping.MAPPING.toMetaDO(taxAdminPO));
        when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class))).thenReturn(taxAdminPOS);

        // Run the test
        final Map<Long, TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.getTaxAdminsByIds(Arrays.asList(0L));

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetTaxAdminsByIds_TaxAdminMapperReturnsNoItems() {
        // Setup
        final Map<Long, TaxAdminMetaDO> expectedResult = new HashMap<>();
        when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final Map<Long, TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.getTaxAdminsByIds(Arrays.asList(0L));

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetTaxAdminSubById() {
        // Setup
        final TaxAdminSubjectMetaDO expectedResult = new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L);

        // Configure TaxAdminRepository.getAllTaxAdminSubject(...).
        final List<TaxAdminSubjectMetaDO> taxAdminSubjectMetaDOS = Arrays.asList(new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L));
        when(mockTaxAdminRepository.getAllTaxAdminSubject(false)).thenReturn(taxAdminSubjectMetaDOS);

        // Run the test
        final TaxAdminSubjectMetaDO result = taxAdminRepositoryImplUnderTest.getTaxAdminSubById(0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetTaxAdminSubById_TaxAdminRepositoryReturnsNoItems() {
        // Setup
        when(mockTaxAdminRepository.getAllTaxAdminSubject(false)).thenReturn(Collections.emptyList());

        // Run the test
        final TaxAdminSubjectMetaDO result = taxAdminRepositoryImplUnderTest.getTaxAdminSubById(0L);

        // Verify the results
        assertNull(result);
    }

    @Test
    public void testGetTaxAdminSubsByIds_TaxAdminRepositoryReturnsNoItems() {
        // Setup
        final Map<Long, TaxAdminSubjectMetaDO> expectedResult = new HashMap<>();
        when(mockTaxAdminRepository.getAllTaxAdminSubject(false)).thenReturn(Collections.emptyList());

        // Run the test
        final Map<Long, TaxAdminSubjectMetaDO> result = taxAdminRepositoryImplUnderTest.getTaxAdminSubsByIds(Arrays.asList(0L));

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testSaveTaxAdminSub() {
        // Setup
        final TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L);
        when(mockTaxAdminSubjectMapper.insertSelective(any())).thenReturn(0);

        // Run the test
        final Long result = taxAdminRepositoryImplUnderTest.saveTaxAdminSub(metaDO);

        // Verify the results
        verify(mockTaxAdminSubjectMapper).insertSelective(any(TaxAdminSubjectPO.class));
    }

    @Test
    public void testGetAllTaxAdmin() {
        // Setup
        final List<TaxAdminMetaDO> expectedResult = Arrays.asList(new TaxAdminMetaDO(0L, "remark", "taxationCurrency", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, 0, 0, "name", "countryName", 0, EnumTaxTimeType.CONSUME_TIME, EnumTaxNoType.GST_HST, new AddressMetaDO(0L, 0L, null, null)));

        // Configure TaxAdminMapper.selectByExample(...).
        final TaxAdminPO taxAdminPO = new TaxAdminPO();
        taxAdminPO.setId(0L);
        taxAdminPO.setRemark("remark");
        taxAdminPO.setTaxationCurrency("taxationCurrency");
        taxAdminPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminPO.setIsDelete(0);
        taxAdminPO.setCountryId(0L);
        taxAdminPO.setLevelOne(0L);
        taxAdminPO.setReportDateType(0);
        taxAdminPO.setReportDate(0);
        taxAdminPO.setName("name");
        taxAdminPO.setCountryName("countryName");
        taxAdminPO.setOperatorId(0);
        taxAdminPO.setTaxTimeType(1);
        taxAdminPO.setTaxNoType("GST/HST");
        final List<TaxAdminPO> taxAdminPOS = Arrays.asList(taxAdminPO);
        when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class))).thenReturn(taxAdminPOS);

        // Run the test
        final List<TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdmin(false);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetAllTaxAdmin_TaxAdminMapperReturnsNoItems() {
        // Setup
        when(mockTaxAdminMapper.selectByExample(any(TaxAdminPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<TaxAdminMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdmin(false);

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testGetAllTaxAdminSubject1() {
        // Setup
        final List<TaxAdminSubjectMetaDO> expectedResult = Arrays.asList(new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L));

        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(0);
        taxAdminSubjectPO.setOperatorId(0L);
        taxAdminSubjectPO.setTaxTransactionType(1);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdminSubject(false);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetAllTaxAdminSubject1_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdminSubject(false);

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testGetAllTaxAdminSubject2_TaxAdminRepositoryReturnsNoItems() {
        // Setup
        final Map<Long, TaxAdminSubjectMetaDO> expectedResult = new HashMap<>();
        when(mockTaxAdminRepository.getAllTaxAdminSubject(false)).thenReturn(Collections.emptyList());

        // Run the test
        final Map<Long, TaxAdminSubjectMetaDO> result = taxAdminRepositoryImplUnderTest.getAllTaxAdminSubject(0L, false);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetAllTaxAdminSubjectTaxNo() {
        // Setup
        final Map<Long, String> expectedResult = new HashMap<>();

        // Configure TaxAdminRepository.getAllTaxAdminSubject(...).
        final List<TaxAdminSubjectMetaDO> taxAdminSubjectMetaDOS = Arrays.asList(new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L));
        expectedResult.put(taxAdminSubjectMetaDOS.get(0).getId(),taxAdminSubjectMetaDOS.get(0).getTaxNo());
        when(mockTaxAdminRepository.getAllTaxAdminSubject(false)).thenReturn(taxAdminSubjectMetaDOS);

        // Run the test
        final Map<Long, String> result = taxAdminRepositoryImplUnderTest.getAllTaxAdminSubjectTaxNo(0L, false);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetAllTaxAdminSubjectTaxNo_TaxAdminRepositoryReturnsNoItems() {
        // Setup
        final Map<Long, String> expectedResult = new HashMap<>();
        when(mockTaxAdminRepository.getAllTaxAdminSubject(false)).thenReturn(Collections.emptyList());

        // Run the test
        final Map<Long, String> result = taxAdminRepositoryImplUnderTest.getAllTaxAdminSubjectTaxNo(0L, false);

        // Verify the results
        assertEquals(expectedResult, result);
    }
}
