package com.bytedance.cg.oversea.bytetax.dal.query;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class TaxRuleQueryBitsUTTest {
  public static class TaxRuleQueryGenerateBillFromCountrySqlTest {

    @Test
    public void testGenerateBillFromCountrySql_BillFromNull() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();

      // Run the test
      final String result = query.generateBillFromCountrySql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillFromCountrySql_LevelZeroNull() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();
      final AddressMetaDO billFrom = new AddressMetaDO();
      query.setBillFrom(billFrom);

      // Run the test
      final String result = query.generateBillFromCountrySql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillFromCountrySql_LevelZeroIsZero() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();
      final AddressMetaDO billFrom = new AddressMetaDO();
      billFrom.setLevelZero(0L);
      query.setBillFrom(billFrom);
      final String expected = "(bill_from is null or bill_from like '%\"levelZero\":0,%')";

      // Run the test
      final String result = query.generateBillFromCountrySql();

      // Verify the results
      assertEquals(expected, result);
    }

    @Test
    public void testGenerateBillFromCountrySql_LevelZeroNonZero() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();
      final AddressMetaDO billFrom = new AddressMetaDO();
      billFrom.setLevelZero(100L);
      query.setBillFrom(billFrom);
      final String expected = "(bill_from like '%\"levelZero\":100,%')";

      // Run the test
      final String result = query.generateBillFromCountrySql();

      // Verify the results
      assertEquals(expected, result);
    }
  }

  public static class TaxRuleQueryGenerateBillFromRegionSqlTest {

    @Test
    public void testGenerateBillFromRegionSql_BillFromNull() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();

      // Run the test
      final String result = query.generateBillFromRegionSql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillFromRegionSql_LevelOneNull() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();
      final AddressMetaDO billFrom = new AddressMetaDO();
      billFrom.setLevelOne(null);
      query.setBillFrom(billFrom);

      // Run the test
      final String result = query.generateBillFromRegionSql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillFromRegionSql_LevelOneZero() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();
      final AddressMetaDO billFrom = new AddressMetaDO();
      billFrom.setLevelOne(0L);
      query.setBillFrom(billFrom);

      // Run the test
      final String result = query.generateBillFromRegionSql();

      // Verify the results
      assertEquals("(bill_from is null or bill_from like '%\"levelOne\":0,%')", result);
    }

    @Test
    public void testGenerateBillFromRegionSql_LevelOneNonZero() {
      // Setup
      final TaxRuleQuery query = new TaxRuleQuery();
      final AddressMetaDO billFrom = new AddressMetaDO();
      billFrom.setLevelOne(123L);
      query.setBillFrom(billFrom);

      // Run the test
      final String result = query.generateBillFromRegionSql();

      // Verify the results
      assertEquals("(bill_from like '%\"levelOne\":123,%')", result);
    }
  }

  public static class TaxRuleQueryGenerateBillToRegionSqlTest {

    @Test
    public void testGenerateBillToRegionSql_NullBillTo() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      query.setBillTo(null);

      // Run the test
      String result = query.generateBillToRegionSql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillToRegionSql_NullLevelOne() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      AddressMetaDO billTo = new AddressMetaDO();
      billTo.setLevelOne(null);
      query.setBillTo(billTo);

      // Run the test
      String result = query.generateBillToRegionSql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillToRegionSql_LevelOneIsZero() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      AddressMetaDO billTo = new AddressMetaDO();
      billTo.setLevelOne(0L);
      query.setBillTo(billTo);

      // Run the test
      String result = query.generateBillToRegionSql();

      // Verify the results
      assertEquals("(bill_to is null or bill_to like '%\"levelOne\":0,%')", result);
    }

    @Test
    public void testGenerateBillToRegionSql_LevelOneNonZero() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      AddressMetaDO billTo = new AddressMetaDO();
      billTo.setLevelOne(123L);
      query.setBillTo(billTo);

      // Run the test
      String result = query.generateBillToRegionSql();

      // Verify the results
      assertEquals("(bill_to like '%\"levelOne\":123,%')", result);
    }
  }

  public static class TaxRuleQueryGenerateBillToCountrySqlTest {

    @Test
    public void testGenerateBillToCountrySql_BillToNull() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      query.setBillTo(null);

      // Run the test
      String result = query.generateBillToCountrySql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillToCountrySql_LevelZeroNull() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      AddressMetaDO address = new AddressMetaDO();
      address.setLevelZero(null);
      query.setBillTo(address);

      // Run the test
      String result = query.generateBillToCountrySql();

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGenerateBillToCountrySql_LevelZeroIsZero() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      AddressMetaDO address = new AddressMetaDO();
      address.setLevelZero(0L);
      query.setBillTo(address);

      // Run the test
      String result = query.generateBillToCountrySql();

      // Verify the results
      assertEquals("(bill_to is null or bill_to like '%\"levelZero\":0,%')", result);
    }

    @Test
    public void testGenerateBillToCountrySql_LevelZeroPositive() {
      // Setup
      TaxRuleQuery query = new TaxRuleQuery();
      AddressMetaDO address = new AddressMetaDO();
      address.setLevelZero(123L);
      query.setBillTo(address);

      // Run the test
      String result = query.generateBillToCountrySql();

      // Verify the results
      assertEquals("(bill_to like '%\"levelZero\":123,%')", result);
    }
  }
}
