package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxRuleMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxRuleMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePOExample.Criteria;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxRuleQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxRuleRepository;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxRuleRepositoryImplBitsUTTest {

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplSaveTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;

    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      final TaxRuleMetaDO metaDO = new TaxRuleMetaDO();
      metaDO.setIsReverseCharge(Boolean.FALSE);

      when(mockTaxRuleMapper.insert(any(TaxRulePO.class)))
          .thenAnswer(
              invocation -> {
                TaxRulePO po = (TaxRulePO) invocation.getArguments()[0];
                po.setId(100L);
                return 1;
              });

      // Run the test
      taxRuleRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      verify(mockTaxRuleMapper).insert(any(TaxRulePO.class));
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertEquals(metaDO.getCreateTime(), metaDO.getModifyTime());
      assertEquals(EnumDeleteStatus.ACTIVE, metaDO.getIsDelete());
      assertEquals(100L, metaDO.getId().longValue());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplQueryByIdTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testQueryById() {
      // Setup
      TaxRulePO taxRulePO = new TaxRulePO();
      taxRulePO.setId(0L);
      taxRulePO.setIsReverseCharge(0);
      List<TaxRulePO> taxRulePOS = Arrays.asList(taxRulePO);
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class))).thenReturn(taxRulePOS);

      TaxRuleMetaDO expected = new TaxRuleMetaDO();
      expected.setId(0L);
      expected.setIsReverseCharge(false);

      // Run the test
      final TaxRuleMetaDO result = taxRuleRepositoryImplUnderTest.queryById(0L);

      // Verify the results
      assertEquals(expected, result);
    }

    @Test
    public void testQueryById_TaxRuleMapperReturnsNoItems() {
      // Setup
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Collections.emptyList());

      // Run the test
      final TaxRuleMetaDO result = taxRuleRepositoryImplUnderTest.queryById(0L);

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testQueryById_NullId() {
      // Run the test
      final TaxRuleMetaDO result = taxRuleRepositoryImplUnderTest.queryById(null);

      // Verify the results
      assertNull(result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplQueryByIdsTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;
    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @Mock
    private com.bytedance.cg.oversea.bytetax.dal.repository.TaxRuleRepository mockTaxRuleRepository;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testQueryByIds_NullIds() {
      final List<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryByIds(null, true);
      assertEquals(0, result.size());
      verify(mockTaxRuleMapper, never()).selectByExample(any(TaxRulePOExample.class));
    }

    @Test
    public void testQueryByIds_EmptyIds() {
      final List<TaxRuleMetaDO> result =
          taxRuleRepositoryImplUnderTest.queryByIds(Collections.<Long>emptyList(), false);
      assertEquals(0, result.size());
      verify(mockTaxRuleMapper, never()).selectByExample(any(TaxRulePOExample.class));
    }

    @Test
    public void testQueryByIds_NeedActiveFalse() {
      TaxRulePO po1 = new TaxRulePO();
      po1.setId(1L);
      po1.setIsReverseCharge(0);
      po1.setIsDelete(0);
      TaxRulePO po2 = new TaxRulePO();
      po2.setId(2L);
      po2.setIsReverseCharge(0);
      po2.setIsDelete(0);
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(po1, po2));

      final List<TaxRuleMetaDO> result =
          taxRuleRepositoryImplUnderTest.queryByIds(Arrays.asList(1L, 2L), false);

      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());
      assertEquals(Long.valueOf(2L), result.get(1).getId());

      ArgumentCaptor<TaxRulePOExample> captor = ArgumentCaptor.forClass(TaxRulePOExample.class);
      verify(mockTaxRuleMapper).selectByExample(captor.capture());
      TaxRulePOExample passedExample = captor.getValue();

      assertEquals(1, passedExample.getOredCriteria().size());
      Criteria criteria = passedExample.getOredCriteria().get(0);
      boolean hasIdIn = false;
      boolean hasIsDeleteEq = false;
      for (Object criterionObj : criteria.getAllCriteria()) {
        com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePOExample.Criterion crt =
            (com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePOExample.Criterion) criterionObj;
        if ("id in".equals(crt.getCondition())) {
          hasIdIn = true;
        }
        if ("is_delete =".equals(crt.getCondition())) {
          hasIsDeleteEq = true;
        }
      }
      assertEquals(true, hasIdIn);
      assertEquals(false, hasIsDeleteEq);
    }

    @Test
    public void testQueryByIds_NeedActiveTrue() {
      TaxRulePO po = new TaxRulePO();
      po.setId(10L);
      po.setIsReverseCharge(0);
      po.setIsDelete(0);
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(po));

      final List<TaxRuleMetaDO> result =
          taxRuleRepositoryImplUnderTest.queryByIds(Arrays.asList(10L), true);

      assertEquals(1, result.size());
      assertEquals(Long.valueOf(10L), result.get(0).getId());

      verify(mockTaxRuleMapper).selectByExample(any(TaxRulePOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplValidateTest {

    private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Before
    public void setUp() {
      taxRuleRepositoryImplUnderTest = new TaxRuleRepositoryImpl();
    }

    @Test
    public void testValidate_EscapeUnderscoreAndPercent() {
      // Setup
      String input = "abc_def%ghi";
      String expected = "abc\\_def\\%ghi";

      // Run the test
      String result = taxRuleRepositoryImplUnderTest.validate(input);

      // Verify the results
      assertEquals(expected, result);
    }

    @Test
    public void testValidate_TrimAndEscape() {
      // Setup
      String input = "  _abc%  ";
      String expected = "\\_abc\\%";

      // Run the test
      String result = taxRuleRepositoryImplUnderTest.validate(input);

      // Verify the results
      assertEquals(expected, result);
    }

    @Test
    public void testValidate_OnlySpaces() {
      // Setup
      String input = "   ";
      String expected = "";

      // Run the test
      String result = taxRuleRepositoryImplUnderTest.validate(input);

      // Verify the results
      assertEquals(expected, result);
    }

    @Test
    public void testValidate_NoSpecialChars_OnlyTrim() {
      // Setup
      String input = "  abc def  ";
      String expected = "abc def";

      // Run the test
      String result = taxRuleRepositoryImplUnderTest.validate(input);

      // Verify the results
      assertEquals(expected, result);
    }

    @Test(expected = NullPointerException.class)
    public void testValidate_NullInput_ThrowsException() {
      // Run the test
      taxRuleRepositoryImplUnderTest.validate(null);
    }

    @Test
    public void testValidate_MultipleConsecutiveSpecials() {
      // Setup
      String input = "%%__";
      String expected = "\\%\\%\\_\\_";

      // Run the test
      String result = taxRuleRepositoryImplUnderTest.validate(input);

      // Verify the results
      assertEquals(expected, result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplUpdateByIdTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;
    @Mock private TaxCategoryMapper mockTaxCategoryMapper;
    @Mock private TaxRuleRepository mockTaxRuleRepository;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testUpdateById_Success() {
      TaxRuleMetaDO input = new TaxRuleMetaDO();
      input.setId(1L);

      TaxRuleMetaDO existed = new TaxRuleMetaDO();
      existed.setId(1L);
      existed.setIsDelete(EnumDeleteStatus.ACTIVE);

      when(mockTaxRuleRepository.queryById(1L)).thenReturn(existed);
      when(mockTaxRuleMapper.updateByPrimaryKey(any())).thenReturn(1);

      taxRuleRepositoryImplUnderTest.updateById(input);

      verify(mockTaxRuleMapper).updateByPrimaryKey(any());
    }

    @Test
    public void testUpdateById_OrgNull_ThrowsBizException() {
      TaxRuleMetaDO input = new TaxRuleMetaDO();
      input.setId(2L);

      when(mockTaxRuleRepository.queryById(2L)).thenReturn(null);

      try {
        taxRuleRepositoryImplUnderTest.updateById(input);
      } catch (BizException e) {
        verify(mockTaxRuleMapper, never()).updateByPrimaryKey(any());
        return;
      }
      throw new AssertionError("BizException expected");
    }

    @Test
    public void testUpdateById_OrgDeleted_ThrowsBizException() {
      TaxRuleMetaDO input = new TaxRuleMetaDO();
      input.setId(3L);

      TaxRuleMetaDO existed = new TaxRuleMetaDO();
      existed.setId(3L);
      existed.setIsDelete(EnumDeleteStatus.DELETED);

      when(mockTaxRuleRepository.queryById(3L)).thenReturn(existed);

      try {
        taxRuleRepositoryImplUnderTest.updateById(input);
      } catch (BizException e) {
        verify(mockTaxRuleMapper, never()).updateByPrimaryKey(any());
        return;
      }
      throw new AssertionError("BizException expected");
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;

    @Mock
    private com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryMapper mockTaxCategoryMapper;

    @Mock private TaxRuleRepository mockTaxRuleRepository;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective_Success() {
      // Setup
      TaxRuleMetaDO metaDO = new TaxRuleMetaDO();
      metaDO.setId(1L);

      TaxRuleMetaDO orgMeta = new TaxRuleMetaDO();
      orgMeta.setId(1L);
      orgMeta.setIsDelete(EnumDeleteStatus.ACTIVE);

      when(mockTaxRuleRepository.queryById(1L)).thenReturn(orgMeta);
      when(mockTaxRuleMapper.updateByPrimaryKeySelective(any())).thenReturn(1);

      // Run the test
      taxRuleRepositoryImplUnderTest.updateByIdSelective(metaDO);

      // Verify the results
      ArgumentCaptor<TaxRulePO> captor = ArgumentCaptor.forClass(TaxRulePO.class);
      verify(mockTaxRuleMapper).updateByPrimaryKeySelective(captor.capture());
      TaxRulePO updatedPO = captor.getValue();
      assertEquals(Long.valueOf(1L), updatedPO.getId());
      assertNotNull(updatedPO.getModifyTime());
    }

    @Test
    public void testUpdateByIdSelective_QueryByIdReturnsNull_ThrowsBizException() {
      // Setup
      TaxRuleMetaDO metaDO = new TaxRuleMetaDO();
      metaDO.setId(2L);

      when(mockTaxRuleRepository.queryById(2L)).thenReturn(null);

      // Run the test
      try {
        taxRuleRepositoryImplUnderTest.updateByIdSelective(metaDO);
      } catch (BizException e) {
        // Verify the results
        verify(mockTaxRuleMapper, never()).updateByPrimaryKeySelective(any());
        return;
      }
      // If no exception is thrown, fail the test
      throw new AssertionError("Expected BizException to be thrown");
    }

    @Test
    public void testUpdateByIdSelective_QueryByIdReturnsDeleted_ThrowsBizException() {
      // Setup
      TaxRuleMetaDO metaDO = new TaxRuleMetaDO();
      metaDO.setId(3L);

      TaxRuleMetaDO orgMeta = new TaxRuleMetaDO();
      orgMeta.setId(3L);
      orgMeta.setIsDelete(EnumDeleteStatus.DELETED);

      when(mockTaxRuleRepository.queryById(3L)).thenReturn(orgMeta);

      // Run the test
      try {
        taxRuleRepositoryImplUnderTest.updateByIdSelective(metaDO);
      } catch (BizException e) {
        // Verify the results
        verify(mockTaxRuleMapper, never()).updateByPrimaryKeySelective(any());
        return;
      }
      // If no exception is thrown, fail the test
      throw new AssertionError("Expected BizException to be thrown");
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplQueryAllTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testQueryAll() {
      // Setup
      final TaxRulePO taxRulePO = new TaxRulePO();
      taxRulePO.setId(1L);
      taxRulePO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      // 防止 MapStruct 在 isReverseCharge 映射处发生空指针
      taxRulePO.setIsReverseCharge(0);
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(taxRulePO));

      // Run the test
      final List<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryAll();

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());
      assertEquals(EnumDeleteStatus.ACTIVE, result.get(0).getIsDelete());
      verify(mockTaxRuleMapper).selectByExample(any(TaxRulePOExample.class));
    }

    @Test
    public void testQueryAll_TaxRuleMapperReturnsNoItems() {
      // Setup
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Collections.emptyList());

      // Run the test
      final List<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryAll();

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxRuleMapper).selectByExample(any(TaxRulePOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplQueryAllWithInactiveTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;
    @Mock private TaxCategoryMapper mockTaxCategoryMapper;
    @Mock private TaxRuleRepository mockTaxRuleRepository;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testQueryAllWithInactive() {
      // Setup
      TaxRulePO po = new TaxRulePO();
      po.setId(1L);
      // Avoid NPE in mapping: isReverseCharge is used with primitive comparison (== 1)
      po.setIsReverseCharge(0);
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run the test
      List<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryAllWithInactive();

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getId());
      verify(mockTaxRuleMapper).selectByExample(any(TaxRulePOExample.class));
    }

    @Test
    public void testQueryAllWithInactive_TaxRuleMapperReturnsNoItems() {
      // Setup
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Collections.<TaxRulePO>emptyList());

      // Run the test
      List<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryAllWithInactive();

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxRuleMapper).selectByExample(any(TaxRulePOExample.class));
    }
  }

  public static class TaxRuleRepositoryImplCheckStringTest {

    private final TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest =
        new TaxRuleRepositoryImpl();

    @Test
    public void testCheckString_NonEmpty() {
      // Run the test
      boolean result = taxRuleRepositoryImplUnderTest.checkString("abc");

      // Verify the results
      assertTrue(result);
    }

    @Test
    public void testCheckString_EmptyString() {
      // Run the test
      boolean result = taxRuleRepositoryImplUnderTest.checkString("");

      // Verify the results
      assertFalse(result);
    }

    @Test
    public void testCheckString_OnlySpaces() {
      // Run the test
      boolean result = taxRuleRepositoryImplUnderTest.checkString("   ");

      // Verify the results
      assertFalse(result);
    }

    @Test
    public void testCheckString_Null() {
      // Run the test
      boolean result = taxRuleRepositoryImplUnderTest.checkString(null);

      // Verify the results
      assertFalse(result);
    }

    @Test
    public void testCheckString_TrimmedNonEmpty() {
      // Run the test
      boolean result = taxRuleRepositoryImplUnderTest.checkString("  a  ");

      // Verify the results
      assertTrue(result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxRuleRepositoryImplQueryTaxRuleListTest {

    @Mock private TaxRuleMapper mockTaxRuleMapper;
    @Mock private TaxCategoryMapper mockTaxCategoryMapper;

    @InjectMocks private TaxRuleRepositoryImpl taxRuleRepositoryImplUnderTest;

    @Test
    public void testQueryTaxRuleList_BasicFiltersAndPaging() {
      TaxRuleQuery query = new TaxRuleQuery();
      query.setId(1L);
      query.setTaxTag("hello");
      query.setItemId(7L);
      query.setTaxCategoryId(9L);
      query.setTransactionType(2);
      query.setPageNumber(1);
      query.setPageSize(10);

      TaxRulePO taxRulePO = new TaxRulePO();
      taxRulePO.setId(1L);
      taxRulePO.setIsDelete(0);
      taxRulePO.setTaxTag("hello");
      taxRulePO.setItemId(7L);
      taxRulePO.setTaxCategoryId(9L);
      taxRulePO.setTransactionType(2);
      taxRulePO.setIsReverseCharge(0);

      List<TaxRulePO> poList = Arrays.asList(taxRulePO);
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class))).thenReturn(poList);

      PageResult<TaxRuleMetaDO> expectedResult =
          new PageResult<>(1L, Arrays.asList(TaxRuleMapping.MAPPING.toMetaDO(taxRulePO)));

      PageResult<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryTaxRuleList(query);

      assertEquals(expectedResult, result);

      ArgumentCaptor<TaxRulePOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxRulePOExample.class);
      verify(mockTaxRuleMapper).selectByExample(exampleCaptor.capture());
      TaxRulePOExample exampleUsed = exampleCaptor.getValue();
      assertEquals("modify_time desc", exampleUsed.getOrderByClause());
    }

    @Test
    public void testQueryTaxRuleList_TaxAdminIdNoCategories() {
      TaxRuleQuery query = new TaxRuleQuery();
      query.setTaxAdminId(123L);
      query.setPageNumber(1);
      query.setPageSize(10);

      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Collections.<TaxCategoryPO>emptyList());

      PageResult<TaxRuleMetaDO> expectedResult =
          new PageResult<>(0L, Collections.<TaxRuleMetaDO>emptyList());

      PageResult<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryTaxRuleList(query);

      assertEquals(expectedResult, result);
      Mockito.verify(mockTaxRuleMapper, Mockito.never())
          .selectByExample(any(TaxRulePOExample.class));
    }

    @Test
    public void testQueryTaxRuleList_TaxAdminIdWithCategoriesAndAddressSql() {
      AddressMetaDO billFrom = new AddressMetaDO();
      billFrom.setLevelZero(0L);
      billFrom.setLevelOne(10L);
      AddressMetaDO billTo = new AddressMetaDO();
      billTo.setLevelZero(3L);
      billTo.setLevelOne(7L);

      TaxRuleQuery query = new TaxRuleQuery();
      query.setTaxAdminId(55L);
      query.setBillFrom(billFrom);
      query.setBillTo(billTo);

      TaxCategoryPO categoryPO = new TaxCategoryPO();
      categoryPO.setId(100L);
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Arrays.asList(categoryPO));

      TaxRulePO taxRulePO = new TaxRulePO();
      taxRulePO.setId(2L);
      taxRulePO.setIsDelete(0);
      taxRulePO.setTaxCategoryId(100L);
      taxRulePO.setIsReverseCharge(0);
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(taxRulePO));

      PageResult<TaxRuleMetaDO> expectedResult =
          new PageResult<>(1L, Arrays.asList(TaxRuleMapping.MAPPING.toMetaDO(taxRulePO)));

      PageResult<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryTaxRuleList(query);

      assertEquals(expectedResult, result);

      ArgumentCaptor<TaxRulePOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxRulePOExample.class);
      verify(mockTaxRuleMapper).selectByExample(exampleCaptor.capture());
      TaxRulePOExample exampleUsed = exampleCaptor.getValue();
      assertEquals("modify_time desc", exampleUsed.getOrderByClause());
    }

    @Test
    public void testQueryTaxRuleList_TaxTagEscapeCharacters() {
      TaxRuleQuery query = new TaxRuleQuery();
      query.setTaxTag("a_b%c");

      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Collections.<TaxRulePO>emptyList());

      PageResult<TaxRuleMetaDO> expectedResult =
          new PageResult<>(0L, Collections.<TaxRuleMetaDO>emptyList());

      PageResult<TaxRuleMetaDO> result = taxRuleRepositoryImplUnderTest.queryTaxRuleList(query);

      assertEquals(expectedResult, result);

      ArgumentCaptor<TaxRulePOExample> exampleCaptor =
          ArgumentCaptor.forClass(TaxRulePOExample.class);
      verify(mockTaxRuleMapper).selectByExample(exampleCaptor.capture());
      TaxRulePOExample exampleUsed = exampleCaptor.getValue();
      assertEquals("modify_time desc", exampleUsed.getOrderByClause());
    }
  }
}
