package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxExemptionMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxExemptionMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxExemptionPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxExemptionPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxExemptionQuery;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxExemptionRepository;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxExemptionRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxExemptionRepositoryImplQueryTaxExemptionListTest {

    @Mock private TaxExemptionMapper mockTaxExemptionMapper;

    @InjectMocks private TaxExemptionRepositoryImpl taxExemptionRepositoryImplUnderTest;

    @Test
    public void testQueryTaxExemptionList_AllFilters_Pagination_And_Mapping() {
      TaxExemptionQuery query = new TaxExemptionQuery();
      query.setCustomerName("ab_%c%");
      query.setSubjectId(100L);
      query.setCustomerId(200L);
      query.setPageNumber(1);
      query.setPageSize(10);

      TaxExemptionPO po = new TaxExemptionPO();
      po.setId(1L);
      po.setCustomerId(200L);
      po.setCustomerName("Alice_A");
      po.setCertificate("[]");
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      List<TaxExemptionPO> poList = Arrays.asList(po);
      when(mockTaxExemptionMapper.selectByExample(any(TaxExemptionPOExample.class)))
          .thenReturn(poList);

      PageResult<TaxExemptionMetaDO> result =
          taxExemptionRepositoryImplUnderTest.queryTaxExemptionList(query);

      ArgumentCaptor<TaxExemptionPOExample> captor =
          ArgumentCaptor.forClass(TaxExemptionPOExample.class);
      verify(mockTaxExemptionMapper).selectByExample(captor.capture());
      TaxExemptionPOExample usedExample = captor.getValue();

      assertEquals("modify_time desc", usedExample.getOrderByClause());
      assertEquals(2, usedExample.getOredCriteria().size());

      List<TaxExemptionPOExample.Criterion> c1 = usedExample.getOredCriteria().get(0).getCriteria();
      assertTrue(containsConditionWithValue(c1, "is_delete =", EnumDeleteStatus.ACTIVE.getCode()));
      String expectedLike = "%ab\\_\\%c\\%%";
      assertTrue(containsConditionWithValue(c1, "customer_name like", expectedLike));
      assertTrue(containsConditionWithValue(c1, "subject_id =", 100L));
      assertTrue(containsConditionWithValue(c1, "customer_id =", 200L));

      List<TaxExemptionPOExample.Criterion> c2 = usedExample.getOredCriteria().get(1).getCriteria();
      assertTrue(containsConditionWithValue(c2, "is_delete =", EnumDeleteStatus.ACTIVE.getCode()));
      assertTrue(containsConditionWithValue(c2, "customer_name like", expectedLike));
      assertTrue(containsConditionWithValue(c2, "subject_id =", 100L));
      assertTrue(containsConditionWithValue(c2, "remark =", "200"));

      assertEquals(Long.valueOf(1L), result.getTotal());
      assertEquals(1, result.getData().size());
      TaxExemptionMetaDO meta = result.getData().iterator().next();
      assertEquals(Long.valueOf(1L), meta.getId());
      assertEquals(Long.valueOf(200L), meta.getCustomerId());
      assertEquals("Alice_A", meta.getCustomerName());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());
    }

    @Test
    public void testQueryTaxExemptionList_NameBlank_NoNameCriteria_OneCriteriaOnly() {
      TaxExemptionQuery query = new TaxExemptionQuery();
      query.setCustomerName("   ");
      when(mockTaxExemptionMapper.selectByExample(any(TaxExemptionPOExample.class)))
          .thenReturn(Collections.<TaxExemptionPO>emptyList());

      PageResult<TaxExemptionMetaDO> result =
          taxExemptionRepositoryImplUnderTest.queryTaxExemptionList(query);

      ArgumentCaptor<TaxExemptionPOExample> captor =
          ArgumentCaptor.forClass(TaxExemptionPOExample.class);
      verify(mockTaxExemptionMapper).selectByExample(captor.capture());
      TaxExemptionPOExample usedExample = captor.getValue();

      assertEquals(1, usedExample.getOredCriteria().size());
      List<TaxExemptionPOExample.Criterion> c1 = usedExample.getOredCriteria().get(0).getCriteria();

      assertTrue(containsConditionWithValue(c1, "is_delete =", EnumDeleteStatus.ACTIVE.getCode()));
      assertFalse(containsCondition(c1, "customer_name like"));

      assertTrue(result.getData().isEmpty());
      assertEquals(Long.valueOf(0L), result.getTotal());
    }

    @Test
    public void testQueryTaxExemptionList_MapperReturnsEmpty() {
      TaxExemptionQuery query = new TaxExemptionQuery();
      query.setCustomerName("Alice");
      query.setPageNumber(1);
      query.setPageSize(10);

      when(mockTaxExemptionMapper.selectByExample(any(TaxExemptionPOExample.class)))
          .thenReturn(Collections.<TaxExemptionPO>emptyList());

      PageResult<TaxExemptionMetaDO> result =
          taxExemptionRepositoryImplUnderTest.queryTaxExemptionList(query);

      assertTrue(result.getData().isEmpty());
      assertEquals(Long.valueOf(0L), result.getTotal());
    }

    private boolean containsConditionWithValue(
        List<TaxExemptionPOExample.Criterion> list, String condition, Object value) {
      for (TaxExemptionPOExample.Criterion c : list) {
        if (condition.equals(c.getCondition())) {
          Object v = c.getValue();
          if (v == null && value == null) {
            return true;
          }
          if (v != null && v.equals(value)) {
            return true;
          }
        }
      }
      return false;
    }

    private boolean containsCondition(
        List<TaxExemptionPOExample.Criterion> list, String condition) {
      for (TaxExemptionPOExample.Criterion c : list) {
        if (condition.equals(c.getCondition())) {
          return true;
        }
      }
      return false;
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxExemptionRepositoryImplGetTaxExemptionByIdTest {

    @Mock private TaxExemptionMapper mockTaxExemptionMapper;

    @InjectMocks private TaxExemptionRepositoryImpl taxExemptionRepositoryImplUnderTest;

    @Test
    public void testGetTaxExemptionById_IdIsNull() {
      // Run the test
      final TaxExemptionMetaDO result =
          taxExemptionRepositoryImplUnderTest.getTaxExemptionById(null);

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testGetTaxExemptionById() {
      // Setup
      TaxExemptionPO po = new TaxExemptionPO();
      po.setId(123L);
      po.setCustomerId(456L);
      po.setCustomerName("customer");
      po.setAddress("addr");
      po.setTaxId("tax123");
      po.setReason("reason");
      po.setCertificate("[]");
      po.setOperatorId(789);
      Date now = new Date();
      po.setCreateTime(now);
      po.setModifyTime(now);
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      po.setCountry(86L);
      po.setSubjectId(999L);
      po.setRemark("remark");
      List<TaxExemptionPO> list = Arrays.asList(po);

      when(mockTaxExemptionMapper.selectByExample(any(TaxExemptionPOExample.class)))
          .thenReturn(list);

      // Run the test
      final TaxExemptionMetaDO result =
          taxExemptionRepositoryImplUnderTest.getTaxExemptionById(123L);

      // Verify the results
      assertNotNull(result);
      assertEquals(Long.valueOf(123L), result.getId());
      assertEquals(Long.valueOf(456L), result.getCustomerId());
      assertEquals("customer", result.getCustomerName());
      assertEquals("addr", result.getAddress());
      assertEquals("tax123", result.getTaxId());
      assertEquals("reason", result.getReason());
      assertEquals(Integer.valueOf(789), result.getOperatorId());
      assertEquals(Long.valueOf(86L), result.getCountry());
      assertEquals(Long.valueOf(999L), result.getSubjectId());
      assertEquals("remark", result.getRemark());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
    }

    @Test
    public void testGetTaxExemptionById_TaxExemptionMapperReturnsNoItems() {
      // Setup
      when(mockTaxExemptionMapper.selectByExample(any(TaxExemptionPOExample.class)))
          .thenReturn(Collections.<TaxExemptionPO>emptyList());

      // Run the test
      final TaxExemptionMetaDO result = taxExemptionRepositoryImplUnderTest.getTaxExemptionById(1L);

      // Verify the results
      assertNull(result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxExemptionRepositoryImplGetTaxExemptionByCustomerIdTest {

    @Mock private TaxExemptionMapper mockTaxExemptionMapper;

    @InjectMocks private TaxExemptionRepositoryImpl taxExemptionRepositoryImplUnderTest;

    @Test
    public void testGetTaxExemptionByCustomerId_NullId() {
      final TaxExemptionMetaDO result =
          taxExemptionRepositoryImplUnderTest.getTaxExemptionByCustomerId(null);
      assertNull(result);
      verify(mockTaxExemptionMapper, never()).selectByExample(any(TaxExemptionPOExample.class));
    }

    @Test
    public void testGetTaxExemptionByCustomerId_ReturnsMeta() {
      final TaxExemptionPO taxExemptionPO = new TaxExemptionPO();
      taxExemptionPO.setId(100L);
      taxExemptionPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      taxExemptionPO.setCustomerId(1L);
      taxExemptionPO.setCustomerName("customerName");
      taxExemptionPO.setRemark("remark");

      final List<TaxExemptionPO> taxExemptionPOS = Arrays.asList(taxExemptionPO);
      when(mockTaxExemptionMapper.selectByExample(any(TaxExemptionPOExample.class)))
          .thenReturn(taxExemptionPOS);

      final TaxExemptionMetaDO result =
          taxExemptionRepositoryImplUnderTest.getTaxExemptionByCustomerId(1L);

      assertNotNull(result);
      assertEquals(Long.valueOf(100L), result.getId());
      assertEquals(Long.valueOf(1L), result.getCustomerId());
      assertEquals(EnumDeleteStatus.ACTIVE, result.getIsDelete());
    }

    @Test
    public void testGetTaxExemptionByCustomerId_MapperReturnsEmpty() {
      when(mockTaxExemptionMapper.selectByExample(any(TaxExemptionPOExample.class)))
          .thenReturn(Collections.<TaxExemptionPO>emptyList());

      final TaxExemptionMetaDO result =
          taxExemptionRepositoryImplUnderTest.getTaxExemptionByCustomerId(1L);

      assertNull(result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxExemptionRepositoryImplUpdateByIdSelectiveTest {

    @Mock private TaxExemptionMapper mockTaxExemptionMapper;

    @Mock private TaxExemptionRepository mockTaxExemptionRepository;

    @InjectMocks private TaxExemptionRepositoryImpl taxExemptionRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective_Success() {
      // Setup
      TaxExemptionMetaDO input = new TaxExemptionMetaDO();
      input.setId(1L);

      TaxExemptionMetaDO exist = new TaxExemptionMetaDO();
      exist.setId(1L);
      exist.setIsDelete(EnumDeleteStatus.ACTIVE);

      when(mockTaxExemptionRepository.getTaxExemptionById(1L)).thenReturn(exist);
      when(mockTaxExemptionMapper.updateByPrimaryKeySelective(any())).thenReturn(1);

      // Run
      taxExemptionRepositoryImplUnderTest.updateByIdSelective(input);

      // Verify
      ArgumentCaptor<TaxExemptionPO> captor = ArgumentCaptor.forClass(TaxExemptionPO.class);
      verify(mockTaxExemptionMapper, times(1)).updateByPrimaryKeySelective(captor.capture());
      TaxExemptionPO updated = captor.getValue();
      assertNotNull(updated.getModifyTime());
      assertEquals(Long.valueOf(1L), updated.getId());
    }

    @Test
    public void testUpdateByIdSelective_OrgNotFound_ThrowsBizException() {
      // Setup
      TaxExemptionMetaDO input = new TaxExemptionMetaDO();
      input.setId(2L);

      when(mockTaxExemptionRepository.getTaxExemptionById(2L)).thenReturn(null);

      // Run
      boolean thrown = false;
      try {
        taxExemptionRepositoryImplUnderTest.updateByIdSelective(input);
      } catch (BizException e) {
        thrown = true;
      }

      // Verify
      assertTrue(thrown);
      verify(mockTaxExemptionMapper, never()).updateByPrimaryKeySelective(any());
    }

    @Test
    public void testUpdateByIdSelective_OrgDeleted_ThrowsBizException() {
      // Setup
      TaxExemptionMetaDO input = new TaxExemptionMetaDO();
      input.setId(3L);

      TaxExemptionMetaDO exist = new TaxExemptionMetaDO();
      exist.setId(3L);
      exist.setIsDelete(EnumDeleteStatus.DELETED);

      when(mockTaxExemptionRepository.getTaxExemptionById(3L)).thenReturn(exist);

      // Run
      boolean thrown = false;
      try {
        taxExemptionRepositoryImplUnderTest.updateByIdSelective(input);
      } catch (BizException e) {
        thrown = true;
      }

      // Verify
      assertTrue(thrown);
      verify(mockTaxExemptionMapper, never()).updateByPrimaryKeySelective(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxExemptionRepositoryImplSaveTest {

    @Mock private TaxExemptionMapper mockTaxExemptionMapper;

    @InjectMocks private TaxExemptionRepositoryImpl taxExemptionRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      final TaxExemptionMetaDO metaDO = new TaxExemptionMetaDO();
      metaDO.setCustomerId(1L);
      metaDO.setCustomerName("name");
      when(mockTaxExemptionMapper.insert(any())).thenReturn(1);

      // Run the test
      taxExemptionRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      verify(mockTaxExemptionMapper).insert(any());
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertEquals(EnumDeleteStatus.ACTIVE, metaDO.getIsDelete());
    }

    @Test
    public void testSave_OverrideFields() {
      // Setup
      final TaxExemptionMetaDO metaDO = new TaxExemptionMetaDO();
      metaDO.setIsDelete(EnumDeleteStatus.DELETED);
      when(mockTaxExemptionMapper.insert(any())).thenReturn(1);

      // Run the test
      taxExemptionRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      verify(mockTaxExemptionMapper).insert(any());
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertEquals(EnumDeleteStatus.ACTIVE, metaDO.getIsDelete());
    }
  }
}
