package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCountryBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.AddressMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCountryBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCountryBindRepository;
import java.util.*;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxCountryBindRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplQueryBySubjectCountryRegionTest {

    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testQueryBySubjectCountryRegion_FilteredResults() {
      // Setup
      Long subjectId = 1L;
      Long countryGeoId = 100L;
      Long secondGeoId = 10L;

      TaxCountryBindMetaDO match1 = buildMeta(1L, 100L, 10L);
      TaxCountryBindMetaDO notMatchSecond = buildMeta(1L, 100L, 11L);
      TaxCountryBindMetaDO notMatchSubject = buildMeta(2L, 100L, 10L);
      TaxCountryBindMetaDO notMatchCountry = buildMeta(1L, 101L, 10L);
      TaxCountryBindMetaDO match2 = buildMeta(1L, 100L, 10L);

      when(mockTaxCountryBindRepository.queryAll(true))
          .thenReturn(
              Arrays.asList(match1, notMatchSecond, notMatchSubject, notMatchCountry, match2));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectCountryRegion(
              subjectId, countryGeoId, secondGeoId);

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(subjectId, result.get(0).getSubjectId());
      assertEquals(countryGeoId, result.get(0).getAddress().getLevelZero());
      assertEquals(secondGeoId, result.get(0).getAddress().getLevelOne());
      assertEquals(subjectId, result.get(1).getSubjectId());
      assertEquals(countryGeoId, result.get(1).getAddress().getLevelZero());
      assertEquals(secondGeoId, result.get(1).getAddress().getLevelOne());

      verify(mockTaxCountryBindRepository).queryAll(true);
    }

    @Test
    public void testQueryBySubjectCountryRegion_RepositoryReturnsEmpty() {
      // Setup
      when(mockTaxCountryBindRepository.queryAll(true))
          .thenReturn(Collections.<TaxCountryBindMetaDO>emptyList());

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectCountryRegion(1L, 100L, 10L);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxCountryBindRepository).queryAll(true);
    }

    @Test
    public void testQueryBySubjectCountryRegion_NoMatch() {
      // Setup
      TaxCountryBindMetaDO a = buildMeta(1L, 999L, 10L);
      TaxCountryBindMetaDO b = buildMeta(2L, 100L, 10L);
      TaxCountryBindMetaDO c = buildMeta(1L, 100L, 999L);
      when(mockTaxCountryBindRepository.queryAll(true)).thenReturn(Arrays.asList(a, b, c));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectCountryRegion(1L, 100L, 10L);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxCountryBindRepository).queryAll(true);
    }

    private TaxCountryBindMetaDO buildMeta(Long subjectId, Long countryGeoId, Long secondGeoId) {
      TaxCountryBindMetaDO meta = new TaxCountryBindMetaDO();
      meta.setSubjectId(subjectId);
      AddressMetaDO addr = new AddressMetaDO();
      addr.setLevelZero(countryGeoId);
      addr.setLevelOne(secondGeoId);
      meta.setAddress(addr);
      return meta;
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplQueryAllTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testQueryAll_needActiveTrue() {
      // 返回仅ACTIVE的数据，模拟数据库按条件过滤的行为
      TaxCountryBindPO activePo = new TaxCountryBindPO();
      activePo.setId(1L);
      activePo.setSubjectId(10L);
      activePo.setCountryGeoId(100L);
      activePo.setSecondGeoId(200L);
      activePo.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(mockTaxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Collections.singletonList(activePo));

      // 调用
      List<TaxCountryBindMetaDO> result = taxCountryBindRepositoryImplUnderTest.queryAll(true);

      // 断言
      assertNotNull(result);
      assertEquals(1, result.size());
      TaxCountryBindMetaDO meta = result.get(0);
      assertEquals(Long.valueOf(1L), meta.getId());
      assertEquals(Long.valueOf(10L), meta.getSubjectId());
      assertNotNull(meta.getAddress());
      assertEquals(Long.valueOf(100L), meta.getAddress().getLevelZero());
      assertEquals(Long.valueOf(200L), meta.getAddress().getLevelOne());
      assertEquals(EnumDeleteStatus.ACTIVE, meta.getIsDelete());

      // 验证调用
      verify(mockTaxCountryBindMapper).selectByExample(any(TaxCountryBindPOExample.class));
    }

    @Test
    public void testQueryAll_needActiveFalse() {
      // 返回所有数据
      TaxCountryBindPO activePo = new TaxCountryBindPO();
      activePo.setId(1L);
      activePo.setSubjectId(10L);
      activePo.setCountryGeoId(100L);
      activePo.setSecondGeoId(200L);
      activePo.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      TaxCountryBindPO deletedPo = new TaxCountryBindPO();
      deletedPo.setId(2L);
      deletedPo.setSubjectId(20L);
      deletedPo.setCountryGeoId(101L);
      deletedPo.setSecondGeoId(201L);
      deletedPo.setIsDelete(EnumDeleteStatus.DELETED.getCode());

      when(mockTaxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Arrays.asList(activePo, deletedPo));

      // 调用
      List<TaxCountryBindMetaDO> result = taxCountryBindRepositoryImplUnderTest.queryAll(false);

      // 断言
      assertNotNull(result);
      assertEquals(2, result.size());

      TaxCountryBindMetaDO meta1 = result.get(0);
      assertEquals(Long.valueOf(1L), meta1.getId());
      assertEquals(Long.valueOf(10L), meta1.getSubjectId());
      assertNotNull(meta1.getAddress());
      assertEquals(Long.valueOf(100L), meta1.getAddress().getLevelZero());
      assertEquals(Long.valueOf(200L), meta1.getAddress().getLevelOne());
      assertEquals(EnumDeleteStatus.ACTIVE, meta1.getIsDelete());

      TaxCountryBindMetaDO meta2 = result.get(1);
      assertEquals(Long.valueOf(2L), meta2.getId());
      assertEquals(Long.valueOf(20L), meta2.getSubjectId());
      assertNotNull(meta2.getAddress());
      assertEquals(Long.valueOf(101L), meta2.getAddress().getLevelZero());
      assertEquals(Long.valueOf(201L), meta2.getAddress().getLevelOne());
      assertEquals(EnumDeleteStatus.DELETED, meta2.getIsDelete());

      // 验证调用
      verify(mockTaxCountryBindMapper).selectByExample(any(TaxCountryBindPOExample.class));
    }

    @Test
    public void testQueryAll_empty() {
      when(mockTaxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Collections.<TaxCountryBindPO>emptyList());

      List<TaxCountryBindMetaDO> result = taxCountryBindRepositoryImplUnderTest.queryAll(true);

      assertNotNull(result);
      assertTrue(result.isEmpty());
      verify(mockTaxCountryBindMapper).selectByExample(any(TaxCountryBindPOExample.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplQueryBySubjectAndCountryTest {

    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testQueryBySubjectAndCountry_ReturnsMatchedItems() {
      // Setup
      Long subjectId = 1L;
      Long countryId = 100L;

      TaxCountryBindMetaDO meta1 = new TaxCountryBindMetaDO();
      meta1.setSubjectId(1L);
      AddressMetaDO addr1 = new AddressMetaDO();
      addr1.setLevelZero(100L);
      meta1.setAddress(addr1);

      TaxCountryBindMetaDO meta2 = new TaxCountryBindMetaDO();
      meta2.setSubjectId(1L);
      AddressMetaDO addr2 = new AddressMetaDO();
      addr2.setLevelZero(101L);
      meta2.setAddress(addr2);

      TaxCountryBindMetaDO meta3 = new TaxCountryBindMetaDO();
      meta3.setSubjectId(2L);
      AddressMetaDO addr3 = new AddressMetaDO();
      addr3.setLevelZero(100L);
      meta3.setAddress(addr3);

      when(mockTaxCountryBindRepository.queryAll(true))
          .thenReturn(Arrays.asList(meta1, meta2, meta3));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectAndCountry(
              subjectId, countryId, true);

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(subjectId, result.get(0).getSubjectId());
      assertEquals(countryId, result.get(0).getAddress().getLevelZero());
      verify(mockTaxCountryBindRepository).queryAll(true);
    }

    @Test
    public void testQueryBySubjectAndCountry_NoMatch() {
      // Setup
      Long subjectId = 1L;
      Long countryId = 100L;

      TaxCountryBindMetaDO meta1 = new TaxCountryBindMetaDO();
      meta1.setSubjectId(2L);
      AddressMetaDO addr1 = new AddressMetaDO();
      addr1.setLevelZero(101L);
      meta1.setAddress(addr1);

      TaxCountryBindMetaDO meta2 = new TaxCountryBindMetaDO();
      meta2.setSubjectId(3L);
      AddressMetaDO addr2 = new AddressMetaDO();
      addr2.setLevelZero(102L);
      meta2.setAddress(addr2);

      when(mockTaxCountryBindRepository.queryAll(true)).thenReturn(Arrays.asList(meta1, meta2));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectAndCountry(
              subjectId, countryId, true);

      // Verify the results
      assertEquals(0, result.size());
      verify(mockTaxCountryBindRepository).queryAll(true);
    }

    @Test
    public void testQueryBySubjectAndCountry_needActiveFalse() {
      // Setup
      Long subjectId = 5L;
      Long countryId = 200L;

      TaxCountryBindMetaDO meta1 = new TaxCountryBindMetaDO();
      meta1.setSubjectId(5L);
      AddressMetaDO addr1 = new AddressMetaDO();
      addr1.setLevelZero(200L);
      meta1.setAddress(addr1);

      TaxCountryBindMetaDO meta2 = new TaxCountryBindMetaDO();
      meta2.setSubjectId(5L);
      AddressMetaDO addr2 = new AddressMetaDO();
      addr2.setLevelZero(201L);
      meta2.setAddress(addr2);

      when(mockTaxCountryBindRepository.queryAll(false)).thenReturn(Arrays.asList(meta1, meta2));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectAndCountry(
              subjectId, countryId, false);

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(subjectId, result.get(0).getSubjectId());
      assertEquals(countryId, result.get(0).getAddress().getLevelZero());
      verify(mockTaxCountryBindRepository).queryAll(false);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplQueryBySubjectExcludeCountryTest {

    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testQueryBySubjectExcludeCountry_FilterAndNeedActiveTrue() {
      // Setup
      TaxCountryBindMetaDO meta1 = buildMeta(1L, 1L, 100L);
      TaxCountryBindMetaDO meta2 = buildMeta(2L, 1L, 101L);
      TaxCountryBindMetaDO meta3 = buildMeta(3L, 2L, 102L);
      List<TaxCountryBindMetaDO> all = Arrays.asList(meta1, meta2, meta3);
      when(mockTaxCountryBindRepository.queryAll(true)).thenReturn(all);

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectExcludeCountry(1L, 100L, true);

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getSubjectId());
      assertEquals(Long.valueOf(101L), result.get(0).getAddress().getLevelZero());
      verify(mockTaxCountryBindRepository).queryAll(true);
    }

    @Test
    public void testQueryBySubjectExcludeCountry_AllExcluded_ReturnEmpty_whenNeedActiveFalse() {
      // Setup
      TaxCountryBindMetaDO meta1 = buildMeta(1L, 1L, 100L);
      TaxCountryBindMetaDO meta2 = buildMeta(2L, 1L, 100L);
      TaxCountryBindMetaDO meta3 = buildMeta(3L, 2L, 100L);
      List<TaxCountryBindMetaDO> all = Arrays.asList(meta1, meta2, meta3);
      when(mockTaxCountryBindRepository.queryAll(false)).thenReturn(all);

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryBySubjectExcludeCountry(1L, 100L, false);

      // Verify the results
      assertEquals(Collections.emptyList(), result);
      verify(mockTaxCountryBindRepository).queryAll(false);
    }

    private TaxCountryBindMetaDO buildMeta(Long id, Long subjectId, Long levelZeroCountry) {
      TaxCountryBindMetaDO meta = new TaxCountryBindMetaDO();
      meta.setId(id);
      meta.setSubjectId(subjectId);
      AddressMetaDO address = new AddressMetaDO();
      address.setLevelZero(levelZeroCountry);
      meta.setAddress(address);
      return meta;
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplDeleteByIdTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testDeleteById_Success() {
      // Setup
      when(mockTaxCountryBindMapper.updateByPrimaryKeySelective(any())).thenReturn(1);

      // Run the test
      final boolean result = taxCountryBindRepositoryImplUnderTest.deleteById(100L);

      // Verify the results
      assertTrue(result);
      ArgumentCaptor<TaxCountryBindPO> captor = ArgumentCaptor.forClass(TaxCountryBindPO.class);
      verify(mockTaxCountryBindMapper).updateByPrimaryKeySelective(captor.capture());
      TaxCountryBindPO passedPo = captor.getValue();
      assertEquals(Long.valueOf(100L), passedPo.getId());
      assertEquals(EnumDeleteStatus.DELETED.getCode(), passedPo.getIsDelete());
    }

    @Test
    public void testDeleteById_Fail() {
      // Setup
      when(mockTaxCountryBindMapper.updateByPrimaryKeySelective(any())).thenReturn(0);

      // Run the test
      final boolean result = taxCountryBindRepositoryImplUnderTest.deleteById(200L);

      // Verify the results
      assertFalse(result);
      ArgumentCaptor<TaxCountryBindPO> captor = ArgumentCaptor.forClass(TaxCountryBindPO.class);
      verify(mockTaxCountryBindMapper).updateByPrimaryKeySelective(captor.capture());
      TaxCountryBindPO passedPo = captor.getValue();
      assertEquals(Long.valueOf(200L), passedPo.getId());
      assertEquals(EnumDeleteStatus.DELETED.getCode(), passedPo.getIsDelete());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplSaveTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testSave_ReturnsMetaId_WhenMapperDoesNotAssignId() {
      // Setup
      TaxCountryBindMetaDO metaDO = new TaxCountryBindMetaDO();
      metaDO.setId(123L);
      metaDO.setSubjectId(1L);
      metaDO.setTaxNo("TAX123");
      metaDO.setOperatorId(12L);
      metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      metaDO.setTaxNoCountry(44L);
      metaDO.setTaxAdminId(55L);
      AddressMetaDO addressMetaDO = new AddressMetaDO();
      addressMetaDO.setLevelZero(100L);
      addressMetaDO.setLevelOne(200L);
      metaDO.setAddress(addressMetaDO);

      when(mockTaxCountryBindMapper.insertSelective(any(TaxCountryBindPO.class))).thenReturn(1);

      // Run the test
      final Long result = taxCountryBindRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      assertEquals(Long.valueOf(123L), result);
      verify(mockTaxCountryBindMapper).insertSelective(any(TaxCountryBindPO.class));
    }

    @Test
    public void testSave_ReturnsGeneratedId_WhenMapperAssignsId() {
      // Setup
      TaxCountryBindMetaDO metaDO = new TaxCountryBindMetaDO();
      metaDO.setSubjectId(2L);
      metaDO.setTaxNo("TAX456");
      metaDO.setOperatorId(34L);
      metaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      metaDO.setTaxNoCountry(66L);
      metaDO.setTaxAdminId(77L);
      AddressMetaDO addressMetaDO = new AddressMetaDO();
      addressMetaDO.setLevelZero(300L);
      addressMetaDO.setLevelOne(400L);
      metaDO.setAddress(addressMetaDO);

      when(mockTaxCountryBindMapper.insertSelective(any(TaxCountryBindPO.class)))
          .thenAnswer(
              invocation -> {
                TaxCountryBindPO po = invocation.getArgument(0);
                po.setId(999L);
                return 1;
              });

      // Run the test
      final Long result = taxCountryBindRepositoryImplUnderTest.save(metaDO);

      // Verify the results
      assertEquals(Long.valueOf(999L), result);
      verify(mockTaxCountryBindMapper).insertSelective(any(TaxCountryBindPO.class));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplQueryBySubjectTest {

    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;

    @InjectMocks private TaxCountryBindRepositoryImpl repositoryUnderTest;

    @Test
    public void testQueryBySubject_needActiveTrue() {
      // Setup
      Long subjectId = 1L;
      List<TaxCountryBindMetaDO> allData = new ArrayList<TaxCountryBindMetaDO>();
      allData.add(buildMeta(101L, 1L));
      allData.add(buildMeta(102L, 1L));
      allData.add(buildMeta(201L, 2L));
      when(mockTaxCountryBindRepository.queryAll(true)).thenReturn(allData);

      // Run
      List<TaxCountryBindMetaDO> result = repositoryUnderTest.queryBySubject(subjectId, true);

      // Verify
      verify(mockTaxCountryBindRepository, times(1)).queryAll(true);
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getSubjectId());
      assertEquals(Long.valueOf(1L), result.get(1).getSubjectId());
      assertEquals(Long.valueOf(101L), result.get(0).getId());
      assertEquals(Long.valueOf(102L), result.get(1).getId());
    }

    @Test
    public void testQueryBySubject_needActiveFalse() {
      // Setup
      Long subjectId = 3L;
      List<TaxCountryBindMetaDO> allData =
          Arrays.asList(buildMeta(301L, 3L), buildMeta(401L, 4L), buildMeta(302L, 3L));
      when(mockTaxCountryBindRepository.queryAll(false)).thenReturn(allData);

      // Run
      List<TaxCountryBindMetaDO> result = repositoryUnderTest.queryBySubject(subjectId, false);

      // Verify
      verify(mockTaxCountryBindRepository, times(1)).queryAll(false);
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(3L), result.get(0).getSubjectId());
      assertEquals(Long.valueOf(3L), result.get(1).getSubjectId());
      assertEquals(Long.valueOf(301L), result.get(0).getId());
      assertEquals(Long.valueOf(302L), result.get(1).getId());
    }

    @Test
    public void testQueryBySubject_empty() {
      // Setup
      when(mockTaxCountryBindRepository.queryAll(true))
          .thenReturn(Collections.<TaxCountryBindMetaDO>emptyList());

      // Run
      List<TaxCountryBindMetaDO> result = repositoryUnderTest.queryBySubject(10L, true);

      // Verify
      verify(mockTaxCountryBindRepository, times(1)).queryAll(true);
      assertEquals(0, result.size());
    }

    private TaxCountryBindMetaDO buildMeta(Long id, Long subjectId) {
      TaxCountryBindMetaDO meta = new TaxCountryBindMetaDO();
      meta.setId(id);
      meta.setSubjectId(subjectId);
      AddressMetaDO address = new AddressMetaDO();
      address.setLevelZero(100L);
      meta.setAddress(address);
      return meta;
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplQueryByIdTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;

    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testQueryById_Found() {
      // Setup
      Long targetId = 1L;
      TaxCountryBindMetaDO matched = new TaxCountryBindMetaDO();
      matched.setId(targetId);
      TaxCountryBindMetaDO other = new TaxCountryBindMetaDO();
      other.setId(2L);
      when(mockTaxCountryBindRepository.queryAll(false)).thenReturn(Arrays.asList(other, matched));

      // Run the test
      TaxCountryBindMetaDO result = taxCountryBindRepositoryImplUnderTest.queryById(targetId);

      // Verify the results
      assertEquals(targetId, result.getId());
      verify(mockTaxCountryBindRepository).queryAll(false);
    }

    @Test
    public void testQueryById_NotFound() {
      // Setup
      when(mockTaxCountryBindRepository.queryAll(false))
          .thenReturn(Collections.<TaxCountryBindMetaDO>emptyList());

      // Run the test
      TaxCountryBindMetaDO result = taxCountryBindRepositoryImplUnderTest.queryById(99L);

      // Verify the results
      assertNull(result);
      verify(mockTaxCountryBindRepository).queryAll(false);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplFullUpdateByIdTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testFullUpdateById_ReturnsTrue() {
      // Setup
      final AddressMetaDO address = new AddressMetaDO(1L, 2L, 3L, 4L);
      final TaxCountryBindMetaDO metaDO =
          new TaxCountryBindMetaDO(
              1L,
              10L,
              "TAX_NO",
              100L,
              new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(),
              new GregorianCalendar(2020, Calendar.JANUARY, 2).getTime(),
              EnumDeleteStatus.ACTIVE,
              20L,
              30L,
              address);
      when(mockTaxCountryBindMapper.updateByPrimaryKey(any())).thenReturn(1);

      // Run the test
      final boolean result = taxCountryBindRepositoryImplUnderTest.fullUpdateById(metaDO);

      // Verify the results
      assertTrue(result);
      verify(mockTaxCountryBindMapper).updateByPrimaryKey(any());
    }

    @Test
    public void testFullUpdateById_ReturnsFalse() {
      // Setup
      final AddressMetaDO address = new AddressMetaDO(5L, 6L, 7L, 8L);
      final TaxCountryBindMetaDO metaDO =
          new TaxCountryBindMetaDO(
              2L,
              11L,
              "TAX_NO_2",
              101L,
              new GregorianCalendar(2021, Calendar.FEBRUARY, 1).getTime(),
              new GregorianCalendar(2021, Calendar.FEBRUARY, 2).getTime(),
              EnumDeleteStatus.DELETED,
              21L,
              31L,
              address);
      when(mockTaxCountryBindMapper.updateByPrimaryKey(any())).thenReturn(0);

      // Run the test
      final boolean result = taxCountryBindRepositoryImplUnderTest.fullUpdateById(metaDO);

      // Verify the results
      assertFalse(result);
      verify(mockTaxCountryBindMapper).updateByPrimaryKey(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplUpdateSelectiveTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;

    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testUpdateSelective_ReturnsTrue() {
      // Setup
      AddressMetaDO addressMetaDO = new AddressMetaDO();
      addressMetaDO.setLevelZero(100L);
      addressMetaDO.setLevelOne(200L);

      TaxCountryBindMetaDO metaDO =
          TaxCountryBindMetaDO.builder()
              .id(1L)
              .subjectId(2L)
              .taxNo("TAX-001")
              .operatorId(3L)
              .createTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime())
              .modifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 2).getTime())
              .isDelete(EnumDeleteStatus.ACTIVE)
              .taxNoCountry(100L)
              .taxAdminId(999L)
              .address(addressMetaDO)
              .build();

      when(mockTaxCountryBindMapper.updateByPrimaryKeySelective(any())).thenReturn(1);

      // Run the test
      final boolean result = taxCountryBindRepositoryImplUnderTest.updateSelective(metaDO);

      // Verify the results
      assertTrue(result);
      verify(mockTaxCountryBindMapper).updateByPrimaryKeySelective(any());
    }

    @Test
    public void testUpdateSelective_ReturnsFalse() {
      // Setup
      AddressMetaDO addressMetaDO = new AddressMetaDO();
      addressMetaDO.setLevelZero(101L);
      addressMetaDO.setLevelOne(201L);

      TaxCountryBindMetaDO metaDO =
          TaxCountryBindMetaDO.builder()
              .id(10L)
              .subjectId(20L)
              .taxNo("TAX-002")
              .operatorId(30L)
              .createTime(new GregorianCalendar(2021, Calendar.FEBRUARY, 1).getTime())
              .modifyTime(new GregorianCalendar(2021, Calendar.FEBRUARY, 2).getTime())
              .isDelete(EnumDeleteStatus.ACTIVE)
              .taxNoCountry(101L)
              .taxAdminId(888L)
              .address(addressMetaDO)
              .build();

      when(mockTaxCountryBindMapper.updateByPrimaryKeySelective(any())).thenReturn(0);

      // Run the test
      final boolean result = taxCountryBindRepositoryImplUnderTest.updateSelective(metaDO);

      // Verify the results
      assertEquals(false, result);
      verify(mockTaxCountryBindMapper).updateByPrimaryKeySelective(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCountryBindRepositoryImplQueryByCountryRegionTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;
    @Mock private TaxCountryBindRepository mockTaxCountryBindRepository;

    @InjectMocks private TaxCountryBindRepositoryImpl taxCountryBindRepositoryImplUnderTest;

    @Test
    public void testQueryByCountryRegion() {
      // Setup
      Long countryGeoId = 10L;
      Long secondGeoId = 20L;
      AddressMetaDO addressMatch = new AddressMetaDO(countryGeoId, secondGeoId, 0L, 0L);
      AddressMetaDO addressSecondMismatch = new AddressMetaDO(countryGeoId, 99L, 0L, 0L);
      AddressMetaDO addressCountryMismatch = new AddressMetaDO(99L, secondGeoId, 0L, 0L);

      GregorianCalendar cal = new GregorianCalendar(2020, Calendar.JANUARY, 1);
      TaxCountryBindMetaDO match =
          new TaxCountryBindMetaDO(
              1L,
              101L,
              "taxNo1",
              100L,
              cal.getTime(),
              cal.getTime(),
              EnumDeleteStatus.ACTIVE,
              0L,
              0L,
              addressMatch);
      TaxCountryBindMetaDO secondMismatch =
          new TaxCountryBindMetaDO(
              2L,
              102L,
              "taxNo2",
              100L,
              cal.getTime(),
              cal.getTime(),
              EnumDeleteStatus.ACTIVE,
              0L,
              0L,
              addressSecondMismatch);
      TaxCountryBindMetaDO countryMismatch =
          new TaxCountryBindMetaDO(
              3L,
              103L,
              "taxNo3",
              100L,
              cal.getTime(),
              cal.getTime(),
              EnumDeleteStatus.ACTIVE,
              0L,
              0L,
              addressCountryMismatch);

      when(mockTaxCountryBindRepository.queryAll(true))
          .thenReturn(Arrays.asList(match, secondMismatch, countryMismatch));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryByCountryRegion(countryGeoId, secondGeoId);

      // Verify the results
      assertEquals(1, result.size());
      assertEquals(match.getId(), result.get(0).getId());
      assertEquals(countryGeoId, result.get(0).getAddress().getLevelZero());
      assertEquals(secondGeoId, result.get(0).getAddress().getLevelOne());
      verify(mockTaxCountryBindRepository).queryAll(true);
    }

    @Test
    public void testQueryByCountryRegion_MultipleMatches() {
      // Setup
      Long countryGeoId = 100L;
      Long secondGeoId = 200L;
      AddressMetaDO addressMatch1 = new AddressMetaDO(countryGeoId, secondGeoId, 0L, 0L);
      AddressMetaDO addressMatch2 = new AddressMetaDO(countryGeoId, secondGeoId, 1L, 1L);

      GregorianCalendar cal = new GregorianCalendar(2021, Calendar.JANUARY, 1);
      TaxCountryBindMetaDO match1 =
          new TaxCountryBindMetaDO(
              11L,
              201L,
              "taxNoA",
              300L,
              cal.getTime(),
              cal.getTime(),
              EnumDeleteStatus.ACTIVE,
              0L,
              0L,
              addressMatch1);
      TaxCountryBindMetaDO match2 =
          new TaxCountryBindMetaDO(
              12L,
              202L,
              "taxNoB",
              300L,
              cal.getTime(),
              cal.getTime(),
              EnumDeleteStatus.ACTIVE,
              0L,
              0L,
              addressMatch2);

      when(mockTaxCountryBindRepository.queryAll(true)).thenReturn(Arrays.asList(match1, match2));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryByCountryRegion(countryGeoId, secondGeoId);

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(match1.getId(), result.get(0).getId());
      assertEquals(match2.getId(), result.get(1).getId());
    }

    @Test
    public void testQueryByCountryRegion_NoMatch() {
      // Setup
      Long countryGeoId = 5L;
      Long secondGeoId = 6L;
      AddressMetaDO addressMismatch1 = new AddressMetaDO(countryGeoId, 999L, 0L, 0L);
      AddressMetaDO addressMismatch2 = new AddressMetaDO(999L, secondGeoId, 0L, 0L);

      GregorianCalendar cal = new GregorianCalendar(2019, Calendar.JANUARY, 1);
      TaxCountryBindMetaDO mismatch1 =
          new TaxCountryBindMetaDO(
              21L,
              301L,
              "taxNoX",
              400L,
              cal.getTime(),
              cal.getTime(),
              EnumDeleteStatus.ACTIVE,
              0L,
              0L,
              addressMismatch1);
      TaxCountryBindMetaDO mismatch2 =
          new TaxCountryBindMetaDO(
              22L,
              302L,
              "taxNoY",
              400L,
              cal.getTime(),
              cal.getTime(),
              EnumDeleteStatus.ACTIVE,
              0L,
              0L,
              addressMismatch2);

      when(mockTaxCountryBindRepository.queryAll(true))
          .thenReturn(Arrays.asList(mismatch1, mismatch2));

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryByCountryRegion(countryGeoId, secondGeoId);

      // Verify the results
      assertEquals(0, result.size());
    }

    @Test
    public void testQueryByCountryRegion_TaxCountryBindRepositoryReturnsNoItems() {
      // Setup
      Long countryGeoId = 1L;
      Long secondGeoId = 2L;
      when(mockTaxCountryBindRepository.queryAll(true))
          .thenReturn(Collections.<TaxCountryBindMetaDO>emptyList());

      // Run the test
      List<TaxCountryBindMetaDO> result =
          taxCountryBindRepositoryImplUnderTest.queryByCountryRegion(countryGeoId, secondGeoId);

      // Verify the results
      assertEquals(0, result.size());
    }
  }
}
