package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumApproveStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumHead;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.*;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxBizBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxBizMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCountryBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxItemMapper;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxRuleMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.BaseRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.BizTaxRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxBizContextMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxContextMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxRuleMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.*;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxBizPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCountryBindPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxItemPOExample;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxRulePOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminRepository;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxBizComplexRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizComplexRepositoryImplQueryBizContextTest {

    @Mock private TaxCountryBindMapper taxCountryBindMapper;
    @Mock private TaxBizBindMapper taxBizBindMapper;
    @Mock private TaxBizMapper taxBizMapper;
    @Mock private TaxAdminRepository taxAdminRepository;

    @InjectMocks private TaxBizComplexRepositoryImpl taxBizComplexRepositoryImplUnderTest;

    @Test
    public void testQueryBizContext_WithData() {
      // Setup
      TaxBizBindPO bind1 = new TaxBizBindPO();
      bind1.setId(1L);
      bind1.setCountryBindId(100L);
      bind1.setBizId(10L);
      bind1.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      TaxBizBindPO bind2 = new TaxBizBindPO();
      bind2.setId(2L);
      bind2.setCountryBindId(200L); // not existing in country bind map
      bind2.setBizId(11L); // not existing in biz map
      bind2.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());

      when(taxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Arrays.asList(bind1, bind2));

      TaxAdminSubjectMetaDO sub1 = new TaxAdminSubjectMetaDO();
      sub1.setId(10001L);
      sub1.setSubjectId(1000L);

      TaxAdminSubjectMetaDO subOther = new TaxAdminSubjectMetaDO();
      subOther.setId(20001L);
      subOther.setSubjectId(2000L);

      when(taxAdminRepository.getAllTaxAdminSubject(true))
          .thenReturn(Arrays.asList(sub1, subOther));

      TaxBizPO biz10 = new TaxBizPO();
      biz10.setId(10L);
      when(taxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Arrays.asList(biz10));

      TaxCountryBindPO countryBind100 = new TaxCountryBindPO();
      countryBind100.setId(100L);
      countryBind100.setSubjectId(1000L);
      when(taxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Arrays.asList(countryBind100));

      // Run the test
      final List<BizTaxRuleMetaDO> result = taxBizComplexRepositoryImplUnderTest.queryBizContext();

      // Verify the results
      assertNotNull(result);
      assertEquals(2, result.size());

      BizTaxRuleMetaDO r1 = result.get(0);
      assertNotNull(r1.getTaxBizBindMetaDO());
      assertEquals(Long.valueOf(1L), r1.getTaxBizBindMetaDO().getId());
      assertNotNull(r1.getTaxBizMetaDO());
      assertEquals(Long.valueOf(10L), r1.getTaxBizMetaDO().getId());
      assertNotNull(r1.getTaxCountryBindMetaDO());
      assertEquals(Long.valueOf(1000L), r1.getTaxCountryBindMetaDO().getSubjectId());
      assertNotNull(r1.getTaxAdminSubjectMetaDO());
      assertEquals(1, r1.getTaxAdminSubjectMetaDO().size());
      assertEquals(Long.valueOf(1000L), r1.getTaxAdminSubjectMetaDO().get(0).getSubjectId());

      BizTaxRuleMetaDO r2 = result.get(1);
      assertNotNull(r2.getTaxBizMetaDO());
      assertEquals(Long.valueOf(-1L), r2.getTaxBizMetaDO().getId());
      assertNotNull(r2.getTaxCountryBindMetaDO());
      assertEquals(Long.valueOf(-1L), r2.getTaxCountryBindMetaDO().getSubjectId());
      assertNotNull(r2.getTaxAdminSubjectMetaDO());
      assertEquals(0, r2.getTaxAdminSubjectMetaDO().size());
    }

    @Test
    public void testQueryBizContext_NoBizBind() {
      // Setup
      when(taxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Collections.<TaxBizBindPO>emptyList());
      when(taxAdminRepository.getAllTaxAdminSubject(true))
          .thenReturn(Collections.<TaxAdminSubjectMetaDO>emptyList());
      when(taxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Collections.<TaxBizPO>emptyList());
      when(taxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Collections.<TaxCountryBindPO>emptyList());

      // Run the test
      final List<BizTaxRuleMetaDO> result = taxBizComplexRepositoryImplUnderTest.queryBizContext();

      // Verify the results
      assertNull(result);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizComplexRepositoryImplQueryTaxRuleContextTest {

    @Mock private TaxRuleMapper taxRuleMapper;
    @Mock private TaxAdminRepository taxAdminRepository;
    @Mock private TaxCategoryMapper taxCategoryMapper;
    @Mock private TaxItemMapper taxItemMapper;

    @InjectMocks private TaxBizComplexRepositoryImpl taxBizComplexRepositoryImplUnderTest;

    private TaxRulePO buildFullTaxRule(Long id, Long categoryId, Long itemId) {
      TaxRulePO po = new TaxRulePO();
      po.setId(id);
      po.setTaxCategoryId(categoryId);
      po.setItemId(itemId);
      po.setHead(EnumHead.HEAD_FIRST.getCode());
      po.setApproveStatus(EnumApproveStatus.APPROVED.getCode());
      po.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      // 补齐映射中可能用到的字段，避免 NPE
      po.setBillFrom("{}");
      po.setBillTo("{}");
      po.setShipFrom("{}");
      po.setShipTo("{}");
      po.setFromWithTaxNo(0);
      po.setToWithTaxNo(0);
      po.setFromVatCountry(0L);
      po.setToTaxNoCountry(0L);
      po.setIsReverseCharge(0);
      po.setTaxTag("TAG");
      po.setRemark("remark");
      po.setVersion(1);
      po.setModifyTime(new Date());
      po.setCreateTime(new Date());
      po.setOperatorId(1);
      po.setDescription("desc");
      po.setTransactionType(0);
      po.setExtend("{}");
      return po;
    }

    @Test
    public void testQueryTaxRuleContext_ReturnsBaseRuleList() {
      // tax_rule
      TaxRulePO taxRulePO = buildFullTaxRule(1L, 10L, 100L);
      when(taxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(taxRulePO));

      // tax_admin
      TaxAdminMetaDO adminMetaDO = new TaxAdminMetaDO();
      adminMetaDO.setId(1000L);
      when(taxAdminRepository.getAllTaxAdmin(true)).thenReturn(Arrays.asList(adminMetaDO));

      // tax_category
      TaxCategoryPO taxCategoryPO = new TaxCategoryPO();
      taxCategoryPO.setId(10L);
      taxCategoryPO.setTaxAdminId(1000L);
      taxCategoryPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(taxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Arrays.asList(taxCategoryPO));

      // tax_item
      TaxItemPO taxItemPO = new TaxItemPO();
      taxItemPO.setId(100L);
      taxItemPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(taxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(taxItemPO));

      List<BaseRuleMetaDO> result = taxBizComplexRepositoryImplUnderTest.queryTaxRuleContext();

      assertNotNull(result);
      assertEquals(1, result.size());
      BaseRuleMetaDO baseRuleMetaDO = result.get(0);
      assertEquals(Long.valueOf(1L), baseRuleMetaDO.getTaxRuleMetaDO().getId());
      assertEquals(Long.valueOf(10L), baseRuleMetaDO.getTaxCategoryMetaDO().getId());
      assertEquals(Long.valueOf(100L), baseRuleMetaDO.getTaxItemMetaDO().getId());
      assertNotNull(baseRuleMetaDO.getTaxAdminMetaDO());
      assertEquals(Long.valueOf(1000L), baseRuleMetaDO.getTaxAdminMetaDO().getId());
    }

    @Test
    public void testQueryTaxRuleContext_EmptyRulesReturnsNull() {
      when(taxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Collections.<TaxRulePO>emptyList());
      when(taxAdminRepository.getAllTaxAdmin(true))
          .thenReturn(Collections.<TaxAdminMetaDO>emptyList());
      when(taxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Collections.<TaxCategoryPO>emptyList());
      when(taxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Collections.<TaxItemPO>emptyList());

      List<BaseRuleMetaDO> result = taxBizComplexRepositoryImplUnderTest.queryTaxRuleContext();

      assertNull(result);
    }

    @Test
    public void testQueryTaxRuleContext_CategoryMissingAdminNullAndDefaultCategoryUsed() {
      // tax_rule 引用不存在的 category
      TaxRulePO taxRulePO = buildFullTaxRule(2L, 99L, 200L);
      when(taxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(taxRulePO));

      // admin list
      TaxAdminMetaDO adminMetaDO = new TaxAdminMetaDO();
      adminMetaDO.setId(3000L);
      when(taxAdminRepository.getAllTaxAdmin(true)).thenReturn(Arrays.asList(adminMetaDO));

      // category list 为空 -> 使用默认 -1
      when(taxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Collections.<TaxCategoryPO>emptyList());

      // item 存在
      TaxItemPO taxItemPO = new TaxItemPO();
      taxItemPO.setId(200L);
      taxItemPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(taxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(taxItemPO));

      List<BaseRuleMetaDO> result = taxBizComplexRepositoryImplUnderTest.queryTaxRuleContext();

      assertNotNull(result);
      assertEquals(1, result.size());
      BaseRuleMetaDO baseRuleMetaDO = result.get(0);
      assertEquals(Long.valueOf(2L), baseRuleMetaDO.getTaxRuleMetaDO().getId());
      assertEquals(Long.valueOf(200L), baseRuleMetaDO.getTaxItemMetaDO().getId());
      assertNull(baseRuleMetaDO.getTaxAdminMetaDO());
      assertEquals(Long.valueOf(-1L), baseRuleMetaDO.getTaxCategoryMetaDO().getTaxAdminId());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizComplexRepositoryImplQueryTaxBizTest {

    @Mock private TaxCountryBindMapper taxCountryBindMapper;

    @Mock private TaxBizBindMapper taxBizBindMapper;

    @InjectMocks private TaxBizComplexRepositoryImpl taxBizComplexRepositoryImplUnderTest;

    @Test
    public void testQueryTaxBiz_ReturnsNull_WhenAnyParamIsNull() {
      // Run the test
      TaxBizBindMetaDO result1 = taxBizComplexRepositoryImplUnderTest.queryTaxBiz(null, 1L, 1L);
      TaxBizBindMetaDO result2 = taxBizComplexRepositoryImplUnderTest.queryTaxBiz(1L, null, 1L);
      TaxBizBindMetaDO result3 = taxBizComplexRepositoryImplUnderTest.queryTaxBiz(1L, 1L, null);

      // Verify the results
      assertNull(result1);
      assertNull(result2);
      assertNull(result3);
    }

    @Test
    public void testQueryTaxBiz_ReturnsNull_WhenNoCountryBind() {
      // Setup
      when(taxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Collections.<TaxCountryBindPO>emptyList());

      // Run the test
      TaxBizBindMetaDO result = taxBizComplexRepositoryImplUnderTest.queryTaxBiz(11L, 22L, 33L);

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testQueryTaxBiz_ReturnsNull_WhenNoBizBind() {
      // Setup country bind found
      TaxCountryBindPO countryBind = new TaxCountryBindPO();
      countryBind.setId(100L);
      when(taxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Arrays.asList(countryBind));

      // Setup no biz bind
      when(taxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Collections.<TaxBizBindPO>emptyList());

      // Run the test
      TaxBizBindMetaDO result = taxBizComplexRepositoryImplUnderTest.queryTaxBiz(11L, 22L, 33L);

      // Verify the results
      assertNull(result);
    }

    @Test
    public void testQueryTaxBiz_ReturnsMappedMetaDO_WhenFound() {
      // Setup country bind found
      TaxCountryBindPO countryBind = new TaxCountryBindPO();
      countryBind.setId(100L);
      when(taxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Arrays.asList(countryBind));

      // Setup biz bind found
      TaxBizBindPO bizBind = new TaxBizBindPO();
      bizBind.setId(200L);
      bizBind.setCountryBindId(100L);
      bizBind.setBizId(300L);
      bizBind.setRule("{}"); // ensure mapper can deserialize
      bizBind.setCreateTime(new GregorianCalendar(2020, 1, 1).getTime());
      when(taxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Arrays.asList(bizBind));

      // Run the test
      TaxBizBindMetaDO result = taxBizComplexRepositoryImplUnderTest.queryTaxBiz(11L, 22L, 33L);

      // Verify the results
      assertNotNull(result);
      assertEquals(200L, result.getId().longValue());
      assertEquals(100L, result.getCountryBindId().longValue());
      assertEquals(300L, result.getBizId().longValue());
    }
  }

  public static class TaxBizComplexRepositoryImplQueryAllBizTaxContextTest {

    @Test
    public void testQueryAllBizTaxContext_WhenContextNull_ThrowsBizException() {
      TaxBizComplexRepositoryImpl repo = new TaxBizComplexRepositoryImpl();
      try {
        repo.queryAllBizTaxContext();
        fail("Expected BizException to be thrown");
      } catch (BizException e) {
        assertEquals("data error", e.getMessage());
      }
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizComplexRepositoryImplQueryBizTaxContextByIdsTest {

    @Mock private TaxBizComplexRepositoryImpl mockTaxBizComplexRepository;

    @InjectMocks private TaxBizComplexRepositoryImpl taxBizComplexRepositoryImplUnderTest;

    @Test
    public void testQueryBizTaxContextByIds_FilterMatched() {
      // mock context with base rules: ids 1,2,3
      BaseRuleMetaDO rule1 = new BaseRuleMetaDO();
      TaxRuleMetaDO taxRuleMetaDO1 = new TaxRuleMetaDO();
      taxRuleMetaDO1.setId(1L);
      rule1.setTaxRuleMetaDO(taxRuleMetaDO1);

      BaseRuleMetaDO rule2 = new BaseRuleMetaDO();
      TaxRuleMetaDO taxRuleMetaDO2 = new TaxRuleMetaDO();
      taxRuleMetaDO2.setId(2L);
      rule2.setTaxRuleMetaDO(taxRuleMetaDO2);

      BaseRuleMetaDO rule3 = new BaseRuleMetaDO();
      TaxRuleMetaDO taxRuleMetaDO3 = new TaxRuleMetaDO();
      taxRuleMetaDO3.setId(3L);
      rule3.setTaxRuleMetaDO(taxRuleMetaDO3);

      List<BaseRuleMetaDO> baseRuleMetaDOS = Arrays.asList(rule1, rule2, rule3);

      TaxBizContextMetaDO taxBizContextMetaDO = org.mockito.Mockito.mock(TaxBizContextMetaDO.class);
      when(taxBizContextMetaDO.getBaseRuleMetaDOS()).thenReturn(baseRuleMetaDOS);
      when(mockTaxBizComplexRepository.queryAllBizTaxContext()).thenReturn(taxBizContextMetaDO);

      // run
      List<BaseRuleMetaDO> result =
          taxBizComplexRepositoryImplUnderTest.queryBizTaxContextByIds(Arrays.asList(1L, 3L));

      // verify
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getTaxRuleMetaDO().getId());
      assertEquals(Long.valueOf(3L), result.get(1).getTaxRuleMetaDO().getId());
    }

    @Test
    public void testQueryBizTaxContextByIds_EmptyIds() {
      BaseRuleMetaDO rule1 = new BaseRuleMetaDO();
      TaxRuleMetaDO taxRuleMetaDO1 = new TaxRuleMetaDO();
      taxRuleMetaDO1.setId(1L);
      rule1.setTaxRuleMetaDO(taxRuleMetaDO1);

      TaxBizContextMetaDO taxBizContextMetaDO = org.mockito.Mockito.mock(TaxBizContextMetaDO.class);
      when(taxBizContextMetaDO.getBaseRuleMetaDOS()).thenReturn(Collections.singletonList(rule1));
      when(mockTaxBizComplexRepository.queryAllBizTaxContext()).thenReturn(taxBizContextMetaDO);

      List<BaseRuleMetaDO> result =
          taxBizComplexRepositoryImplUnderTest.queryBizTaxContextByIds(
              Collections.<Long>emptyList());

      assertEquals(0, result.size());
    }

    @Test(expected = NullPointerException.class)
    public void testQueryBizTaxContextByIds_NullIds() {
      BaseRuleMetaDO rule1 = new BaseRuleMetaDO();
      TaxRuleMetaDO taxRuleMetaDO1 = new TaxRuleMetaDO();
      taxRuleMetaDO1.setId(1L);
      rule1.setTaxRuleMetaDO(taxRuleMetaDO1);

      TaxBizContextMetaDO taxBizContextMetaDO = org.mockito.Mockito.mock(TaxBizContextMetaDO.class);
      when(taxBizContextMetaDO.getBaseRuleMetaDOS()).thenReturn(Collections.singletonList(rule1));
      when(mockTaxBizComplexRepository.queryAllBizTaxContext()).thenReturn(taxBizContextMetaDO);

      taxBizComplexRepositoryImplUnderTest.queryBizTaxContextByIds(null);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizComplexRepositoryImplRefreshScheduleTest {

    @Mock private TaxCountryBindMapper mockTaxCountryBindMapper;
    @Mock private TaxBizBindMapper mockTaxBizBindMapper;
    @Mock private TaxBizMapper mockTaxBizMapper;
    @Mock private TaxRuleMapper mockTaxRuleMapper;
    @Mock private TaxCategoryMapper mockTaxCategoryMapper;
    @Mock private TaxItemMapper mockTaxItemMapper;
    @Mock private TaxAdminRepository mockTaxAdminRepository;

    @InjectMocks private TaxBizComplexRepositoryImpl taxBizComplexRepositoryImplUnderTest;

    @Test
    public void testRefreshSchedule() {
      // Setup: queryBizContext 相关依赖
      when(mockTaxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Collections.<TaxBizBindPO>emptyList());
      when(mockTaxAdminRepository.getAllTaxAdminSubject(anyBoolean()))
          .thenReturn(Collections.<TaxAdminSubjectMetaDO>emptyList());
      when(mockTaxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Collections.<TaxBizPO>emptyList());
      when(mockTaxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Collections.<TaxCountryBindPO>emptyList());

      // Setup: queryTaxRuleContext 相关依赖
      when(mockTaxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Collections.<TaxRulePO>emptyList());
      when(mockTaxAdminRepository.getAllTaxAdmin(anyBoolean()))
          .thenReturn(Collections.<TaxAdminMetaDO>emptyList());
      when(mockTaxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Collections.<TaxCategoryPO>emptyList());
      when(mockTaxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Collections.<TaxItemPO>emptyList());

      // Run
      taxBizComplexRepositoryImplUnderTest.refreshSchedule();

      // Verify
      TaxBizContextMetaDO context = taxBizComplexRepositoryImplUnderTest.queryAllBizTaxContext();
      assertNotNull(context);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizComplexRepositoryImplInitTest {

    @Mock private TaxCountryBindMapper taxCountryBindMapper;
    @Mock private TaxBizBindMapper taxBizBindMapper;
    @Mock private TaxBizMapper taxBizMapper;
    @Mock private TaxRuleMapper taxRuleMapper;
    @Mock private TaxCategoryMapper taxCategoryMapper;
    @Mock private TaxItemMapper taxItemMapper;

    @Mock
    private com.bytedance.cg.oversea.bytetax.dal.repository.TaxAdminRepository taxAdminRepository;

    @InjectMocks private TaxBizComplexRepositoryImpl taxBizComplexRepositoryImplUnderTest;

    @Test
    public void testInit() {
      // biz bind部分
      final TaxBizBindPO taxBizBindPO = new TaxBizBindPO();
      taxBizBindPO.setId(10L);
      taxBizBindPO.setCountryBindId(1L);
      taxBizBindPO.setBizId(2L);
      taxBizBindPO.setRule("{}");
      taxBizBindPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      when(taxBizBindMapper.selectByExample(any(TaxBizBindPOExample.class)))
          .thenReturn(Arrays.asList(taxBizBindPO));

      when(taxAdminRepository.getAllTaxAdminSubject(true)).thenReturn(Collections.emptyList());

      final TaxBizPO taxBizPO = new TaxBizPO();
      taxBizPO.setId(2L);
      taxBizPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      taxBizPO.setName("biz");
      when(taxBizMapper.selectByExample(any(TaxBizPOExample.class)))
          .thenReturn(Arrays.asList(taxBizPO));

      final TaxCountryBindPO taxCountryBindPO = new TaxCountryBindPO();
      taxCountryBindPO.setId(1L);
      taxCountryBindPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      taxCountryBindPO.setSubjectId(999L);
      taxCountryBindPO.setCountryGeoId(44L);
      taxCountryBindPO.setTaxNo("TAXNO");
      when(taxCountryBindMapper.selectByExample(any(TaxCountryBindPOExample.class)))
          .thenReturn(Arrays.asList(taxCountryBindPO));

      // base rule部分 - 需要提供可解析的JSON字符串（如"{}"）
      final TaxRulePO taxRulePO = new TaxRulePO();
      taxRulePO.setId(1000L);
      taxRulePO.setHead(EnumHead.HEAD_FIRST.getCode());
      taxRulePO.setApproveStatus(EnumApproveStatus.APPROVED.getCode());
      taxRulePO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      taxRulePO.setTaxCategoryId(100L);
      taxRulePO.setItemId(200L);
      taxRulePO.setBillFrom("{}");
      taxRulePO.setBillTo("{}");
      taxRulePO.setShipFrom("{}");
      taxRulePO.setShipTo("{}");
      taxRulePO.setFromWithTaxNo(0);
      taxRulePO.setToWithTaxNo(0);
      taxRulePO.setFromVatCountry(11L);
      taxRulePO.setToTaxNoCountry(22L);
      taxRulePO.setIsReverseCharge(0);
      taxRulePO.setTransactionType(1);
      taxRulePO.setTaxTag("tag");
      taxRulePO.setRemark("remark");
      taxRulePO.setVersion(1);
      taxRulePO.setExtend("{}");
      when(taxRuleMapper.selectByExample(any(TaxRulePOExample.class)))
          .thenReturn(Arrays.asList(taxRulePO));

      final TaxAdminMetaDO taxAdminMetaDO = new TaxAdminMetaDO();
      taxAdminMetaDO.setId(300L);
      taxAdminMetaDO.setIsDelete(EnumDeleteStatus.ACTIVE);
      taxAdminMetaDO.setName("admin");
      when(taxAdminRepository.getAllTaxAdmin(true)).thenReturn(Arrays.asList(taxAdminMetaDO));

      final TaxCategoryPO taxCategoryPO = new TaxCategoryPO();
      taxCategoryPO.setId(100L);
      taxCategoryPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      taxCategoryPO.setTaxAdminId(300L);
      taxCategoryPO.setCode("CAT");
      taxCategoryPO.setCategory("category");
      taxCategoryPO.setClassify(1);
      taxCategoryPO.setDefaultTaxRate(BigDecimal.ZERO);
      when(taxCategoryMapper.selectByExample(any(TaxCategoryPOExample.class)))
          .thenReturn(Arrays.asList(taxCategoryPO));

      final TaxItemPO taxItemPO = new TaxItemPO();
      taxItemPO.setId(200L);
      taxItemPO.setIsDelete(EnumDeleteStatus.ACTIVE.getCode());
      taxItemPO.setName("item");
      taxItemPO.setCode("ITEM");
      taxItemPO.setType(1);
      when(taxItemMapper.selectByExample(any(TaxItemPOExample.class)))
          .thenReturn(Arrays.asList(taxItemPO));

      // 执行
      taxBizComplexRepositoryImplUnderTest.init();

      // 验证
      final TaxBizContextMetaDO ctx = taxBizComplexRepositoryImplUnderTest.queryAllBizTaxContext();
      assertNotNull(ctx);

      final List<BaseRuleMetaDO> baseList = ctx.getBaseRuleMetaDOS();
      assertNotNull(baseList);
      assertEquals(1, baseList.size());

      final BaseRuleMetaDO baseRule = baseList.get(0);
      assertNotNull(baseRule.getTaxRuleMetaDO());
      assertEquals(Long.valueOf(100L), baseRule.getTaxRuleMetaDO().getTaxCategoryId());
      assertEquals(Long.valueOf(200L), baseRule.getTaxRuleMetaDO().getItemId());
      assertNotNull(baseRule.getTaxAdminMetaDO());
      assertEquals(Long.valueOf(300L), baseRule.getTaxAdminMetaDO().getId());

      assertNotNull(ctx.getBizTaxRuleMetaDOS());
      assertEquals(1, ctx.getBizTaxRuleMetaDOS().size());
      assertNotNull(ctx.getBizTaxRuleMetaDOS().get(0).getTaxCountryBindMetaDO());
      assertEquals(
          Long.valueOf(1L), ctx.getBizTaxRuleMetaDOS().get(0).getTaxCountryBindMetaDO().getId());
      assertNotNull(ctx.getBizTaxRuleMetaDOS().get(0).getTaxBizMetaDO());
      assertEquals(Long.valueOf(2L), ctx.getBizTaxRuleMetaDOS().get(0).getTaxBizMetaDO().getId());
    }

    @Test
    public void testQueryAllBizTaxContext_BeforeInitThrows() {
      try {
        taxBizComplexRepositoryImplUnderTest.queryAllBizTaxContext();
        fail("Expected BizException");
      } catch (BizException e) {
        assertEquals("data error", e.getMessage());
      }
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TaxBizComplexRepositoryImplQueryAllNoBizTaxContextTest {

    @Test
    public void testQueryAllNoBizTaxContext_ReturnsContextWithBaseRules() {
      // Setup
      TaxBizComplexRepositoryImpl repo = spy(new TaxBizComplexRepositoryImpl());
      List<BaseRuleMetaDO> baseRuleMetaDOS = Arrays.asList(new BaseRuleMetaDO());
      doReturn(baseRuleMetaDOS).when(repo).queryTaxRuleContext();

      // Run the test
      TaxContextMetaDO result = repo.queryAllNoBizTaxContext();

      // Verify the results
      assertNotNull(result);
      assertSame(baseRuleMetaDOS, result.getBaseRuleMetaDOS());
      verify(repo, times(1)).queryTaxRuleContext();
    }

    @Test
    public void testQueryAllNoBizTaxContext_QueryTaxRuleContextReturnsNull() {
      // Setup
      TaxBizComplexRepositoryImpl repo = spy(new TaxBizComplexRepositoryImpl());
      doReturn(null).when(repo).queryTaxRuleContext();

      // Run the test
      TaxContextMetaDO result = repo.queryAllNoBizTaxContext();

      // Verify the results
      assertNotNull(result);
      assertNull(result.getBaseRuleMetaDOS());
      verify(repo, times(1)).queryTaxRuleContext();
    }
  }
}
