package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxTransactionType;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxAdminSubjectMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.TaxAdminSubjectMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxAdminSubjectMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxAdminSubjectPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.TaxAdminSubjectBindQuery;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TaxAdminSubjectRepositoryImplTest {

    @Mock
    private TaxAdminSubjectMapper mockTaxAdminSubjectMapper;

    @InjectMocks
    private TaxAdminSubjectRepositoryImpl taxAdminSubjectRepositoryImplUnderTest;

    @Test
    public void testQueryTaxAdminSubject() {
        // Setup
        final Map<Long, TaxAdminSubjectMetaDO> expectedResult = new HashMap<>();

        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(0);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        expectedResult.put(taxAdminSubjectPO.getId(), TaxAdminSubjectMapping.MAPPING.toMetaDO(taxAdminSubjectPO));
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final Map<Long, TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.queryTaxAdminSubject(Arrays.asList(0L), 0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testQueryTaxAdminSubject_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        final Map<Long, TaxAdminSubjectMetaDO> expectedResult = new HashMap<>();
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final Map<Long, TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.queryTaxAdminSubject(Arrays.asList(0L), 0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetById() {
        // Setup
        final TaxAdminSubjectMetaDO expectedResult = new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L);

        // Configure TaxAdminSubjectMapper.selectByPrimaryKey(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(1);
        taxAdminSubjectPO.setOperatorId(0L);
        when(mockTaxAdminSubjectMapper.selectByPrimaryKey(0L)).thenReturn(taxAdminSubjectPO);

        // Run the test
        final TaxAdminSubjectMetaDO result = taxAdminSubjectRepositoryImplUnderTest.getById(0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetByIds() {
        // Setup
        final List<TaxAdminSubjectMetaDO> expectedResult = Arrays.asList(new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L));

        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(1);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.getByIds(Arrays.asList(0L));

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetByIds_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.getByIds(Arrays.asList(0L));

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testQueryTaxAdminSubjectByAdminId() {
        // Setup
        final List<TaxAdminSubjectMetaDO> expectedResult = Arrays.asList(new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L));

        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(1);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.queryTaxAdminSubjectByAdminId(0L);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testQueryTaxAdminSubjectByAdminId_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.queryTaxAdminSubjectByAdminId(0L);

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testSaveSelective() {
        // Setup
        final TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L);
        when(mockTaxAdminSubjectMapper.insertSelective(any())).thenReturn(0);

        // Run the test
        taxAdminSubjectRepositoryImplUnderTest.saveSelective(metaDO);

        // Verify the results
        verify(mockTaxAdminSubjectMapper).insertSelective(any(TaxAdminSubjectPO.class));
    }

    @Test
    public void testFullSave() {
        // Setup
        final TaxAdminSubjectMetaDO metaDO = new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L);
        when(mockTaxAdminSubjectMapper.insertSelective(any())).thenReturn(0);

        // Run the test
        taxAdminSubjectRepositoryImplUnderTest.fullSave(metaDO);

        // Verify the results
        verify(mockTaxAdminSubjectMapper).insertSelective(any(TaxAdminSubjectPO.class));
    }

    @Test
    public void testQueryTaxAdminSubjectBySubjectId() {
        // Setup
        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(0);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final List<Long> result = taxAdminSubjectRepositoryImplUnderTest.queryTaxAdminSubjectBySubjectId(0L);

        // Verify the results
        assertEquals(Arrays.asList(0L), result);
    }

    @Test
    public void testQueryTaxAdminSubjectBySubjectId_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<Long> result = taxAdminSubjectRepositoryImplUnderTest.queryTaxAdminSubjectBySubjectId(0L);

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testQuery() {
        // Setup
        final TaxAdminSubjectBindQuery query = new TaxAdminSubjectBindQuery(0L, 0L, 0, 0);
        final PageResult<TaxAdminSubjectMetaDO> expectedResult = new PageResult<>(1L, Arrays.asList(new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L)));

        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(1);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final PageResult<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.query(query);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testQuery_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        final TaxAdminSubjectBindQuery query = new TaxAdminSubjectBindQuery(0L, 0L, 0, 0);
        final PageResult<TaxAdminSubjectMetaDO> expectedResult = new PageResult<>(0L, Collections.emptyList());
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final PageResult<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.query(query);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetAllTaxAdminSubjectByAdminId() {
        // Setup
        final List<TaxAdminSubjectMetaDO> expectedResult = Arrays.asList(new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L));

        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(1);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.getAllTaxAdminSubjectByAdminId(0L, false);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testGetAllTaxAdminSubjectByAdminId_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<TaxAdminSubjectMetaDO> result = taxAdminSubjectRepositoryImplUnderTest.getAllTaxAdminSubjectByAdminId(0L, false);

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testQueryById() {
        // Setup
        final TaxAdminSubjectMetaDO expectedResult = new TaxAdminSubjectMetaDO(0L, 0L, 0L, "taxNo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE, EnumTaxTransactionType.RECORD, 0L);

        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(1);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        // Run the test
        final TaxAdminSubjectMetaDO result = taxAdminSubjectRepositoryImplUnderTest.queryById(0L, false);

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testQueryById_TaxAdminSubjectMapperReturnsNoItems() {
        // Setup
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final TaxAdminSubjectMetaDO result = taxAdminSubjectRepositoryImplUnderTest.queryById(0L, false);

        // Verify the results
        assertNull(result);
    }

    @Test
    public void testDeleteById() {
        // Setup
        // Configure TaxAdminSubjectMapper.selectByExample(...).
        final TaxAdminSubjectPO taxAdminSubjectPO = new TaxAdminSubjectPO();
        taxAdminSubjectPO.setId(0L);
        taxAdminSubjectPO.setSubjectId(0L);
        taxAdminSubjectPO.setTaxAdminId(0L);
        taxAdminSubjectPO.setTaxNoCountry(0L);
        taxAdminSubjectPO.setTaxNo("taxNo");
        taxAdminSubjectPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        taxAdminSubjectPO.setIsDelete(0);
        taxAdminSubjectPO.setTaxTransactionType(0);
        taxAdminSubjectPO.setOperatorId(0L);
        final List<TaxAdminSubjectPO> taxAdminSubjectPOS = Arrays.asList(taxAdminSubjectPO);
        when(mockTaxAdminSubjectMapper.selectByExample(any(TaxAdminSubjectPOExample.class))).thenReturn(taxAdminSubjectPOS);

        when(mockTaxAdminSubjectMapper.updateByPrimaryKeySelective(any())).thenReturn(0);

        // Run the test
        taxAdminSubjectRepositoryImplUnderTest.deleteById(0L);

        // Verify the results
        verify(mockTaxAdminSubjectMapper).updateByPrimaryKeySelective(any(TaxAdminSubjectPO.class));
    }

}
