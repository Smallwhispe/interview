package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.dal.dao.base.TransactionDetailMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionLineMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDetailPOExample;
import com.bytedance.cg.oversea.bytetax.dal.repository.TaxCategoryRepository;
import java.math.BigDecimal;
import java.util.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TransactionLineRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionLineRepositoryImplQueryDetailByTransactionIdsTest {

    @Mock private TransactionDetailMapper mockTransactionDetailMapper;

    @Mock private TaxCategoryRepository mockTaxCategoryRepository;

    @InjectMocks private TransactionLineRepositoryImpl transactionLineRepositoryImplUnderTest;

    @Test
    public void testQueryDetailByTransactionIds_NullInput() {
      // Run the test
      final Map<Long, List<TransactionLineMetaDO>> result =
          transactionLineRepositoryImplUnderTest.queryDetailByTransactionIds(null);

      // Verify the results
      assertEquals(0, result.size());
    }

    @Test
    public void testQueryDetailByTransactionIds_EmptyInput() {
      // Run the test
      final Map<Long, List<TransactionLineMetaDO>> result =
          transactionLineRepositoryImplUnderTest.queryDetailByTransactionIds(
              Collections.<Long>emptyList());

      // Verify the results
      assertEquals(0, result.size());
    }

    @Test
    public void testQueryDetailByTransactionIds_GroupingByTransactionId() {
      // Setup
      TransactionDetailPO po1 = new TransactionDetailPO();
      po1.setTransactionId(1L);
      TransactionDetailPO po2 = new TransactionDetailPO();
      po2.setTransactionId(1L);
      TransactionDetailPO po3 = new TransactionDetailPO();
      po3.setTransactionId(2L);
      List<TransactionDetailPO> pos = Arrays.asList(po1, po2, po3);
      when(mockTransactionDetailMapper.selectByExample(any(TransactionDetailPOExample.class)))
          .thenReturn(pos);

      // Run the test
      final Map<Long, List<TransactionLineMetaDO>> result =
          transactionLineRepositoryImplUnderTest.queryDetailByTransactionIds(Arrays.asList(1L, 2L));

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(2, result.get(1L).size());
      assertEquals(1, result.get(2L).size());
    }

    @Test
    public void testQueryDetailByTransactionIds_MapperReturnsEmpty() {
      // Setup
      when(mockTransactionDetailMapper.selectByExample(any(TransactionDetailPOExample.class)))
          .thenReturn(Collections.<TransactionDetailPO>emptyList());

      // Run the test
      final Map<Long, List<TransactionLineMetaDO>> result =
          transactionLineRepositoryImplUnderTest.queryDetailByTransactionIds(
              Arrays.asList(10L, 20L));

      // Verify the results
      assertEquals(0, result.size());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionLineRepositoryImplQueryByTranIdAndItemIdTest {

    @Mock private TransactionDetailMapper transactionDetailMapper;

    @Mock private TaxCategoryRepository taxCategoryRepository;

    @InjectMocks private TransactionLineRepositoryImpl transactionLineRepositoryImplUnderTest;

    @Test
    public void testQueryByTranIdAndItemId_ReturnsTaxCategories() {
      // Setup
      final Long tranId = 100L;
      final Long itemId = 200L;
      final TransactionLineRepositoryImpl spyRepo = spy(transactionLineRepositoryImplUnderTest);

      TransactionLineMetaDO matchMeta = new TransactionLineMetaDO();
      matchMeta.setItemId(itemId);
      matchMeta.setTaxCategoryBindIds(Arrays.asList(10L, 20L));

      TransactionLineMetaDO otherMeta = new TransactionLineMetaDO();
      otherMeta.setItemId(201L);

      doReturn(Arrays.asList(matchMeta, otherMeta))
          .when(spyRepo)
          .queryDetailByTransactionId(tranId);

      TaxCategoryMetaDO cat1 = new TaxCategoryMetaDO();
      cat1.setId(10L);
      TaxCategoryMetaDO cat2 = new TaxCategoryMetaDO();
      cat2.setId(20L);
      List<TaxCategoryMetaDO> expectedCats = Arrays.asList(cat1, cat2);
      when(taxCategoryRepository.queryByIds(matchMeta.getTaxCategoryBindIds()))
          .thenReturn(expectedCats);

      // Run the test
      List<TaxCategoryMetaDO> result = spyRepo.queryByTranIdAndItemId(tranId, itemId);

      // Verify the results
      assertEquals(2, result.size());
      assertEquals(Long.valueOf(10L), result.get(0).getId());
      assertEquals(Long.valueOf(20L), result.get(1).getId());
      verify(taxCategoryRepository).queryByIds(matchMeta.getTaxCategoryBindIds());
    }

    @Test
    public void testQueryByTranIdAndItemId_NoMatchReturnsEmptyList() {
      // Setup
      final Long tranId = 101L;
      final Long itemId = 202L;
      final TransactionLineRepositoryImpl spyRepo = spy(transactionLineRepositoryImplUnderTest);

      TransactionLineMetaDO otherMeta = new TransactionLineMetaDO();
      otherMeta.setItemId(203L);

      doReturn(Arrays.asList(otherMeta)).when(spyRepo).queryDetailByTransactionId(tranId);

      // Run the test
      List<TaxCategoryMetaDO> result = spyRepo.queryByTranIdAndItemId(tranId, itemId);

      // Verify the results
      assertEquals(Collections.emptyList(), result);
      verify(taxCategoryRepository, never()).queryByIds(anyList());
    }

    @Test
    public void testQueryByTranIdAndItemId_MatchButNoBindIdsReturnsEmptyList() {
      // Setup
      final Long tranId = 102L;
      final Long itemId = 204L;
      final TransactionLineRepositoryImpl spyRepo = spy(transactionLineRepositoryImplUnderTest);

      TransactionLineMetaDO matchMeta = new TransactionLineMetaDO();
      matchMeta.setItemId(itemId);
      matchMeta.setTaxCategoryBindIds(null);

      doReturn(Arrays.asList(matchMeta)).when(spyRepo).queryDetailByTransactionId(tranId);
      when(taxCategoryRepository.queryByIds(null))
          .thenReturn(Collections.<TaxCategoryMetaDO>emptyList());

      // Run the test
      List<TaxCategoryMetaDO> result = spyRepo.queryByTranIdAndItemId(tranId, itemId);

      // Verify the results
      assertEquals(0, result.size());
      verify(taxCategoryRepository).queryByIds(null);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionLineRepositoryImplSaveTest {

    @Mock private TransactionDetailMapper mockTransactionDetailMapper;

    @InjectMocks private TransactionLineRepositoryImpl transactionLineRepositoryImplUnderTest;

    @Test
    public void testSave() {
      // Setup
      TransactionLineMetaDO meta1 = new TransactionLineMetaDO();
      meta1.setId(1L);
      meta1.setTransactionId(100L);
      meta1.setItemId(200L);
      meta1.setQuantity(1);
      meta1.setTaxable(BigDecimal.ONE);
      meta1.setTax(BigDecimal.ZERO);
      meta1.setDiscount(BigDecimal.ZERO);

      TransactionLineMetaDO meta2 = new TransactionLineMetaDO();
      meta2.setId(2L);
      meta2.setTransactionId(101L);
      meta2.setItemId(201L);
      meta2.setQuantity(2);
      meta2.setTaxable(BigDecimal.TEN);
      meta2.setTax(BigDecimal.ONE);
      meta2.setDiscount(BigDecimal.ZERO);

      final List<TransactionLineMetaDO> transactionLineMetaDOS = Arrays.asList(meta1, meta2);
      when(mockTransactionDetailMapper.insertSelective(any())).thenReturn(1);

      // Run the test
      final int result = transactionLineRepositoryImplUnderTest.save(transactionLineMetaDOS);

      // Verify the results
      assertEquals(1, result);
      verify(mockTransactionDetailMapper, times(2)).insertSelective(any());
    }

    @Test
    public void testSave_EmptyList() {
      // Setup - no stubbing to avoid unnecessary stubbing

      // Run the test
      final int result =
          transactionLineRepositoryImplUnderTest.save(
              Collections.<TransactionLineMetaDO>emptyList());

      // Verify the results
      assertEquals(1, result);
      verify(mockTransactionDetailMapper, never()).insertSelective(any());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionLineRepositoryImplQueryDetailByTransactionIdTest {

    @Mock private TransactionDetailMapper mockTransactionDetailMapper;
    @Mock private TaxCategoryRepository mockTaxCategoryRepository;

    @InjectMocks private TransactionLineRepositoryImpl transactionLineRepositoryImplUnderTest;

    @Test
    public void testQueryDetailByTransactionId_ReturnsEmptyWhenMapperReturnsEmpty() {
      when(mockTransactionDetailMapper.selectByExample(any(TransactionDetailPOExample.class)))
          .thenReturn(Collections.<TransactionDetailPO>emptyList());

      final List<TransactionLineMetaDO> result =
          transactionLineRepositoryImplUnderTest.queryDetailByTransactionId(1L);

      assertEquals(0, result.size());
      verify(mockTransactionDetailMapper).selectByExample(any(TransactionDetailPOExample.class));
    }

    @Test
    public void testQueryDetailByTransactionId_FiltersOutOtherTransactionIds() {
      TransactionDetailPO other = new TransactionDetailPO();
      other.setId(2L);
      other.setTransactionId(2L);
      other.setItemId(200L);
      other.setIsDelete(0);

      when(mockTransactionDetailMapper.selectByExample(any(TransactionDetailPOExample.class)))
          .thenReturn(Arrays.asList(other));

      final List<TransactionLineMetaDO> result =
          transactionLineRepositoryImplUnderTest.queryDetailByTransactionId(1L);

      assertEquals(0, result.size());
      verify(mockTransactionDetailMapper).selectByExample(any(TransactionDetailPOExample.class));
    }

    @Test
    public void testQueryDetailByTransactionId_ReturnsMappedItemsForTransactionId() {
      TransactionDetailPO line1 = new TransactionDetailPO();
      line1.setId(10L);
      line1.setTransactionId(1L);
      line1.setItemId(100L);
      line1.setIsDelete(0);

      TransactionDetailPO line2 = new TransactionDetailPO();
      line2.setId(11L);
      line2.setTransactionId(1L);
      line2.setItemId(101L);
      line2.setIsDelete(0);

      // 即使 example 只包含 transactionId=1L，我们的 mock 返回两个属于该 id 的记录
      when(mockTransactionDetailMapper.selectByExample(any(TransactionDetailPOExample.class)))
          .thenReturn(Arrays.asList(line1, line2));

      final List<TransactionLineMetaDO> result =
          transactionLineRepositoryImplUnderTest.queryDetailByTransactionId(1L);

      assertEquals(2, result.size());
      assertEquals(Long.valueOf(1L), result.get(0).getTransactionId());
      assertEquals(Long.valueOf(1L), result.get(1).getTransactionId());
      verify(mockTransactionDetailMapper).selectByExample(any(TransactionDetailPOExample.class));
    }
  }
}
