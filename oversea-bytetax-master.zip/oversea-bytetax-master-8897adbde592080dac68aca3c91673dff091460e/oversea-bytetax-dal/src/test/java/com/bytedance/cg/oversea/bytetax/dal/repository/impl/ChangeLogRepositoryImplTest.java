package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeLogType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumChangeType;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.ChangeLogMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.ChangeLogMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPO;
import com.bytedance.cg.oversea.bytetax.dal.po.ChangeLogPOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.ChangeLogQuery;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ChangeLogRepositoryImplTest {

    @Mock
    private ChangeLogMapper mockChangeLogMapper;

    @InjectMocks
    private ChangeLogRepositoryImpl changeLogRepositoryImplUnderTest;

    @Test
    public void testSave() {
        // Setup
        when(mockChangeLogMapper.insertSelective(any())).thenReturn(0);

        // Run the test
        changeLogRepositoryImplUnderTest.save(0L, 0, "originalPo", "updatedPo", 0, 0);

        // Verify the results
        verify(mockChangeLogMapper).insertSelective(any());
    }

    //todo 有问题等修复
//    @Test
//    public void testQueryChangeLogList() {
//        // Setup
//        final ChangeLogQuery query = new ChangeLogQuery(0L, 0, 0L, 0, 0);
//        final PageResult<ChangeLogMetaDO> expectedResult = new PageResult<>(1L, Arrays.asList(new ChangeLogMetaDO(0L, 0L, EnumChangeLogType.ADMIN_ID, "originalPo", "updatedPo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0, EnumChangeType.CREATE)));
//
//        // Configure ChangeLogMapper.selectByExample(...).
//        final ChangeLogPO changeLogPO = new ChangeLogPO();
//        changeLogPO.setId(0L);
//        changeLogPO.setEntityId(0L);
//        changeLogPO.setEntityType(1L);
//        changeLogPO.setOriginalPo("originalPo");
//        changeLogPO.setUpdatedPo("updatedPo");
//        changeLogPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
//        changeLogPO.setOperatorId(0);
//        changeLogPO.setChangeType(1);
//        final List<ChangeLogPO> changeLogPOS = Arrays.asList(changeLogPO);
//        when(mockChangeLogMapper.selectByExample(any(ChangeLogPOExample.class))).thenReturn(changeLogPOS);
//
//        // Run the test
//        final PageResult<ChangeLogMetaDO> result = changeLogRepositoryImplUnderTest.queryChangeLogList(query);
//
//        // Verify the results
//        assertEquals(expectedResult, result);
//    }

    @Test
    public void testQueryChangeLogList_ChangeLogMapperReturnsNoItems() {
        // Setup
        final ChangeLogQuery query = new ChangeLogQuery(0L, 0, 0L, 0, 0);
        final PageResult<ChangeLogMetaDO> expectedResult = new PageResult<>(0L, Arrays.asList(new ChangeLogMetaDO(0L, 0L, EnumChangeLogType.ADMIN_ID, "originalPo", "updatedPo", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0, EnumChangeType.CREATE)));
        when(mockChangeLogMapper.selectByExample(any(ChangeLogPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final PageResult<ChangeLogMetaDO> result = changeLogRepositoryImplUnderTest.queryChangeLogList(query);

        // Verify the results
        assertEquals(Collections.emptyList(), result.getData());
    }
}
