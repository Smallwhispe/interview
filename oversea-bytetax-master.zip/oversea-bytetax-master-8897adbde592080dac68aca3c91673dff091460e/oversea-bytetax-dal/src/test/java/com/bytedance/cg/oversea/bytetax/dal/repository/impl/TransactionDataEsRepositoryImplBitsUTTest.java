package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.dal.elasticsearch.TransactionDataEsDAO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsCommonMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.metado.TransactionDataEsScrollMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TransactionDataEsPO;
import java.util.ArrayList;
import java.util.Arrays;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TransactionDataEsRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionDataEsRepositoryImplTransactionSelectScrollTest {

    @Mock private TransactionDataEsDAO mockTransactionDataEsDAO;

    @InjectMocks private TransactionDataEsRepositoryImpl transactionDataEsRepositoryImplUnderTest;

    @Test
    public void testTransactionSelectScroll_MultiPages() {
      // Setup
      TransactionDataEsPO po1 = new TransactionDataEsPO();
      po1.setId(1L);
      TransactionDataEsPO po2 = new TransactionDataEsPO();
      po2.setId(2L);
      TransactionDataEsPO po3 = new TransactionDataEsPO();
      po3.setId(3L);

      TransactionDataEsScrollMetaDO first =
          TransactionDataEsScrollMetaDO.builder()
              .transactionDataEsPOS(Arrays.asList(po1, po2))
              .scrollId("s1")
              .build();
      TransactionDataEsScrollMetaDO second =
          TransactionDataEsScrollMetaDO.builder()
              .transactionDataEsPOS(Arrays.asList(po3))
              .scrollId("s2")
              .build();
      TransactionDataEsScrollMetaDO thirdEmpty =
          TransactionDataEsScrollMetaDO.builder().scrollId("s3").build();

      when(mockTransactionDataEsDAO.transactionSelectScroll(any(SearchSourceBuilder.class)))
          .thenReturn(first);
      when(mockTransactionDataEsDAO.scrollEachTag(eq("s1"))).thenReturn(second);
      when(mockTransactionDataEsDAO.scrollEachTag(eq("s2"))).thenReturn(thirdEmpty);

      // Run the test
      TransactionDataEsCommonMetaDO result =
          transactionDataEsRepositoryImplUnderTest.transactionSelectScroll(
              new SearchSourceBuilder());

      // Verify the results
      assertEquals(3L, result.getTotal().longValue());
      assertEquals(3, result.getTransactionDataEsPOS().size());
      assertEquals(1L, result.getTransactionDataEsPOS().get(0).getId().longValue());
      assertEquals(2L, result.getTransactionDataEsPOS().get(1).getId().longValue());
      assertEquals(3L, result.getTransactionDataEsPOS().get(2).getId().longValue());
      verify(mockTransactionDataEsDAO).clearScroll(eq("s3"));
      verify(mockTransactionDataEsDAO).scrollEachTag(eq("s1"));
      verify(mockTransactionDataEsDAO).scrollEachTag(eq("s2"));
    }

    @Test
    public void testTransactionSelectScroll_EmptyInitial() {
      // Setup
      TransactionDataEsScrollMetaDO emptyInitial =
          TransactionDataEsScrollMetaDO.builder().scrollId("s0").build();
      when(mockTransactionDataEsDAO.transactionSelectScroll(any(SearchSourceBuilder.class)))
          .thenReturn(emptyInitial);

      // Run the test
      TransactionDataEsCommonMetaDO result =
          transactionDataEsRepositoryImplUnderTest.transactionSelectScroll(
              new SearchSourceBuilder());

      // Verify the results
      assertEquals(0L, result.getTotal().longValue());
      assertEquals(0, result.getTransactionDataEsPOS().size());
      verify(mockTransactionDataEsDAO, never()).scrollEachTag(anyString());
      verify(mockTransactionDataEsDAO).clearScroll(eq("s0"));
    }

    @Test
    public void testTransactionSelectScroll_ExceptionDuringScroll() {
      // Setup
      TransactionDataEsPO po1 = new TransactionDataEsPO();
      po1.setId(1L);

      TransactionDataEsScrollMetaDO first =
          TransactionDataEsScrollMetaDO.builder()
              .transactionDataEsPOS(Arrays.asList(po1))
              .scrollId("s1")
              .build();

      when(mockTransactionDataEsDAO.transactionSelectScroll(any(SearchSourceBuilder.class)))
          .thenReturn(first);
      when(mockTransactionDataEsDAO.scrollEachTag(eq("s1")))
          .thenThrow(new RuntimeException("scroll error"));

      // Run the test
      try {
        transactionDataEsRepositoryImplUnderTest.transactionSelectScroll(new SearchSourceBuilder());
      } catch (RuntimeException e) {
        // Verify the results
        assertEquals("scroll error", e.getMessage());
        verify(mockTransactionDataEsDAO).clearScroll(eq("s1"));
        return;
      }
      throw new AssertionError("Expected RuntimeException was not thrown");
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class TransactionDataEsRepositoryImplTransactionSelectTest {

    @Mock private TransactionDataEsDAO mockTransactionDataEsDAO;

    @InjectMocks private TransactionDataEsRepositoryImpl repository;

    @Test
    public void testTransactionSelect_DelegateAndReturn() {
      // Setup
      SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
      TransactionDataEsCommonMetaDO expected =
          TransactionDataEsCommonMetaDO.builder()
              .transactionDataEsPOS(new ArrayList<TransactionDataEsPO>())
              .total(0L)
              .build();
      when(mockTransactionDataEsDAO.transactionSelect(any(SearchSourceBuilder.class)))
          .thenReturn(expected);

      // Run the test
      TransactionDataEsCommonMetaDO result = repository.transactionSelect(sourceBuilder);

      // Verify the results
      verify(mockTransactionDataEsDAO).transactionSelect(sourceBuilder);
      assertEquals(expected.getTotal(), result.getTotal());
      assertEquals(expected.getTransactionDataEsPOS(), result.getTransactionDataEsPOS());
    }

    @Test
    public void testTransactionSelect_ReturnsNullFromDAO() {
      // Setup
      SearchSourceBuilder sourceBuilder = new SearchSourceBuilder();
      when(mockTransactionDataEsDAO.transactionSelect(any(SearchSourceBuilder.class)))
          .thenReturn(null);

      // Run the test
      TransactionDataEsCommonMetaDO result = repository.transactionSelect(sourceBuilder);

      // Verify the results
      verify(mockTransactionDataEsDAO).transactionSelect(sourceBuilder);
      assertNull(result);
    }
  }
}
