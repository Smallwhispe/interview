package com.bytedance.cg.oversea.bytetax.dal.elasticsearch;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.elasticsearch.client.RestHighLevelClient;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class EsClientBitsUTTest {
  public static class EsClientRestHighLevelClientTest {

    @Test
    public void testRestHighLevelClient_call() {
      EsClient esClient = new EsClient();
      try {
        RestHighLevelClient client = esClient.restHighLevelClient();
        assertNotNull(client);
      } catch (Throwable t) {
        assertTrue(
            t instanceof RuntimeException
                || t instanceof IllegalArgumentException
                || t instanceof NullPointerException);
      }
    }
  }
}
