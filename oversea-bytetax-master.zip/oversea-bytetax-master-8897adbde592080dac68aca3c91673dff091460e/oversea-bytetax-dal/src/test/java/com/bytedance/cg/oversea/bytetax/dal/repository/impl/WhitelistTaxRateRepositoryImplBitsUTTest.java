package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.WhitelistTaxRateMapper;
import com.bytedance.cg.oversea.bytetax.dal.mapping.WhitelistTaxRateMapping;
import com.bytedance.cg.oversea.bytetax.dal.metado.WhitelistTaxRateMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.WhitelistTaxRatePO;
import com.bytedance.cg.oversea.bytetax.dal.po.WhitelistTaxRatePOExample;
import com.bytedance.cg.oversea.bytetax.dal.query.WhitelistTaxRateQuery;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class WhitelistTaxRateRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class WhitelistTaxRateRepositoryImplQueryListTest {

    @Mock private WhitelistTaxRateMapper mockMapper;

    @Mock private WhitelistTaxRateMapping mockMapping;

    @InjectMocks private WhitelistTaxRateRepositoryImpl repositoryImplUnderTest;

    @Test
    public void testQueryList_Normal() {
      WhitelistTaxRateQuery query = new WhitelistTaxRateQuery();
      query.setAccountId(1001L);
      query.setAccountIdList(Arrays.asList(1001L, 1002L));
      query.setCountry("US");
      query.setSubjectId(2001L);
      query.setPageNumber(1);
      query.setPageSize(10);

      WhitelistTaxRatePO po1 = new WhitelistTaxRatePO();
      po1.setId(1L);
      po1.setAccountId(1001L);
      po1.setSubjectId(2001L);
      po1.setCountry("US");
      po1.setTaxRate(new BigDecimal("0.10"));
      po1.setCreateTime(new Date());
      po1.setModifyTime(new Date());

      WhitelistTaxRatePO po2 = new WhitelistTaxRatePO();
      po2.setId(2L);
      po2.setAccountId(1002L);
      po2.setSubjectId(2001L);
      po2.setCountry("US");
      po2.setTaxRate(new BigDecimal("0.20"));
      po2.setCreateTime(new Date());
      po2.setModifyTime(new Date());

      List<WhitelistTaxRatePO> poList = Arrays.asList(po1, po2);
      when(mockMapper.selectByExample(any(WhitelistTaxRatePOExample.class))).thenReturn(poList);

      WhitelistTaxRateMetaDO meta1 = new WhitelistTaxRateMetaDO();
      meta1.setId(1L);
      meta1.setAccountId(1001L);
      meta1.setSubjectId(2001L);
      meta1.setCountry("US");
      meta1.setTaxRate(new BigDecimal("0.10"));

      WhitelistTaxRateMetaDO meta2 = new WhitelistTaxRateMetaDO();
      meta2.setId(2L);
      meta2.setAccountId(1002L);
      meta2.setSubjectId(2001L);
      meta2.setCountry("US");
      meta2.setTaxRate(new BigDecimal("0.20"));

      List<WhitelistTaxRateMetaDO> expectedMetaList = Arrays.asList(meta1, meta2);
      when(mockMapping.toMetaDOList(anyList())).thenReturn(expectedMetaList);

      PageResult<WhitelistTaxRateMetaDO> result = repositoryImplUnderTest.queryList(query);

      assertEquals(Long.valueOf(2L), result.getTotal());
      assertEquals(expectedMetaList, result.getData());
      verify(mockMapper).selectByExample(any(WhitelistTaxRatePOExample.class));
      verify(mockMapping).toMetaDOList(anyList());
    }

    @Test
    public void testQueryList_EmptyResult() {
      WhitelistTaxRateQuery query = new WhitelistTaxRateQuery();
      when(mockMapper.selectByExample(any(WhitelistTaxRatePOExample.class)))
          .thenReturn(Collections.<WhitelistTaxRatePO>emptyList());
      when(mockMapping.toMetaDOList(anyList()))
          .thenReturn(Collections.<WhitelistTaxRateMetaDO>emptyList());

      PageResult<WhitelistTaxRateMetaDO> result = repositoryImplUnderTest.queryList(query);

      assertEquals(Collections.emptyList(), result.getData());
      assertEquals(Long.valueOf(0L), result.getTotal());
      verify(mockMapper).selectByExample(any(WhitelistTaxRatePOExample.class));
      verify(mockMapping).toMetaDOList(anyList());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class WhitelistTaxRateRepositoryImplSaveTest {

    @Mock private WhitelistTaxRateMapper mockMapper;

    @Mock private WhitelistTaxRateMapping mockMapping;

    @InjectMocks private WhitelistTaxRateRepositoryImpl repository;

    @Test
    public void testSave() {
      // Setup
      final WhitelistTaxRateMetaDO metaDO = new WhitelistTaxRateMetaDO();
      final WhitelistTaxRatePO po = new WhitelistTaxRatePO();
      when(mockMapping.toPO(any(WhitelistTaxRateMetaDO.class))).thenReturn(po);
      when(mockMapper.insertSelective(any(WhitelistTaxRatePO.class))).thenReturn(1);

      // Run the test
      repository.save(metaDO);

      // Verify the results
      verify(mockMapping).toPO(metaDO);
      verify(mockMapper).insertSelective(po);
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertEquals(metaDO.getCreateTime(), metaDO.getModifyTime());
    }

    @Test
    public void testSave_ShouldOverrideExistingTimestamps() {
      // Setup
      final WhitelistTaxRateMetaDO metaDO = new WhitelistTaxRateMetaDO();
      Date old = new Date(0L);
      metaDO.setCreateTime(old);
      metaDO.setModifyTime(old);
      final WhitelistTaxRatePO po = new WhitelistTaxRatePO();
      when(mockMapping.toPO(any(WhitelistTaxRateMetaDO.class))).thenReturn(po);
      when(mockMapper.insertSelective(any(WhitelistTaxRatePO.class))).thenReturn(1);

      // Run the test
      repository.save(metaDO);

      // Verify the results
      ArgumentCaptor<WhitelistTaxRateMetaDO> metaCaptor =
          ArgumentCaptor.forClass(WhitelistTaxRateMetaDO.class);
      verify(mockMapping).toPO(metaCaptor.capture());
      verify(mockMapper).insertSelective(po);

      WhitelistTaxRateMetaDO passedToMapping = metaCaptor.getValue();
      assertNotNull(passedToMapping.getCreateTime());
      assertNotNull(passedToMapping.getModifyTime());
      assertEquals(passedToMapping.getCreateTime(), passedToMapping.getModifyTime());
      // Ensure timestamps were overridden
      // old time is epoch (0), after save it should not be equal
      assertNotNull(metaDO.getCreateTime());
      assertNotNull(metaDO.getModifyTime());
      assertEquals(metaDO.getCreateTime(), metaDO.getModifyTime());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class WhitelistTaxRateRepositoryImplUpdateByIdSelectiveTest {

    @Mock private WhitelistTaxRateMapper mockWhitelistTaxRateMapper;

    @Mock private WhitelistTaxRateMapping mockWhitelistTaxRateMapping;

    @InjectMocks private WhitelistTaxRateRepositoryImpl whitelistTaxRateRepositoryImplUnderTest;

    @Test
    public void testUpdateByIdSelective() {
      // Setup
      WhitelistTaxRateMetaDO metaDO = new WhitelistTaxRateMetaDO();
      metaDO.setId(1L);

      WhitelistTaxRatePO po = new WhitelistTaxRatePO();
      po.setId(1L);
      java.util.Date oldModify = new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime();
      po.setModifyTime(oldModify);

      when(mockWhitelistTaxRateMapping.toPO(any(WhitelistTaxRateMetaDO.class))).thenReturn(po);
      when(mockWhitelistTaxRateMapper.updateByPrimaryKeySelective(any(WhitelistTaxRatePO.class)))
          .thenReturn(1);

      // Run the test
      whitelistTaxRateRepositoryImplUnderTest.updateByIdSelective(metaDO);

      // Verify the results
      ArgumentCaptor<WhitelistTaxRatePO> captor = ArgumentCaptor.forClass(WhitelistTaxRatePO.class);
      verify(mockWhitelistTaxRateMapper).updateByPrimaryKeySelective(captor.capture());
      WhitelistTaxRatePO updatedPO = captor.getValue();

      assertNotNull(updatedPO.getModifyTime());
      assertTrue(updatedPO.getModifyTime().after(oldModify));
    }

    @Test
    public void testUpdateByIdSelective_ModifyTimeIsSetWhenNull() {
      // Setup
      WhitelistTaxRateMetaDO metaDO = new WhitelistTaxRateMetaDO();
      metaDO.setId(2L);

      WhitelistTaxRatePO po = new WhitelistTaxRatePO();
      po.setId(2L);
      po.setModifyTime(null);

      when(mockWhitelistTaxRateMapping.toPO(any(WhitelistTaxRateMetaDO.class))).thenReturn(po);
      when(mockWhitelistTaxRateMapper.updateByPrimaryKeySelective(any(WhitelistTaxRatePO.class)))
          .thenReturn(1);

      // Run the test
      whitelistTaxRateRepositoryImplUnderTest.updateByIdSelective(metaDO);

      // Verify the results
      ArgumentCaptor<WhitelistTaxRatePO> captor = ArgumentCaptor.forClass(WhitelistTaxRatePO.class);
      verify(mockWhitelistTaxRateMapper).updateByPrimaryKeySelective(captor.capture());
      WhitelistTaxRatePO updatedPO = captor.getValue();

      assertNotNull(updatedPO.getModifyTime());
    }

    @Test(expected = NullPointerException.class)
    public void testUpdateByIdSelective_NullMetaThrows() {
      // Run the test
      whitelistTaxRateRepositoryImplUnderTest.updateByIdSelective(null);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class WhitelistTaxRateRepositoryImplGetByIdTest {

    @Mock private WhitelistTaxRateMapper mapper;

    @Mock private WhitelistTaxRateMapping MAPPING;

    @InjectMocks private WhitelistTaxRateRepositoryImpl whitelistTaxRateRepositoryImplUnderTest;

    @Test
    public void testGetById() {
      // Setup
      final Long id = 1L;
      final WhitelistTaxRatePO whitelistTaxRatePO = new WhitelistTaxRatePO();
      whitelistTaxRatePO.setId(id);
      when(mapper.selectByPrimaryKey(id)).thenReturn(whitelistTaxRatePO);

      final WhitelistTaxRateMetaDO expectedResult = new WhitelistTaxRateMetaDO();
      expectedResult.setId(id);
      when(MAPPING.toMetaDO(whitelistTaxRatePO)).thenReturn(expectedResult);

      // Run the test
      final WhitelistTaxRateMetaDO result = whitelistTaxRateRepositoryImplUnderTest.getById(id);

      // Verify the results
      assertEquals(expectedResult, result);
    }

    @Test
    public void testGetById_MapperReturnsNull() {
      // Setup
      final Long id = 2L;
      when(mapper.selectByPrimaryKey(id)).thenReturn(null);

      // Run the test
      final WhitelistTaxRateMetaDO result = whitelistTaxRateRepositoryImplUnderTest.getById(id);

      // Verify the results
      assertNull(result);
    }
  }
}
