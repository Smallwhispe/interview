package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.CasesMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.CasesMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.CasesPO;
import com.bytedance.cg.oversea.bytetax.dal.po.CasesPOExample;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CasesRepositoryImplTest {

    @Mock
    private CasesMapper mockCasesMapper;

    @InjectMocks
    private CasesRepositoryImpl casesRepositoryImplUnderTest;

    @Test
    public void testSelectAll() {
        // Setup
        final List<CasesMetaDO> expectedResult = Arrays.asList(new CasesMetaDO(0L, "{\"fromVatInfo\":{\"taxNo\":\"WITH\",\"taxNoMap\":null},\"toVatInfo\":{\"taxNo\":\"WITHOUT\",\"taxNoMap\":null},\"addressInfo\":{\"shipFrom\":null,\"shipTo\":null,\"billFrom\":{\"levelZero\":2635167,\"levelOne\":0,\"levelTwo\":0,\"levelThree\":0},\"billTo\":{\"levelZero\":3042058,\"levelOne\":0,\"levelTwo\":0,\"levelThree\":0}},\"itemIds\":[2],\"queryTime\":null,\"exemptionCustomerId\":null}", Arrays.asList(390L), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE));

        // Configure CasesMapper.selectByExample(...).
        final CasesPO casesPO = new CasesPO();
        casesPO.setId(0L);
        casesPO.setCaseKey("{\"fromVatInfo\":{\"taxNo\":\"WITH\",\"taxNoMap\":null},\"toVatInfo\":{\"taxNo\":\"WITHOUT\",\"taxNoMap\":null},\"addressInfo\":{\"shipFrom\":null,\"shipTo\":null,\"billFrom\":{\"levelZero\":2635167,\"levelOne\":0,\"levelTwo\":0,\"levelThree\":0},\"billTo\":{\"levelZero\":3042058,\"levelOne\":0,\"levelTwo\":0,\"levelThree\":0}},\"itemIds\":[2],\"queryTime\":null,\"exemptionCustomerId\":null}");
        casesPO.setValue("[390]");
        casesPO.setCreateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        casesPO.setModifyTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime());
        casesPO.setIsDelete(0);
        final List<CasesPO> casesPOS = Arrays.asList(casesPO);
        when(mockCasesMapper.selectByExample(any(CasesPOExample.class))).thenReturn(casesPOS);

        // Run the test
        final List<CasesMetaDO> result = casesRepositoryImplUnderTest.selectAll();

        // Verify the results
        assertEquals(expectedResult, result);
    }

    @Test
    public void testSelectAll_CasesMapperReturnsNoItems() {
        // Setup
        when(mockCasesMapper.selectByExample(any(CasesPOExample.class))).thenReturn(Collections.emptyList());

        // Run the test
        final List<CasesMetaDO> result = casesRepositoryImplUnderTest.selectAll();

        // Verify the results
        assertEquals(Collections.emptyList(), result);
    }

    @Test
    public void testSave() {
        // Setup
        final CasesMetaDO metaDO = new CasesMetaDO(0L, "key", Arrays.asList(0L), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE);
        when(mockCasesMapper.insert(any())).thenReturn(0);

        // Run the test
        final int result = casesRepositoryImplUnderTest.save(metaDO);

        // Verify the results
        assertEquals(0, result);
    }

    @Test
    public void testUpdateByIdSelective() {
        // Setup
        final CasesMetaDO metaDO = new CasesMetaDO(0L, "key", Arrays.asList(0L), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), EnumDeleteStatus.ACTIVE);
        when(mockCasesMapper.updateByPrimaryKeySelective(any())).thenReturn(0);

        // Run the test
        final int result = casesRepositoryImplUnderTest.updateByIdSelective(metaDO);

        // Verify the results
        assertEquals(0, result);
    }
}
