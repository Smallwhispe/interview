package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxSubjectCompanyCodeBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxSubjectCompanyCodeBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxSubjectCompanyCodeBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxSubjectCompanyCodeBindPOExample;
import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxSubjectCompanyCodeBindRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxSubjectCompanyCodeBindRepositoryImplQueryBySubjectIdTest {

    @Mock private TaxSubjectCompanyCodeBindMapper mockTaxSubjectCompanyCodeBindMapper;

    @InjectMocks private TaxSubjectCompanyCodeBindRepositoryImpl repository;

    @Test
    public void testQueryBySubjectId_SubjectIdNull() {
      // Run
      TaxSubjectCompanyCodeBindMetaDO result = repository.queryBySubjectId(null, 1L);

      // Verify
      assertNull(result);
      verify(mockTaxSubjectCompanyCodeBindMapper, never())
          .selectByExample(any(TaxSubjectCompanyCodeBindPOExample.class));
    }

    @Test
    public void testQueryBySubjectId_EmptyList() {
      // Setup
      when(mockTaxSubjectCompanyCodeBindMapper.selectByExample(
              any(TaxSubjectCompanyCodeBindPOExample.class)))
          .thenReturn(Collections.<TaxSubjectCompanyCodeBindPO>emptyList());

      // Run
      TaxSubjectCompanyCodeBindMetaDO result = repository.queryBySubjectId(1L, 2L);

      // Verify
      assertNull(result);
      verify(mockTaxSubjectCompanyCodeBindMapper)
          .selectByExample(any(TaxSubjectCompanyCodeBindPOExample.class));
    }

    @Test
    public void testQueryBySubjectId_HasResult() {
      // Setup
      TaxSubjectCompanyCodeBindPO po = new TaxSubjectCompanyCodeBindPO();
      try {
        po.getClass()
            .getMethod("setIsDelete", Integer.class)
            .invoke(po, EnumDeleteStatus.ACTIVE.getCode());
      } catch (Exception ignore) {
        // In case setter signature differs, ignore and rely on default mapping behavior.
      }
      when(mockTaxSubjectCompanyCodeBindMapper.selectByExample(
              any(TaxSubjectCompanyCodeBindPOExample.class)))
          .thenReturn(Arrays.asList(po));

      // Run
      TaxSubjectCompanyCodeBindMetaDO result = repository.queryBySubjectId(100L, 200L);

      // Verify
      assertNotNull(result);
      verify(mockTaxSubjectCompanyCodeBindMapper)
          .selectByExample(any(TaxSubjectCompanyCodeBindPOExample.class));
    }
  }
}
