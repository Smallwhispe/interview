package com.bytedance.cg.oversea.bytetax.dal.plugin;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyZeroInteractions;

import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.dom.java.Field;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.InnerClass;
import org.mybatis.generator.api.dom.java.Method;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.TextElement;
import org.mybatis.generator.api.dom.xml.XmlElement;

@RunWith(Enclosed.class)
public class ElegantCommentGeneratorBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class ElegantCommentGeneratorAddFieldCommentH1cc64Test {

    @Mock private IntrospectedTable introspectedTable;

    @Mock private IntrospectedColumn introspectedColumn;

    @Test
    public void testAddFieldComment_NormalRemarks() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Field field = mock(Field.class);
      when(introspectedColumn.getRemarks()).thenReturn("This is a remark.");

      generator.addFieldComment(field, introspectedTable, introspectedColumn);

      ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
      verify(field, times(3)).addJavaDocLine(captor.capture());
      List<String> lines = captor.getAllValues();
      assertEquals(3, lines.size());
      assertEquals("/**", lines.get(0));
      assertEquals(" * This is a remark.", lines.get(1));
      assertEquals(" */", lines.get(2));
    }

    @Test
    public void testAddFieldComment_NewlineInRemarks() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Field field = mock(Field.class);
      when(introspectedColumn.getRemarks()).thenReturn("line1\nline2");

      generator.addFieldComment(field, introspectedTable, introspectedColumn);

      ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
      verify(field, times(3)).addJavaDocLine(captor.capture());
      List<String> lines = captor.getAllValues();
      assertEquals(3, lines.size());
      assertEquals("/**", lines.get(0));
      assertEquals(" * line1 line2", lines.get(1));
      assertEquals(" */", lines.get(2));
    }

    @Test
    public void testAddFieldComment_NullRemarks() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Field field = mock(Field.class);
      when(introspectedColumn.getRemarks()).thenReturn(null);

      generator.addFieldComment(field, introspectedTable, introspectedColumn);

      ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
      verify(field, times(3)).addJavaDocLine(captor.capture());
      List<String> lines = captor.getAllValues();
      assertEquals(3, lines.size());
      assertEquals("/**", lines.get(0));
      assertEquals(" * null", lines.get(1));
      assertEquals(" */", lines.get(2));
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class ElegantCommentGeneratorAddClassCommentH651a9Test {

    @Mock private IntrospectedTable introspectedTable;

    @Test
    public void testAddClassComment_NoChanges() {
      // Setup
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      InnerClass innerClass = new InnerClass(new FullyQualifiedJavaType("TestInner"));

      // Run the test
      generator.addClassComment(innerClass, introspectedTable);

      // Verify the results
      assertEquals(0, innerClass.getJavaDocLines().size());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class ElegantCommentGeneratorAddClassCommentHeb5e5Test {

    private ElegantCommentGenerator elegantCommentGeneratorUnderTest;

    @Mock private InnerClass mockInnerClass;

    @Mock private IntrospectedTable mockIntrospectedTable;

    @Before
    public void setUp() {
      elegantCommentGeneratorUnderTest = new ElegantCommentGenerator();
    }

    @Test
    public void testAddClassComment_MarkAsDoNotDeleteTrue() {
      // Setup

      // Run the test
      elegantCommentGeneratorUnderTest.addClassComment(mockInnerClass, mockIntrospectedTable, true);

      // Verify the results
      verifyZeroInteractions(mockInnerClass);
      verifyZeroInteractions(mockIntrospectedTable);
    }

    @Test
    public void testAddClassComment_MarkAsDoNotDeleteFalse() {
      // Setup

      // Run the test
      elegantCommentGeneratorUnderTest.addClassComment(
          mockInnerClass, mockIntrospectedTable, false);

      // Verify the results
      verifyZeroInteractions(mockInnerClass);
      verifyZeroInteractions(mockIntrospectedTable);
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class ElegantCommentGeneratorAddGetterCommentTest {

    private ElegantCommentGenerator elegantCommentGeneratorUnderTest;

    @Before
    public void setUp() {
      elegantCommentGeneratorUnderTest = new ElegantCommentGenerator();
    }

    @Test
    public void testAddGetterComment_DoNothing() {
      // Setup
      Method method = new Method("getName");
      method.addJavaDocLine("/**");
      method.addJavaDocLine(" * test");
      method.addJavaDocLine(" */");
      List<String> beforeJavaDoc = new ArrayList<String>(method.getJavaDocLines());

      IntrospectedTable introspectedTable = mock(IntrospectedTable.class);
      IntrospectedColumn introspectedColumn = mock(IntrospectedColumn.class);

      // Run the test
      elegantCommentGeneratorUnderTest.addGetterComment(
          method, introspectedTable, introspectedColumn);

      // Verify the results
      assertEquals(beforeJavaDoc.size(), method.getJavaDocLines().size());
      for (int i = 0; i < beforeJavaDoc.size(); i++) {
        assertEquals(beforeJavaDoc.get(i), method.getJavaDocLines().get(i));
      }
    }

    @Test
    public void testAddGetterComment_NullParams_NoChange() {
      // Setup
      Method method = new Method("getId");

      // Run the test
      elegantCommentGeneratorUnderTest.addGetterComment(method, null, null);

      // Verify the results
      assertEquals(0, method.getJavaDocLines().size());
    }
  }

  @RunWith(MockitoJUnitRunner.class)
  public static class ElegantCommentGeneratorAddGeneralMethodCommentTest {

    @Mock private IntrospectedTable introspectedTable;

    @Test
    public void testAddGeneralMethodComment_NoChangeForEmptyJavaDoc() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Method method = new Method("testMethod");

      int before = method.getJavaDocLines().size();
      generator.addGeneralMethodComment(method, introspectedTable);
      int after = method.getJavaDocLines().size();

      assertEquals(before, after);
      assertEquals(0, after);
    }

    @Test
    public void testAddGeneralMethodComment_NoChangeForExistingJavaDoc() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Method method = new Method("testMethod");
      method.addJavaDocLine("existing");

      generator.addGeneralMethodComment(method, introspectedTable);

      assertEquals(1, method.getJavaDocLines().size());
      assertEquals("existing", method.getJavaDocLines().get(0));
    }
  }

  public static class ElegantCommentGeneratorAddSetterCommentTest {

    @Test
    public void testAddSetterComment_NoChangeOnMethodJavaDoc() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();

      Method method = new Method("setName");
      method.addJavaDocLine("/**");
      method.addJavaDocLine(" * before");
      method.addJavaDocLine(" */");

      List<String> before = new ArrayList<String>(method.getJavaDocLines());

      IntrospectedTable table = mock(IntrospectedTable.class);
      IntrospectedColumn column = mock(IntrospectedColumn.class);

      generator.addSetterComment(method, table, column);

      List<String> after = method.getJavaDocLines();

      assertEquals(before.size(), after.size());
      for (int i = 0; i < before.size(); i++) {
        assertEquals(before.get(i), after.get(i));
      }
    }

    @Test
    public void testAddSetterComment_WithNullParams_NoExceptionAndNoChange() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();

      Method method = new Method("setId");
      method.addJavaDocLine("/**");
      method.addJavaDocLine(" * id setter");
      method.addJavaDocLine(" */");

      List<String> before = new ArrayList<String>(method.getJavaDocLines());

      generator.addSetterComment(method, null, null);

      List<String> after = method.getJavaDocLines();

      assertEquals(before.size(), after.size());
      for (int i = 0; i < before.size(); i++) {
        assertEquals(before.get(i), after.get(i));
      }
    }
  }

  public static class ElegantCommentGeneratorAddFieldCommentHd15d0Test {

    @Test
    public void testAddFieldComment_NoInteractions() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Field field = mock(Field.class);
      IntrospectedTable mockTable = mock(IntrospectedTable.class);

      generator.addFieldComment(field, mockTable);

      verifyZeroInteractions(field);
    }

    @Test
    public void testAddFieldComment_PreserveExistingJavaDocLines() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Field field = mock(Field.class);
      List<String> docLines = new ArrayList<String>();
      docLines.add("/** existing */");
      docLines.add(" * line 2");
      when(field.getJavaDocLines()).thenReturn(docLines);
      IntrospectedTable mockTable = mock(IntrospectedTable.class);

      generator.addFieldComment(field, mockTable);

      assertEquals(2, field.getJavaDocLines().size());
      verify(field, never()).addJavaDocLine(anyString());
    }

    @Test
    public void testAddFieldComment_NullTableDoesNotThrow() {
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      Field field = mock(Field.class);

      generator.addFieldComment(field, null);

      verify(field, never()).addJavaDocLine(anyString());
    }
  }

  public static class ElegantCommentGeneratorAddCommentTest {

    @Test
    public void testAddComment_ShouldNotModifyXmlElement() {
      // Setup
      ElegantCommentGenerator generator = new ElegantCommentGenerator();
      XmlElement xmlElement = new XmlElement("mapper");
      xmlElement.addAttribute(new Attribute("id", "testId"));
      xmlElement.addElement(new TextElement("original text"));

      String nameBefore = xmlElement.getName();
      int attributesSizeBefore = xmlElement.getAttributes().size();
      int elementsSizeBefore = xmlElement.getElements().size();
      String firstAttrNameBefore = xmlElement.getAttributes().get(0).getName();
      String firstAttrValueBefore = xmlElement.getAttributes().get(0).getValue();
      String firstTextContentBefore = ((TextElement) xmlElement.getElements().get(0)).getContent();

      // Run the test
      generator.addComment(xmlElement);

      // Verify the results
      assertEquals(nameBefore, xmlElement.getName());
      assertEquals(attributesSizeBefore, xmlElement.getAttributes().size());
      assertEquals(elementsSizeBefore, xmlElement.getElements().size());
      assertEquals(firstAttrNameBefore, xmlElement.getAttributes().get(0).getName());
      assertEquals(firstAttrValueBefore, xmlElement.getAttributes().get(0).getValue());
      assertEquals(
          firstTextContentBefore, ((TextElement) xmlElement.getElements().get(0)).getContent());
    }

    @Test
    public void testAddComment_NullInput_NoException() {
      // Setup
      ElegantCommentGenerator generator = new ElegantCommentGenerator();

      // Run the test
      generator.addComment(null);

      // Verify the results
      // No exception should be thrown
    }
  }
}
