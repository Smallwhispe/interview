package com.bytedance.cg.oversea.bytetax.dal.repository.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.bytedance.cg.oversea.bytetax.dal.dao.base.TaxCategoryBindMapper;
import com.bytedance.cg.oversea.bytetax.dal.metado.TaxCategoryBindMetaDO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryBindPO;
import com.bytedance.cg.oversea.bytetax.dal.po.TaxCategoryBindPOExample;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(Enclosed.class)
public class TaxCategoryBindRepositoryImplBitsUTTest {
  @RunWith(MockitoJUnitRunner.class)
  public static class TaxCategoryBindRepositoryImplQueryByIdsTest {

    @Mock private TaxCategoryBindMapper mockTaxCategoryBindMapper;

    @InjectMocks private TaxCategoryBindRepositoryImpl taxCategoryBindRepositoryImplUnderTest;

    @Test
    public void testQueryByIds_NullIds() {
      List<TaxCategoryBindMetaDO> result = taxCategoryBindRepositoryImplUnderTest.queryByIds(null);
      assertEquals(0, result.size());
      verify(mockTaxCategoryBindMapper, never())
          .selectByExample(any(TaxCategoryBindPOExample.class));
    }

    @Test
    public void testQueryByIds_EmptyIds() {
      List<TaxCategoryBindMetaDO> result =
          taxCategoryBindRepositoryImplUnderTest.queryByIds(Collections.<Long>emptyList());
      assertEquals(0, result.size());
      verify(mockTaxCategoryBindMapper, never())
          .selectByExample(any(TaxCategoryBindPOExample.class));
    }

    @Test
    public void testQueryByIds_Normal() {
      TaxCategoryBindPO po = new TaxCategoryBindPO();
      po.setId(1L);
      when(mockTaxCategoryBindMapper.selectByExample(any(TaxCategoryBindPOExample.class)))
          .thenReturn(Arrays.asList(po));

      List<TaxCategoryBindMetaDO> result =
          taxCategoryBindRepositoryImplUnderTest.queryByIds(Arrays.asList(1L, 2L));

      assertEquals(1, result.size());
      assertNotNull(result.get(0));
      verify(mockTaxCategoryBindMapper).selectByExample(any(TaxCategoryBindPOExample.class));
    }

    @Test
    public void testQueryByIds_MapperReturnsEmpty() {
      when(mockTaxCategoryBindMapper.selectByExample(any(TaxCategoryBindPOExample.class)))
          .thenReturn(Collections.<TaxCategoryBindPO>emptyList());

      List<TaxCategoryBindMetaDO> result =
          taxCategoryBindRepositoryImplUnderTest.queryByIds(Arrays.asList(3L));

      assertEquals(Collections.emptyList(), result);
      verify(mockTaxCategoryBindMapper).selectByExample(any(TaxCategoryBindPOExample.class));
    }
  }
}
