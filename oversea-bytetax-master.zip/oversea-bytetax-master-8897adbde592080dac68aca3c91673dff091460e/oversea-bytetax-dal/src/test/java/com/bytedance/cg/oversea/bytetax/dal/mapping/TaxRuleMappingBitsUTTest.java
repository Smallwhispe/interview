package com.bytedance.cg.oversea.bytetax.dal.mapping;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class TaxRuleMappingBitsUTTest {
  public static class ConvertMethodToIsReverseChargeTest {

    @Test
    public void testToIsReverseCharge_Null() {
      // Run the test
      final Integer result = TaxRuleMapping.ConvertMethod.toIsReverseCharge(null);

      // Verify the results
      assertEquals(Integer.valueOf(0), result);
    }

    @Test
    public void testToIsReverseCharge_True() {
      // Run the test
      final Integer result = TaxRuleMapping.ConvertMethod.toIsReverseCharge(true);

      // Verify the results
      assertEquals(Integer.valueOf(1), result);
    }

    @Test
    public void testToIsReverseCharge_False() {
      // Run the test
      final Integer result = TaxRuleMapping.ConvertMethod.toIsReverseCharge(false);

      // Verify the results
      assertEquals(Integer.valueOf(0), result);
    }
  }
}
