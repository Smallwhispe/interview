include "../base.thrift"
namespace java com.bytedance.remote.thrift.bi

enum ActorType {
    I18N_AD = 13;
    I18N_AGENT = 29;
    I18N_BC = 43;
    TCM = 58;
    BUSINESS_ACCOUNT = 74;
    MMM_CRM_ACCOUNT = 1001;
    VERIFICATION_IDENTITY = 1002;
}

enum PropertyType {
    CORE_INFO = 0;
    POI = 1;
    TAX_INFO = 2;
}

enum ItemType {
    TEXT = 1;
    IMAGE = 2;
}

struct ReviewItem {
    1: string Key,
    2: string Value,
    3: ItemType Type // text, image
}

enum ReviewStatus {
    UNDER_REVIEW = 0;
    PASS = 1;
    REJECTED = 2;
}

enum ObjectType {
    PASSTHROUGH_INFO = -1; ##this one is only for passthrough in callbacks
    SUBJECT_QUALIFICATION = 0;
    OTHER_QUALIFICATION = 1;
    POI_INFO = 2;
    TAX_INFO = 3;
}

struct PropertyReviewObject {
    1: i64 ID,
    2: list<ReviewItem> Details,
    3: ReviewStatus reviewStatus,
    4: list<string> rejectReasons,
    5: ObjectType objectType,
    6: string reviewComment,
}

enum AccountType {
    SELF_SERVE = 1;
    NON_SELF_SERVE = 2;
}

struct ActorBaseInfo {
    1: string address,
    2: string zipcode,
    3: string website,
    4: string industry,
    5: string contactFirstName,
    6: string contactLastName,
    7: string email,
    8: string phone,
    10: i64 accountID,
    11: i32 accountType
}

struct ActorPropertyReview {
    1: i64 ActorID,
    2: ActorType actorType,
    3: PropertyType propertyType,
    4: list<PropertyReviewObject> ReviewObjects,
    5: string region,
    6: string lang,
    7: AccountType accountType
    8: string name,
    9: ActorBaseInfo baseInfo,
}

struct SubmitActorPropertyReviewReq {
    1: ActorPropertyReview review,
    2: i64 submitTimestamp,
    255: base.Base Base
}

struct SubmitActorPropertyReviewResp {
    1: string taskID,
    255: base.BaseResp BaseResp
}


service ActorReviewGateway {
    SubmitActorPropertyReviewResp SubmitActorPropertyReview(1: SubmitActorPropertyReviewReq req);
}