include "../base.thrift"

namespace java com.bytedance.cg.thrift.be

enum SourceType {                      # （业务系统类型）
    GCRM = 1,    // GCRM 业务
    PROMOTE = 2, // promote 业务
    TCM = 3,     // tcm 业务
    CF = 4,      // cf 业务
}

// 客户主体数据模型
struct TBeCustomerEntity {
    1: required i64 billingEntityId;              // 交易实体ID
    2: required string billingEntityName;         // 交易实体名称
    3: required i16 type;                         // 实体类型：开票主体、签约主体、交易主体 --废弃
    4: required i16 status;                       // 实体状态  TStatusEnum
    5: required i16 sourceType;                   // 实体来源：GCRM、TCM、Promote等
    6: required i64 businessEntityId;             // 业务实体ID
    7: required string businessEntityName;        // 业务实体名称
    8: optional i16 endType;                      // 实体属于个人、还是广告主（B端、C端）0：to B，1： to C  -1 ：未知
    9: optional string bizType;                   // -
    10: optional i32 countryId;                   // 账单地址：国家id 默认值0
    11: optional i32 stateId;                     // 账单地址：省份id 默认值0
    12: optional i32 cityId;                      // 账单地址：城市id 默认值0
    13: optional string detailAddress;            // 详细地址q
    15: optional string postcode;                 // 邮编
    16: optional string contactName;              // 联系人名称
    17: optional string contactPhone;             // 联系电话
    18: optional string contactEmail;             // 联系邮箱
    19: optional string receiveInvoiceEmail;      // 发票接收邮箱地址
    20: optional i64 salesId;                     // 客户销售id
    21: optional i64 salesDepartmentId;           // 客户销售部门id
    22: optional list<TBeTax> taxIdInfo;          // 税号信息 暂时不提供，以BP信息为准
    23: optional string ext;                      // 扩展信息
    // 兼容个性化属性   marketAddress、registerAddress、ssBusinessLine、Coworker、isSelfService、recordType、cusType、companyId、segment、externalAccountId、externalSource、qualifications
    24: optional map<string,string> extData;
    25: optional list<i32> supportTransactions;   // 支持的业务类型 TSupportTransaction  0：所有，1：bill to,2:合同,3:订单，4：对账单，5：税单，6：返点，7：保证金，8：发票，9：回款，10：认款，11：资金
    26: optional string salesName;                // 客户销售名称
    27: optional string salesDepartmentName;      // 客户销售部门名称
    28: optional i64 businessCreateTime;          // 业务主体在数据源端创建时间
}

struct TBeTax {
    1: required string taxIdCode;         // 税号名称，如：VAT、inn、kpp
    2: required string taxIdValue;        // 税号，如：37889984、5765675
}

struct QueryByBusinessIdReq {
    # 业务实体ID
    1: required i64 businessEntityId;
    # 实体来源：GCRM、TCM、Promote等
    2: required SourceType sourceType;
    # 是否接受降级数据：0：否，1：是
    3: optional i32 acceptFallBack;
    #是否查询写库，默认走读库(延时100ms以内)，当创建即刻查询时可走写库，但是必须和数据源方 RDs沟通，确保qps！
    4: optional bool forceMaster,
    255: required base.Base base;
}

struct BatchQueryByBusinessIdReq {
    # 业务实体ID list  批量查询统一限制 size 200
    1: required list<i64> businessEntityIds;
    # 实体来源：GCRM、TCM、Promote等
    2: required SourceType sourceType;
    # 是否接受降级数据：0：否，1：是
    3: optional i32 acceptFallBack;
    255: required base.Base base;
}

struct QueryCustomerEntityResp {
    # 客户主体信息
    1: optional TBeCustomerEntity customerEntity;
    # 是否是降级数据 0：否 ，1 ： 是
    2: optional i32 isFallBack;
    255: required base.BaseResp baseResp;
}

struct BatchQueryCustomerEntityResp {
    # 客户主体信息
    1: optional list<TBeCustomerEntity> customerEntities;
    # 是否是降级数据 0：否 ，1 ： 是
    2: optional i32 isFallBack;
    255: required base.BaseResp baseResp;
}

struct CommonSearchEntityReq {
    # 搜索关键字
    1: optional string keyword;
    # 操作人员
    2: optional i64 operatorId;
    # 实体来源：GCRM、TCM、Promote等
    3: required SourceType sourceType;
    # 分页参数，默认值：1
    4: optional i32 pageIndex;
    # 分页参数，默认值：20，最大值：200
    5: optional i32 pageSize;
    #自助类型 -1:仅查询非自助数据 0:查询全部数据 1:仅查询自助数据
    6: optional i32 isSelfService,
    # 是否接受降级数据：0：否，1：是
    7: optional i32 acceptFallBack;
    # 业务实体ID list  批量查询统一限制 size 200
    8: optional list<i64> businessEntityIds,
    #客户状态，1:未审批，2:审批中 3:审批通过 4:审批拒绝
    9: optional list<i32> statusList,
    #CRM客户业务类型，1:ADVERTISER,2:AGENCY,3:PARTNER,4:CREATOR
    10: optional list<i32> recordTypeList,
    #CRM客户ownerId
    11: optional list<i64> saleIds,
    #CRM客户owner所属的departmentId
    12: optional list<i64> saleDempartmentIds,
    #公司id,ocrm迁移数据为segma id,grep account为accountId
    13: optional list<i64> companyIds,
    #是否需要基于crm权限进行过滤(配合crmBase#employeeId) 默认false:不过滤权限,true:过滤权限,权限逻辑参考:https://bytedance.feishu.cn/docs/doccnz4ZgcEULm50My3fDETcmJe
    14: optional bool needAuth,
    #客户主体类型 1:个人, 2:公司, 3:品牌
    15: optional list<i32> subjectType,
    #客户主体注册地国家code
    16: optional string registeredCountryCode, //注册国家code
    #是否需要进行精确匹配，默认false(配合name参数使用)
    17: optional bool needNameExactMatch,
    #行业IDs,支持多级行业查询
    18: optional list<string> industryIds,
    #多个名称进行查询，使用精确匹配
    19: optional list<string> exactNames,
    #返回值增加销售部门链 仅数据源为CRM有效
    20: optional bool needSaleDeps,
    255: required base.Base base;
}

//BE v2 新增
struct CommonSearchEntityResp {
    # 客户主体列表
    1: optional list<TBeCustomerEntity> customerEntities;
    # 总数量
    2: optional i64 total;
    # 是否是降级数据 0：否 ，1 ： 是
    3: optional i32 isFallBack;
    255: required base.BaseResp baseResp;
}

service BillingEntityService {

    # 通过业务实体Id和来源类型查询客户实体 CRM对标 cg.crm_overseas.thrift_read.QueryAccountById
    QueryCustomerEntityResp queryCustomerEntityByBusinessEntityId(1: QueryByBusinessIdReq req);

    # 批量查询，通过业务实体Id list 查询客户实体 底层CRM代理 cg.crm_overseas.thrift_read.QueryAccountByCondition 接口，基于ES有秒级延迟，不适合创建完马上查询
    BatchQueryCustomerEntityResp batchQueryCustomerEntityByBusinessEntityId(1: BatchQueryByBusinessIdReq req);

    # Billing Entity V2 新增接口  PS：目前CRM不支持多个查询联系人，批量接口不支持联系信息获取
    # 名称模糊搜索客户主体 CRM支持isSelfService 筛选 ，底层代理 cg.crm_overseas.thrift_read.QueryAccountByCondition 接口,
    CommonSearchEntityResp commonSearchEntity(1: CommonSearchEntityReq req);
}
