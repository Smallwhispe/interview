include "base.thrift"

namespace java com.bytedance.remote.thrift.basic
namespace py common_basic_platform
namespace go common_basic_platform

enum LanguageType {
    ZH, // 中文
    EN, // 英文
    JA,  // 日文
    KO,
    FR,
    DE,
    RU,
    IT,
    ES,
    TR,
    TH,
    VI,
    ID,
    MS,
    AR
}

struct CityInfo {
    1: i64 id,
    2: i64 p_id,
    3: i16 level,
    4: string name,
    5: string iso_code,
    6: string iso_3code,
    7: string en,
    8: string code,
    9: string i18n_str_code
    10: i64 geo_id
}




struct CityQueryByLevelReq {
    1: i64 pid,
    2: i16 level,
    3: LanguageType language,

    255: required base.Base Base,
}

struct CityQueryByCodeReq {
    1: string code,
    2: LanguageType language,

    255: required base.Base Base,
}

struct CityQueryByIdReq {
    1: i64 id,
    2: LanguageType language,

    255: required base.Base Base,
}

struct CityQueryByGeoIdReq {
    1: i64 geoId,
    2: LanguageType language,

    255: required base.Base Base,
}

struct CountryQueryByIsoCodeReq {
    1: string isoCode,
    2: i16 isoType,
    3: LanguageType language,

    255: required base.Base Base,
}

struct CityQueryAllReq {
    1: i16 level,
    #国际化语言'ZH','EN'等
    2: LanguageType language,

    255: required base.Base Base,
}

struct CityQueryNameReq {
    1: string name,
    2: optional i16 level,
    #国际化语言'ZH','EN'等
    3: LanguageType language,

    255: required base.Base Base,
}

struct CityListResp {
    1: list<CityInfo> data
    255: base.BaseResp BaseResp,
}

struct CityResp {
    1: CityInfo data
    255: base.BaseResp BaseResp,
}

struct AppTicketListReq {
    1: required list<string> appIdList,
    255: required base.Base Base
}
struct AppTicketInfo{
   1: optional string appId
   2: optional string appTicket
}
struct AppTicketListResp {
    1: optional list<AppTicketInfo> appTickets
    255: base.BaseResp BaseResp,
}

struct IndustryInfo {
    ## 行业id
    1: required i64 industryId,
    ## 行业版本, 1=1.0, 3=3.0, 4=3.1
    2: required i32 version,
    ## 行业级别, 一级行业=1, 二级行业=2
    3: required i32 level,
    ## 行业名
    4: optional string name
    ## 当industryId是二级行业时对应的一级行业
    5: optional i64 parentIndustryId
    ## name的i18ncdoe
    6: optional string nameI18nCode
    ## desc的i18ncdoe
    7: optional string descI18nCode
}

struct IndustryMappingInfo {
    ## 原行业id
    1: required i64 fromIndustryId,
    ## 新行业id
    2: required i64 toIndustryId,
    ## 行业映射类型
    3: required i32 type,
    ## 新行业parentId
    4: optional i64 toParentIndustryId,
}

struct IndustryQueryReq {
    ## 行业级别,1=一级行业，2=二级行业
    1: optional list<i32> level,
    ## 行业版本,1=1.0, 3=3.0, 4=3.1
    2: optional list<i32> version,
    ## 语言
    3: required LanguageType lang
    255: base.Base Base
}


struct IndustryListResp {
    1: optional list<IndustryInfo> items
    255: base.BaseResp BaseResp,
}

struct AgencyIndustryQueryReq {
    ## 语言
    1: required LanguageType lang
    255: base.Base Base
}


struct IndustryTransferReq {
    ## 行业ids
    1: required list<i64> industryIds,
    ## 原行业版本,1=1.0, 3=3.0, 4=3.1
    2: optional i32 fromVersion,
    ## 新行业版本,1=1.0, 3=3.0, 4=3.1
    3: optional i32 toVersion,
    255: base.Base Base
}


struct IndustryTransferResp {
    1: optional map<i64, IndustryInfo> items
    255: base.BaseResp BaseResp,
}



struct IndustryMappingReq {
    ## 类型
    1: optional list<i32> types,
    255: base.Base Base
}

struct IndustryMappingResp {
    1: optional list<IndustryMappingInfo> items
    255: base.BaseResp BaseResp,
}

struct CityQueryByIdsReq {
    1: list<i64> id,
    2: LanguageType language,

    255: required base.Base Base,
}

service CommonBasicService {

    #根据id查询city
    CityResp queryCityById(1: CityQueryByIdReq req);

    #根据geoid查询city
    CityResp queryCityByGeoId(1: CityQueryByGeoIdReq req);

    #根据code查询country
    CityResp queryCityByCode(1: CityQueryByCodeReq req);

    #根据id查询city
    CityResp queryCountryByIsoCode(1: CountryQueryByIsoCodeReq req);

    #查询城市信息
    CityListResp queryCityByLevelAndPid(1: CityQueryByLevelReq req);

    #查询所有城市信息
    CityListResp allCity(1: CityQueryAllReq req);

    #查询所有城市信息
    CityListResp queryCityByName(1: CityQueryNameReq req);

    #根据appid批量查询appTicket
    AppTicketListResp appTicketList(1:AppTicketListReq req)

    #查询行业信息
    IndustryListResp queryIndustryInfo(1: IndustryQueryReq req);

    #查询代理商行业信息
    IndustryListResp queryAgencyIndustryInfo(1: AgencyIndustryQueryReq req);

    #行业版本转换
    IndustryTransferResp queryIndustryTransferInfo(1: IndustryTransferReq req);

    #行业版本映射关系
    IndustryMappingResp queryIndustryMappingInfo(1: IndustryMappingReq req);

    #根据id查询city
    CityListResp queryCityByIds(1: CityQueryByIdsReq req);
}