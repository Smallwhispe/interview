package com.bytedance.cg.oversea.bytetax.manager.http.impl;

import com.bytedance.cg.common.exception.BaseException;
import com.bytedance.cg.common.util.OkHttpUtil;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.utils.DateUtil;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.district.District;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.district.RegionProfileResp;
import com.bytedance.cg.oversea.bytetax.manager.http.LocationPlatformHttpService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class LocationPlatformHttpServiceImpl implements LocationPlatformHttpService {

    @Resource
    private LocationPlatformHttpService locationPlatformHttpService;

    @Value("${location.baseUrl}")
    private String baseUrl;

    @Value("${location.key}")
    private String key;

    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    @Cacheable(value = ConstantValue.GUAVA_24H_CACHE, unless = "#result == null")
    public Integer computeTimezoneOffsetByDistrictCode(String geoId) {
        District aimDistrict = queryDistrictRegions(geoId);
        if (aimDistrict == null || aimDistrict.getProperties() == null || aimDistrict.getProperties().getTimezone_offset() == null) {
            return null;
        }
        return NumberUtils.toInt(aimDistrict.getProperties().getTimezone_offset());
    }

    @Override
    public Date localDate2UTC0ByGeoId(String geoId, Date date) {
        Integer timeOffset = locationPlatformHttpService.computeTimezoneOffsetByDistrictCode(geoId);
        return DateUtil.dateLocal2UTC0(date, timeOffset);
    }

    public District queryDistrictRegions(String geoId) {
        String path = baseUrl + "/bytemap/v1/config/region_profile";
        Map<String, String> headers = new HashMap<>();
        Map<String, String> params = new HashMap<>();
        headers.put("Content-Type", "application/json");
        params.put("key", key);
        params.put("geonameid", geoId);
        try {
            RegionProfileResp parseResp = OkHttpUtil.get(path, params, RegionProfileResp.class, headers);
            if (parseResp == null) {
                return null;
            }
            return parseResp.getDistrict();
        } catch (Exception e) {
            throw new BaseException("query district regions error.", e);
        }
    }
}
