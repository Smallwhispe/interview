package com.bytedance.cg.oversea.bytetax.manager.mapping;

import com.alibaba.fastjson.JSONObject;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.utils.StringUtil;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.customer.CustomerInfoDTO;
import com.bytedance.cg.thrift.be.TBeCustomerEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author
 * @date 2021/6/1
 **/
@Mapper
public interface CustomerInfoMapping {

    CustomerInfoMapping MAPPING = Mappers.getMapper(CustomerInfoMapping.class);

    @Mapping(target = "accountId", source = "businessEntityId")
    @Mapping(target = "accountName", source = "businessEntityName")
    @Mapping(target = "address", source = "detailAddress")
    @Mapping(target = "countryId", expression = "java(getCountryId(beCustomerEntity))")
    @Mapping(target = "taxNo", expression = "java(getOnlyTaxNo(beCustomerEntity))")
    CustomerInfoDTO toCustomerInfo(TBeCustomerEntity beCustomerEntity);

    List<CustomerInfoDTO> toCustomerInfoList(List<TBeCustomerEntity> beCustomerEntities);

    default String getOnlyTaxNo(TBeCustomerEntity beCustomerEntity) {
        return Optional.ofNullable(beCustomerEntity.getTaxIdInfo()).orElse(Collections.emptyList()).stream().map(e -> e.getTaxIdValue()).findFirst().orElse("");
    }

    default Long getCountryId(TBeCustomerEntity beCustomerEntity) {
        Map<String, String> ext =  beCustomerEntity.getExtData();
        String address = ext.get("registerAddress");
        if (StringUtil.isNotEmpty(address)) {
            Long country = JSONObject.parseObject(address).getLong("countryCode");
            return country;
        }
        return ConstantValue.ZERO_LONG;
    }

}
