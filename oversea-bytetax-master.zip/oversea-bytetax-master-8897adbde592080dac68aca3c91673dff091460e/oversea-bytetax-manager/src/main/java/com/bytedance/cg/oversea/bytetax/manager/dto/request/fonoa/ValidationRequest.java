package com.bytedance.cg.oversea.bytetax.manager.dto.request.fonoa;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.compress.utils.Lists;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class ValidationRequest {

    @JsonProperty(value = "country_iso")
    private String countryIso;

    private String tin;

    /**
     * "individual" "business"
     */
    @JsonProperty(value = "tin_type")
    private String tinType;

    @JsonProperty(value = "check_tin_online")
    private Boolean checkTinOnline;

    @JsonProperty(value = "cache_age_seconds")
    private Integer cacheAgeSeconds;

    /**
     * "vies" "local"
     */
    @JsonProperty(value = "validation_source")
    private String validationSource;

    @JsonProperty(value = "external_id")
    private String externalId;

    @JsonProperty(value = "additional_parameters")
    private List<NameValueDTO> additionalParameters;

    public void addAdditionalParameter(String name, String value) {
        if (value == null) {
            return;
        }
        if (additionalParameters == null) {
            additionalParameters = Lists.newArrayList();
        }
        additionalParameters.add(NameValueDTO.builder().name(name).value(value).build());
    }

//    以下字段暂不解析
//    @JsonProperty(value = "fuzzy_matching")
//    private String fuzzyMatching;

}

