package com.bytedance.cg.oversea.bytetax.manager.thrift;


import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CityInfoDTO;

import java.util.List;
import java.util.Map;

public interface CommonBasicThriftService {

    String queryCountryNameByGeoId(Long geoId);

    Long queryGeoIdByCityId(int cityId);

    Map<Long, CityInfoDTO> queryCityInfoByCityIds(List<Long> cityIds);

}
