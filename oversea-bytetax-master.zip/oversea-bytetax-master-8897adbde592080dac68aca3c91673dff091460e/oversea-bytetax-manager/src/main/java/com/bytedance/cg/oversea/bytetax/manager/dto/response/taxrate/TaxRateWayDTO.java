package com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxationParty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaxRateWayDTO {

    private Long id;

    private String acceptorCountry;

    private Long subjectId;

    private EnumTaxationParty type;

    private Integer operatorId;

    private EnumDeleteStatus isDelete;
}
