package com.bytedance.cg.oversea.bytetax.manager.dto.response.location;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author hanyuxiao
 * @date 2023/8/28
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CountryDescriptionDTO {

    private Long geoId;

    private String level1Name;

    private String level2Name;

    private String level3Name;
}
