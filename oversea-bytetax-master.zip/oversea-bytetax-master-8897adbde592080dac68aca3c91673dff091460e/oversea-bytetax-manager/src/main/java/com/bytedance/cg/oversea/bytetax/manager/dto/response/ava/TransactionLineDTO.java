package com.bytedance.cg.oversea.bytetax.manager.dto.response.ava;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Auther yangyl
 * @Date 2022/8/12
 **/
@Data
public class TransactionLineDTO {
    private BigDecimal lineAmount;

    private BigDecimal tax;

    private BigDecimal taxableAmount;

    private String taxCode;

    private String itemCode;

    private BigDecimal quantity;

    private String lineNumber;

    private String ref;

    private List<LineDetailDTO> details;

}
