package com.bytedance.cg.oversea.bytetax.manager.mapping;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.subject.SubjectInfoDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author hanyuxiao
 * @date 2022/1/17
 **/
@Mapper
public interface SubjectDTOMapping {

    SubjectDTOMapping MAPPING = Mappers.getMapper(SubjectDTOMapping.class);

//    @Mapping(target = "subjectId", source = "subject_id")
//    @Mapping(target = "subjectName", source = "subject_name")
//    SubjectInfoDTO toSubjectInfoDTO(com.bytedance.cg.thrift.signups.SubjectInfo subjectInfo);

    @Mapping(target = "taxRegistrationNumber", source = "tax")
    @Mapping(target = "subjectId", source = "subject_id")
    @Mapping(target = "subjectName", source = "subject_name")
    SubjectInfoDTO toSubjectInfoDTO(com.bytedance.cg.thrift.legal.entity.SubjectInfo subjectInfo);
}
