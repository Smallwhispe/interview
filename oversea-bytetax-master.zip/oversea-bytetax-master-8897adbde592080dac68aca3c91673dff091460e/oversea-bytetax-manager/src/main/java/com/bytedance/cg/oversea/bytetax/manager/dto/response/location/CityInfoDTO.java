package com.bytedance.cg.oversea.bytetax.manager.dto.response.location;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author: yangyl
 * @Date: 2021/4/16 12:25 下午
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CityInfoDTO {

    private Long id;
    private String name;
    private String code;
    private Long geoId;
    private String isoCode;
    private Integer level;
    private String description;

    private List<CityInfoDTO> subRegion;
}
