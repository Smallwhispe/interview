package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.oversea.bytetax.manager.dto.request.bi.BIValidationReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.bi.BICheckRspDTO;

/**
 * @author hanyuxiao
 * @date 2023/7/10
 **/
public interface BIThriftService {

    BICheckRspDTO taxNoValidation(BIValidationReqDTO reqDTO);
}
