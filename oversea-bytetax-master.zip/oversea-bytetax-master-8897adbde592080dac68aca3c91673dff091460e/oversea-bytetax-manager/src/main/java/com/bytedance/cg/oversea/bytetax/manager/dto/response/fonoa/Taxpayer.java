package com.bytedance.cg.oversea.bytetax.manager.dto.response.fonoa;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Taxpayer {

    @JsonProperty(value = "registration_type")
    private String registrationType;

    @JsonProperty(value = "entity_type")
    private String entityType;

    @JsonProperty(value = "registration_date")
    private String registrationDate;

    @JsonProperty(value = "deregistration_date")
    private String deregistrationDate;

    private String address;
}
