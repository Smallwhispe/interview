package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.subject.SubjectInfoDTO;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/17
 **/
public interface SubjectThriftService {
    /**
     * 根据主体ID查主体信息
     * @param subjectId
     * @return
     */
    SubjectInfoDTO querySubjectInfo(Long subjectId);

    List<SubjectInfoDTO> querySubjectInfoList(List<Long> subjectIds, boolean needCountryDetail);

    List<SubjectInfoDTO> querySubjectInfo(String name);
}
