package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.contract.ContractInfoDTO;

import java.util.List;

public interface MasterSpiderThriftService {

    List<ContractInfoDTO> batchQueryContractByAccountId(Long accountId);
    List<ContractInfoDTO> batchQueryContractByAccountIdValid(Long accountId);

    ContractInfoDTO queryContractInfo(Long contractId);
}
