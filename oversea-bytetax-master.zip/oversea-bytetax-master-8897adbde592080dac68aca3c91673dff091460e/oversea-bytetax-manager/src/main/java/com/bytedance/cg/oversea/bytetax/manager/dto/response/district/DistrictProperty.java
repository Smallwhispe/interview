package com.bytedance.cg.oversea.bytetax.manager.dto.response.district;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DistrictProperty {

    private String time_zone;

    private String timezone_offset;
}
