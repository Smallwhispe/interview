package com.bytedance.cg.oversea.bytetax.manager.dto.response.subject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author hanyuxiao
 * @date 2022/1/17
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubjectInfoDTO {

    private Long subjectId;

    private String subjectName;

    private Long countryId;

    private String countryName;

    private String address;

    private String businessId;

    private String taxRegistrationNumber;
}
