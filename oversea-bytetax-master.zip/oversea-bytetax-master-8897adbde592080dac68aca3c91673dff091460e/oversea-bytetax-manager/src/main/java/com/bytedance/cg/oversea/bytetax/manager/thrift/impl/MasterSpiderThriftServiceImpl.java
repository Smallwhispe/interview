package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.contract.ContractInfoDTO;
import com.bytedance.cg.oversea.bytetax.manager.thrift.MasterSpiderThriftService;
import com.bytedance.cg.oversea.master.data.spider.thrift.enums.CommonStatusEnum;
import com.bytedance.cg.thrift.master.*;
import com.bytedance.thrift.base.BaseResp;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
@Profile({"prod-sg","prod-va", "prod-ttp", "prod-gcp","boe-va", "dev", "boe-prod"})
public class MasterSpiderThriftServiceImpl implements MasterSpiderThriftService {


    @Resource
    private SpiderService.Client client;

    @Override
    public List<ContractInfoDTO> batchQueryContractByAccountId(Long accountId) {
        List<SpiderBO> spiderBOS = querySpiderBOList(accountId);
        return toContractInfoDTO(spiderBOS);
    }

    @Override
    public List<ContractInfoDTO> batchQueryContractByAccountIdValid(Long accountId) {
        List<SpiderBO> spiderBOS = querySpiderBOList(accountId);
        // 过滤当前生效的合同
        spiderBOS = spiderBOS.stream().filter(spiderBO -> spiderBO.getSpiderBase().getStatus() == CommonStatusEnum.VALID.getValue() && new Date().getTime() <= spiderBO.getContractInfo().getEndDate()).collect(Collectors.toList());
        return toContractInfoDTO(spiderBOS);
    }

    private List<SpiderBO> querySpiderBOList(Long accountId) {
        BatchQuerySpiderRequest request = new BatchQuerySpiderRequest();
        request.setAccountIdList(Collections.singletonList(accountId));
        request.setModuleList(Lists.newArrayList(ModuleEnum.SPIDER_BASE.getValue(),ModuleEnum.ACCOUNT_MASTER_DATA.getValue(), ModuleEnum.SPIDER_CONTRACT_INFO.getValue(), ModuleEnum.ADDRESS.getValue()));
        request.setNeedSerial(true);
        ThriftInvoker<BatchQuerySpiderRequest, BatchQuerySpiderResponse> thriftInvoker = new ThriftInvoker<>();
        BatchQuerySpiderResponse querySpiderResponse = thriftInvoker.request(request, req -> client.batchQuerySpiderBySpiderIdList(req));
        check(querySpiderResponse.getBaseResp());
        return querySpiderResponse.getSpiderBOList();
    }

    @Override
    public ContractInfoDTO queryContractInfo(Long contractId) {
        BatchQuerySpiderRequest request = new BatchQuerySpiderRequest();
        request.setContractIdList(Collections.singletonList(contractId));
        request.setModuleList(Lists.newArrayList(ModuleEnum.SPIDER_BASE.getValue(),ModuleEnum.ACCOUNT_MASTER_DATA.getValue(), ModuleEnum.SPIDER_CONTRACT_INFO.getValue()));
        request.setNeedSerial(true);
        ThriftInvoker<BatchQuerySpiderRequest, BatchQuerySpiderResponse> thriftInvoker = new ThriftInvoker<>();
        BatchQuerySpiderResponse querySpiderResponse = thriftInvoker.request(request, req -> client.batchQuerySpiderBySpiderIdList(req));
        check(querySpiderResponse.getBaseResp());
        if (querySpiderResponse.getSpiderBOList().isEmpty()) {
            return null;
        }
        return toContractInfoDTO(querySpiderResponse.getSpiderBOList()).get(0);
    }


    private List<ContractInfoDTO> toContractInfoDTO(List<SpiderBO> spiderBOList) {
        return spiderBOList.stream().map(spiderBO -> {
            ContractInfoDTO dto = new ContractInfoDTO();
            dto.setContractId(spiderBO.getContractInfo().getContractId());
            dto.setContractSerial(spiderBO.getContractInfo().getSerial());
            dto.setSubjectId(spiderBO.getSpiderBase().getSubjectId());
            dto.setAccountIdList(spiderBO.getAccountMasterDataList().stream().map(AccountMasterData::getAccountId).collect(Collectors.toList()));
            Optional.ofNullable(spiderBO)
                    .map(SpiderBO::getAccountMasterDataList)
                    .filter(list -> !list.isEmpty())
                    .map(list -> list.get(0))
                    .map(AccountMasterData::getAddressList)
                    .filter(list -> !list.isEmpty())
                    .map(list -> list.get(0))
                    .map(Address::getLevel1AddressId).ifPresent(level1AddressId -> dto.setBillingAddressId(Long.valueOf(level1AddressId)));
            return dto;
        }).collect(Collectors.toList());
    }


    private void check(BaseResp resp) {
        if (resp.StatusCode != 0) {
            throw new RuntimeException(resp.StatusMessage);
        }
    }
}
