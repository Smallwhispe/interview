package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.currency.CurrencyDTO;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
public interface CurrencyThriftService {

    List<CurrencyDTO> getAllCurrency();

    CurrencyDTO getCurrencyByCurrencyCode(String code);

    Map<String, CurrencyDTO> getCurrencyByCurrencyCodes(List<String> codes);

    BigDecimal queryExchangeRate(String sourceCurrency, String targetCurrency, Long sourceId);
}
