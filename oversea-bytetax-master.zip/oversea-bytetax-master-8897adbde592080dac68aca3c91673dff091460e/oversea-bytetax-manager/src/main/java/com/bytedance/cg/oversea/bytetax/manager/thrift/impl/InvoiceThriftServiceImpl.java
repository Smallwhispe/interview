package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.oversea.bytetax.common.utils.PageQueryUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.invoice.InvoiceDTO;
import com.bytedance.cg.oversea.bytetax.manager.thrift.InvoiceThriftService;
import com.bytedance.cg.thrift.note.gateway.*;
import com.bytedance.thrift.base.BaseResp;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.joda.time.DateTime;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * bytedance
 * 2022/11/24 8:43 下午
 */
@Service
@Slf4j
@Profile({"prod-sg","prod-va",  "boe-va", "dev", "boe-prod"})
public class InvoiceThriftServiceImpl implements InvoiceThriftService {

    @Resource
    private NoteGateWayService.Client client;

    private static final Integer LIMIT = 200;

    private static final String IDC = "sg1";

    @Override
    public List<InvoiceDTO> queryInvoiceByStatusAndTime(List<Integer> status, DateTime sendStartDate, DateTime sendEndDate){
        return PageQueryUtil.queryByPage(afterId -> queryInvoiceByStatusAndTime(status, sendStartDate, sendEndDate, afterId), InvoiceDTO::getId, LIMIT);

    }

    @Override
    public List<InvoiceDTO> queryInvoiceByStatusAndTime(List<Integer> status, DateTime sendStartDate, DateTime sendEndDate, Long afterId) {
        TGwNoteListQueryWithCursorReq req = new TGwNoteListQueryWithCursorReq();
        if(CollectionUtils.isNotEmpty(status)) {
            req.setStatuses(status);
        }
        if(sendStartDate != null) {
            // 这里是秒
            req.setSendStartDate(sendStartDate.getMillis()/1000);
        }
        if(sendEndDate != null) {
            req.setSendEndDate(sendEndDate.getMillis()/1000);
        }
        req.setAfterId(afterId);
        // 1 为发票
        req.setNoteCategory(1);
        req.setLimit(LIMIT);
        // 设置为sg1机房
        req.setIdc(IDC);
        // 只需要serial
//        req.setResultFields(Lists.newArrayList("NoteSerial"));

        ThriftInvoker<TGwNoteListQueryWithCursorReq, TGwNoteListQueryWithCursorResp> thriftInvoker = new ThriftInvoker<>();
        TGwNoteListQueryWithCursorResp resp = thriftInvoker.request(req, re -> client.NoteListQueryWithCursor(re));
        check(resp.getBaseResp());
        if (CollectionUtils.isEmpty(resp.getList())) {
            return Lists.newArrayList();
        }
        return resp.getList().stream().map(this::tGwNoteInfoToInvoiceDTO).collect(Collectors.toList());
    }

    @Override
    public void informLackInvoice(Set<String> serials) {
        InformBytetaxReq informBytetaxReq = new InformBytetaxReq();
        serials.stream().filter(Objects::nonNull).forEach(serial -> {
            informBytetaxReq.setSerial(serial);
            ThriftInvoker<InformBytetaxReq, InformBytetaxResp> thriftInvoker = new ThriftInvoker<>();
            InformBytetaxResp resp = thriftInvoker.request(informBytetaxReq, re -> client.InformBytetax(re));
            check(resp.getBaseResp());
        });
    }

    private InvoiceDTO tGwNoteInfoToInvoiceDTO(TGwNoteInfo tGwNoteInfo) {
        return InvoiceDTO.builder().id(tGwNoteInfo.getId()).serial(tGwNoteInfo.getSerial()).build();
    }

    private void check(BaseResp resp) {
        if (resp.StatusCode != 0) {
            throw new RuntimeException(resp.StatusMessage);
        }
    }
}
