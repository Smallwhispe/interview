package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.currency.CurrencyDTO;
import com.bytedance.cg.oversea.bytetax.manager.mapping.CurrencyDTOMapping;
import com.bytedance.cg.oversea.bytetax.manager.thrift.CurrencyThriftService;
import com.bytedance.cg.thrift.currency.CurrencyExchangeRateService;
import com.bytedance.cg.thrift.exchange.CommonCurrencyConvertReq;
import com.bytedance.cg.thrift.exchange.CommonCurrencyConvertRsp;
import com.bytedance.cg.thrift.exchange.OverseaCurrencyExchangeRateService;
import com.bytedance.cg.thrift.exchange.oversea_exchange_rateConstants;
import com.bytedance.cg.thrift.signups.CurrencyListReq;
import com.bytedance.cg.thrift.signups.CurrencyListResp;
import com.bytedance.cg.thrift.signups.OverseaContractService;
import com.bytedance.thrift.base.BaseResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
@Service
@Slf4j
//@Profile({"prod-sg","prod-va",  "boe-va", "dev", "boe-prod"})
public class CurrencyThriftServiceImpl implements CurrencyThriftService {

    @Resource
    private OverseaContractService.Client client;

    @Resource
    private CurrencyThriftServiceImpl currencyThriftService;

    @Resource
    private OverseaCurrencyExchangeRateService.Client exchangeRateClient;

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public List<CurrencyDTO> getAllCurrency() {
        CurrencyListReq req = new CurrencyListReq();
        ThriftInvoker<CurrencyListReq, CurrencyListResp> thriftInvoker = new ThriftInvoker<>();
        CurrencyListResp rsp = thriftInvoker.request(req, re -> client.query_currency_list(req));
        return rsp.getData().stream().map(CurrencyDTOMapping.MAPPING::toCurrencyDTO).collect(Collectors.toList());
    }

    @Override
    public CurrencyDTO getCurrencyByCurrencyCode(String code) {
        Map<String, CurrencyDTO> currenciesByCode = currencyThriftService.getAllCurrency()
                .stream().collect(Collectors.toMap(CurrencyDTO::getCode, Function.identity()));
        if (!currenciesByCode.containsKey(code)) {
            throw new BizException(I18nConstants.CANNOT_FIND_CODE + code);
        }
        return currenciesByCode.get(code);
    }

    @Override
    public Map<String, CurrencyDTO> getCurrencyByCurrencyCodes(List<String> codes){
        return currencyThriftService.getAllCurrency().stream()
                .filter(codes::contains).collect(Collectors.toMap(CurrencyDTO::getCode, Function.identity()));
    }

    @Override
    public BigDecimal queryExchangeRate(String sourceCurrency, String targetCurrency, Long sourceId) {
        if (sourceCurrency.equals(targetCurrency)) {
            return BigDecimal.ONE;
        }
        CommonCurrencyConvertReq req = new CommonCurrencyConvertReq();
        req.setSource_currency_code(sourceCurrency);
        req.setTarget_currency_code(targetCurrency);
        if (sourceId != null) {
            req.setSource_id(sourceId);
        } else {
            // 没有设置人工汇率来源取竞价汇率
            req.setSource_id(oversea_exchange_rateConstants.BIDDING_CURRENCY_EXCHANGE_RATE_SOURCE_ID);
            req.setIs_converter_result(false);
            req.setSource_amount("0.1");
        }
        req.setConvert_timestamp(System.currentTimeMillis() / 1000);
        ThriftInvoker<CommonCurrencyConvertReq, CommonCurrencyConvertRsp> thriftInvoker = new ThriftInvoker<>();
        CommonCurrencyConvertRsp response = thriftInvoker.request(req, re -> exchangeRateClient.common_query_currency_exchange_rate(req));
        check(response.getBaseResp());
        // 如果没有获取到汇率，返回为0，然后打标
        if(!response.acquire_exchange_rate) {
            return BigDecimal.ZERO;
        }
        return new BigDecimal(response.getExchange_rate());
    }

    protected void check (BaseResp resp) {
        if(resp.StatusCode != 0) {
            log.error("thrift bad answer" + resp.StatusMessage);
            CgMonitorMetricRecorder.exceptionOneMetrics("thrift_bad_answer", null, CgMetricsConstants.ServiceType.RPC);
            throw new BizException(I18nConstants.THRIFT_BAD_ANSWER + resp.StatusMessage);
        }
    }
}
