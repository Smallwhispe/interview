package com.bytedance.cg.oversea.bytetax.manager.http;

import java.util.Date;

/**
 * 地区中台接口
 */
public interface LocationPlatformHttpService {

    /**
     * 根据地区编码，计算该地区的时区偏移量，单位秒，如编码错误则返回null
     * @param geoId
     * @return
     */
    Integer computeTimezoneOffsetByDistrictCode(String geoId);

    Date localDate2UTC0ByGeoId(String geoId, Date date);
}
