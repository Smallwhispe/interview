package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CityInfoDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CountryDescriptionDTO;

import java.util.List;
import java.util.Map;

/**
 * @Author: yangyl
 * @Date: 2021/4/16 12:22 下午
 */
public interface LocationDistrictThriftService {

    /**
     * 根据国家CODE查询国家
     * @param codes
     * @return
     */
    List<CityInfoDTO> getCountryByCode(List<String> codes);

    /**
     * 根据单个城市GEO_ID查询城市信息
     * @param geoId
     * @return
     */
    CityInfoDTO getCityByGeoId(Long geoId);

    CityInfoDTO getCityByGeoId(Long geoId, String language);

    /**
     * 根据单个编码查询国家信息
     * @param countryCode
     * @return
     */
    CityInfoDTO getCountryByCode(String countryCode);

    /**
     * 根据单个编码查询国家信息 得到英文
     * @param countryCode
     * @return
     */
    CityInfoDTO getEnglishCountryByCode(String countryCode);

    CityInfoDTO getSubCityWithLevel(Long geoId, String language, Integer level);

    List<CityInfoDTO> getAllCountryInfos(String language);

    /**
     * 根据城市GEO_ID查询下一级城市信息
     * @param geoId
     * @return
     */
    List<CityInfoDTO> getSubCitiesByGeoId(Long geoId, String language);

    Map<Long, CityInfoDTO> getCityByGeoIds(List<Long> geoIds, String language);

    Map<Long, CountryDescriptionDTO> getAllDescriptionDTO();

    Map<Long, CountryDescriptionDTO> getDescriptionDTO(List<Long> geoIds);

}
