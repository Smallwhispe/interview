package com.bytedance.cg.oversea.bytetax.manager.http;

import com.bytedance.cg.oversea.bytetax.manager.dto.request.fonoa.ValidationRequest;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.fonoa.ValidationResponse;

public interface FonoaHttpService {

    ValidationResponse requestAValidationByClient(ValidationRequest validationRequest) throws Exception;

    ValidationResponse getResultOfAValidationByClient(String id) throws Exception;
}
