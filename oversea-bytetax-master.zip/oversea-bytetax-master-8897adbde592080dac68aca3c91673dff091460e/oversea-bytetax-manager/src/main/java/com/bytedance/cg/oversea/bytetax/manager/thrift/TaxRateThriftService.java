package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate.QueryBillToAccountReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate.QueryTaxRateWayReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate.BillToAccountDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate.TaxRateWayDTO;

public interface TaxRateThriftService {

    TaxRateWayDTO saveTaxRateWay (TaxRateWayDTO taxRateWayDTO);

    PageResult<TaxRateWayDTO> queryTaxRateWay (QueryTaxRateWayReqDTO req);

    BillToAccountDTO saveBillToAccount(BillToAccountDTO billToAccountDTO);

    PageResult<BillToAccountDTO> queryBillToAccount (QueryBillToAccountReqDTO req);
}
