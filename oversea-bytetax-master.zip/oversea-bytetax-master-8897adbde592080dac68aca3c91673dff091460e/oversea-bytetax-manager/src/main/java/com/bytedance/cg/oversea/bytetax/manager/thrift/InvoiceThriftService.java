package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.invoice.InvoiceDTO;
import org.joda.time.DateTime;

import java.util.List;
import java.util.Set;

/**
 * bytedance
 * 2022/11/24 8:39 下午
 */
public interface InvoiceThriftService {

    List<InvoiceDTO>  queryInvoiceByStatusAndTime(List<Integer> status, DateTime sendStartDate, DateTime sendEndDate);

    List<InvoiceDTO> queryInvoiceByStatusAndTime(List<Integer> status, DateTime sendStartDate, DateTime sendEndDate, Long afterId);

    void informLackInvoice(Set<String> serials);
}
