package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.CountryConstant;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CityInfoDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CountryDescriptionDTO;
import com.bytedance.cg.oversea.bytetax.manager.mapping.CityInfoMapping;
import com.bytedance.cg.oversea.bytetax.manager.thrift.LocationDistrictThriftService;
import com.bytedance.remote.thrift.location.district.*;
import com.bytedance.thrift.base.BaseResp;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.thrift.TException;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

/**
 * query location
 *
 * @Author: yangyl
 * @Date: 2021/4/16 12:30 下午
 */
@Service
@Slf4j
public class LocationDistrictThriftServiceImpl implements LocationDistrictThriftService {

    public static Map<Long, String> levelZero2Name = new HashMap<>();

    private final static String EN_LANG = "en";

    private Map<Long, CountryDescriptionDTO> map;

    static{
        levelZero2Name.put(CountryConstant.HK_GEO_ID_LEVEL0, CountryConstant.CN_HK);
        levelZero2Name.put(CountryConstant.MO_GEO_ID_LEVEL0, CountryConstant.CN_MO);
        levelZero2Name.put(CountryConstant.TW_GEO_ID_LEVEL0, CountryConstant.CN_TW);
    }

    private static final String SPILT = "/";

    @Resource
    private DistrictService.Iface client;

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public List<CityInfoDTO> getAllCountryInfos(String language) {
        GetAllCountryInfoReq req = new GetAllCountryInfoReq();
        req.setLanguage(language);
        try {
            GetAllCountryInfoRsp resp = client.GetCountryInfo(req);
            if (resp.getBaseResp().getStatusCode() != ConstantValue.ZERO) {
                throw new BizException(resp.getBaseResp().getStatusMessage());
            }
            if (resp.getDistricts() == null || resp.getDistricts().size() == 0) {
                return null;
            }
            return CityInfoMapping.MAPPING.toCityInfoDTOList(resp.getDistricts())
                    .stream().map(this::convertName).collect(Collectors.toList());
        } catch (TException e) {
            throw new BizException(e.getMessage());
        }
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public List<CityInfoDTO> getCountryByCode(List<String> codes) {
        if (CollectionUtils.isEmpty(codes)) {
            return Lists.newArrayList();
        }
        GetAllCountryInfoReq req = new GetAllCountryInfoReq();
        req.setLanguage(I18nConstants.EN);
        ThriftInvoker<GetAllCountryInfoReq, GetAllCountryInfoRsp> invoker = new ThriftInvoker<>();
        GetAllCountryInfoRsp rsp = invoker.request(req, re -> client.GetCountryInfo(re));
        check(rsp.getBaseResp());
        return rsp.getDistricts().stream()
                .map(CityInfoMapping.MAPPING::toCityInfoDTO)
                .filter(cityInfoDTO -> codes.contains(cityInfoDTO.getCode()))
                .map(this::convertName)
                .collect(Collectors.toList());
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public CityInfoDTO getCityByGeoId(Long geoId) {
        return convertName(getCityByGeoIds(Lists.newArrayList(geoId), "CN").get(geoId));
    }

    @Override
    public CityInfoDTO getCityByGeoId(Long geoId, String language) {
        return convertName(getCityByGeoIds(Lists.newArrayList(geoId), language).get(geoId));
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public List<CityInfoDTO> getSubCitiesByGeoId(Long geoId, String language) {
        GetDistrictsReq req = new GetDistrictsReq();
        req.setGeoname_ids(Arrays.asList(geoId));
        req.setType(DistrictType.ADMIN);
        req.setLanguage(language);
        req.setSubdistrict(2);
        ThriftInvoker<GetDistrictsReq, GetDistrictsRsp> invoker = new ThriftInvoker<>();
        GetDistrictsRsp rsp = invoker.request(req, re -> client.GetDistricts(re));
        check(rsp.getBaseResp());
        Map<Long, Region> geoIdAndRegionMap = rsp.getDistricts().values().stream()
                .collect(Collectors.toMap(Region::getGeoname_id, Function.identity()));
        List<Region> subRegions = geoIdAndRegionMap.getOrDefault(geoId, new Region()).getSub_region();
        return Optional.ofNullable(subRegions).orElse(Collections.emptyList()).stream().map(CityInfoMapping.MAPPING::toCityInfoDTO)
                .map(this::convertName).collect(Collectors.toList());
    }


    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public Map<Long, CityInfoDTO> getCityByGeoIds(List<Long> geoIds, String language) {
        if (CollectionUtils.isEmpty(geoIds)) {
            return Maps.newHashMap();
        }
        GetDistrictsReq req = new GetDistrictsReq();
        req.setGeoname_ids(geoIds);
        req.setLanguage(language);
        req.setType(DistrictType.ADMIN);
        ThriftInvoker<GetDistrictsReq, GetDistrictsRsp> invoker = new ThriftInvoker<>();
        GetDistrictsRsp rsp = invoker.request(req, re -> client.GetDistricts(re));
        check(rsp.getBaseResp());
        return rsp.getDistricts().values().stream()
                .map(CityInfoMapping.MAPPING::toCityInfoDTO)
                .map(this::convertName)
                .collect(Collectors.toMap(CityInfoDTO::getGeoId, Function.identity()));
    }

    @Override
    public Map<Long, CountryDescriptionDTO> getAllDescriptionDTO() {
        return map;
    }

    @Override
    public Map<Long, CountryDescriptionDTO> getDescriptionDTO(List<Long> geoIds) {
        if (map != null) {
            return geoIds.stream().map(id -> map.get(id))
                    .collect(Collectors.toMap(CountryDescriptionDTO::getGeoId, Function.identity()));
        }
        return geoIds.stream().map(id -> getAllDescription(id, EN_LANG))
                .collect(Collectors.toMap(CountryDescriptionDTO::getGeoId, Function.identity()));
    }

    @Override
    public CityInfoDTO getSubCityWithLevel(Long geoId, String language, Integer level) {
        return convertName(CityInfoMapping.MAPPING.toCityInfoDTO(getSubRegionWithLevel(geoId, language, level)));
    }

    public Region getSubRegionWithLevel(Long geoId, String language, Integer level) {
        GetDistrictReq req = new GetDistrictReq();
        req.setGeoname_id(geoId);
        req.setLanguage(language);
        req.setSubdistrict(level);
        ThriftInvoker<GetDistrictReq, GetDistrictRsp> invoker = new ThriftInvoker<>();
        GetDistrictRsp rsp = invoker.request(req, re -> client.GetDistrict(re));
        check(rsp.getBaseResp());
        return rsp.getDistrict();
    }

    public CountryDescriptionDTO getAllDescription(Long geoId, String language) {
        List<Region> allSubRegion = getAllSubRegion(getSubRegionWithLevel(geoId, language, 3));
        return CountryDescriptionDTO.builder()
                .geoId(geoId)
                .level1Name(getDescription(allSubRegion, 1))
                .level2Name(getDescription(allSubRegion, 2))
                .level3Name(getDescription(allSubRegion, 3))
                .build();
    }

    private List<Region> getAllSubRegion(Region region) {
        List<Region> res = Lists.newArrayList();
        if (CollectionUtils.isEmpty(region.getSub_region())) {
            return res;
        }
        for (Region sub: region.getSub_region()) {
            res.add(sub);
            res.addAll(getAllSubRegion(sub));
        }
        return res;
    }

    private String getDescription(List<Region> regions, int level) {
        return regions.stream()
                .filter(region -> region.getLevel() == level)
                .map(Region::getDescription)
                .distinct()
                .collect(Collectors.joining(SPILT));
    }


    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public CityInfoDTO getCountryByCode(String cityCode) {
        GetDistrictsReq req = new GetDistrictsReq();
        req.setCodes(Arrays.asList(cityCode));
        req.setCountry_code("CN");
        req.setType(DistrictType.ADMIN);
        req.setLanguage("zh-CN-gov");
        req.setKeep(DuplicateKeep.HIGH);
        try {
            GetDistrictsRsp resp = client.GetDistricts(req);
            if (resp.getBaseResp().getStatusCode() != ConstantValue.ZERO) {
                throw new BizException(resp.getBaseResp().getStatusMessage());
            }
            if (resp.getDistricts() == null || resp.getDistricts().size() == 0) {
                return null;
            }
            Region firstCity = resp.getDistricts().values().stream().filter(it -> it.getLevel() == 0).findFirst().orElse(null);
            if (firstCity != null) {
                return convertName(CityInfoDTO.builder().code(firstCity.getCode()).
                        name(firstCity.getName()).geoId(firstCity.getGeoname_id()).build());
            }
            return null;
        } catch (TException e) {
            throw new BizException(e.getMessage());
        }
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public CityInfoDTO getEnglishCountryByCode(String cityCode) {
        GetDistrictsReq req = new GetDistrictsReq();
        req.setCodes(Arrays.asList(cityCode));
        req.setCountry_code("CN");
        req.setType(DistrictType.ADMIN);
        req.setLanguage("English");
        req.setKeep(DuplicateKeep.HIGH);
        try {
            GetDistrictsRsp resp = client.GetDistricts(req);
            if (resp.getBaseResp().getStatusCode() != ConstantValue.ZERO) {
                throw new BizException(resp.getBaseResp().getStatusMessage());
            }
            if (resp.getDistricts() == null || resp.getDistricts().size() == 0) {
                return null;
            }
            Region firstCity = resp.getDistricts().values().stream().filter(it -> it.getLevel() == 0).findFirst().orElse(null);
            if (firstCity != null) {
                return convertName(CityInfoMapping.MAPPING.toCityInfoDTO(firstCity));
            }
            return null;
        } catch (TException e) {
            throw new BizException(e.getMessage());
        }
    }

    protected void check(BaseResp resp) {
        if (resp.StatusCode != 0) {
            log.error("thrift bad answer" + resp.StatusMessage);
            CgMonitorMetricRecorder.exceptionOneMetrics("thrift_bad_answer", null, CgMetricsConstants.ServiceType.RPC);
            throw new BizException(I18nConstants.THRIFT_BAD_ANSWER + resp.StatusMessage);
        }
    }

    private CityInfoDTO convertName(CityInfoDTO cityInfoDTO) {
        if(cityInfoDTO != null && levelZero2Name.containsKey(cityInfoDTO.getGeoId())) {
            cityInfoDTO.setName(levelZero2Name.get(cityInfoDTO.getGeoId()));
        }
        return cityInfoDTO;
    }

    @Scheduled(fixedRate = 24 * 60 * 60 * 1000)
    public void refreshSchedule() {
        log.info("定时初始化新政区域层级描述信息");
        refresh();
    }

    private void refresh() {
        List<Long> ids = getAllCountryInfos(EN_LANG).stream()
                .map(CityInfoDTO::getGeoId).collect(Collectors.toList());
        map = ids.stream().map(id -> getAllDescription(id, EN_LANG))
                .collect(Collectors.toMap(CountryDescriptionDTO::getGeoId, Function.identity()));
    }
}
