package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.common.bsm.RequestContext;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.customer.CustomerInfoDTO;
import com.bytedance.cg.oversea.bytetax.manager.mapping.CustomerInfoMapping;
import com.bytedance.cg.oversea.bytetax.manager.thrift.CustomerThriftService;
import com.bytedance.cg.thrift.be.*;
import com.bytedance.thrift.base.BaseResp;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Auther yangyl
 * @Date 2022/5/26
 **/
@Service
@Profile({"prod-sg","prod-va",  "boe-va", "dev", "boe-prod"})
public class CustomerThriftServiceImpl implements CustomerThriftService {

    @Resource
    private BillingEntityService.Client beClient;

    @Override
    public CustomerInfoDTO queryGrepCustomer(Long customerId) {
        if (customerId == null || customerId == ConstantValue.ZERO_LONG) {
            return null;
        }
        QueryByBusinessIdReq req = new QueryByBusinessIdReq();
        req.setBusinessEntityId(customerId);
        req.setSourceType(SourceType.GCRM);
        req.setForceMaster(true);

        ThriftInvoker<QueryByBusinessIdReq, QueryCustomerEntityResp> invoker = new ThriftInvoker<>();
        QueryCustomerEntityResp resp = invoker.request(req, re -> beClient.queryCustomerEntityByBusinessEntityId(re));
        check(resp.getBaseResp());
        return CustomerInfoMapping.MAPPING.toCustomerInfo(resp.getCustomerEntity());
    }

    @Override
    public List<CustomerInfoDTO> queryGrepCustomers(List<Long> customerIds) {
        if (CollectionUtils.isEmpty(customerIds)) {
            return Lists.newArrayList();
        }
        List<List<Long>> cusIdsGroup = Lists.partition(customerIds, 199);
        return Optional.ofNullable(cusIdsGroup)
                .orElseGet(Collections::emptyList)
                .stream()
                .filter(Objects::nonNull)
                .map(curGroup -> {
                    BatchQueryByBusinessIdReq req = new BatchQueryByBusinessIdReq();
                    req.setBusinessEntityIds(curGroup);
                    req.setSourceType(SourceType.GCRM);
                    ThriftInvoker<BatchQueryByBusinessIdReq, BatchQueryCustomerEntityResp> invoker = new ThriftInvoker<>();
                    BatchQueryCustomerEntityResp resp = invoker.request(req, re -> beClient.batchQueryCustomerEntityByBusinessEntityId(req));
                    check(resp.getBaseResp());
                    return resp.getCustomerEntities();
                })
                .flatMap(Collection::stream)
                .filter(Objects::nonNull)
                .map(CustomerInfoMapping.MAPPING::toCustomerInfo)
                .collect(Collectors.toList());
    }

    private void check(BaseResp resp) {
        if (resp.StatusCode != 0) {
            throw new RuntimeException(resp.StatusMessage);
        }
    }

    @Override
    public List<CustomerInfoDTO> queryGrepCustomerByKeyword(String keyword) {
        if(keyword == null) {
            return Lists.newArrayList();
        }
        CommonSearchEntityReq req = new CommonSearchEntityReq();
        req.setKeyword(keyword);
        req.setOperatorId(RequestContext.getEmployeeId().intValue());
        req.setSourceType(SourceType.GCRM);
        ThriftInvoker<CommonSearchEntityReq, CommonSearchEntityResp> invoker = new ThriftInvoker<>();
        CommonSearchEntityResp resp = invoker.request(req, re -> beClient.commonSearchEntity(req));
        check(resp.getBaseResp());
        return CustomerInfoMapping.MAPPING.toCustomerInfoList(resp.getCustomerEntities());
    }
}
