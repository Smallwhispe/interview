package com.bytedance.cg.oversea.bytetax.manager.http;


import com.bytedance.cg.oversea.bytetax.manager.dto.request.AvaRefundTransactionRequestDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.UpdateTransactionRequestDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.TransactionRequestDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.ava.TransactionRspDTO;

/**
 * avalara接口
 */
public interface AvalaraHttpService {


    TransactionRspDTO createAvaTransaction(TransactionRequestDTO req);

    void commitTransaction(UpdateTransactionRequestDTO build);

    void voidTransaction(UpdateTransactionRequestDTO build);

    TransactionRspDTO refundTransaction(AvaRefundTransactionRequestDTO requestDTO);
}
