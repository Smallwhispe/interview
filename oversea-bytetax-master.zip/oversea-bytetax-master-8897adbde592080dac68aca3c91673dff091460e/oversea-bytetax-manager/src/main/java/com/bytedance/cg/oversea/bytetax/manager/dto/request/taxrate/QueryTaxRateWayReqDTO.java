package com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryTaxRateWayReqDTO {

    private Long id;

    private String acceptorCountry;

    private Long subjectId;

    private Integer type;

    private Integer pageNumber;

    private Integer pageSize;

    private String customerName;
}
