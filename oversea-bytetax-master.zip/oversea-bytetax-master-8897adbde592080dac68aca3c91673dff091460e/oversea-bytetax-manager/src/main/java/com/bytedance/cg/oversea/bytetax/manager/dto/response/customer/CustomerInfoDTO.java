package com.bytedance.cg.oversea.bytetax.manager.dto.response.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import java.util.List;

/**
 * @author
 * @date 2021-05-19 4:56 下午
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class CustomerInfoDTO {
    /**
     * 客户id
     */
    private Long accountId;

    /**
     * 客户名称
     */
    private String accountName;

    /**
     * 国家id
     */
    private Long countryId;

    /**
     * 国家GeoId
     */
    private Long countryGeoId;
    /**
     * 税号
     */
    private String taxNo;

    /**
     * 地址信息
     */
    private String address;
}
