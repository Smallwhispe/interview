package com.bytedance.cg.oversea.bytetax.manager.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * @Auther yangyl
 * @Date 2022/8/11
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AvaItemLineDTO {
    private String itemCode;
    private BigDecimal amount;
    private Boolean taxIncluded;
    private BigDecimal quantity;
    private String ref;
}
