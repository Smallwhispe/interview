package com.bytedance.cg.oversea.bytetax.manager.mapping;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxationParty;
import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate.QueryBillToAccountReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate.QueryTaxRateWayReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate.BillToAccountDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate.TaxRateWayDTO;
import com.bytedance.cg.thrift.taxrate.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(imports = {EnumUtils.class, TaxationParty.class, DeleteStatus.class,
        EnumTaxationParty.class, EnumDeleteStatus.class})
public interface TaxRateWayMapping {

    TaxRateWayMapping MAPPING = Mappers.getMapper(TaxRateWayMapping.class);

    @Mapping(target = "type",
            expression = "java(taxRateWayDTO.getType() == null? null : " +
                    "TaxationParty.findByValue(EnumUtils.getCode(taxRateWayDTO.getType())))")
    @Mapping(target = "isDelete", expression = "java(taxRateWayDTO.getIsDelete() == null? null :" +
            "DeleteStatus.findByValue(EnumUtils.getCode(taxRateWayDTO.getIsDelete())))")
    TaxRateWay toTaxRateWay (TaxRateWayDTO taxRateWayDTO);

    @Mapping(target = "type", expression = "java(taxRateWay.getType() == null? null : " +
            "EnumUtils.getEnumByCode(EnumTaxationParty.values(), taxRateWay.getType().getValue()))")
    @Mapping(target = "isDelete", expression = "java(taxRateWay.getIsDelete() == null? null : " +
            "EnumUtils.getEnumByCode(EnumDeleteStatus.values(), taxRateWay.getIsDelete().getValue()))")
    TaxRateWayDTO toTaxRateWayDTO (TaxRateWay taxRateWay);

    List<TaxRateWayDTO> toTaxRateWayDTOList (List<TaxRateWay> taxRateWayList);

    @Mapping(target = "type", expression = "java(reqDTO.getType() == null? null : TaxationParty.findByValue(reqDTO.getType()))")
    QueryTaxRateWayReq toQueryTaxRateWayReq (QueryTaxRateWayReqDTO reqDTO);

    @Mapping(target = "isDelete", expression = "java(billToAccountDTO.getIsDelete() == null? null :" +
            "DeleteStatus.findByValue(EnumUtils.getCode(billToAccountDTO.getIsDelete())))")
    BillToAccount toBillToAccount (BillToAccountDTO billToAccountDTO);

    @Mapping(target = "isDelete", expression = "java(billToAccount.getIsDelete() == null? null : " +
            "EnumUtils.getEnumByCode(EnumDeleteStatus.values(), billToAccount.getIsDelete().getValue()))")
    BillToAccountDTO toBillToAccountDTO (BillToAccount billToAccount);

    List<BillToAccountDTO> toBillToAccountDTOList (List<BillToAccount> billToAccountList);

    QueryBillToAccountReq toQueryBillToAccountReq (QueryBillToAccountReqDTO reqDTO);

}
