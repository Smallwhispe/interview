package com.bytedance.cg.oversea.bytetax.manager.dto.request;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Auther yangyl
 * @Date 2022/8/11
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateTransactionRequestDTO {
    private String companyCode;
    private String code;
    private EnumTransactionCategory transactionCategory;

}