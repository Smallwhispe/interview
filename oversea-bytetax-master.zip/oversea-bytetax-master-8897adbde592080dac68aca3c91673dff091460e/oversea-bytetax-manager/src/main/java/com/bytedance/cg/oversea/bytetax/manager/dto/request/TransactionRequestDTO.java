package com.bytedance.cg.oversea.bytetax.manager.dto.request;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @Auther yangyl
 * @Date 2022/8/11
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionRequestDTO {
    private String companyCode;
    private AddressDTO addressDTO;
    private String customerCode;
    private List<AvaItemLineDTO> items;
    private EnumTransactionCategory transactionCategory;
    private Date transactionTime;
    private BigDecimal discount;
    private String currencyCode;
    private String bizTransactionId;
}