package com.bytedance.cg.oversea.bytetax.manager.dto.response.contract;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class ContractInfoDTO {

    /**
     * 合同ID
     */
    private Long contractId;

    /**
     * 合同编号
     */
    private String contractSerial;

    /**
     * 主体ID
     */
    private Long subjectId;

    /**
     * accountId
     */
    private List<Long> accountIdList;

    private Long billingAddressId;

    private String countryName;

    private String countryCode;
}
