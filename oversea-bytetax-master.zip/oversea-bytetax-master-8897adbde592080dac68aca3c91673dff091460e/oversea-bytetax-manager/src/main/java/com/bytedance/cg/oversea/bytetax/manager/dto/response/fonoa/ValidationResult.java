package com.bytedance.cg.oversea.bytetax.manager.dto.response.fonoa;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidationResult {

    private String id;

    private String tin;

    @JsonProperty(value = "country_iso")
    private String countryIso;

    @JsonProperty(value = "format_valid")
    private Boolean formatValid;

    @JsonProperty(value = "checksum_valid")
    private Boolean checksumValid;

    private String requested;

    private String type;

    /**
     * "vies" "local"
     */
    @JsonProperty(value = "validation_source")
    private String validationSource;

    @JsonProperty(value = "error_code")
    private Integer errorCode;

    @JsonProperty(value = "company_name")
    private String companyName;

    @JsonProperty(value = "tin_exists_online")
    private Boolean tinExistsOnline;

    @JsonProperty(value = "last_checked_online")
    private String lastCheckedOnline;

    /**
     * "active" or "inactive"
     */
    @JsonProperty(value = "business_status")
    private String businessStatus;

    private Taxpayer taxpayer;

    @JsonProperty(value = "external_id")
    private String externalId;

    private String status;

    @JsonProperty(value = "error_details")
    private ErrorDetails errorDetails;

    @JsonProperty(value = "extraFields")
    private ExtraFields extraFields;

////    以下字段暂不解析
//    @JsonProperty(value = "fuzzy_matching")
//    private String fuzzyMatching;
}
