package com.bytedance.cg.oversea.bytetax.manager.dto.response.ava;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Auther yangyl
 * @Date 2022/8/12
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionRspDTO {
    private String code;

    private String status;

    private String currencyCode;

    private BigDecimal totalAmount;

    private BigDecimal totalExempt;

    private BigDecimal totalTax;

    private BigDecimal totalTaxable;

    private List<TransactionLineDTO> lines;

}
