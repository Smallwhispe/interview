package com.bytedance.cg.oversea.bytetax.manager.dto.request;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumRefundType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * bytedance
 * 2023/3/30 11:42 上午
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AvaRefundTransactionRequestDTO {
    private String companyCode;
    private String originalTransactionId;
    private String bizTransactionId;
    private Date invoiceDate;
    private EnumRefundType refundType;
    // 退款只用传item行
    private List<String> refundItemLines;
}
