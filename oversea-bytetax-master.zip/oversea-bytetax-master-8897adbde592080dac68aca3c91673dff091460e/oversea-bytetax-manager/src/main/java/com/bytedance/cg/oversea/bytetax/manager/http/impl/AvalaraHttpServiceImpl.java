package com.bytedance.cg.oversea.bytetax.manager.http.impl;


import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.ThriftStatusCodeConstant;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumRefundType;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTransactionCategory;
import com.bytedance.cg.oversea.bytetax.common.tcc.TccConfig;
import com.bytedance.cg.oversea.bytetax.common.utils.HttpUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.StringUtil;
import com.bytedance.cg.oversea.bytetax.config.HttpConfig;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.AddressDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.AvaRefundTransactionRequestDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.TransactionRequestDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.UpdateTransactionRequestDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.ava.TransactionRspDTO;
import com.bytedance.cg.oversea.bytetax.manager.http.AvalaraHttpService;
import com.bytedance.cg.oversea.bytetax.manager.mapping.AvaMapping;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import lombok.extern.slf4j.Slf4j;
import net.avalara.avatax.rest.client.AvaTaxClientException;
import net.avalara.avatax.rest.client.enums.*;
import net.avalara.avatax.rest.client.models.*;
import net.avalara.avatax.rest.client.serializer.JsonSerializer;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

/**
 * avalara接口
 */
@Service
@Slf4j
public class AvalaraHttpServiceImpl implements AvalaraHttpService, InitializingBean {

    @Value("${ava.account}")
    private String account;

    @Value("${ava.password}")
    private String password;

    @Value("${ava.domain}")
    private String domain;

    @Value("${bytetax.debug:#{null}}")
    private Boolean debug;

    @Autowired
    private TccConfig tccConfig;

    private String auth;

    public static final String CREATE_PATH = "/api/v2/transactions/create";

    public static final String COMMIT_PATH = "/api/v2/companies/%s/transactions/%s/commit?documentType=%s";

    public static final String VOID_PATH = "/api/v2/companies/%s/transactions/%s/void?documentType=%s";

    public static final String REFUND_PATH = "/api/v2/companies/%s/transactions/%s/refund?documentType=%s";

    public static final String ERROR_MSG = "errorCode:%s, message:%s, helpLink:%s.";

    @Override
    public TransactionRspDTO createAvaTransaction(TransactionRequestDTO req) {
        try {
            CreateTransactionModel model = setCreateTransactionModel(req);
            long start = System.currentTimeMillis();
            TransactionModel transactionModel = callAvalara(model, new TypeToken<TransactionModel>(){}, domain + CREATE_PATH, domain + CREATE_PATH);
            log.info("ava call method:{}, during:{} ms, request:{}, response:{}", "createTransaction", System.currentTimeMillis() - start, JsonUtil.writeValueAsString(model), JsonUtil.writeValueAsString(transactionModel));
            return AvaMapping.MAPPING.toTransactionRspDTO(transactionModel);
        } catch (IOException | URISyntaxException | AvaTaxClientException e) {
            throw new RuntimeException("ava call error", e);
        }
    }

    @Override
    public void commitTransaction(UpdateTransactionRequestDTO req) {
        try {
            DocumentType documentType = getDocumentType(req.getTransactionCategory());
            CommitTransactionModel commitTransactionModel = new CommitTransactionModel();
            commitTransactionModel.setCommit(true);
            long start = System.currentTimeMillis();
            String path = String.format(COMMIT_PATH, req.getCompanyCode(), req.getCode(),  URLEncoder.encode(documentType.toString(), "UTF-8"));
            TransactionModel transactionModel = callAvalara(commitTransactionModel, new TypeToken<TransactionModel>() {}, domain + path, domain + COMMIT_PATH);
            log.info("ava call method:{}, during:{} ms, request:{}, response:{}","commitTransaction", System.currentTimeMillis() - start, JsonUtil.writeValueAsString(req), JsonUtil.writeValueAsString(transactionModel));
        } catch (AvaTaxClientException | IOException | URISyntaxException e) {
            throw new RuntimeException("ava call error", e);
        }
    }

    @Override
    public void voidTransaction(UpdateTransactionRequestDTO req) {
        try {
            DocumentType documentType = getDocumentType(req.getTransactionCategory());
            VoidTransactionModel voidTransactionModel = new VoidTransactionModel();
            voidTransactionModel.setCode(VoidReasonCode.DocVoided);
            long start = System.currentTimeMillis();
            String path = String.format(VOID_PATH, req.getCompanyCode(), req.getCode(),  URLEncoder.encode(documentType.toString(), "UTF-8"));
            TransactionModel transactionModel = callAvalara(voidTransactionModel, new TypeToken<TransactionModel>() {}, domain + path, domain + VOID_PATH);
            log.info("ava call method:{}, during:{} ms, request:{}, response:{}","voidTransaction", System.currentTimeMillis() - start, JsonUtil.writeValueAsString(req), JsonUtil.writeValueAsString(transactionModel));
        } catch (AvaTaxClientException e) {
            throw new BizException(e.getErrorResult().getError().getMessage());
        } catch (Exception e) {
            throw new BizException(e.getMessage());
        }
    }

    @Override
    public TransactionRspDTO refundTransaction(AvaRefundTransactionRequestDTO requestDTO) {
        try {
            RefundType refundType = getRefundType(requestDTO.getRefundType());
            RefundTransactionModel refundTransactionModel = new RefundTransactionModel();
            refundTransactionModel.setRefundType(refundType);
            refundTransactionModel.setRefundDate(requestDTO.getInvoiceDate());
            if(CollectionUtils.isNotEmpty(requestDTO.getRefundItemLines())) {
                refundTransactionModel.setRefundLines(new ArrayList<>(requestDTO.getRefundItemLines()));
            }
            // 记录bizTransactionId
            refundTransactionModel.setReferenceCode(requestDTO.getBizTransactionId());
            long start = System.currentTimeMillis();
            String path = String.format(REFUND_PATH, requestDTO.getCompanyCode(),requestDTO.getOriginalTransactionId(), URLEncoder.encode(DocumentType.SalesInvoice.toString(), "UTF-8"));
            TransactionModel transactionModel = callAvalara(refundTransactionModel, new TypeToken<TransactionModel>() {}, domain + path, domain + REFUND_PATH);
            log.info("ava call method:{}, during:{} ms, request:{}, response:{}","refundTransaction", System.currentTimeMillis() - start, JsonUtil.writeValueAsString(requestDTO), JsonUtil.writeValueAsString(transactionModel));
            return AvaMapping.MAPPING.toTransactionRspDTO(transactionModel);
        } catch (AvaTaxClientException e) {
            log.info("call refundTransaction method but get AvaTaxClientException");
            throw new BizException(e.getErrorResult().getError().getMessage());
        } catch (Exception e) {
            // 抛出runtimeException会告警在群里
            throw new RuntimeException(e.getMessage());
        }
    }

    private RefundType getRefundType(EnumRefundType enumRefundType) {
        if(EnumRefundType.PARTIAL.equals(enumRefundType)) {
            return RefundType.Partial;
        }
        return RefundType.Full;
    }

    private CreateTransactionModel setCreateTransactionModel(TransactionRequestDTO req){
        List<LineItemModel> lineItemModels = Optional.ofNullable(req.getItems()).orElse(Collections.emptyList()).stream().map(e -> {
            LineItemModel line = new LineItemModel();
            line.setQuantity(e.getQuantity());
            line.setAmount(e.getAmount());
            line.setItemCode(e.getItemCode());
            line.setTaxIncluded(e.getTaxIncluded());
            line.setRef1(e.getRef());
            return line;
        }).collect(Collectors.toList());

        AddressesModel addressesModel = new AddressesModel();
        AddressLocationInfo shipTo = new AddressLocationInfo();
        if (req.getAddressDTO().getCity() != null) {
            shipTo.setCity(req.getAddressDTO().getCity());
        }
        if (req.getAddressDTO().getProvince() != null) {
            shipTo.setRegion(req.getAddressDTO().getProvince());
        }
        shipTo.setPostalCode(req.getAddressDTO().getZipCode());
        shipTo.setCountry(req.getAddressDTO().getCountry());
        //添加详细地址逻辑 20241112
        if(StringUtils.isNotEmpty(req.getAddressDTO().getStreetAddress())){
            shipTo.setLine1(req.getAddressDTO().getStreetAddress());
        }
        if(StringUtils.isNotEmpty(req.getAddressDTO().getBuildingNumber())){
            shipTo.setLine2(req.getAddressDTO().getBuildingNumber());
        }
        if(StringUtils.isNotEmpty(req.getAddressDTO().getOtherAddress())){
            shipTo.setLine3(req.getAddressDTO().getOtherAddress());
        }
        addressesModel.setShipTo(shipTo);
        CreateTransactionModel createTransactionModel = new CreateTransactionModel();
        createTransactionModel.setLines((ArrayList<LineItemModel>) lineItemModels);
        createTransactionModel.setCurrencyCode(req.getCurrencyCode());
        createTransactionModel.setDate(req.getTransactionTime());
        createTransactionModel.setCustomerCode(req.getCustomerCode());
        createTransactionModel.setAddresses(addressesModel);
//        createTransactionModel.setDiscount(req.getDiscount());
        createTransactionModel.setCompanyCode(req.getCompanyCode());
        // 将业务方的bizTransactionId设置到avalara参考代码中
        createTransactionModel.setReferenceCode(req.getBizTransactionId());
        TaxOverrideModel taxOverrideModel = new TaxOverrideModel();
        taxOverrideModel.setTaxDate(req.getTransactionTime());
        taxOverrideModel.setType(TaxOverrideType.TaxDate);
        taxOverrideModel.setReason("history time rate");
        createTransactionModel.setTaxOverride(taxOverrideModel);
        createTransactionModel.setType(DocumentType.SalesInvoice);
        if (StringUtil.isEmpty(req.getCustomerCode())) {
            createTransactionModel.setCustomerCode("00000");
        }
        return createTransactionModel;
    }

    private DocumentType getDocumentType(EnumTransactionCategory transactionCategory) {
        if (EnumTransactionCategory.SALES_CREDIT_NOTE.equals(transactionCategory)) {
            return DocumentType.ReturnInvoice;
        } else if (EnumTransactionCategory.SALES_INVOICE.equals(transactionCategory)){
            return DocumentType.SalesInvoice;
        } else {
            return DocumentType.SalesOrder;
        }
    }

    @Override
    public void afterPropertiesSet() {
       auth = Base64.encodeBase64String((account + ":" + password).getBytes(StandardCharsets.UTF_8));
    }

    public <T> T callAvalara(Object model, TypeToken<T> typeToken, String path, String tagPath) throws URISyntaxException, IOException, AvaTaxClientException {
        CloseableHttpClient client = HttpConfig.getCloseableHttpClient();
        HttpPost httpPost = new HttpPost();
        httpPost.setURI(new URI(path));
        httpPost.setHeader("X-Avalara-Client", "ByteTax; 1.0; JavaRestClient; 22.5.0; ByteTax");
        httpPost.setHeader("Authorization", "Basic "+ auth);
        httpPost.setEntity(new StringEntity(JsonSerializer.SerializeObject(model), StandardCharsets.UTF_8));
        CloseableHttpResponse response = HttpUtil.executeByEnv(client, httpPost, tagPath, debug);
        T obj = null;
        String json = null;
        try {
            HttpEntity entity = response.getEntity();
            if (entity!=null) {
                json = EntityUtils.toString(entity);
            }
            if (response.getStatusLine().getStatusCode() / 100 != 2)
            {
                dealWithError(json);
                throw new AvaTaxClientException((ErrorResult) JsonSerializer.DeserializeObject(json, ErrorResult.class), model);
            }
            if (json != null) {
                if (ContentType.getOrDefault(entity).getMimeType().equals("application/json")) {
                    obj = (T) JsonSerializer.DeserializeObject(json, typeToken.getType());
                } else {
                    obj = (T) json;
                }
            }
        } catch (JsonParseException | AvaTaxClientException jsonParseException) {
            ErrorResult errorResult = new ErrorResult();
            int statusCode = response.getStatusLine().getStatusCode();
            ArrayList<ErrorDetail> errors = new ArrayList<>();
            ErrorDetail errorDetail = new ErrorDetail();
            errorDetail.setDescription(json);
            errors.add(errorDetail);
            //set error info
            ErrorInfo errorInfo = new ErrorInfo();
            errorInfo.setMessage("The server returned " + statusCode + " but the response is in an unexpected format. See details for the complete response.");
            errorInfo.setTarget(ErrorTargetCode.Unknown);
            errorInfo.setDetails(errors);
            errorResult.setError(errorInfo);
            throw new AvaTaxClientException(errorResult, model);
        } finally {
            response.close();
        }
        return obj;
    }

    private void dealWithError(String json) throws AvaTaxClientException {
        ErrorResult errorResult = JsonUtil.readValue(json, ErrorResult.class);
        if (StringUtil.isEmpty(json) || errorResult == null) {
           return;
        }
        Set<String> avalaraErrorCodeList = tccConfig.getAvalaraErrorCodeList();
        List<String> errorCodes = errorResult.getError().getDetails().stream().map(e -> getFaultCode(e)).collect(Collectors.toList());
        List<String> message = errorResult.getError().getDetails().stream().map(ErrorDetail::getMessage).collect(Collectors.toList());
        List<String> helpLink = errorResult.getError().getDetails().stream().map(ErrorDetail::getHelpLink).collect(Collectors.toList());
        String errorMsg = String.format(ERROR_MSG, errorCodes, message, helpLink);
        if (!avalaraErrorCodeList.containsAll(errorCodes)) {
            log.error("new error code from ava, mes:{}", errorMsg);
            CgMonitorMetricRecorder.exceptionOneMetrics("new_error_code_from_ava", null, CgMetricsConstants.ServiceType.COMMON);
        }
        throw new BizException(ThriftStatusCodeConstant.ERROR_FROM_AVA, errorMsg);
    }


    /**
     * @param errorDetail 报错详细信息
     * @return 优先返回faultSubCode，但如果faultSubCode为空，就返回faultCode
     */
    private String getFaultCode(ErrorDetail errorDetail) {
        if (errorDetail.getFaultSubCode() != null) {
            return errorDetail.getFaultSubCode();
        }
        return errorDetail.getFaultCode();
    }
}
