package com.bytedance.cg.oversea.bytetax.manager.mapping;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.bi.BICheckRspDTO;
import com.bytedance.remote.thrift.bi.SubmitActorPropertyReviewResp;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @Author: Cai Yuxin
 * @Date： 7/10/23 7:38 PM
 */
@Mapper
public interface BIMapping {

    BIMapping MAPPING = Mappers.getMapper(BIMapping.class);

    @Mapping(target = "taskId", source = "taskID")
    BICheckRspDTO toBICheckRspDTO(SubmitActorPropertyReviewResp resp);
}
