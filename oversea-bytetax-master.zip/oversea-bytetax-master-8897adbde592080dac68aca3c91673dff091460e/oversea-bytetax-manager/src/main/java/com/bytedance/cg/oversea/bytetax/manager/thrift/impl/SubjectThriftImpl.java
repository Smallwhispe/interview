package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CityInfoDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.subject.SubjectInfoDTO;
import com.bytedance.cg.oversea.bytetax.manager.mapping.SubjectDTOMapping;
import com.bytedance.cg.oversea.bytetax.manager.thrift.LocationDistrictThriftService;
import com.bytedance.cg.oversea.bytetax.manager.thrift.SubjectThriftService;
import com.bytedance.cg.thrift.legal.entity.CommonQuerySubjectRequest;
import com.bytedance.cg.thrift.legal.entity.CommonQuerySubjectResponse;
import com.bytedance.cg.thrift.legal.entity.LegalEntityService;
import com.bytedance.thrift.base.BaseResp;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

/**
 * @author hanyuxiao
 * @date 2022/1/17
 **/
@Service
@Slf4j
//@Profile({"prod-sg","prod-va",  "boe-va", "dev", "boe-prod"})
public class SubjectThriftImpl implements SubjectThriftService {

    @Resource
    private LocationDistrictThriftService locationDistrictThriftService;

    @Resource
    private LegalEntityService.Client legalEntityClient;

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public SubjectInfoDTO querySubjectInfo(Long subjectId) {
        List<SubjectInfoDTO> subjectInfoDTOList = querySubjectInfoList(Lists.newArrayList(subjectId), true);
        return subjectInfoDTOList.get(0);
    }

    @Override
    public List<SubjectInfoDTO> querySubjectInfoList(List<Long> subjectIds, boolean needCountryDetail) {
        CommonQuerySubjectRequest req = new CommonQuerySubjectRequest();
        req.setSubject_id(subjectIds);
        ThriftInvoker<CommonQuerySubjectRequest, CommonQuerySubjectResponse> invoker = new ThriftInvoker<>();
        CommonQuerySubjectResponse rsp = invoker.request(req, re -> legalEntityClient.commonQuerySubject(re));
        check(rsp.getBaseResp());
        if(rsp.getSubjects() == null) {
            throw new BizException(I18nConstants.WRONG_SUBJECT_ID + JsonUtil.writeValueAsString(subjectIds));
        }
        return rsp.getSubjects().stream().map(e->{
            SubjectInfoDTO subjectInfoDTO = SubjectDTOMapping.MAPPING.toSubjectInfoDTO(e);
            if (needCountryDetail) {
                CityInfoDTO cityInfo = locationDistrictThriftService.getCountryByCode(e.getCountry_code());
                if (cityInfo != null) {
                    subjectInfoDTO.setCountryId(cityInfo.getGeoId());
                    subjectInfoDTO.setCountryName(cityInfo.getName());
                }
            }
            return subjectInfoDTO;
        }).collect(Collectors.toList());
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public List<SubjectInfoDTO> querySubjectInfo(String name) {
        CommonQuerySubjectRequest req = new CommonQuerySubjectRequest();
        req.setLimit(1000);
        ThriftInvoker<CommonQuerySubjectRequest, CommonQuerySubjectResponse> invoker = new ThriftInvoker<>();
        CommonQuerySubjectResponse rsp = invoker.request(req, re -> legalEntityClient.commonQuerySubject(re));
        check(rsp.getBaseResp());
        List<SubjectInfoDTO> subjectInfoDTOList = rsp.getSubjects().stream().map(e->{
            CityInfoDTO cityInfo = locationDistrictThriftService.getEnglishCountryByCode(e.getCountry_code());
            SubjectInfoDTO subjectInfoDTO = SubjectDTOMapping.MAPPING.toSubjectInfoDTO(e);
            if(cityInfo != null) {
                subjectInfoDTO.setCountryId(cityInfo.getGeoId());
                subjectInfoDTO.setCountryName(cityInfo.getName());
            }
            return subjectInfoDTO;
        }).collect(Collectors.toList());
        return subjectInfoDTOList;
    }


    protected void check(BaseResp resp) {
        if (resp.StatusCode != 0) {
            log.error("thrift bad answer" + resp.StatusMessage);
            CgMonitorMetricRecorder.exceptionOneMetrics("thrift_bad_answer", null, CgMetricsConstants.ServiceType.RPC);
            throw new BizException(I18nConstants.THRIFT_BAD_ANSWER + resp.StatusMessage);
        }
    }
}
