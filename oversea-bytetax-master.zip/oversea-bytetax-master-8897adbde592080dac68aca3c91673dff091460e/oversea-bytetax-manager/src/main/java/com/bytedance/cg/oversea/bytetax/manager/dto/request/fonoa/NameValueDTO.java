package com.bytedance.cg.oversea.bytetax.manager.dto.request.fonoa;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/10/09 7:00 PM
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NameValueDTO {

    private String name;

    private String value;
}
