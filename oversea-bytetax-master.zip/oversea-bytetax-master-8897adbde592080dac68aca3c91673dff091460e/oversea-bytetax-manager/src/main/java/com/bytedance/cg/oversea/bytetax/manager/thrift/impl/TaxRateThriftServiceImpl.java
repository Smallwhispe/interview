package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.web.dto.PageResult;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate.QueryBillToAccountReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate.QueryTaxRateWayReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate.BillToAccountDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate.TaxRateWayDTO;
import com.bytedance.cg.oversea.bytetax.manager.mapping.TaxRateWayMapping;
import com.bytedance.cg.oversea.bytetax.manager.thrift.TaxRateThriftService;
import com.bytedance.cg.thrift.taxrate.*;
import com.bytedance.thrift.base.BaseResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

@Service
@Slf4j
@Profile({"prod-sg","prod-va",  "boe-va", "dev", "boe-prod"})
public class TaxRateThriftServiceImpl implements TaxRateThriftService {

    @Resource
    private TaxService.Client client;

    @Override
    public TaxRateWayDTO saveTaxRateWay(TaxRateWayDTO taxRateWayDTO) {
        SaveTaxRateWayReq req = new SaveTaxRateWayReq();
        req.setTaxRateWay(TaxRateWayMapping.MAPPING.toTaxRateWay(taxRateWayDTO));
        ThriftInvoker<SaveTaxRateWayReq, SaveTaxRateWayRsp> invoker = new ThriftInvoker<>();
        SaveTaxRateWayRsp rsp = invoker.request(req, re -> client.SaveTaxRateWay(re));
        check(rsp.getBaseResp());
        return TaxRateWayMapping.MAPPING.toTaxRateWayDTO(rsp.getTaxRateWay());
    }

    @Override
    public PageResult<TaxRateWayDTO> queryTaxRateWay(QueryTaxRateWayReqDTO reqDTO) {
        QueryTaxRateWayReq req = TaxRateWayMapping.MAPPING.toQueryTaxRateWayReq(reqDTO);
        ThriftInvoker<QueryTaxRateWayReq, QueryTaxRateWayRsp> invoker = new ThriftInvoker<>();
        QueryTaxRateWayRsp rsp = invoker.request(req, re -> client.QueryTaxRateWay(re));
        check(rsp.getBaseResp());
        List<TaxRateWayDTO> taxRateWayDTOList = TaxRateWayMapping.MAPPING.toTaxRateWayDTOList(rsp.getTaxRateWays());
        return new PageResult<>((long) rsp.getTotal(), taxRateWayDTOList);
    }

    @Override
    public BillToAccountDTO saveBillToAccount(BillToAccountDTO billToAccountDTO) {
        SaveBillToAccountReq req = new SaveBillToAccountReq();
        req.setBillToAccount(TaxRateWayMapping.MAPPING.toBillToAccount(billToAccountDTO));
        ThriftInvoker<SaveBillToAccountReq, SaveBillToAccountRsp> invoker = new ThriftInvoker<>();
        SaveBillToAccountRsp rsp = invoker.request(req, re -> client.SaveBillToAccount(re));
        check(rsp.getBaseResp());
        return TaxRateWayMapping.MAPPING.toBillToAccountDTO(rsp.getBillToAccount());
    }

    @Override
    public PageResult<BillToAccountDTO> queryBillToAccount(QueryBillToAccountReqDTO reqDTO) {
        QueryBillToAccountReq req = TaxRateWayMapping.MAPPING.toQueryBillToAccountReq(reqDTO);
        ThriftInvoker<QueryBillToAccountReq, QueryBillToAccountRsp> invoker = new ThriftInvoker<>();
        QueryBillToAccountRsp rsp = invoker.request(req, re -> client.QueryBillToAccount(re));
        check(rsp.getBaseResp());
        List<BillToAccountDTO> billToAccountDTOList = TaxRateWayMapping.MAPPING.toBillToAccountDTOList(rsp.getBillToAccounts());
        return new PageResult<>((long) rsp.getTotal(), billToAccountDTOList);
    }

    protected void check(BaseResp resp) {
        if (resp.StatusCode != 0) {
            log.error("thrift bad answer" + resp.StatusMessage);
            CgMonitorMetricRecorder.exceptionOneMetrics("thrift_bad_answer", null, CgMetricsConstants.ServiceType.RPC);
            throw new BizException(I18nConstants.THRIFT_BAD_ANSWER + resp.StatusMessage);
        }
    }
}
