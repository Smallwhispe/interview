package com.bytedance.cg.oversea.bytetax.manager.dto.response.taxrate;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumDeleteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillToAccountDTO {

    private Long id;

    private Long accountId;

    private String taxId;

    private Integer operatorId;

    private EnumDeleteStatus isDelete;
}
