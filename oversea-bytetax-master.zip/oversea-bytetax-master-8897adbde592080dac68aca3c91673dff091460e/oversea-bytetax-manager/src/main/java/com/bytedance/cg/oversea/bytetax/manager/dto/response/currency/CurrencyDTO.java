package com.bytedance.cg.oversea.bytetax.manager.dto.response.currency;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyDTO {
    private Long id;
    private String name;
    private String code;
    private PrecisionType precisionType;
}
