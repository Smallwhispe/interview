package com.bytedance.cg.oversea.bytetax.manager.dto.response.ava;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Auther yangyl
 * @Date 2022/8/12
 **/
@Data
public class LineDetailDTO {

    private BigDecimal tax;

    private BigDecimal taxableAmount;

    private BigDecimal rate;

    private String taxName;

    private String taxType;

    private LineDetailExtendDTO extend;

}
