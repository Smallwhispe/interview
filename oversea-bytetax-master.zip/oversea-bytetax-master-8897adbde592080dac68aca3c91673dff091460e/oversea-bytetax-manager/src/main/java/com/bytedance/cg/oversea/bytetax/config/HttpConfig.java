package com.bytedance.cg.oversea.bytetax.config;

import com.bytedance.http.props.BytedanceParams;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.cache.BytedanceHttpClientBuilder;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.nio.charset.StandardCharsets;

/**
 * @author hanyuxiao
 * @date 2023/4/10
 **/
@Configuration
@Slf4j
public class HttpConfig implements InitializingBean {

    private static Boolean debug;

    private static Boolean forwardEnable;

    private static String forwardProxy;

    private static String forwardAuth;

    @Autowired
    private Environment environment;

    private static PoolingHttpClientConnectionManager conMgr;

    /**
     * 访问公网需要走正向代理
     * @return
     */
    public static CloseableHttpClient getCloseableHttpClient() {
        if (debug) {
            return HttpClientBuilder.create().build();
        }
        BytedanceParams.Builder params = BytedanceParams.builder().setIsPublicDomain(true);
        if (forwardEnable) {
            params.setProxyAuthorization("Basic "+ forwardAuth).setForwardProxy(forwardProxy);
            log.info("proxy enable, auth:{}, proxy:{}", forwardAuth, forwardProxy);
        }
        return BytedanceHttpClientBuilder.create().setConnectionManager(conMgr).setParams(params.build()).build();
    }

    @Override
    public void afterPropertiesSet() {
        forwardEnable = Boolean.TRUE.toString().equals(environment.getProperty("forward.proxy.enable"));
        debug = Boolean.TRUE.toString().equals(environment.getProperty("bytetax.debug", ""));
        if (forwardEnable) {
            String password = environment.getProperty("forward.proxy.password");
            String user = environment.getProperty("forward.proxy.user");
            forwardAuth = Base64.encodeBase64String((user + ":" + password).getBytes(StandardCharsets.UTF_8));
            forwardProxy = environment.getProperty("forward.proxy.address");
        }
        conMgr = new PoolingHttpClientConnectionManager();
        conMgr.setMaxTotal(300);
        conMgr.setDefaultMaxPerRoute(200);
    }

}
