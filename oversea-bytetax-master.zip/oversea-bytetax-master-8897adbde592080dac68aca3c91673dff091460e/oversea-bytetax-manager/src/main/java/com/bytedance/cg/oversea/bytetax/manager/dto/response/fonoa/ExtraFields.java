package com.bytedance.cg.oversea.bytetax.manager.dto.response.fonoa;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExtraFields {

    @JsonProperty(value = "colombia_large_taxpayer")
    private String colombiaLargeTaxpayer;

    @JsonProperty(value = "brazil_fantasy_name")
    private String brazilFantasyName;

    @JsonProperty(value = "hungary_full_tax_identification_number")
    private String hungaryFullTaxIdentificationNumber;
}
