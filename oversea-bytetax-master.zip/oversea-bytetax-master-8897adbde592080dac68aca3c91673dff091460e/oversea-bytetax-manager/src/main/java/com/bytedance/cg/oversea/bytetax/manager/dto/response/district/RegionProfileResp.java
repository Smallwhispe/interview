package com.bytedance.cg.oversea.bytetax.manager.dto.response.district;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 行政区域查询返回结果
 */
@Data
@NoArgsConstructor
public class RegionProfileResp {

    District district;
}
