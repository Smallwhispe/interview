package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.common.util.JsonUtils;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CityInfoDTO;
import com.bytedance.cg.oversea.bytetax.manager.mapping.CityInfoMapping;
import com.bytedance.cg.oversea.bytetax.manager.thrift.CommonBasicThriftService;
import com.bytedance.remote.thrift.basic.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.thrift.TException;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

/**
 * @Auther yangyl
 * @Date 2022/1/12
 **/
@Service
@Slf4j
@Profile({"prod-sg","prod-va",  "boe-va", "dev", "boe-prod"})
public class CommonBasicThriftServiceImpl implements CommonBasicThriftService {

    @Resource
    private CommonBasicService.Client basicClient;

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public String queryCountryNameByGeoId(Long geoId) {
        CityQueryByGeoIdReq req = new CityQueryByGeoIdReq();
        req.setGeoId(geoId);
        req.setLanguage(LanguageType.EN);
        try {
            CityResp response = basicClient.queryCityByGeoId(req);
            if (response.getBaseResp().getStatusCode() != ConstantValue.ZERO) {
                throw new BizException(response.getBaseResp().getStatusMessage());
            }
            if (response.getData() == null) {
                log.error("wrong Id:{}", geoId);
                CgMonitorMetricRecorder.exceptionOneMetrics("wrong_Id", null, CgMetricsConstants.ServiceType.COMMON);
                throw new BizException(I18nConstants.WRONG_GEO_ID);
            }
            return response.getData().getName();
        } catch (TException e) {
            throw new BizException(e.getMessage());
        }
    }

    @Override
    @Cacheable(value = ConstantValue.GUAVA_1H_CACHE, unless = "#result == null")
    public Long queryGeoIdByCityId(int cityId) {
        CityQueryByIdReq req = new CityQueryByIdReq();
        req.setId(cityId);
        req.setLanguage(LanguageType.EN);
        try {
            CityResp response = basicClient.queryCityById(req);
            if (response.getBaseResp().getStatusCode() != ConstantValue.ZERO) {
                throw new BizException(response.getBaseResp().getStatusMessage());
            }
            if (response.getData() == null) {
                log.error("wrong Id:{}", cityId);
                CgMonitorMetricRecorder.exceptionOneMetrics("wrong_Id", null, CgMetricsConstants.ServiceType.COMMON);

                throw new BizException(I18nConstants.WRONG_CITY_ID);
            }
            return response.getData().getGeo_id();
        } catch (TException e) {
            throw new BizException(e.getMessage());
        }
    }

    @Override
    public Map<Long, CityInfoDTO> queryCityInfoByCityIds(List<Long> cityIds) {
        CityQueryByIdsReq req = new CityQueryByIdsReq();
        req.setId(cityIds);
        req.setLanguage(LanguageType.EN);
        try {
            CityListResp response = basicClient.queryCityByIds(req);
            if (response.getBaseResp().getStatusCode() != ConstantValue.ZERO) {
                throw new BizException(response.getBaseResp().getStatusMessage());
            }
            if (response.getData() == null) {
                log.error("wrong Id:{}", JsonUtils.toString(cityIds));
                CgMonitorMetricRecorder.exceptionOneMetrics("wrong_Id", null, CgMetricsConstants.ServiceType.COMMON);

                throw new BizException(I18nConstants.WRONG_CITY_ID);
            }
            return CityInfoMapping.MAPPING.toCityInfoDTOS(response.getData()).stream().collect(
                    Collectors.toMap(
                            CityInfoDTO::getId,
                            Function.identity()
                    ));
        } catch (TException e) {
            throw new BizException(e.getMessage());
        }
    }
}
