package com.bytedance.cg.oversea.bytetax.manager.dto.response.invoice;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * bytedance
 * 2022/11/24 8:41 下午
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InvoiceDTO {
    /**
     * 发票ID
     */
    private Long id;

    /**
     * 票据发送日期 2021-02-21
     */
    private String sendDate;

    /**
     * 发票编号
     */
    private String serial;
}
