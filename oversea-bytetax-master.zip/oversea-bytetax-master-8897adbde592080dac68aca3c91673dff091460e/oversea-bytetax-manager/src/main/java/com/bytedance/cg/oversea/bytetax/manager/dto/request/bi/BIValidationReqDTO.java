package com.bytedance.cg.oversea.bytetax.manager.dto.request.bi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author hanyuxiao
 * @date 2023/7/10
 **/
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class BIValidationReqDTO {

    private Long bizPrimaryKey;

    Map<String, String> checkParamsMap;

    private String countryCode;

    private String companyName;

    private String zipCode;

}
