package com.bytedance.cg.oversea.bytetax.manager.mapping;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.ava.LineDetailDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.ava.LineDetailExtendDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.ava.TransactionLineDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.ava.TransactionRspDTO;
import net.avalara.avatax.rest.client.models.TransactionLineDetailModel;
import net.avalara.avatax.rest.client.models.TransactionLineModel;
import net.avalara.avatax.rest.client.models.TransactionModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
@Mapper
public interface AvaMapping {

    AvaMapping MAPPING = Mappers.getMapper(AvaMapping.class);

    TransactionRspDTO toTransactionRspDTO(TransactionModel model);

    @Mapping(target = "ref", source = "ref1")
    TransactionLineDTO toTransactionLineDTO(TransactionLineModel transactionLineModel);

    @Mapping(target = "extend", expression = "java(toLineDetailExtendDTO(detailModel))")
    LineDetailDTO toLineDetailDTO(TransactionLineDetailModel detailModel);

    @Mapping(target = "jurisType", source = "jurisdictionType")
    LineDetailExtendDTO toLineDetailExtendDTO(TransactionLineDetailModel detailModel);

}
