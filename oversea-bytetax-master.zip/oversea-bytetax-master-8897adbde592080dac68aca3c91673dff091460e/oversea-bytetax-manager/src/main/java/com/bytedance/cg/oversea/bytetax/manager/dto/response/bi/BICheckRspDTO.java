package com.bytedance.cg.oversea.bytetax.manager.dto.response.bi;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author hanyuxiao
 * @date 2023/7/10
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BICheckRspDTO {

    private String taskId;

}
