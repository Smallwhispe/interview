package com.bytedance.cg.oversea.bytetax.manager.dto.response.district;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 地区信息
 * @author wangjian.2021
 */
@Data
@NoArgsConstructor
public class District {

    /**
     * 国家特殊编码
     */
    private String code;

    /**
     * 扩展信息
     */
    private DistrictProperty properties;
}
