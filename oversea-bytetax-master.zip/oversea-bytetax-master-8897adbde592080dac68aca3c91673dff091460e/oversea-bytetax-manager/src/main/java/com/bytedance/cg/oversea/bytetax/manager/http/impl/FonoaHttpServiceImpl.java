package com.bytedance.cg.oversea.bytetax.manager.http.impl;

import com.bytedance.cg.oversea.bytetax.common.utils.HttpUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.cg.oversea.bytetax.common.utils.log.ExecuteTime;
import com.bytedance.cg.oversea.bytetax.config.HttpConfig;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.fonoa.ValidationRequest;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.fonoa.ValidationResponse;
import com.bytedance.cg.oversea.bytetax.manager.http.FonoaHttpService;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.nio.charset.StandardCharsets;

@Slf4j
@Service
public class FonoaHttpServiceImpl implements FonoaHttpService {

    @Value("${fonoa.key}")
    private String key;

    @Value("${fonoa.url}")
    private String url;

    @Value("${bytetax.debug:#{null}}")
    private Boolean debug;

    @Override
    @ExecuteTime
    public ValidationResponse requestAValidationByClient(ValidationRequest validationRequest) throws Exception {
        CloseableHttpClient client = HttpConfig.getCloseableHttpClient();
        HttpPost httpPost = new HttpPost();
        httpPost.setURI(new URI(url));
        setHeaders(httpPost);
        String requestBody = JsonUtil.writeValueAsString(validationRequest);
        httpPost.setEntity(new StringEntity(requestBody, StandardCharsets.UTF_8));

        long start = System.currentTimeMillis();
        ValidationResponse validationResponse = getValidationResByClient(client, httpPost, url);
        log.info("Fonoa requestAValidationByClient. request:{}, response:{}, take:{} ms", requestBody, validationResponse, System.currentTimeMillis() - start);

        return validationResponse;
    }

    @Override
    @ExecuteTime
    public ValidationResponse getResultOfAValidationByClient(String id) throws Exception {
        CloseableHttpClient client = HttpConfig.getCloseableHttpClient();
        HttpGet httpGet = new HttpGet();
        String urlWithId = url + "/"+ id;
        httpGet.setURI(new URI(urlWithId));
        setHeaders(httpGet);

        long start = System.currentTimeMillis();
        ValidationResponse validationResponse = getValidationResByClient(client, httpGet, urlWithId);
        log.info("Fonoa getResultOfAValidationByClient. id:{}, response:{}, take:{} ms", id, validationResponse, System.currentTimeMillis() - start);

        return validationResponse;
    }

    private ValidationResponse getValidationResByClient(CloseableHttpClient client, HttpUriRequest request, String path) throws Exception {
        CloseableHttpResponse response = HttpUtil.executeByEnv(client, request, path, debug);
        ValidationResponse validationResponse = null;
        String responseBody = null;
        try {
            HttpEntity entity = response.getEntity();
            if (entity!=null) {
                responseBody = EntityUtils.toString(entity);
                log.info("responseBody : {}", responseBody);
            }
            if (responseBody != null) {
                validationResponse = JsonUtil.readValue(responseBody, ValidationResponse.class);
            }
        } catch (Exception e) {
            throw new RuntimeException("Fonoa request fails! {}" + e);
        }
        return validationResponse;
    }

    private void setHeaders(HttpUriRequest request) {
        request.setHeader("accept", "application/json");
        request.setHeader("content-type", "application/json");
        request.setHeader("Ocp-Apim-Subscription-Key", key);
    }
}
