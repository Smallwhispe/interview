package com.bytedance.cg.oversea.bytetax.manager.dto.request.taxrate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryBillToAccountReqDTO {

    private Long id;

    private Long accountId;

    private Integer pageNumber;

    private Integer pageSize;
}
