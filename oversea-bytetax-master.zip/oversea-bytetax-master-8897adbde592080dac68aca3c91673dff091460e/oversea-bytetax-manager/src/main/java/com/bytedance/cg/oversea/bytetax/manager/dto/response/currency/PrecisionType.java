package com.bytedance.cg.oversea.bytetax.manager.dto.response.currency;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author admin
 */

@Getter
@AllArgsConstructor
public enum PrecisionType {
    last_two(1, 2, "2位"),
    integer(2, 0, "没有小数"),
    last_three(3, 3, "3位");

    private Integer code;
    private Integer scale;
    private String name;

    public static PrecisionType codeOf(Integer code) {
        return Lists.newArrayList(PrecisionType.values())
                .stream()
                .filter(type -> type.getCode().equals(code))
                .findFirst().orElse(last_two);
    }
}
