package com.bytedance.cg.oversea.bytetax.manager.dto.response.location;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author yangyl
 * @date 2021/6/21
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DistrictInfoDTO {

    private String name;
    private String code;

}
