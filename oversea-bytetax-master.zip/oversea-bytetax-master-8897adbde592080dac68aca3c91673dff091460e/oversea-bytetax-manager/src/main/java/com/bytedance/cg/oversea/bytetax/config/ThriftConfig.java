package com.bytedance.cg.oversea.bytetax.config;

import com.bytedance.thrift.client.EnableThriftClients;
import com.bytedance.thrift.client.ThriftClient;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

/**
 * @author hanyuxiao
 * @date 2022/1/17
 **/
@Configuration
public class ThriftConfig {
    @Profile({"boe-ttp", "prod-ttp"})
    @Configuration
    @EnableThriftClients({
            @ThriftClient(psm = "cg.oversea.legal_entity_thrift", basePackage = "com.bytedance.cg.thrift.legal.entity"),
            @ThriftClient(psm = "tiktok.location.district", basePackage = "com.bytedance.remote.thrift.location.district"),
            @ThriftClient(psm = "cg.oversea.transaction_signups", basePackage = "com.bytedance.cg.thrift.signups"),
            @ThriftClient(psm = "cg.oversea_exchange_rate.thrift", basePackage = "com.bytedance.cg.thrift.exchange", idcs = {"maliva"}),
            @ThriftClient(psm = "cg.oversea.transaction_master_data_spider", basePackage = "com.bytedance.cg.thrift.master")
    })
    public static class VaThriftConfig {
    }

    @Profile({"prod-gcp"})
    @Configuration
    @EnableThriftClients({
            @ThriftClient(psm = "cg.billing_entity.thrift", basePackage = "com.bytedance.cg.thrift.be", idcs = {"sg1"}),
            @ThriftClient(psm = "cg.oversea.legal_entity_thrift", basePackage = "com.bytedance.cg.thrift.legal.entity"),
            @ThriftClient(psm = "tiktok.location.district", basePackage = "com.bytedance.remote.thrift.location.district"),
            @ThriftClient(psm = "cg.oversea.transaction_signups", basePackage = "com.bytedance.cg.thrift.signups"),
            @ThriftClient(psm = "cg.oversea_exchange_rate.thrift", basePackage = "com.bytedance.cg.thrift.exchange", idcs = {"sg1"}),
            @ThriftClient(psm = "cg.common_basic.thrift", basePackage = "com.bytedance.remote.thrift.basic", idcs = {"sg1"}),
            @ThriftClient(psm = "cg.oversea_taxrate.thrift", basePackage = "com.bytedance.cg.thrift.taxrate"),
            @ThriftClient(psm = "cg.oversea.transaction_master_data_spider", basePackage = "com.bytedance.cg.thrift.master")
    })
    public static class GcpThriftConfig {

    }


    @Profile({"prod-sg","prod-va",  "boe-va", "dev", "boe-prod"})
    @Configuration
    @EnableThriftClients({
            @ThriftClient(psm = "cg.billing_entity.thrift", basePackage = "com.bytedance.cg.thrift.be"),
            @ThriftClient(psm = "cg.oversea.legal_entity_thrift", basePackage = "com.bytedance.cg.thrift.legal.entity"),
            @ThriftClient(psm = "tiktok.location.district", basePackage = "com.bytedance.remote.thrift.location.district"),
            @ThriftClient(psm = "cg.oversea.transaction_signups", basePackage = "com.bytedance.cg.thrift.signups"),
            @ThriftClient(psm = "cg.currency_exchange_rate.thrift", basePackage = "com.bytedance.cg.thrift.currency"),
            @ThriftClient(psm = "cg.oversea_exchange_rate.thrift", basePackage = "com.bytedance.cg.thrift.exchange"),
            @ThriftClient(psm = "cg.common_basic.thrift", basePackage = "com.bytedance.remote.thrift.basic"),
            @ThriftClient(psm = "cg.oversea_taxrate.thrift", basePackage = "com.bytedance.cg.thrift.taxrate"),
            @ThriftClient(psm = "ad.audit.actor_review_gateway", basePackage = "com.bytedance.remote.thrift.bi"),
            @ThriftClient(psm = "cg.oversea_note_gateway.thrift", basePackage = "com.bytedance.cg.thrift.note.gateway"),
            @ThriftClient(psm = "cg.oversea.transaction_master_data_spider", basePackage = "com.bytedance.cg.thrift.master")
    })
    public static class OtherThriftConfig {

    }
}
