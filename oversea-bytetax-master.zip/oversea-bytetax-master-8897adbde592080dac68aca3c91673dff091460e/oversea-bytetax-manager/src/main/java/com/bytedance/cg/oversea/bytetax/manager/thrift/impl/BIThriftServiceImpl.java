package com.bytedance.cg.oversea.bytetax.manager.thrift.impl;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.I18nConstants;
import com.bytedance.cg.oversea.bytetax.common.utils.ThriftInvoker;
import com.bytedance.cg.oversea.bytetax.manager.dto.request.bi.BIValidationReqDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.bi.BICheckRspDTO;
import com.bytedance.cg.oversea.bytetax.manager.mapping.BIMapping;
import com.bytedance.cg.oversea.bytetax.manager.thrift.BIThriftService;
import com.bytedance.remote.thrift.bi.*;
import com.bytedance.thrift.base.BaseResp;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;

/**
 * @author hanyuxiao
 * @date 2023/7/10
 **/
@Service
@Slf4j
public class BIThriftServiceImpl implements BIThriftService {

    @Autowired(required = false)
    private ActorReviewGateway.Client client;

    @Override
    public BICheckRspDTO taxNoValidation(BIValidationReqDTO reqDTO) {
        SubmitActorPropertyReviewReq request = new SubmitActorPropertyReviewReq();
        ActorPropertyReview actorPropertyReview = new ActorPropertyReview();
        actorPropertyReview.setActorID(reqDTO.getBizPrimaryKey());
        actorPropertyReview.setActorType(ActorType.MMM_CRM_ACCOUNT);
        actorPropertyReview.setPropertyType(PropertyType.TAX_INFO);
        actorPropertyReview.setRegion(reqDTO.getCountryCode());
        actorPropertyReview.setName(reqDTO.getCompanyName());
        ActorBaseInfo actorBaseInfo = new ActorBaseInfo();
        actorBaseInfo.setZipcode(reqDTO.getZipCode());
        actorPropertyReview.setBaseInfo(actorBaseInfo);
        actorPropertyReview.setReviewObjects(Lists.newArrayList());
        PropertyReviewObject propertyReviewObject = new PropertyReviewObject();
        propertyReviewObject.setID(1L);
        propertyReviewObject.setObjectType(ObjectType.TAX_INFO);
        propertyReviewObject.setDetails(Lists.newArrayList());
        for (Map.Entry<String, String> entry: reqDTO.getCheckParamsMap().entrySet()){
            //多税号，按照type,number,type,number的顺序传参
            String taxName = entry.getKey();
            String taxValue = entry.getValue();
            ReviewItem reviewItem1 = new ReviewItem();
            reviewItem1.setKey("tax_type");
            reviewItem1.setValue(taxName);
            reviewItem1.setType(ItemType.TEXT);
            ReviewItem reviewItem2 = new ReviewItem();
            reviewItem2.setKey("tax_number");
            reviewItem2.setValue(taxValue);
            reviewItem2.setType(ItemType.TEXT);
            propertyReviewObject.getDetails().addAll(Lists.newArrayList(reviewItem1,reviewItem2));
        }
        actorPropertyReview.getReviewObjects().add(propertyReviewObject);
        request.setReview(actorPropertyReview);
        request.setSubmitTimestamp(System.currentTimeMillis());
        ThriftInvoker<SubmitActorPropertyReviewReq, SubmitActorPropertyReviewResp> thriftInvoker = new ThriftInvoker<>();

        SubmitActorPropertyReviewResp response = thriftInvoker.request(request, re -> client.SubmitActorPropertyReview(re));
        check(response.getBaseResp());
        return BIMapping.MAPPING.toBICheckRspDTO(response);
    }

    protected void check (BaseResp resp) {
        if(resp.StatusCode != 0) {
            log.error("thrift bad answer" + resp.StatusMessage);
            CgMonitorMetricRecorder.exceptionOneMetrics("thrift_bad_answer", null, CgMetricsConstants.ServiceType.RPC);
            throw new BizException(I18nConstants.THRIFT_BAD_ANSWER + resp.StatusMessage);
        }
    }
}
