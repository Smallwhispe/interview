package com.bytedance.cg.oversea.bytetax.manager.mapping;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.location.CityInfoDTO;
import com.bytedance.remote.thrift.basic.CityInfo;
import com.bytedance.remote.thrift.location.district.Region;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
@Mapper
public interface CityInfoMapping {

    CityInfoMapping MAPPING = Mappers.getMapper(CityInfoMapping.class);

    @Mapping(target = "geoId", source = "geoname_id")
    @Mapping(target = "subRegion", source = "sub_region")
    CityInfoDTO toCityInfoDTO(Region region);

    List<CityInfoDTO> toCityInfoDTOList(List<Region> regions);

    @Mapping(target = "isoCode", source = "iso_code")
    @Mapping(target = "geoId", source = "geo_id")
    @Mapping(target = "code", source = "iso_code")
    CityInfoDTO toCityInfoDTO(CityInfo cityInfo);

    List<CityInfoDTO> toCityInfoDTOS(List<CityInfo> cityInfos);
}
