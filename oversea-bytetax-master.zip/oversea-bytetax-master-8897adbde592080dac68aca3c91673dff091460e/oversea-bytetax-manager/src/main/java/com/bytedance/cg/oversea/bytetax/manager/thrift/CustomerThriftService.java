package com.bytedance.cg.oversea.bytetax.manager.thrift;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.customer.CustomerInfoDTO;

import java.util.List;

public interface CustomerThriftService {

    CustomerInfoDTO queryGrepCustomer(Long customerId);

    List<CustomerInfoDTO> queryGrepCustomers(List<Long> customerId);

    List<CustomerInfoDTO> queryGrepCustomerByKeyword(String keyword);

}
