package com.bytedance.cg.oversea.bytetax.manager.mapping;

import com.bytedance.cg.oversea.bytetax.manager.dto.response.currency.CurrencyDTO;
import com.bytedance.cg.oversea.bytetax.manager.dto.response.currency.PrecisionType;
import com.bytedance.cg.thrift.signups.Currency;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author hanyuxiao
 * @date 2022/1/20
 **/
@Mapper(imports = {PrecisionType.class})
public interface CurrencyDTOMapping {

    CurrencyDTOMapping MAPPING = Mappers.getMapper(CurrencyDTOMapping.class);

    @Mapping(target = "precisionType", expression = "java(PrecisionType.codeOf((int)(currency.getPrecision_type())))")
    CurrencyDTO toCurrencyDTO(Currency currency);
}
