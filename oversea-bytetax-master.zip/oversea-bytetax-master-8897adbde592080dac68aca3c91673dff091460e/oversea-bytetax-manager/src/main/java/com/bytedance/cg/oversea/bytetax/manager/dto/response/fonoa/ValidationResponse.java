package com.bytedance.cg.oversea.bytetax.manager.dto.response.fonoa;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidationResponse {

    /**
     * "completed" "running" "pending" "cancel"
     */
    private String status;

    private ValidationResult validation;

    @JsonProperty(value = "validation_status")
    private String validationStatus;
}
