package com.bytedance.cg.oversea.bytetax.manager.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * county ->市概念
 * @Auther yangyl
 * @Date 2022/8/11
 **/
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddressDTO {
    // level 0
    private String country;
    // level 1
    private String province;
    // level 3
    private String city;
    //street name and street number
    private String streetAddress;
    //楼栋号
    private String buildingNumber;
    //其他地址信息，如：apartment number, suite number, floor number ，company name等
    private String otherAddress;
    private String zipCode;
}
