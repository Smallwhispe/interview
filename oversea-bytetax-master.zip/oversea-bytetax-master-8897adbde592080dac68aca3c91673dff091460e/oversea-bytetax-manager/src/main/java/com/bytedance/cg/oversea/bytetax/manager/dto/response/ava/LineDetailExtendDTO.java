package com.bytedance.cg.oversea.bytetax.manager.dto.response.ava;

import lombok.Data;

/**
 * @Author: Cai Yuxin
 * @Date： 2024/04/16 11:08 AM
 */
@Data
public class LineDetailExtendDTO {

    private String region;

    private String jurisType;

    private String jurisCode;

    private String jurisName;

}
