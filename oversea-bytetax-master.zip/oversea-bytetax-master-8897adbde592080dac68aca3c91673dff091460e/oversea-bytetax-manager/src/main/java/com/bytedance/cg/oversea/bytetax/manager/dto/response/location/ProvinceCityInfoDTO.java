package com.bytedance.cg.oversea.bytetax.manager.dto.response.location;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


/**
 * @Author: yangyl
 * @Date: 2021/4/16 12:25 下午
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProvinceCityInfoDTO extends CityInfoDTO {
    List<CityInfoDTO> cityList;
}
