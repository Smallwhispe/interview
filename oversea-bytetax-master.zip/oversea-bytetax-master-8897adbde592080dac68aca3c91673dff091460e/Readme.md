#海外税务平台服务

##模块介绍
###oversea-taxrate-common
枚举、常量定义、i18n相关、客增通用逻辑、util和配置
###oversea-taxrate-dal
数据库访问相关代码，封装所有与数据库（Mysql）的交互，把有业务意义的MetaDO暴露给service层，主要包含：PO、Mapper、MetaDO、Dao、数据库切面。
####dao
封装数据库访问相关的mapper接口
####do
数据库模型 data object

###oversea-taxrate-manager
外部服务依赖代理模块,封装所有与外部服务的交互（Thirft、Http），主要包含：外部idl及其编译产生的类代码、外部调用封装service及serviceImpl。
###oversea-taxrate-service
税率业务逻辑
###oversea-taxrate-task
定时任务模块
对于正常业务逻辑，只会作为程序入口，不包含任何业务逻辑
临时任务可以放少量业务逻辑
###oversea-taxrate-mq
mq消费者处理
###oversea-taxrate-thrift
对外提供thrift服务，提供接口、入参和返回值封装、参数校验、文案获取等
###oversea-taxrate-web
对外提供http接口，提供接口、入参和返回值封装、参数校验、文案获取等
