#!/bin/sh

exec ./mvnw -U -T6 -DskipTests -Pprod clean package