#!/bin/sh

exec ./mvnw -T6 -DskipTests clean package
