#!/bin/sh

exec ./mvnw -T6 -DskipTests clean package -pl '!oversea-bytetax-web,!oversea-bytetax-test'
