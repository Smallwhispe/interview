#!/bin/bash

# 设置要计算的目录，默认为当前目录
DIRECTORY=$(pwd)

echo "仓库路径: $DIRECTORY"

# 定义要排除的路径模式
EXCLUDE_PATTERNS=(
    '**/*Application.java'
    '**/*Config.java'
    '**/*Configuration.java'
    '**/constants/**'
    '**/annotation/**'
    '**/protobuf/**'
    '**/proto/**'
    '**/*DTO.java'
    '**/DTO/**'
    '**/dto/**'
    '**/*Dto.java'
    '**/output/**'
    '**/target/**'
    '**/*PO.java'
    '**/*DO.java'
    '**/*Mapper.java'
    '**/mapper/**'
    '**/*POExample.java'
    '**/*MappingImpl.java'
    '**/test/**'
    '**/Test/**'
    '**/*Test.java'
)

# 创建排除参数
EXCLUDE_ARGS=()
for pattern in "${EXCLUDE_PATTERNS[@]}"; do
    EXCLUDE_ARGS+=(-not -path "$pattern")
done

# 查找所有 .java 文件并计算行数，排除指定路径
TOTAL_LINES=$(find "$DIRECTORY" -name "*.java" "${EXCLUDE_ARGS[@]}" -exec cat {} + | \
grep -v '^\s*$' |   # 排除空行
grep -v '^\s*//' |   # 排除单行注释
grep -v '^\s*/\*' |   # 排除多行注释开头
grep -v '\*/\s*$' |   # 排除多行注释结尾
grep -v '^\s*import ' |   # 排除 import 行
grep -v '^\s*[{]+$' | grep -v '^\s*[}]+$' |
grep -v '^\s*@' | #排除注解行
grep -v '^\s*public\s\+.*\s*\(.*\)\s*{' |   # 排除类/函数/变量声明行
grep -v '^\s*protected\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*private\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*default\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*static\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*final\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*abstract\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*synchronized\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*native\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*strictfp\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*void\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*int\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*String\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*boolean\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*double\s\+.*\s*\(.*\)\s*{' |
grep -v '^\s*[{]+$' | grep -v '^\s*[}]+$' |
grep -v '^\s*@' | #排除注解行
wc -l)

# 输出结果
echo "Java 代码行数 (排除指定路径、空行、import 行、注释行、注解行): $TOTAL_LINES"
