package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * @author hanyuxiao
 * @date 2022/5/12
 **/
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

import java.util.List;
import java.util.Set;

/**
 * @author hanyuxiao
 * @date 2022/6/24
 **/
public class CountryConstant {

    public static final String COUNTRY = "country";
    public static final String CANADA = "CA";
    public static final String USA = "US";
    public static final Long USA_GEO_ID = 6252001L;
    public static String AT = "AT";
    public static String BE = "BE";
    public static String BG = "BG";
    public static String CY = "CY";
    public static String CZ = "CZ";
    public static String DE = "DE";
    public static String DK = "DK";
    public static String EE = "EE";
    public static String ES = "ES";
    public static String FI = "FI";
    public static String FR = "FR";
    public static String HR = "HR";
    public static String HU = "HU";
    public static String IE = "IE";
    public static String IT = "IT";
    public static String LT = "LT";
    public static String LU = "LU";
    public static String LV = "LV";
    public static String MT = "MT";
    public static String NL = "NL";
    public static String PL = "PL";
    public static String PT = "PT";
    public static String RO = "RO";
    public static String SE = "SE";
    public static String SI = "SI";
    public static String SK = "SK";
    public static String GB = "GB";
    public static String GR = "GR";
    public static String MX = "MX";

    public static List<String> EU_COUNTRY = Lists.newArrayList(AT,BE,BG,CY,CZ,DE,DK,EE,ES,FI,FR,HR,HU,IE,IT,
            LT,LU,LV, MT,NL,PL,PT,RO,SE,SI,SK,GB,GR);

    public static final Long CN_GEO_ID = 1814991L;
    public static final Long HK_GEO_ID_LEVEL0 = 1819730L;
    public static final Long MO_GEO_ID_LEVEL0 = 1821275L;
    public static final Long TW_GEO_ID_LEVEL0 = 1668284L;
    public static final Long HK_GEO_ID_LEVEL1 = 1819729L;
    public static final Long MO_GEO_ID_LEVEL1 = 1821274L;
    public static final Long TW_GEO_ID_LEVEL1 = 7280291L;
    public static final String CN_HK = "Chi_na-Ho_ng Ko_ng".replace("_","");
    public static final String CN_MO = "Chi_na-Ma_cau".replace("_","");
    public static final String CN_TW = "Chi_na-Tai_wan Province".replace("_","");
    public static final String HK_ISO = "HK";
    public static final String MO_ISO = "MO";
    public static final String TW_ISO = "TW";

    public static final Set<Long> MULTIPLE_BIZ_CONFIG_LIST = Sets.newHashSet(6251999L);

    public static boolean checkMultipleBizConfigCountry(Long countryGeoId) {
        return MULTIPLE_BIZ_CONFIG_LIST.contains(countryGeoId);
    }

}
