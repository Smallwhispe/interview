package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.property;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("idgenerator")
public class IdGeneratorProperties {

  public static final int DEFAULT_CONNECTION_REQUEST_TIMEOUT = 200;

  public static final int DEFAULT_CONNECT_TIMEOUT = 200;

  public static final int DEFAULT_SOCKET_TIMEOUT = 200;

  public static final int MAX_RETRY_COUNT = 5;

  private String idGeneratorPsm;

  private int connectionRequestTimeout = DEFAULT_CONNECTION_REQUEST_TIMEOUT;

  private int connectTimeout = DEFAULT_CONNECT_TIMEOUT;

  private int socketTimeout = DEFAULT_SOCKET_TIMEOUT;

  private int maxRetryCount = MAX_RETRY_COUNT;

  public int getConnectionRequestTimeout() {
    return connectionRequestTimeout;
  }

  public void setConnectionRequestTimeout(int connectionRequestTimeout) {
    this.connectionRequestTimeout = connectionRequestTimeout;
  }

  public int getConnectTimeout() {
    return connectTimeout;
  }

  public void setConnectTimeout(int connectTimeout) {
    this.connectTimeout = connectTimeout;
  }

  public int getSocketTimeout() {
    return socketTimeout;
  }

  public void setSocketTimeout(int socketTimeout) {
    this.socketTimeout = socketTimeout;
  }

  public int getMaxRetryCount() {
    return maxRetryCount;
  }

  public void setMaxRetryCount(int maxRetryCount) {
    this.maxRetryCount = maxRetryCount;
  }

  public String getIdGeneratorPsm() {
    return idGeneratorPsm;
  }

  public void setIdGeneratorPsm(String idGeneratorPsm) {
    this.idGeneratorPsm = idGeneratorPsm;
  }

}
