package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author wangjian.2021
 * @date 2022/6/14
 **/
@Getter
@AllArgsConstructor
public enum EnumAsyncTaskType implements BaseIntEnum  {

    TAX_REPORTER_DOWNLOAD(1, "税务报表导出"),
    TAX_CATEGORY_DOWNLOAD(2, "税种表导出"),
    TRANSACTION_DOWNLOAD(3, "交易列表导出"),
    TAX_NO_CHECK(4, "读取tax_no_check_rule表，发出税号校验请求"),
    TAX_NO_RESULT(5, "获得税号校验结果"),
    TAX_CONFIG_CHECK(6, "读取tax_no_config表，发出税号校验请求"),
    ;

    private Integer code;
    private String name;
}
