package com.bytedance.cg.oversea.bytetax.common.utils;

import com.bytedance.cg.common.exception.BizException;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumBizExceptionCode;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumRpcResult;

/**
 * @author caolei.l
 */
public final class ExceptionUtils {

    public static BizException newBizException(EnumRpcResult rpcResult) {
        return newBizException(rpcResult.getCode(), rpcResult.getName());
    }

    public static BizException newBizException(EnumRpcResult code, String msg) {
        return newBizException(code.getCode(), msg);
    }

    public static BizException newBizException(EnumBizExceptionCode exceptionCode, String msg) {
        return newBizException(exceptionCode.getCode(), msg);
    }

    public static BizException newBizException(int code, String msg) {
        return new BizException(code, msg);
    }

}
