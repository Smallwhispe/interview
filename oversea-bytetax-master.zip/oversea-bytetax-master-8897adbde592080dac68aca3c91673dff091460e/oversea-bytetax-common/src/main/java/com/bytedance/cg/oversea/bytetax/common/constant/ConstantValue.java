package com.bytedance.cg.oversea.bytetax.common.constant;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import java.util.List;
import java.util.Map;

/**
 * @author yangyl
 * @date 2020/9/7
 **/
public interface ConstantValue {
    Integer MAX_ALLOW_PAGE_SIZE = 100;
    Integer FLUSH_PAGE_SIZE = 25;
    Integer FLUSH_INITIAL_PAGE_NUM = 1;
    Integer ONE = 1;
    Integer THREE = 3;
    Integer FOUR = 4;
    Long ONE_LONG = 1L;
    String ONE_STRING = "1";
    Integer N_ONE = -1;
    Long TWO_LONG = 2L;
    Long N_ONE_LONG = -1L;
    Long N_TWO_LONG = -2L;
    Double ZERO_D = 0D;
    Integer ZERO = 0;
    Long ZERO_LONG = 0L;
    String ZERO_STRING = "0";
    int ZERO_INT = 0;
    Integer FORTY = 40;
    Integer ONE_HUNDRED = 100;
    Integer FIFTY = 50;
    Integer TWO_HUNDRED = 200;
    Long TWO_HUNDRED_LONG = 200L;
    Integer FIVE_HUNDRED = 500;
    Integer ONE_THOUSAND = 1000;
    Integer FIFTY_THOUSAND = 50000;
    Integer ONE_HUNDRED_THOUSAND = 100000;
    Integer ONE_MILLION = 1000_000;
    Integer THIRD = 3;
    Integer TEM_THOUSAND = 10000;
    Integer BACKGROUND_INFO_LIMIT = 500;
    Integer SUGGEST_LIMIT = 20;
    Integer TWENTY = 20;
    Integer BUDGET_CLOSING_WAIT_DAY = -15;
    Integer COUPON_CLOSING_WAIT_DAY = -7;
    Integer WORKFLOW_CANCELD = 2012;
    String WORKFLOW_BUSINESS_KEY = "turbine";
    String DRAFT = "DRAFT";
    String DEFAULT_UNION_NO = "9999";
    String DEFAULT_SUCCESS = "0000";
    String REPEAT_SUCCESS = "ZJJGPB000001";
    Integer FIVE = 5;
    Long FUTURE_TIMEOUT = 3L;
    Integer MILLIS_OF_SECOND = 1000;
    Integer FORTY_NINE = 49;
    Integer TEN = 10;
    Long TEN_LONG = 10L;
    String UNDERLINE = "_";
    Integer RECORD_ID_LENGTH = 19;
    Integer AUXILIARY_ADMINISTRATORS_LIMIT = 50;

    String AS = " as ";
    String COMMA = ", ";
    String POINT = ". ";

    String EXPORT_EXCEL_SUFFIX = ".xlsx";
    String EXPORT_CSV_SUFFIX = ".csv";
    String EMPLOYEE_ID = "employee_id";
    String STATUS = "status";
    String EXPORT_TXT_SUFFIX = ".txt";

    // 定时任务参数列表
    String TASK_NAME = "taskName";
    String RECORD_ID = "recordId";
    String ENTITY_TYPE = "entityType";
    String PKG_LINE_ID = "pkgLineId";
    String RECHARGE_ID = "rechargeId";
    String TOS_URL = "tosUrl";
    String REAL_START = "realStart";
    String AUTO_BOOST = "autoBoost";
    String FACTOR_CHOSEN = "factorChosen";

    String FILE_NAME = "fileName";

    String UNKNOWN = "unknown";

    String EXCEL_SPECIAL_CHAR = "[ #,，；;/、]";

    String TAG_SPLITTER = ",";

    String TCC_PSM = "cg.turbine.biz";
    String COMMERCE_COUPON_FACADE_TCC_PSM = "aweme.commerce.coupon_facade";
    String DEFAULT_COUNT = "default";

    // 账期管理模块，当无营业执照编号时，则不填写营业执照编号
    String DEFAULT_BUSINESS_LICENSE = "";


    String WORKFLOW_RULEVARIABLE_TYPE_STRING = "string";
    String WORKFLOW_RULEVARIABLE_TYPE_LIST = "list";
    String WORKFLOW_RULEVARIABLE_TYPE_STRING_LIST = "stringlist";

    String LAUNCH_SCENE = "直播间短触区";

    String ACTIVITY_OWNER = "activity_owner";

    String X_JWT_TOKEN = "X-Jwt-Token";

    String COMMON_TASK_COMMAND_TEMPLATE = "java -server -Xms%dm -Xmx%dm -Xmn%dm -XX:SurvivorRatio=15 -XX:+UseParNewGC -XX:ParallelGCThreads=4 -XX:MaxTenuringThreshold=15 -XX:+UseConcMarkSweepGC -XX:+UseCMSInitiatingOccupancyOnly -XX:+ScavengeBeforeFullGC -XX:+UseCMSCompactAtFullCollection -XX:+CMSParallelRemarkEnabled -XX:CMSFullGCsBeforeCompaction=9 -XX:CMSInitiatingOccupancyFraction=60 -XX:+CMSClassUnloadingEnabled -XX:SoftRefLRUPolicyMSPerMB=0 -XX:-ReduceInitialCardMarks -XX:CMSInitiatingPermOccupancyFraction=70 -XX:-OmitStackTraceInFastThrow -XX:+PrintGCDetails -Xloggc:/opt/log/tiger/gc.log -XX:+PrintGCTimeStamps -jar /opt/tiger/turbine/turbine-task/turbine-task-1.0-SNAPSHOT.jar com.bytedance.cg.turbine.task.TaskApp --spring.profiles.active=$profile --logging.config=classpath:prod/logback.xml --taskName=turbine_common_task --recordId=%d";
    String COMMON_TASK_PSM = "cg.turbine.common_task";

    // validator
    String RESOURCE_BASIC_VALIDATOR = "RESOURCE_BASIC_VALIDATOR";
    String RESOURCE_STATUS_VALIDATOR = "RESOURCE_STATUS_VALIDATOR";
    String RESOURCE_MODIFY_VALIDATOR = "RESOURCE_MODIFY_VALIDATOR";

    String TAG_MANUAL_ENUM_LIMIT_VALIDATOR = "tag_manual_enum_limit_validator";
    String TAG_MANUAL_VALUE_TYPE_VALIDATOR = "tag_manual_value_type_validator";
    String ACTIVITY_APPLICATION_SAVE_VALIDATOR = "activity_application_save_validator";


    // taxNo check
    String UK_TOKEN_URL = "https://api.service.hmrc.gov.uk/oauth/token";

    String UK_VAT_VERIFY_URL = "https://api.service.hmrc.gov.uk/organisations/vat/check-vat-number/lookup/";

    static Map<String, String> getUKToken() {
        Map<String, String> ukTokenBody = Maps.newHashMap();
        ukTokenBody.put("client_secret", "80417233-28a2-478b-a66d-cea5f212ad8b");
        ukTokenBody.put("client_id", "632MBDN7j1Tt0kblhNdtyEldNQfK");
        ukTokenBody.put("grant_type", "client_credentials");
        return ukTokenBody;
    }

    String ENGLAND = "GB";

    String GREECE = "GR";

    List<String> EUROPEAN_TAX_NO = Lists.newArrayList("AT","BE","BG","CY","CZ","DE","DK","EE",
            "EL","ES","FI","FR","HR","HU","IE","IT","LT","LU","LV","MT","NL","PL","PT","RO","SE","SI","SK","GR");


    String SYSTEM_ERROR = "System error";

    String MQ_ERROR = "Mq consume error";

    String THRIFT_ERROR = "Thrift invoke error";

    /**
     * Id
     */
    String ID = "id";

    /**
     * code
     */
    String CODE = "code";

    /**
     * name
     */
    String NAME = "name";

    /**
     * value
     */
    String VALUE = "value";


    String SOAP_EXCEPTION_INVALID_INPUT = "INVALID_INPUT";

    String GUAVA_1M_CACHE = "guava_1m_cache";

    String GUAVA_5M_CACHE = "guava_5m_cache";

    String GUAVA_1H_CACHE = "guava_1h_cache";

    String GUAVA_24H_CACHE = "guava_24h_cache";

    String DEFAULT_EXCEL_SHEET_NAME = "default";

//    public final static String GUAVA_12H_CACHE = "guava_12h_cache";
    String THIRD_TRANSACTION_DEFAULT_SUFFIX = "_BT";

    String FONOA_STATUS_COMPLETED = "completed";

    String FORMAT = "Format";

    String API = "API";

    String API_RULE_IDS = "apiRuleIds";

    String START_TIME_OFFSET = "startTimeOffset";

    String END_TIME_OFFSET = "endTimeOffset";

    String NEED_ALARM = "needAlarm";

    String SELF_DEFINED_PERIOD = "selfDefinedPeriod";

    String ZIPCODE = "zipcode";

    String COUNTRY = "country";

    /**
     * 联系人信息
     */
    String CONTACT_NAME = "contactName";

    List<String> BI_FIXED_PARAMS = Lists.newArrayList(CONTACT_NAME, ZIPCODE, COUNTRY);

    char CHAR_ZERO = '0';

    String BILLING_ADDRESS = "billingAddress";

    String TAXPAYER_NAME_CAMEL = "taxpayerName";

    String TAXPAYER_NAME = "taxpayer_name";

    String ZIP_CODE_CAMEL = "zipCode";

    String ZIP_CODE = "zip_code";

    String DEFAULT_MESSAGE_FEATURE = "DEFAULT";
    long BYTETAX_PROMOTE_BUSINESS_LINE =3;
    long BYTETAX_PROMOTE_ITEM = 2 ;
}
