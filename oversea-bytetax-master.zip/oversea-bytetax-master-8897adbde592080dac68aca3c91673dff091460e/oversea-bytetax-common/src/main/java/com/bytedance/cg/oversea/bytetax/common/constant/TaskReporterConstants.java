package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * @author wangjian.2021
 * @date 2022/6/18
 **/
public interface TaskReporterConstants {

    Integer ONE_TASK_REPORTER_RECORD_LIMIT = 400000;
}
