package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EnumTransactionType implements BaseIntEnum {

    PURCHASE(1, "Purchase"),
    SALE(2, "Sale");

    private final Integer code;
    private final String name;
}
