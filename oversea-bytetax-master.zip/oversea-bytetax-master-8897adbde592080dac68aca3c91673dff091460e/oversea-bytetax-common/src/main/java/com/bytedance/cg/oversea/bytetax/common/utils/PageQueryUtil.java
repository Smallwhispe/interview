package com.bytedance.cg.oversea.bytetax.common.utils;

import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

/**
 * @author Yiming Gong
 * @date 2021/6/9 11:51 上午
 */
public class PageQueryUtil {

    public static <R> List<R> queryByPage(Function<Long, List<R>> func, Function<R, Long> idGetter, int queryCountLimit) {
        List<R> resultList = new ArrayList<>();
        Long offsetId = 0L;
        while (true) {
            List<R> subList = func.apply(offsetId);
            resultList.addAll(subList);
            if (subList.size() < queryCountLimit) {
                break;
            }
            offsetId = idGetter.apply(subList.get(subList.size() - 1));
        }
        return resultList;
    }


    public static <R> List<R> fullQueryByPageIndex(Function<Integer, List<R>> func, int initPageIndex, int pageSize) {
        List<R> resultList = new ArrayList<>();
        int curPageIndex = initPageIndex;
        while (true) {
            List<R> subList = func.apply(curPageIndex);
            resultList.addAll(subList);
            if (CollectionUtils.size(subList) < pageSize) {
                break;
            }
            ++curPageIndex;
        }
        return resultList;
    }

}
