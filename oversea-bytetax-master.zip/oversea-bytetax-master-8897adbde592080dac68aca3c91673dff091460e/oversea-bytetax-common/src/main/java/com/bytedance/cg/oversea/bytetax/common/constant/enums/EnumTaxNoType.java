package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import com.bytedance.cg.oversea.bytetax.common.utils.EnumUtils;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2022/10/26
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxNoType implements BaseStringEnum {

    GST_HST("GST/HST", "GST/HST", 1),
    PST("PST", "PST", 2);

    private String code;
    private String name;
    private Integer value;

    public static EnumTaxNoType toEnumTaxNoTypeByValue(int value) {
        for (EnumTaxNoType taxNoType : EnumTaxNoType.values()) {
            if (taxNoType.getValue().equals(value)) {
                return taxNoType;
            }
        }
        return null;
    }
}
