package com.bytedance.cg.oversea.bytetax.common.utils;

import com.alibaba.fastjson.JSON;
import com.bytedance.cg.common.exception.ThriftException;
import com.bytedance.cg.common.util.GsonUtil;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.flow.control.FlowControlContainer;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.thrift.TBase;
import org.apache.thrift.TException;
import org.apache.thrift.TSerializer;
import org.apache.thrift.protocol.TSimpleJSONProtocol;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;

/**
 * @author Yiming Gong
 * @date 2021/5/27 6:01 下午
 */
@Slf4j
@Component
public class ThriftInvoker<T extends TBase, R extends TBase> implements ApplicationContextAware {

    private static final String ENV = System.getProperty("rpc.env");

    private static FlowControlContainer flowControlContainer;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        flowControlContainer = applicationContext.getBean(FlowControlContainer.class);
    }

    public interface ThrowingFunction<T, R> {
        R apply(T t) throws Exception;
    }

    public R request(T req, ThrowingFunction<T, R> func) throws ThriftException {
        if (StringUtils.isNoneBlank(ENV)) {
            flowControlContainer.setEnv(ENV);
        }
        return request(req, func, true);
    }

    public R request(T req, ThrowingFunction<T, R> func, boolean logResp) throws ThriftException {
        String simpleName = func.getClass().getSimpleName();
        simpleName = simpleName.substring(0, simpleName.indexOf("$"));
        StringBuffer sb = new StringBuffer("Thrift request (").append(simpleName).
                append(") : <").append(req.getClass().getSimpleName()).append("> ").
                append(JSON.toJSONString(req));
        StopWatch stopWatch=new StopWatch();
        stopWatch.start();
        try {
            R response = func.apply(req);
            stopWatch.stop();
            if (null == response) {
                sb.append(" empty response ");
                sb.append(stopWatch.getTotalTimeMillis()).append("ms.");
                log.error(sb.toString());
                CgMonitorMetricRecorder.exceptionOneMetrics("sb_toString", null, CgMetricsConstants.ServiceType.COMMON);

            } else {
                if(logResp){
                    sb.append(" success Response: ").append(toJSONString(response));
                    sb.append(" ").append(stopWatch.getTotalTimeMillis()).append("ms.");
                }
                log.info(sb.toString());
            }
            OpeToolsContext.addTrace(sb.toString(), "ThriftInvoker.request");
            return response;
        } catch (Throwable e) {
            stopWatch.stop();
            sb.append(" fail ").append(stopWatch.getTotalTimeMillis()).append("ms. exception: ").
                    append(e.getLocalizedMessage());
            log.error(ConstantValue.THRIFT_ERROR, e);
            log.error(sb.toString() ,e);
            CgMonitorMetricRecorder.exceptionOneMetrics("ConstantValue_THRIFT_ERROR", e, CgMetricsConstants.ServiceType.COMMON);
            throw new ThriftException(e.getMessage(), e);
        }
    }

    public static String toJSONString(TBase base) {
        TSerializer serializer = new TSerializer(new TSimpleJSONProtocol.Factory());
        try {
            return serializer.toString(base);
        } catch (TException e) {
            try {
                return JacksonUtil.marshalToString(base);
            } catch (Exception jsonProcessingException) {
                log.error("rpc serializer error", e);
                CgMonitorMetricRecorder.exceptionOneMetrics("rpc_serializer_error", e, CgMetricsConstants.ServiceType.COMMON);
            }
        }
        return "";
    }
}

