package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EnumItemType implements BaseIntEnum{
    SERVICES(1, "service"),
    GOODS(2, "goods"),
    ;
    private final Integer code;
    private final String name;
}
