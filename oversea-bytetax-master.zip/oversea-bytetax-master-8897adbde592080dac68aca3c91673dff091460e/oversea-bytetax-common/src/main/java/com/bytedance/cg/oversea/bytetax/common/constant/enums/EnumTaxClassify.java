package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

/**
 * 税种类型枚举
 * @author wangjian.2021
 * @date 2022/10/27
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxClassify implements BaseIntEnum {

    /**
     * 流转税
     */
    TURNOVER(1, "turnover tax"),

    /**
     * 预扣税
     */
    WITHHOLDING(2, "withholding tax");

    private final Integer code;
    private final String name;

    public static EnumTaxClassify findByValue(Integer code) {
        if (TURNOVER.getCode().equals(code)) {
            return TURNOVER;
        } else if (WITHHOLDING.getCode().equals(code)) {
            return WITHHOLDING;
        } else {
            return null;
        }
    }

    public static List<EnumTaxClassify> getAll() {
        return Lists.newArrayList(TURNOVER, WITHHOLDING);
    }
}
