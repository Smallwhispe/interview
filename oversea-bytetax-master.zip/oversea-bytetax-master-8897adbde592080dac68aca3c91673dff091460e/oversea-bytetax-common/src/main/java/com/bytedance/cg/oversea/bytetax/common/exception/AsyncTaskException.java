package com.bytedance.cg.oversea.bytetax.common.exception;

import lombok.Data;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/09/07 4:12 PM
 */
@Data
public class AsyncTaskException extends RuntimeException {

    private String message;

    public AsyncTaskException (String message) {
        this.message = message;
    }
}
