package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 是否最新记录
 * @author:
 * @date:
 */
@Getter
@AllArgsConstructor
public enum EnumApproveStatus implements BaseIntEnum {

    REFUSE(2, "审批拒绝"),
    AUDITING(0, "审批中"),
    APPROVED(1, "审批通过"),
    ;
    private Integer code;
    private String name;
}
