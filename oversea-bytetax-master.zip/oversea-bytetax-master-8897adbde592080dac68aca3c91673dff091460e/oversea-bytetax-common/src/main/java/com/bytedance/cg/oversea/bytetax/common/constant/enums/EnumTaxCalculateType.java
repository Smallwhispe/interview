package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2022/1/25
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxCalculateType implements BaseIntEnum {

    /**
     *  传入金额不含税
     */
    NET(1, "tax excluded"),
    /**
     *  传入金额含税
     */
    GROSS(2, "tax included");

    private final Integer code;
    private final String name;

    public Boolean includeTax() {
        return EnumTaxCalculateType.GROSS.equals(this);
    }
}
