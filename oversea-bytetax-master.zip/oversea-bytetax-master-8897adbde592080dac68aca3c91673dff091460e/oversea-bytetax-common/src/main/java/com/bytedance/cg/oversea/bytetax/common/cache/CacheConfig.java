package com.bytedance.cg.oversea.bytetax.common.cache;

import com.bytedance.cg.common.cache.menchache.WriteSafeCache;
import com.google.common.base.Joiner;
import com.google.common.cache.CacheBuilder;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.guava.GuavaCache;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;


/**
 * @author wangjian.2021
 * @date 2023/1/12
 **/
@EnableCaching
@Configuration
@Slf4j
public class CacheConfig implements CachingConfigurer {

    private static final Joiner JOINER = Joiner.on("_");

    private static final Gson GSON = new Gson();

    public final static String GUAVA_1M_CACHE = "guava_1m_cache";

    public final static String GUAVA_5M_CACHE = "guava_5m_cache";

    /**
     * 1小时缓存joiner.join(Lists.newArrayList(target.getClass().getSimpleName(),
     *                       method.getName(), StringUtils.arrayToDelimitedString(args.toArray(), "_")))
     */
    public final static String GUAVA_1H_CACHE = "guava_1h_cache";

    public final static String GUAVA_24H_CACHE = "guava_24h_cache";

    public final static String GUAVA_12H_CACHE = "guava_12h_cache";

    /**
     * 缓存完整对象
     */
    public final static String GUAVA_1M_CACHE_UN_SAFE = "guava_1m_cache_un_safe";

    public final static String GUAVA_5M_CACHE_UN_SAFE = "guava_5m_cache_un_safe";

    public final static String GUAVA_1H_CACHE_UN_SAFE = "guava_1h_cache_un_safe";

    public final static String GUAVA_24H_CACHE_UN_SAFE = "guava_24h_cache_un_safe";

    public final static String LOCAL_CACHE = "localCache";

    /**
     *
     * 名字不能改
     *
     * 这个cache是为
     * @see com.bytedance.cg.common.bsm.internal.remote.client.BsmClient
     * 中用到的缓存创建的。当开启了缓存服务，需要提供名为local_cache的缓存，否则BsmClient中方法无法使用
     *
     * @see com.bytedance.cg.common.bsm.internal.remote.client.BsmClient
     * 本意是依赖cg.bytedance.cg:common-cache-starter中的缓存配置
     * @see com.bytedance.cg.common.cache.menchache.CacheConf
     * ，但是配置没有被SpringBootApplication扫描到,因此配置不生效
     * @return
     */
    @Bean(LOCAL_CACHE)
    @Override
    public CacheManager cacheManager() {
        SimpleCacheManager manager = new SimpleCacheManager();
        ArrayList<GuavaCache> caches = new ArrayList();
        caches.add(new com.bytedance.cg.common.cache.menchache.WriteSafeCache(GUAVA_24H_CACHE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(24L, TimeUnit.HOURS).maximumSize(10000L).build()));
        caches.add(new com.bytedance.cg.common.cache.menchache.WriteSafeCache(GUAVA_1H_CACHE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(1L, TimeUnit.HOURS).maximumSize(10000L).build()));
        caches.add(new com.bytedance.cg.common.cache.menchache.WriteSafeCache(GUAVA_1M_CACHE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(1L, TimeUnit.MINUTES).maximumSize(10000L).build()));
        caches.add(new com.bytedance.cg.common.cache.menchache.WriteSafeCache(GUAVA_5M_CACHE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(5L, TimeUnit.MINUTES).maximumSize(10000L).build()));
        caches.add(new GuavaCache(GUAVA_24H_CACHE_UN_SAFE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(24L, TimeUnit.HOURS).maximumSize(10000L).build()));
        caches.add(new GuavaCache(GUAVA_1H_CACHE_UN_SAFE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(1L, TimeUnit.HOURS).maximumSize(10000L).build()));
        caches.add(new GuavaCache(GUAVA_1M_CACHE_UN_SAFE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(1L, TimeUnit.MINUTES).maximumSize(10000L).build()));
        caches.add(new GuavaCache(GUAVA_5M_CACHE_UN_SAFE, CacheBuilder.newBuilder().recordStats().expireAfterWrite(5L, TimeUnit.MINUTES).maximumSize(10000L).build()));
        manager.setCaches(caches);
        return manager;
    }

    @Override
    public CacheResolver cacheResolver() {
        return null;
    }

    @Bean
    @Override
    public KeyGenerator keyGenerator() {

        return (target, method, params) -> {
            // 参数序列化，拼接类名 方法名
            List<String> args = Lists.newArrayList();
            if (params != null){
                args = Arrays.stream(params).map(GSON::toJson).collect(Collectors.toList());
            }
            return JOINER.join(Lists.newArrayList(target.getClass().getSimpleName(),
                    method.getName(), StringUtils.arrayToDelimitedString(args.toArray(), "_")));
        };

    }

    @Override
    public CacheErrorHandler errorHandler() {
        return null;
    }

}
