package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client;

import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.exception.IDGeneratorException;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.property.IdGeneratorProperties;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.url.URIHolder;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class DefaultIDGenerator implements IDGenerator {

  private static final Logger logger = LoggerFactory.getLogger(DefaultIDGenerator.class);

  private static final String URL_PATTERN = "gen?ns=%s&cs=%s&count=%d&psm=%s";

  private static final String DEFAULT_CHARSET = "UTF-8";

  private final URIHolder uriHolder;

  private final CloseableHttpClient httpClient;

  private final String psm;

  private final String nameSpace;

  private final String counterSpace;

  private final IdGeneratorProperties idGeneratorProperties;

  private DefaultIDGenerator(Builder builder) {
    this.psm = builder.psm;
    this.nameSpace = builder.nameSpace;
    this.counterSpace = builder.counterSpace;
    this.uriHolder = builder.uriHolder;
    this.idGeneratorProperties = builder.idGeneratorProperties;
    if (this.idGeneratorProperties.getConnectionRequestTimeout() <= 0) {
      throw new IllegalArgumentException("connectionRequestTimeout below or equal zero.");
    }
    if (this.idGeneratorProperties.getConnectTimeout() <= 0) {
      throw new IllegalArgumentException("connectTimeout below or equal zero.");
    }
    if (this.idGeneratorProperties.getSocketTimeout() <= 0) {
      throw new IllegalArgumentException("socketTimeout below or equal zero.");
    }
    if (this.idGeneratorProperties.getMaxRetryCount() <= 0) {
      throw new IllegalArgumentException("maxRetryCount below zero.");
    }
    this.httpClient = buildHttpClient();
  }

  @Override
  public Long gen() throws IDGeneratorException {
    return genMulti(1).get(0);
  }

  @Override
  public List<Long> genMulti(int count) throws IDGeneratorException {
    if (count <= 0 || count > 100) {
      throw new IDGeneratorException(
          "count must betweeen (1, 100]. argument is illegal: " + count);
    }

    boolean success = false;
    List<Long> result = null;
    IDGeneratorException ex = new IDGeneratorException("getMulti occur exception");

    for (int retryTime = 0; retryTime < idGeneratorProperties.getMaxRetryCount(); retryTime++) {
      URI uri = buildUri(count);
      HttpGet httpGet = new HttpGet(uri);
      CloseableHttpResponse response = null;

      try {
        response = httpClient.execute(httpGet);
        int statusCode = response.getStatusLine().getStatusCode();

        if (statusCode >= 400) {
          ex =  new IDGeneratorException("http response status is fail. status code:" + statusCode);
          continue;
        }
        HttpEntity entity = response.getEntity();

        if (entity != null) {
          String content = EntityUtils.toString(entity);

          try {
            List<Long> resultList = new ArrayList<>();

            for (String slice : content.split(",")) {
              if (StringUtils.isNotEmpty(slice)) {
                resultList.add(Long.parseLong(slice));
              }
            }
            if (resultList.size() > 0) {
              result = new ArrayList<>(count);

              for (int i = 0; i < resultList.size() && i <= count - 1; i++) {
                result.add(resultList.get(i));
              }
              success = true;
              break;
            } else {
              ex = new IDGeneratorException("IDGenerator response null exception");
              continue;
            }
          } catch (Exception e) {
            ex = new IDGeneratorException("IDGenerator response null exception", e);
            continue;
          }
        } else {
          ex = new IDGeneratorException("http response entity is null");
          continue;
        }
      } catch (IOException e) {
        ex = new IDGeneratorException("IDGenerator io exception", e);
        continue;
      } finally {
        if (response != null) {
          try {
            response.close();
          } catch (IOException e) {
            // ignore
          }
        }
      }
    }

    if(success){
      return result;
    } else {
      logger.error(ex.getMessage(), ex);
      throw ex;
    }
  }

  @Override
  public void close() throws IOException {
    httpClient.close();
  }

  private CloseableHttpClient buildHttpClient() {
    RequestConfig defaultRequestConfig = RequestConfig.custom()
        .setConnectionRequestTimeout(this.idGeneratorProperties.getConnectionRequestTimeout())
        .setConnectTimeout(this.idGeneratorProperties.getConnectTimeout())
        .setSocketTimeout(this.idGeneratorProperties.getSocketTimeout())
        .build();
    HttpClientBuilder httpClientBuilder = HttpClients.custom()
        .setDefaultRequestConfig(defaultRequestConfig);

    return httpClientBuilder.build();
  }

  private URI buildUri(int count) {
    String urlSuffix = String
        .format(URL_PATTERN, urlEscape(nameSpace), urlEscape(counterSpace), count, urlEscape(psm));

    return uriHolder.selectUri().resolve(urlSuffix);
  }

  private static String urlEscape(String url) {
    try {
      return URLEncoder.encode(url, DEFAULT_CHARSET);
    } catch (UnsupportedEncodingException e) {
      throw new IllegalStateException();
    }
  }

  public static Builder builder() {
    return new Builder();
  }

  public static class Builder {

    private URIHolder uriHolder;

    private String psm;

    private String nameSpace;

    private String counterSpace;

    private IdGeneratorProperties idGeneratorProperties;

    public Builder setUriHolder(URIHolder uriHolder) {
      this.uriHolder = uriHolder;
      return this;
    }

    public Builder setPsm(String psm) {
      this.psm = psm;
      return this;
    }

    public Builder setNameSpace(String nameSpace) {
      this.nameSpace = nameSpace;
      return this;
    }

    public Builder setCounterSpace(String counterSpace) {
      this.counterSpace = counterSpace;
      return this;
    }

    public Builder setIdGeneratorProperties(IdGeneratorProperties idGeneratorProperties) {
      this.idGeneratorProperties = idGeneratorProperties;
      return this;
    }

    public DefaultIDGenerator build() {
      return new DefaultIDGenerator(this);
    }

  }

}
