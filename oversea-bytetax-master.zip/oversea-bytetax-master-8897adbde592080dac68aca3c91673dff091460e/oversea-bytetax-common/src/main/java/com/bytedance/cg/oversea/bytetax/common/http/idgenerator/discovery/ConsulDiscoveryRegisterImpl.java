package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery;

import com.bytedance.consul.daemon.ConsulServiceResolver;
import com.bytedance.consul.daemon.LookupOption;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConsulDiscoveryRegisterImpl implements ConsulDiscoveryRegister {

  private static final Logger logger = LoggerFactory.getLogger(ConsulDiscoveryRegisterImpl.class);

  private ConsulServiceResolver consulServiceResolver;

  public ConsulDiscoveryRegisterImpl(ConsulServiceResolver consulServiceResolver) {
    this.consulServiceResolver = consulServiceResolver;
  }

  @Override
  public boolean register(String psm, ConsulListener listener) {
    try {
      LookupOption lookupOption = new LookupOption(psm);

      consulServiceResolver.addWatching(lookupOption);
      consulServiceResolver
          .onAfterRefreshed(() -> listener.onUpdate(consulServiceResolver.get(lookupOption)));
      consulServiceResolver.forceUpdate();

      return !CollectionUtils.isEmpty(consulServiceResolver.get(lookupOption));
    } catch (Exception ex) {
      logger.error("ID Generator register consul error!", ex);
      return false;
    }
  }

}
