package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * bytedance
 * 2022/10/19 4:45 下午
 */
public class CommonEnumsKeyConstant {
    public static String ADMIN_TAX_TIME_TYPE = "admin_tax_time_type";
    public static String TAX_TRANSACTION_TYPE = "tax_transaction_type";
    public static String RULE_LOCATION = "rule_location";
    public static String TAX_REPORTER_GROUP_TYPE = "tax_reporter_group_type";
    public static String TRANSACTION_CATEGORY = "transaction_category";
    public static String RULE_CALCULATE_TYPE = "rule_calculate_type";
    public static String CATEGORY_TYPE = "category_type";
    public static String EXEMPTION_ACCOUNT_TYPE = "exemption_account_type";
    public static String RULE_TRANSACTION_TYPE = "rule_transaction_type";
    public static String TURNOVER_TAX_CODE_TYPE = "turnover_tax_code_type";
    public static String WHT_TAX_CODE_TYPE = "wht_tax_code_type";
    public static String TAX_CODE_CATEGORY= "tax_code_category";
    public final static String COLLECT_CONFIG= "collect_config";
    public final static String TAX_INFO_TYPE = "tax_info_type";
    public final static String TAX_NO_FORMAT_RULE_TYPE = "tax_no_format_rule_type";
    public final static String TAX_CONFIG_VERSION= "tax_config_version";

}
