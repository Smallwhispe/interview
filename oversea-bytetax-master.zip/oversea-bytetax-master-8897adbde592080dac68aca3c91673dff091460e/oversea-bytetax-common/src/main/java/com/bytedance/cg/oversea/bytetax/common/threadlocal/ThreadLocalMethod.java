package com.bytedance.cg.oversea.bytetax.common.threadlocal;

import java.lang.annotation.*;

/**
 * @author wangjian.2021
 * @date 2022/9/13
 **/
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface ThreadLocalMethod {

    String tccGrayRateKey() default "";
}
