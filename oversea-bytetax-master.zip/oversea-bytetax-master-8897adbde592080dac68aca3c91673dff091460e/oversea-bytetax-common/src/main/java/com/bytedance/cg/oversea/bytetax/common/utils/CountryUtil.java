package com.bytedance.cg.oversea.bytetax.common.utils;

/**
 * @author wangjian.2021
 * @date 2023/7/18
 **/
public class CountryUtil {

    public static final Long CANADA_GEO_ID = 6251999L;

    public static boolean checkIsCanada(Long countryGeoId) {
        return CANADA_GEO_ID.equals(countryGeoId);
    }
}
