package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * 对应change_log表中entity_type字段
 * 表明change_log表中entity_id是什么类型的id
 * */
@Getter
@AllArgsConstructor
public enum EnumChangeLogType implements BaseIntEnum{


    ADMIN_ID(1, "adminId"),

    BIZ_ID(2, "bizId"),

    CATEGORY_ID(3, "categoryId"),

    EXEMPTION_ID(4, "exemptionId"),

    ITEM_ID(5, "itemId"),

    RULE_ID(6, "ruleId"),

    BIZBIND_ID(7, "bizBindId"),

    SUBJECTCOUNTRYBIND_ID(8, "subjectCountryBindId"),

    TAX_ADMIN_SUBJECT_BIND_ID(9, "taxAdminSubjectBindId"),

    /**
     * taxrate数据库 tax_rate_way表
     */
    TAX_RATE_WAY_ID(10, "taxRateWayId"),

    /**
     * taxrate数据库 bill_to_account表
     */
    BILL_TO_ACCOUNT_ID(11, "billToAccountId"),

    TAX_NO_CHECK_RULE_ID(12, "taxNoCheckRuleId"),

    TAX_NO_CONFIG(13, "taxNoConfigId"),

    WHITELIST_TAX_RATE_ID(14, "whitelistTaxRateId"),

    ;

    private final Integer code;
    private final String name;
}
