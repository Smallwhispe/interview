package com.bytedance.cg.oversea.bytetax.common.http.idgenerator;

import java.util.List;

/**
 *  * reference: https://wiki.bytedance.net/display/rd/id+generator
 * @author hanyuxiao
 * @date 2021/7/1
 **/
public interface IdGenerateService {
    /**
     * 获取id-generator生成的唯一id
     *
     * 调用id-generator失败时会使用当前timeStamp
     * @return
     */
    Long getId();
    /**
     * 获取id-generator生成的唯一id
     *
     * @return
     */
    List<Long> getIds(int cnt);
}