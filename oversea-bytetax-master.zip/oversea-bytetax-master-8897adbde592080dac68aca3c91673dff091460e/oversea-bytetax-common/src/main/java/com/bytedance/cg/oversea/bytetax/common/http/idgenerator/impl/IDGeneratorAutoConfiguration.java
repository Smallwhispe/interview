package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.impl;

import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client.DefaultIDGeneratorFactory;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client.IDGenerator;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client.IDGeneratorFactory;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery.ConsulDiscoveryRegister;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery.ConsulDiscoveryRegisterImpl;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.property.IdGeneratorProperties;
import com.bytedance.consul.daemon.ConsulServiceResolver;
import com.bytedance.env.ApplicationEnvironment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({
    IdGeneratorProperties.class,
})
public class IDGeneratorAutoConfiguration {

  private static final String NAMESPACE_ITEM = "ad";

  private static final String COUNTSPACE_ITEM = "cg";

  @Autowired
  private IDGeneratorFactory idGeneratorFactory;

  @Bean
  public ConsulDiscoveryRegister getConsulDiscoveryRegister(
      ConsulServiceResolver consulServiceResolver) {
    return new ConsulDiscoveryRegisterImpl(consulServiceResolver);
  }

  @Bean
  public IDGeneratorFactory getIDGeneratorFactory(ConsulDiscoveryRegister consulDiscoveryRegister,
                                                  ApplicationEnvironment applicationEnvironment, IdGeneratorProperties properties) {
    return new DefaultIDGeneratorFactory(consulDiscoveryRegister, applicationEnvironment.psm(), properties);
  }


  @Bean
  public IDGenerator genGenerator() {
    return idGeneratorFactory.createIDGenerator(NAMESPACE_ITEM, COUNTSPACE_ITEM);
  }

}
