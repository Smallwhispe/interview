package com.bytedance.cg.oversea.bytetax.common.utils;

import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import org.apache.commons.lang3.ObjectUtils;

/**
 * @Auther yangyl
 * @Date 2021/12/7
 **/
public class ByteObjectUtils extends ObjectUtils {

    public static boolean longEqual(Long origin, Long compare) {
        if (origin == null || ConstantValue.ZERO_LONG.equals(origin)) {
            return true;
        }
        return origin.equals(compare);

    }
}
