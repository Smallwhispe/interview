package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * @author
 * @date 2021-06-15 4:56 下午
 */
public interface TaskConstants {

    String CASES_INIT = "cases_init";

    String CASES_DATA = "cases_data";

    String DIFF_AVALARA = "diff_avalara";

    String TAX_RULE_INIT = "tax_rule_init";

    String REPORTER_GEN = "report_gen";

    String TAX_NO_CHECK = "tax_no_check";

    String ADMIN_RELATED_INIT = "admin_related_init";

    String ADMIN_BIND_INIT = "admin_bind_init";

    String RULE_ADDRESS_REFRESH = "rule_address_refresh";

    String CASES_CHECK_INIT = "cases_check_init";

    String ADMIN_COUNTRY_INIT = "admin_country_init";

    String SALES_INVOICE_CHECK = "sales_invoice_check";

    String TAX_NO_CHECK_FONOA = "tax_no_check_fonoa";

    String UPDATE_FONOA_RESULT = "update_fonoa_result";

}
