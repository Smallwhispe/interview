package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.exception;

public class IDGeneratorException extends Exception {

  public IDGeneratorException(String message) {
    super(message);
  }

  public IDGeneratorException(String message, Throwable cause) {
    super(message, cause);
  }

  public IDGeneratorException(Throwable cause) {
    super(cause);
  }
  
}
