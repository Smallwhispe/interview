package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @Author: Cai Yuxin
 * @Date： 7/4/23 7:14 PM
 */
@Getter
@AllArgsConstructor
public enum EnumTaxAuditRejectReason implements BaseIntEnum {

    /**
     *
     */
    COMMON_REJECT_REASON(-1, "Inconsistent search result"),

    /**
     * 自定义审核拒绝原因
     */
    CUSTOM_REJECT_REASON(0, "Custom reject reason"),

    /**
     * 税务局查询无结果
     */
    NO_SEARCH_RESULT(1, "Based on the provided document/information, no search result was found in the official business registration database."),

    /**
     * 税务局查询结果不一致
     */
    INCONSISTENT_SEARCH_RESULT(2, "The information found in the official business registration database is inconsistent with the provided document/information."),

    /**
     * 税号校验入参信息有误
     */
    INVALID_TAX_ID(3, "We couldn't verify your tax information. Make sure your tax information is correct."),

    /**
     * 请稍候重试
     */
    TAX_INTERFACE_ERROR(4, "Something went wrong. Please try again later."),


    /**
     * Fonoa报错 统一归类
     */
    ERROR_FROM_FONOA(100, "Error from Fonoa."),
    ;

    private final Integer code;
    private final String name;
}
