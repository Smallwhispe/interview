package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.impl;

import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.IdGenerateService;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client.IDGenerator;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.exception.IDGeneratorException;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;

import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2021/7/1
 **/
@Slf4j
@Service
public class IdGenerateServiceImpl implements IdGenerateService {

    @Autowired
    private IDGenerator idGenerator;

    private final static int MAX_CNT = 50;

    private static final int SUCC_CODE = 0;

    @Override
    public Long getId() {
        try {
            return idGenerator.gen();
        } catch (IDGeneratorException e) {
            throw new RuntimeException("id generator bad answer", e);
        }
    }

    @Override
    public List<Long> getIds(int cnt) {
        long start = System.currentTimeMillis();
        List<Long> res = Lists.newArrayList();
        while(cnt > MAX_CNT) {
            res.addAll(getPartIds(MAX_CNT));
            cnt -= MAX_CNT;
        }
        res.addAll(getPartIds(cnt));
        log.info("generateIds take:{} ms", System.currentTimeMillis() - start);
        if (res.size() < cnt) {
            log.error("generateIds wrong cnt: {}, res:{}", cnt, res);
            CgMonitorMetricRecorder.exceptionOneMetrics("generateIds_wrong_cnt_res", null, CgMetricsConstants.ServiceType.COMMON);
            throw new RuntimeException("generate Id error");
        }
        return res;
    }

    public List<Long> getPartIds(int cnt) {
        try {
            return idGenerator.genMulti(cnt);
        } catch (IDGeneratorException e) {
            throw new RuntimeException("id generator bad answer", e);
        }
    }
}
