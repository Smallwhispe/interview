package com.bytedance.cg.oversea.bytetax.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Slf4j
@Component
public class ExecuteTimeUtils {

    @Pointcut("@annotation(com.bytedance.cg.oversea.bytetax.common.utils.log.ExecuteTime)")
    public void serviceExecutionTimeLog() {
    }

    @Around(value = "serviceExecutionTimeLog()")
    public Object doAfter(ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        Object proceed = proceedingJoinPoint.proceed();
        long last = System.currentTimeMillis() - start;
        log.info("execution-time : [{}], class-method : [{}]",
                last,
                proceedingJoinPoint.getTarget().getClass().getName() + "." + proceedingJoinPoint.getSignature().getName());
        return proceed;
    }
}
