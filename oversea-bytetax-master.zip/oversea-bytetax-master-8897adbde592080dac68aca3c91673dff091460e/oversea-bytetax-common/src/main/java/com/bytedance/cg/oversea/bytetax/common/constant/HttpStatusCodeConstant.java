package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * bytedance
 * 2022/7/5 2:59 下午
 */
public interface HttpStatusCodeConstant {
    Integer SUCCESS = 200;
    Integer ACCEPTED = 202;
    Integer SERVER_NOT_UNDERSTAND_PARAMETER = 400;
    Integer PAGE_NOT_FOUND = 404;
    Integer INVALID_PARAM = 101;
}
