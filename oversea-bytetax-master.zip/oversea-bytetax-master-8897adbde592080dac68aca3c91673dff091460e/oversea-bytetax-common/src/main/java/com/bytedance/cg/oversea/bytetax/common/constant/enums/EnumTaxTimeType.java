package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 计税时点枚举
 * @author wangjian.2021
 * @date 2022/8/26
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxTimeType implements BaseIntEnum {

    /**
     * 消耗时间
     */
    CONSUME_TIME(1, "consume time"),
    /**
     * 账单生成时间
     */
    BILL_TIME(2, "bill time");

    private final Integer code;
    private final String name;
}
