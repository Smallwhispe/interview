package com.bytedance.cg.oversea.bytetax.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;

import java.math.BigDecimal;
import java.math.MathContext;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class DateUtil {
    private static final String UTC_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String UTC_END_STR = "Z";
    public static final String UTC_MILLI_DOT = ".";
    public static final Date DEFAULT_DATE = DateUtil.strToDate("2000-01-01 00:00:00");
    public static final Date NEW_DEFAULT_DATE = DateUtil.strToDate("2999-01-01 00:00:00");
    public static final DateTime DEFAULT_DATETIME = DateUtil.transByPatten("2000-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss");
    public static final DateTime NEW_DEFAULT_DATETIME = DateUtil.transByPatten("2999-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss");
    public static final String DEFAULT_PATTERN = "yyyy-MM-dd HH:mm:ss";
    public static final String QMQDATE_PATTERN = "MM-dd-yyyy HH:mm:ss";
    public static final String FILE_NAME_PATTERN = "yyyyMMddHHmmss";
    public static final String TASK_PATTERN = "yyyyMMddHH";
    public static final String SIMPLE_PATTERN = "yyyy-MM-dd";
    public static final String LONG_PATTERN = "yyyyMMdd";
    public static final String LONG_MONTH_PATTERN = "yyyyMM";
    /**
     * 毫秒
     */
    public final static long MS = 1;
    /**
     * 每秒钟的毫秒数
     */
    public final static long SECOND_MS = MS * 1000;
    /**
     * 每分钟的毫秒数
     */
    public final static long MINUTE_MS = SECOND_MS * 60;
    /**
     * 每小时的毫秒数
     */
    public final static long HOUR_MS = MINUTE_MS * 60;
    /**
     * 每天的毫秒数
     */
    public final static long DAY_MS = HOUR_MS * 24;


    private final static long SEC_IN_A_DAY = 24L * 3600 * 1000;

    public static Date decreaseDays(Date date, int days) {
        return new Date(date.getTime() - days * SEC_IN_A_DAY);
    }


    /**
     * timeStamp 转 date
     *
     * @param timeStamp
     * @return
     */
    public static Date timeStampToDateUTC0(Long timeStamp) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        log.info("simpleDateFormat.format(timeStamp) result: {}", simpleDateFormat.format(timeStamp));
        return strToDate(simpleDateFormat.format(timeStamp));
    }

    /**
     *
     * @param
     * @return
     */
    public static Date dateLocal2UTC0(Date date, int timeOffset) {
        if (date == null) {
            return null;
        }
        return timeStampToDateUTC0(date.getTime() - timeOffset * 1000);
    }

    public static String dateUTC02Local(Date date, int timeOffset) {
        if (date == null) {
            return null;
        }
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date.getTime() + timeOffset * 1000);
    }

    public static Date dateLocal2UTC0ConsiderDefaultDate(Date date, int timeOffset) {
        if (date != null && date.compareTo(NEW_DEFAULT_DATE) == 0) {
            return date;
        }
        return dateLocal2UTC0(date, timeOffset);
    }

    public static String dateUTC02LocalConsiderDefaultDate(Date date, int timeOffset) {
        if (date != null && date.compareTo(NEW_DEFAULT_DATE) == 0) {
            return dateUTC02Local(NEW_DEFAULT_DATE, 0);
        }
        return dateUTC02Local(date, timeOffset);
    }


    public static Date dateUTC02LocalDate(Date date, int timeOffset) {
        if (date == null) {
            return null;
        }
        return timeStampToDateUTC0(date.getTime() + timeOffset * 1000);
    }


    /**
     * LocalDateTime 转 date
     *
     * @param localDateTime
     * @return
     */
    public static Date localDateTime2Date(java.time.LocalDateTime localDateTime, ZoneId zoneId) {
        if (localDateTime == null) {
            return null;
        }
        return java.sql.Date.from(localDateTime.atZone(zoneId).toInstant());
    }

    /**
     * date 转 LocalDateTime
     *
     * @param date
     * @return
     */
    public static java.time.LocalDateTime date2LocalDateTime(Date date, ZoneId zoneId) {
        if (date == null) {
            return null;
        }
        return java.time.LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }

    /**
     * date 转换成字符串 ,格式:  yyyy-MM-dd HH:mm:ss
     *
     * @param date
     * @return String
     */
    public static String dateToStr(Date date) {
        return dateToStr(date, DEFAULT_PATTERN);
    }

    /**
     * Date转String，自定义格式
     *
     * @param date    java日期格式
     * @param pattern 格式串
     * @return 字符串
     */
    public static String dateToStr(Date date, String pattern) {
        LocalDateTime dateTime = new LocalDateTime(date);
        return dateTime.toString(pattern);
    }

    /**
     * String转Date，默认格式
     *
     * @param dateStr 日期字符串
     * @return Date
     */
    public static Date strToDate(String dateStr) {
        //如果字符串以Z结尾，使用utc格式转换
        if (dateStr.endsWith(UTC_END_STR)) {
            if (dateStr.contains(UTC_MILLI_DOT)) {
                dateStr = dateStr.substring(0, dateStr.indexOf(UTC_MILLI_DOT)) + UTC_END_STR;
            }
            return strToDate(dateStr, UTC_PATTERN);
        }
        return strToDate(dateStr, DEFAULT_PATTERN);
    }

    public static Long strToTimestamp(String dateStr) {
        if (dateStr == null) {
            return null;
        }
        Date date = strToDate(dateStr);
        return date == null ? null : date.getTime();
    }

    /**
     * String转Date，自定义格式
     *
     * @param dateStr 日期字符串
     * @param pattern 格式串
     * @return Date
     */
    public static Date strToDate(String dateStr, String pattern) {
        LocalDateTime dateTime = DateTimeFormat.forPattern(pattern).parseLocalDateTime(dateStr);
        return dateTime.toDate();
    }

    public static DateTime getLatestDateTime(List<DateTime> dateTimes) {
        dateTimes = dateTimes.stream().filter(Objects::nonNull)
                .sorted(DateTime::compareTo)
                .collect(Collectors.toList());
        if (dateTimes.isEmpty()) {
            log.error("wrong size {}", dateTimes);
            CgMonitorMetricRecorder.exceptionOneMetrics("wrong_size", null, CgMetricsConstants.ServiceType.COMMON);
            return null;
        }
        return dateTimes.get(dateTimes.size() - 1);
    }

    public static Date getLatestDate(List<Date> dates) {
        dates = dates.stream().filter(Objects::nonNull)
                .sorted(Date::compareTo)
                .collect(Collectors.toList());
        if (dates.isEmpty()) {
            log.info("wrong size {}", dates);
            return null;
        }
        return dates.get(dates.size() - 1);
    }

    public static DateTime getEarliestDateTime(List<DateTime> dateTimes) {
        dateTimes = dateTimes.stream().filter(Objects::nonNull)
                .sorted(DateTime::compareTo)
                .collect(Collectors.toList());
        if (dateTimes.isEmpty()) {
            log.error("wrong size {}", dateTimes);
            CgMonitorMetricRecorder.exceptionOneMetrics("wrong_size", null, CgMetricsConstants.ServiceType.COMMON);
            return null;
        }
        return dateTimes.get(0);
    }

    public static Date getEarliestDate(List<Date> dateTimes) {
        dateTimes = dateTimes.stream().filter(Objects::nonNull)
                .sorted(Date::compareTo)
                .collect(Collectors.toList());
        if (dateTimes.isEmpty()) {
            log.info("wrong size {}", dateTimes);
            return null;
        }
        return dateTimes.get(0);
    }

    public static DateTime strToDateTime(String dateStr, String pattern) {
        LocalDateTime dateTime = DateTimeFormat.forPattern(pattern).parseLocalDateTime(dateStr);
        return new DateTime(dateTime.toDate());
    }

    public static List<String> findDates(String dateType, Date dBegin, Date dEnd) throws Exception {
        List<String> listDate = new ArrayList<>();
        Calendar calBegin = Calendar.getInstance();
        calBegin.setTime(dBegin);
        Calendar calEnd = Calendar.getInstance();
        calEnd.setTime(dEnd);
        listDate.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calBegin.getTime()));
        while (calEnd.after(calBegin)) {
            switch (dateType) {
                case "M":
                    calBegin.add(Calendar.MONTH, 1);
                    break;
                case "D":
                    calBegin.add(Calendar.DAY_OF_YEAR, 1);
                    break;
                case "H":
                    calBegin.add(Calendar.HOUR, 1);
                    break;
                case "N":
                    calBegin.add(Calendar.SECOND, 1);
                    break;
            }
            if (calEnd.after(calBegin)) {
                listDate.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calBegin.getTime()));
            } else {
                listDate.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(calEnd.getTime()));
            }

        }
        return listDate;
    }

    /**
     * 格式 yyyy-MM-dd HH:mm:ss
     *
     * @param date 被格式化的日期
     * @return 格式化后的日期
     */
    public static String formatDateTime(Date date) {
        return new SimpleDateFormat(DEFAULT_PATTERN).format(date);
    }


    /**
     * 获取指定日期偏移指定时间后的时间
     *
     * @param date          基准日期
     * @param calendarField 偏移的粒度大小（小时、天、月等）使用Calendar中的常数
     * @param offset        偏移量，正数为向后偏移，负数为向前偏移
     * @return 偏移后的日期
     */

    public static String offsetDate(Date date, int calendarField, int offset) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(calendarField, offset);
        return formatDateTime(cal.getTime());
    }

    public static String getMonthlyOffsetStartTime(Date now, int offset) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(now);
        calendar.add(Calendar.MONTH, offset);
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return formatDateTime(calendar.getTime());
    }

    /**
     * 日期格式转换 20200826转成2020-08-26
     *
     * @param time
     * @return
     */
    public static String trans(Long time) {
        String dateStr = String.valueOf(time);
        if (StringUtils.isBlank(dateStr) || dateStr.length() != 8) {
            return null;
        }
        try {
            Date date = new SimpleDateFormat("yyyyMMdd").parse(dateStr);
            return new SimpleDateFormat("yyyy-MM-dd").format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Long trans(String str, String pattern) {
        return Long.parseLong(
                new DateTime(DateUtil.strToDate(str, pattern)).toString("yyyyMMdd"));
    }

    public static Long trans(String str, String fromPattern, String toPattern) {
        return Long.parseLong(
                new DateTime(DateUtil.strToDate(str, fromPattern)).toString(toPattern));
    }

    public static DateTime trans(String time) {
        try {
            return new DateTime(new SimpleDateFormat("yyyyMMdd").parse(time));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return new DateTime();
    }

    public static DateTime transByPatten(String time, String pattern) {
        try {
            return new DateTime(new SimpleDateFormat(pattern).parse(time));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return new DateTime();
    }

    /**
     * 计算天数差
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public static BigDecimal diffDays(Date startDate, Date endDate) {
        BigDecimal nd = new BigDecimal(1000 * 24 * 60 * 60, MathContext.DECIMAL128);
        // 获得两个时间的毫秒时间差异
        BigDecimal diff = new BigDecimal(endDate.getTime() - startDate.getTime(),MathContext.DECIMAL128);
        // 计算差多少天
        return diff.divide(nd,MathContext.DECIMAL128);
    }

    public static Long getSecondGap(DateTime startTime, DateTime endTime) {
        return (startTime.getMillis() - endTime.getMillis()) / 1000;
    }

    public static Date getDayAfterTomorrow() {
        Calendar start = Calendar.getInstance();
        start.set(Calendar.SECOND, 0);
        start.set(Calendar.MILLISECOND, 0);
        start.set(Calendar.HOUR_OF_DAY, 0);
        start.set(Calendar.MINUTE, 0);
        start.add(Calendar.DAY_OF_MONTH, 2);
        return start.getTime();
    }

    public static DateTime toDateTime(Long timestamp) {
        return timestamp == null ? null : new DateTime(timestamp);
    }
}


