package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxInfoType implements BaseIntEnum {
    /**
     * 主税号
     */
    MAIN_TAX_NO(1, "main tax no"),

    EXTRA_INFO(2, "extra info");

    private final Integer code;

    private final String name;

}
