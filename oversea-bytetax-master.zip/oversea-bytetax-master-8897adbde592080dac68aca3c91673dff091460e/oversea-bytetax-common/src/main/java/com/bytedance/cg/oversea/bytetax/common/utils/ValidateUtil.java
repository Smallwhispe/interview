package com.bytedance.cg.oversea.bytetax.common.utils;

/**
 * @author hanyuxiao
 * @date 2022/5/13
 **/
public class ValidateUtil {

    public static boolean validLong(Long l) {
        return l != null && l != 0;
    }
}
