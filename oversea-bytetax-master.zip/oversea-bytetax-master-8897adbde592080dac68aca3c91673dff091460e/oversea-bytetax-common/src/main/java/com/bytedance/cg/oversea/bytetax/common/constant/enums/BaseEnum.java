package com.bytedance.cg.oversea.bytetax.common.constant.enums;

/**
 * @author wangyong.1991
 * @version 创建时间：2020/12/17 2:33 PM
 */

public interface BaseEnum {
    Object getCode();

    Object getName();
}
