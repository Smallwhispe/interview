package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EnumActiveStatus implements BaseIntEnum {

    /**
     * 税号校验规则生效状态，默认生效Active
     * 两种方向的转化都允许：
     * Active -> Inactive
     * Inactive -> Active
     */
    ACTIVE(0, "active"),
    INACTIVE(1, "inactive");

    private Integer code;
    private String name;
}
