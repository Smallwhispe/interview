package com.bytedance.cg.oversea.bytetax.common.utils;

import com.bytedance.cg.common.exception.BizException;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * @author yangyl
 */
@Slf4j
public class ByteTaxThreadPoolExecutor extends ThreadPoolExecutor {

    public ByteTaxThreadPoolExecutor(int corePoolSize,
                                     int maximumPoolSize,
                                     long keepAliveTime,
                                     TimeUnit unit,
                                     BlockingQueue<Runnable> workQueue,
                                     ThreadFactory threadFactory,
                                     RejectedExecutionHandler handler) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue, threadFactory, handler);
    }

    @Override
    protected <T> RunnableFuture<T> newTaskFor(Runnable runnable, T value) {
        return newTaskFor(Executors.callable(runnable, value));
    }

    @Override
    public void execute(Runnable command) {
        super.execute(newTaskFor(command, null));
    }

    @Override
    protected <T> RunnableFuture<T> newTaskFor(Callable<T> callable) {
        long submitTime = System.currentTimeMillis();
        return super.newTaskFor(() -> {
            long startTime = System.currentTimeMillis();
            log.info("开始执行任务，等待 {}ms", startTime - submitTime);

            try {
                T ret = callable.call();
                log.info("任务执行结束，等待 {}ms，执行时间 {}ms", startTime - submitTime, System.currentTimeMillis() - startTime);
                return ret;
            } catch (Throwable t) {
                log.info("任务执行异常，等待 {}ms，执行时间 {}ms", startTime - submitTime, System.currentTimeMillis() - startTime);
                throw t;
            }
        });
    }

    public <T> List<T> batchSubmitAndGet(List<Callable<T>> callables, long timeout, TimeUnit unit) {
        if (CollectionUtils.isEmpty(callables)) {
            return Collections.emptyList();
        }

        List<Future<T>> futures = callables.stream()
                .filter(Objects::nonNull)
                .map(this::submit)
                .collect(Collectors.toList());

        List<T> ts = Lists.newArrayListWithCapacity(callables.size());
        for (Future<T> future : futures) {
            try {
                T t = future.get(timeout, unit);
                if (t != null) {
                    ts.add(t);
                }
            } catch (InterruptedException | ExecutionException | TimeoutException e) {
                log.info("batchSubmitAndGet error", e);
                throw new BizException(e.getMessage());
            }
        }

        return ts;
    }


}
