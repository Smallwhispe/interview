package com.bytedance.cg.oversea.bytetax.common.threadlocal;

import com.bytedance.cg.oversea.bytetax.common.tcc.TccConfig;
import com.bytedance.cg.oversea.bytetax.common.utils.StringUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author wangjian.2021
 * @date 2022/9/13
 **/
@Slf4j
@Aspect
@Component
public class ThreadLocalMethodAspect {

    @Autowired
    private TccConfig tccConfig;

    @Around("@annotation(threadLocalMethod)")
    public Object doThreadLocalMethod(ProceedingJoinPoint joinPoint, ThreadLocalMethod threadLocalMethod) throws Throwable {
        boolean needTccGrayRateKey = StringUtil.isNotBlank(threadLocalMethod.tccGrayRateKey());
        try {
            if (needTccGrayRateKey) {
                boolean val = tccConfig.checkAimGray(threadLocalMethod.tccGrayRateKey());
                ThreadLocalContext.setTccGrayResThreadLocalVal(threadLocalMethod.tccGrayRateKey(), val);
            }
            return joinPoint.proceed();
        } finally {
            if (needTccGrayRateKey) {
                ThreadLocalContext.removeTccGrayResThreadLocalVal();
            }
        }
    }
}
