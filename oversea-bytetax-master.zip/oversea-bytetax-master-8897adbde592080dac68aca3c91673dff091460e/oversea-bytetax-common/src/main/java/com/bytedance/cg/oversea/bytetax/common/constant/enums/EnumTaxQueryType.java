package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * bytedance
 * 2022/3/14 4:36 下午
 */
@Getter
@AllArgsConstructor
public enum EnumTaxQueryType implements BaseIntEnum{
    /**
     *  时间点查询
     */
    POINT(1, "包含该时间点"),
    /**
     *  时间段查询
     */
    SEGMENT(2, "在时间点之后的所有时间段");

    private final Integer code;
    private final String name;

}
