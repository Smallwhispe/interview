package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author wangjian.2021
 * @date 2022/6/14
 **/
@Getter
@AllArgsConstructor
public enum EnumAsyncTaskStatus implements BaseIntEnum {

    INIT(1, "初始化"),
    CALCULATING(2, "计算中"),
    SUCCESS(3, "成功"),
    FAIL(4, "失败"),
    ;

    private Integer code;
    private String name;
}
