package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2022/5/10
 **/
@Getter
@AllArgsConstructor
public enum EnumCountryType implements BaseIntStringEnum {
    /**
     *  加拿大
     */
    CA(1, "加拿大"),
    /**
     *  计算
     */
    OTHER(2, "其他");

    private final Integer code;
    private final String name;
}
