package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client;

import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.exception.IDGeneratorException;

import java.io.IOException;
import java.util.List;

public interface IDGenerator {

  Long gen() throws IDGeneratorException, IDGeneratorException;

  List<Long> genMulti(int count) throws IDGeneratorException;

  void close() throws IOException;

}