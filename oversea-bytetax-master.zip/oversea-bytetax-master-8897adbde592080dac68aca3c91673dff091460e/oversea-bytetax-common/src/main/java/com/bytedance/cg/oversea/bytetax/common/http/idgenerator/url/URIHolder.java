package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.url;

import java.net.URI;

public interface URIHolder {

  URI selectUri();

}
