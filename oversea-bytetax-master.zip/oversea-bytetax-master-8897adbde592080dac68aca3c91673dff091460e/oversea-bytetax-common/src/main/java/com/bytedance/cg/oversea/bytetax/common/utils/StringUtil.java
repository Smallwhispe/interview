package com.bytedance.cg.oversea.bytetax.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author hongyu.rhett
 * @date 2021/3/31
 */
public class StringUtil extends StringUtils {
    /**
     * Match underline format
     */
    private static Pattern pattern = Pattern.compile("_(\\w)");


    public static String underLineToCamel(String source) {
        Matcher matcher = pattern.matcher(source);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            matcher.appendReplacement(sb, matcher.group(1).toUpperCase());
        }
        matcher.appendTail(sb);
        return sb.toString();
    }
}
