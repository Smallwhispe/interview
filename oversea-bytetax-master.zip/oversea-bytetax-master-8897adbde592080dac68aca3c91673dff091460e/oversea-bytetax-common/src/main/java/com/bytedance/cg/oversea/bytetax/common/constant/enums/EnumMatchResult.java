package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 规则匹配结果
 * @author:
 * @date:
 */
@Getter
@AllArgsConstructor
public enum EnumMatchResult implements BaseIntEnum {

    MATCH(1, "规则匹配有结果"),
    NOT_MATCH(0, "规则匹配无结果"),
    MATCH_HISTORY(2, "规则匹配历史时间"),
    MATCH_WHITE(3, "规则匹配白名单"),
    BIZ_NOT_VALID(4, "业务线绑定国家未生效")
    ;

    private Integer code;
    private String name;


    public boolean checkNeedWhitelistEnhanced() {
        return this.equals(EnumMatchResult.BIZ_NOT_VALID) || this.equals(EnumMatchResult.NOT_MATCH) || this.equals(EnumMatchResult.MATCH_WHITE);
    }
}
