package com.bytedance.cg.oversea.bytetax.common.utils;

import com.alibaba.fastjson.JSON;
import com.bytedance.cg.common.exception.BizException;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

/**
 * @author yangyl
 * @description
 * @create 2020-06-12 13:19
 */
@Slf4j
public class JsonUtil {

    private static final ObjectMapper OBJECT_MAPPER;

    static {
        OBJECT_MAPPER = new ObjectMapper();
        OBJECT_MAPPER.setVisibility(PropertyAccessor.GETTER, JsonAutoDetect.Visibility.NONE);
        OBJECT_MAPPER.setVisibility(PropertyAccessor.SETTER, JsonAutoDetect.Visibility.NONE);
        OBJECT_MAPPER.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        OBJECT_MAPPER.setVisibility(PropertyAccessor.IS_GETTER, JsonAutoDetect.Visibility.NONE);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        OBJECT_MAPPER.setTimeZone(TimeZone.getTimeZone("GMT+0"));
        OBJECT_MAPPER.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss") {
            @Override
            public Date parse(String source) throws ParseException {
                return DateUtil.strToDate(source);
            }
        });
    }

    public static String writeValueAsString(Object obj) {
        if (obj == null) {
            return null;
        }

        try {
            return OBJECT_MAPPER.writeValueAsString(obj);
        } catch (Exception e) {
            log.warn(e.getMessage(), e);
        }

        return "";
    }

    public static<T> T convertValue(Map<String, Object> map, Class<T> clazz) {
        return OBJECT_MAPPER.convertValue(map, clazz);
    }

    public static <T> T readValue(String json, Class<T> clazz) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return OBJECT_MAPPER.readValue(json, clazz);
        } catch (Exception e) {
            log.warn("json: {}, err_msg: {}", json, e.getMessage(), e);
            throw new BizException("json解析数据异常");
        }
    }

    public static <T> T readValue(String json, TypeReference<?> typeReference) {
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return OBJECT_MAPPER.readValue(json, typeReference);
        } catch (Exception e) {
            log.warn("json: {}, err_msg: {}", json, e.getMessage(), e);
            throw new BizException("json解析数据异常");
        }
    }

    public static <T> List<T> unmarshalArray(String json, Class<T> clazz){
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return JSON.parseArray(json, clazz);
        } catch (Exception e) {
            log.warn("json: {}, err_msg: {}", json, e.getMessage(), e);
            throw new BizException("json解析数据异常");
        }
    }

    public static <T> List<T> unmarshalArrayWithoutException(String json, Class<T> clazz){
        if (StringUtils.isEmpty(json)) {
            return null;
        }
        try {
            return JSON.parseArray(json, clazz);
        } catch (Exception e) {
            log.warn("json: {}, err_msg: {}", json, e.getMessage(), e);
            return null;
        }
    }

    public static <T> List<T> unmarshalFromString2List(String json, Class<T> targetClass)  {
        try {
            return OBJECT_MAPPER.readValue(json, OBJECT_MAPPER.getTypeFactory().constructCollectionType(List.class,
                    targetClass));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
