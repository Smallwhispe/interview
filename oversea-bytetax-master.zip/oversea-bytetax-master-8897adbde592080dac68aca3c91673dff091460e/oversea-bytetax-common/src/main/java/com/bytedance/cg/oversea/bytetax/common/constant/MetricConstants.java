package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * @author zhuxiaoqiang
 * @date 2021-06-15 4:56 下午
 */
public class MetricConstants {

    public static class Tag {
        public final static String PSM_CONSTANT = "psm";

        public final static String ENV_CONSTANT = "env";

        public final static String LOG_ID = "log_id";

        public final static String MATCH_RULE_ID = "match_rule_id";

        public final static String MATCH_AMOUNT = "match_amount";

        public final static String SUCCESS = "success";

        public final static String PATH = "path";

        public final static String STATUS_CODE = "status_code";


        public final static String MATCH_RESULT = "match_result";

        public final static String COUNTRY = "country";

        public final static String CALLER = "caller";

        public final static String BIZ_LINE = "biz_line";

        public final static String TRANSACTION_CATEGORY = "transaction_category";

        public final static String RULE_MATCH_ID = "RULE_MATCH_ID";

        public final static String SUBJECT_ID = "subject_id";

        public final static String CUSTOMER_COUNTRY = "customer_country";

        public final static String ABNORMAL_QUANTITY = "abnormal_quantity";

    }

    public static final String BYTETAX_BIZ_MATCH_RESULT = "bytetax_biz_match_result";

    public static final String TRANSACTION = "transaction";

    public static final String TAX_SEGMENT_QUERY = "tax_segment_query";

    public static final String HTTP_METRICS_COUNTER = "bytetax_http_metrics_counter";

    public static final String HTTP_METRICS_TIMER = "bytetax_http_metrics_timer";

    public static final String CHECK_TAX_NO_TIMER = "check_tax_no_timer";

    public static final String CHECK_TAX_NO_COUNTER = "check_tax_no_counter";

    // 税号校验结果埋点
    public static final String BYTETAX_TAX_NO_MATCH_RESULT = "bytetax_tax_no_match_result";

    public static final String BIZ_ID = "bytetax_business_id";

    public static final String SUBJECT_ID = "bytetax_subject_id";

    public static final String ADDRESS_ZERO = "bytetax_address1";


}
