package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EnumOperatorType implements BaseIntEnum {

    SAVE(1, "save"),
    UPDATE(2, "update"),
    DELETE(3, "delete"),
    ;

    private Integer code;
    private String name;
}
