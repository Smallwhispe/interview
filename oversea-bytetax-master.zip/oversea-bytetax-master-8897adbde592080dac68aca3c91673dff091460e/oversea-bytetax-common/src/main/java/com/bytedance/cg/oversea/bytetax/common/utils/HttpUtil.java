package com.bytedance.cg.oversea.bytetax.common.utils;

import com.bytedance.cg.oversea.bytetax.common.constant.MetricConstants;
import com.bytedance.http.client.impl.HttpClientViaPublicNet;
import com.google.common.collect.Maps;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author hanyuxiao
 * @date 2023/6/14
 **/
public class HttpUtil {

    public CloseableHttpResponse response;

    public static CloseableHttpResponse executeByEnv(CloseableHttpClient client, HttpUriRequest request, String tagPath, Boolean debug) throws RuntimeException, IOException {
        CloseableHttpResponse response;
        if (Boolean.TRUE.equals(debug)) {
            response = client.execute(request);
        } else if (!(client instanceof HttpClientViaPublicNet)){
            throw new RuntimeException("http client type error");
        } else {
            HttpClientViaPublicNet net = (HttpClientViaPublicNet) client;
            response = HttpUtil.execute(net, request, tagPath);
        }
        return response;
    }

    private static CloseableHttpResponse execute(CloseableHttpClient net, HttpUriRequest request, String pathTag) throws IOException {
        long startTime = System.currentTimeMillis();
        CloseableHttpResponse rsp = null;
        boolean success = false;
        try {
             rsp = net.execute(request);
             success = true;
        } finally {
            final CloseableHttpResponse finalRsp = rsp;
            boolean finalSuccess = success;
            ThreadPools.COMMON.execute(() -> addMetrics(System.currentTimeMillis() - startTime, finalRsp,
                    pathTag, finalSuccess));
        }
        return rsp;
    }

    private static void addMetrics(long time,CloseableHttpResponse rsp, String tagPath, boolean success) {
        Map<String, String> tag = Maps.newHashMap();
        tag.put(MetricConstants.Tag.SUCCESS, String.valueOf(success));
        tag.put(MetricConstants.Tag.PATH, tagPath);
        tag.put(MetricConstants.Tag.STATUS_CODE, (rsp == null || rsp.getStatusLine() == null) ? ""
                : String.valueOf(rsp.getStatusLine().getStatusCode()));
        MetricUtil.addCountWithTag(MetricConstants.HTTP_METRICS_COUNTER, 1, tag);
        MetricUtil.addTimerWithTag(MetricConstants.HTTP_METRICS_TIMER, time, TimeUnit.MILLISECONDS, tag);
    }
}
