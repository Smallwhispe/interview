package com.bytedance.cg.oversea.bytetax.common.tcc;

import com.bytedance.cg.oversea.bytetax.common.dto.TaxNoParameterDTO;
import com.bytedance.cg.oversea.bytetax.common.threadlocal.ThreadLocalContext;
import com.bytedance.cg.oversea.bytetax.common.utils.JsonUtil;
import com.bytedance.data.tcc.client.spring.DynamicConfig;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * @author wangjian.2021
 * @date 2022/9/7
 **/
@Slf4j
@Component
@Data
public class TccConfig {

    private static final String PSM = "cg.oversea_bytetax.config";

    public static final String TAX_TIME_TYPE = "taxTimeType";

    public static final String GRAY_NOTICE = "GrayNotice";

    public static final String SWITCH_SINGLE = "switchTaxNoCheckSingle";

    private static Random random = new Random();

    @DynamicConfig(name = PSM, key = "gray_rate")
    private String grayRate;

    @DynamicConfig(name = PSM, key = "bi_country_list")
    private String biCountryList;

    @DynamicConfig(name = PSM, key = "new_tax_type_lark_list")
    private String newTaxTypeLarkList;

    @DynamicConfig(name = PSM, key = "avalara_error_code_list")
    private String avalaraErrorCodeList;

    @DynamicConfig(name = PSM, key = "tax_no_parameter")
    private String taxNoParameter;

    /**
     * 判断是否命中灰度.(相同线程结果保持一致)
     * @param key
     * @return
     */
    public boolean checkAimGray(String key) {
        try {
            Boolean threadVal = ThreadLocalContext.getTccGrayResThreadLocalVal(key);
            if (threadVal != null) {
                return threadVal;
            }
            Map<String, Number> record = JsonUtil.readValue(grayRate, Map.class);
            Double aimVal = Double.valueOf(record.getOrDefault(key, 0D).toString());
            log.info("tcc get success");
            return random.nextDouble() <= aimVal;
        } catch (Exception e) {
            log.error("tcc grayRate key {} get fail.", key, e);
            CgMonitorMetricRecorder.exceptionOneMetrics("tcc_grayRate_key_get_fail", e, CgMetricsConstants.ServiceType.COMMON);
            return false;
        }
    }

    /**
     * 是否切换单次
     * @param key
     * @return
     */
    public boolean switchSingle(String key) {
        try {
            Map<String, Number> record = JsonUtil.readValue(grayRate, Map.class);
            Number aimVal = record.getOrDefault(key, 0);
            log.info("tcc get success");
            return aimVal.intValue() == 0;
        } catch (Exception e) {
            log.error("tcc grayRate key {} get fail.", key, e);
            CgMonitorMetricRecorder.exceptionOneMetrics("tcc_grayRate_key_get_fail", e, CgMetricsConstants.ServiceType.COMMON);
            return false;
        }
    }

    public List<String> getBICountryList() {
        return JsonUtil.readValue(biCountryList, new TypeReference<List<String>>(){});
    }

    public Set<String> getAvalaraErrorCodeList() {
        return Sets.newHashSet(avalaraErrorCodeList.split(","));
    }

    public List<TaxNoParameterDTO> getTaxNoParameter() {
        log.info("Get tax no parameter,{}.", taxNoParameter);
        TaxNoParameterDTO taxNoParameterDTO = new TaxNoParameterDTO();
        taxNoParameterDTO.setCountryList(Lists.newArrayList());
        List<TaxNoParameterDTO> taxNoParameterDTOS = Lists.newArrayList(taxNoParameterDTO);
        try {
            taxNoParameterDTOS = JsonUtil.readValue(taxNoParameter, new TypeReference<List<TaxNoParameterDTO>>(){});
        } catch (Exception e) {
            log.error("Tcc getTaxNoParameter failed!", e);
            CgMonitorMetricRecorder.exceptionOneMetrics("Tcc_getTaxNoParameter_failed", e, CgMetricsConstants.ServiceType.COMMON);
        }
        return taxNoParameterDTOS;
    }
}
