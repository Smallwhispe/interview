package com.bytedance.cg.oversea.bytetax.common.dto;

import lombok.Data;

import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 2024/03/15 4:48 PM
 */
@Data
public class TaxNoParameterDTO {

    private String parameterInCamel;

    private String parameterWithDash;

    private List<String> countryList;
}
