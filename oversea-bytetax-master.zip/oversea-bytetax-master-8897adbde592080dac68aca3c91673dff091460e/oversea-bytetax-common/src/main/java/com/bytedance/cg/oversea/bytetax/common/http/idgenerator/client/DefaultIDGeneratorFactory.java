package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client;

import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery.ConsulDiscoveryRegister;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.property.IdGeneratorProperties;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.url.ListenerURIHolder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

public class DefaultIDGeneratorFactory implements IDGeneratorFactory {

  private static final Logger logger = LoggerFactory.getLogger(DefaultIDGeneratorFactory.class);

  private static final String PSM_ID_GENERATOR = "toutiao.webarch.idgenerator_proxy";

  private ConsulDiscoveryRegister consulDiscoveryRegister;

  private String psm;

  private ListenerURIHolder uriHolder;

  private IdGeneratorProperties idGeneratorProperties;

  public DefaultIDGeneratorFactory(ConsulDiscoveryRegister consulDiscoveryRegister,
                                   String psm, IdGeneratorProperties properties) {
    this.consulDiscoveryRegister = consulDiscoveryRegister;
    this.psm = psm;
    this.idGeneratorProperties = properties;
    String idGeneratorPsm =
        StringUtils.isEmpty(this.idGeneratorProperties.getIdGeneratorPsm()) ? PSM_ID_GENERATOR
            : this.idGeneratorProperties.getIdGeneratorPsm();
    this.uriHolder = new ListenerURIHolder(idGeneratorPsm);
    this.consulDiscoveryRegister.register(idGeneratorPsm, uriHolder);
  }

  @Override
  public IDGenerator createIDGenerator(String nameSpace, String counterSpace) {
    return DefaultIDGenerator.builder().setPsm(psm).setNameSpace(nameSpace)
        .setCounterSpace(counterSpace).setUriHolder(uriHolder)
        .setIdGeneratorProperties(idGeneratorProperties).build();
  }


}
