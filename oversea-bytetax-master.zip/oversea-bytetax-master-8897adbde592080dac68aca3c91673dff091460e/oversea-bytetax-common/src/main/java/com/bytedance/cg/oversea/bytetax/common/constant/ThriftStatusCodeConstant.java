package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * bytedance
 * 2022/7/5 2:59 下午
 */
public interface ThriftStatusCodeConstant {
    Integer SUCCESS = 0;
    Integer DEFAULT_BIZ_E = -500;
    Integer DEFAULT_THRIFT_E = 2;
    Integer DEFAULT_UNKNOWN = -999;
    Integer DEFAULT_OTHER_EXE = 1;


    Integer ERROR_FROM_AVA = -501;
}
