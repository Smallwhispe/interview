package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client;

public interface IDGeneratorFactory {

  IDGenerator createIDGenerator(String nameSpace, String counterSpace);

}
