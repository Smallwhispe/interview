package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * RPC返回状态枚举
 * @author wangjian.2021
 */
@Getter
@AllArgsConstructor
public enum EnumRpcResult implements BaseIntEnum {

    /**
     *
     */
    SUCCESS(0, "SUCCESS"),
    ERR_SERVICE_INTERNAL(-1, "啊哦，服务器打瞌睡了"),
    ERR_PARAM(-2, "参数不合法"),

    ERR_BIZ_NOT_EXIST(-3, "业务线绑定国家不存在"),
    ERR_BIZ_RULE(-4, "业务规则校验未通过"),
    ERR_DEPEND_SERVICE(-5, "依赖服务异常"),
    ERR_MATCH_MORE_ONE_RULE(-6, "匹配到不止一条规则"),
    ERR_SUBJECT_DUPLICATRED(-7, "主体重复了"),
    ERR_ITEM_TOO_MANY(-8, "税种和商品命中多条"),
    ERR_DUP_RECORDED(-9, "交易已经记录"),
    ERR_BIZ_TIME_RULE(-10, "业务线生效时间校验未通过")
    ;

    private final Integer code;
    private final String name;
}
