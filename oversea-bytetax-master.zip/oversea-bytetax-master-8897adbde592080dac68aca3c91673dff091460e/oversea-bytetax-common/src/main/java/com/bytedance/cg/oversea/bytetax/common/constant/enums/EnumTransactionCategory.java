package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

/**
 * @author hanyuxiao
 * @date 2022/1/13
 **/
@Getter
@AllArgsConstructor
public enum  EnumTransactionCategory implements BaseIntEnum {
    /**
     * 试算
     */
    SALES_ORDER(1, "SalesOrder"),

    /**
     * 正向开票
     */
    SALES_INVOICE(2, "SalesInvoice"),

    /**
     * 负向开票
     */
    SALES_CREDIT_NOTE(3, "PurchaseInvoice");

    private final Integer code;
    private final String name;

    public boolean needTaxReport() {
        return NEED_REPORT.contains(this);
    }

    public static List<EnumTransactionCategory> NEED_REPORT = Lists.newArrayList(EnumTransactionCategory.SALES_CREDIT_NOTE, EnumTransactionCategory.SALES_INVOICE);

}
