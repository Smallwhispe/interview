package com.bytedance.cg.oversea.bytetax.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author zhuxiaoqiang
 * @date 2021-06-01 9:40 下午
 */
@Component
@Slf4j
public class MetricUtil implements ApplicationContextAware {

    private static MetricService metricService;

    public static void addCount(String key) {
        addCount(key, 1L);
    }

    public static void addCount(String key, long value) {
        addCountWithTag(key, value, null);
    }

    public static void addTimerWithTag(String key, long time, TimeUnit timeUnit, Map<String, String> tagMap) {
        try {
            metricService.addTimerWithTag(key, time, timeUnit, tagMap);
        } catch (Exception e) {
            log.error("metrics error", e);
            CgMonitorMetricRecorder.exceptionOneMetrics("metrics_error", e, CgMetricsConstants.ServiceType.COMMON);
        }
    }

    public static void addCountWithTag(String name, long value, Map<String, String> tagMap) {
        try {
            metricService.addCountWithTag(name, value, tagMap);
        } catch (Exception e) {
            log.error("metrics error", e);
            CgMonitorMetricRecorder.exceptionOneMetrics("metrics_error", e, CgMetricsConstants.ServiceType.COMMON);
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        metricService = applicationContext.getBean(MetricService.class);
    }

    public interface MetricService {
        void addCountWithTag(String name, long value, Map<String, String> tagMap);

        void addTimerWithTag(String name, long value, TimeUnit timeUnit, Map<String, String> tagMap);
    }
}
