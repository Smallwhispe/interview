package com.bytedance.cg.oversea.bytetax.common.constant.enums;


import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public enum EnumTaxNoAPIRules implements BaseIntEnum{


    /**
     * 欧盟API校验 （vies）
     */
    EU_API_SOURCE(1, "EU API source", EnumAsync.SYNC),

    /**
     * 英国API校验
     */
    GB_API_SOURCE(2, "UK API source", EnumAsync.SYNC),

    /**
     * Fonoa API
     */
    FONOA_API_SOURCE(3, "Fonoa API source", EnumAsync.ASYNC),

    /**
     * BI API
     */
    BI_API_SOURCE(4, "BI API source", EnumAsync.ASYNC),
    ;

    private final Integer code;
    private final String name;
    private final EnumAsync async;

    public static final List<EnumTaxNoAPIRules> ASYNC_CHECKABLE_SOURCE_LIST = Lists.newArrayList(EnumTaxNoAPIRules.FONOA_API_SOURCE);

    @Getter
    @AllArgsConstructor
    public enum EnumAsync implements BaseIntEnum{
        /**
         * 异步
         */
        ASYNC(1, "async"),
        /**
         * 同步
         */
        SYNC(2, "sync");
        private final Integer code;
        private final String name;
    }
}
