package com.bytedance.cg.oversea.bytetax.common.utils;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.write.metadata.WriteSheet;
import com.bytedance.cg.oversea.bytetax.common.CustomCellWriteWeightConfig;
import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @Author: yangyl
 * @Date: 2021/4/15 8:43 下午
 */
@Slf4j
public class ExcelUtil {

    public static <T> void readFirstSheet2Model(InputStream is, Class<T> tClass, AnalysisEventListener<T> listener) {
        EasyExcel.read(is, tClass, listener).sheet().doRead();
    }

    public static <T> byte[] toExcel(List<T> data) {
        if (CollectionUtils.isEmpty(data)) {
            return null;
        }
        ByteArrayOutputStream output = new ByteArrayOutputStream();

        EasyExcel.write(output, data.get(0).getClass())
                .registerWriteHandler(new CustomCellWriteWeightConfig())
                .sheet(0, ConstantValue.DEFAULT_EXCEL_SHEET_NAME)
                .doWrite(data);

        return output.toByteArray();
    }

    public static <T> byte[] toExcel(Map<String, List<T>> dataMap, List<String> sheetNames, Class<T> clazz) {
        if (MapUtils.isEmpty(dataMap) || CollectionUtils.isEmpty(sheetNames)) {
            return null;
        }
        List<String> validSheetNames = sheetNames.stream().distinct().collect(Collectors.toList());
        log.info("valid sheet names: {}", JsonUtil.writeValueAsString(validSheetNames));
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        ExcelWriter excelWriter = EasyExcel.write(output).registerWriteHandler(new CustomCellWriteWeightConfig()).build();
        int sheetIndex = 0;
        for (String curSheetName : validSheetNames) {
            if (StringUtils.isEmpty(curSheetName)) {
                continue;
            }
            log.info("sheet name: {}", curSheetName);
            List<T> curData = dataMap.getOrDefault(curSheetName, new ArrayList<T>());
            WriteSheet sheet = EasyExcel.writerSheet(sheetIndex, curSheetName).head(clazz).build();
            excelWriter.write(curData, sheet);
            ++sheetIndex;
        }
        excelWriter.finish();
        return output.toByteArray();
    }

    public static <T> List<T> read(InputStream is, Class<T> header) {
        return EasyExcel.read(is)
                .head(header)
                .sheet()
                .doReadSync();
    }

}
