package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 枚举值 计税对象
 * */
@Getter
@AllArgsConstructor
public enum EnumTaxationParty implements BaseIntEnum {


    //    开票主体
    BILL_TO_PARTY(1, "bill to party"),
    //    合同主体
    CONTRACT_SIGNING_PARTY(2, "contract signing party"),
    ;

    private Integer code;
    private String name;
}
