package com.bytedance.cg.oversea.bytetax.common.constant;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.BaseIntEnum;
import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

/**
 * @author
 * @date 2022/1/13
 **/
@Getter
@AllArgsConstructor
public enum EnumTransactionAction implements BaseIntEnum {
    /**
     * 提交报税
     */
    COMMIT(1, "COMMIT"),

    /**
     * 废弃
     */
    VOID(2, "VOID");

    private final Integer code;
    private final String name;

}
