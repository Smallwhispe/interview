package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 是否最新记录
 * @author:
 * @date:
 */
@Getter
@AllArgsConstructor
public enum EnumHead implements BaseIntEnum {

    HEAD_FIRST(1, "最新记录"),
    HEAD_NOT_FIRST(2, "历史记录"),
    ;

    private Integer code;
    private String name;
}
