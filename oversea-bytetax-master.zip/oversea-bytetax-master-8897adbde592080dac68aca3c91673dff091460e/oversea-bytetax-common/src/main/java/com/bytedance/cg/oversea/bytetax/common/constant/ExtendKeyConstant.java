package com.bytedance.cg.oversea.bytetax.common.constant;

import java.util.Map;

/**
 * @author wangjian.2021
 * @date 2022/9/20
 **/
public class ExtendKeyConstant {

    /**
     * 消耗时间key
     */
    public static final String NEED_CONSUME_TIME_TAX = "needConsumeTimeTax";


    public static boolean checkNeedConsumeTimeTax(Map<String, String> extend) {
        return extend != null && "1".equals(extend.getOrDefault(NEED_CONSUME_TIME_TAX, ""));
    }
}
