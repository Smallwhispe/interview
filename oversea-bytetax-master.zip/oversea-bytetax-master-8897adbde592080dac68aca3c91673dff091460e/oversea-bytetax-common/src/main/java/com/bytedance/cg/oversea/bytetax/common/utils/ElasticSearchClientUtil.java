package com.bytedance.cg.oversea.bytetax.common.utils;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.sniff.ConsulNodesSniffer;
import org.elasticsearch.client.sniff.NodesSniffer;
import org.elasticsearch.client.sniff.SniffOnFailureListener;
import org.elasticsearch.client.sniff.Sniffer;

/**
 * @author mutual
 * @date 2022/9/25 4:48 下午
 */
//@Profile({"prod-sg", "boe-va", "dev", "boe-prod"})
public class ElasticSearchClientUtil {

    // BOE 环境的 search.es.common 集群
    public static RestHighLevelClient forConnectToNonSecurityCluster(String psm, String cluster) {
        SniffOnFailureListener listener = new SniffOnFailureListener();

        RestHighLevelClient client = new RestHighLevelClient(RestClient.builder(psm, cluster).setFailureListener(listener));

        NodesSniffer nodesSniffer = new ConsulNodesSniffer(client.getLowLevelClient());
        Sniffer sniffer = Sniffer.builder(client.getLowLevelClient()).setNodesSniffer(nodesSniffer).build();
        listener.setSniffer(sniffer);

        return client;
    }

}
