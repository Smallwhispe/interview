package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.url;


import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery.ConsulDiscoveryRegister;
import com.orbitz.consul.model.lookup.Endpoint;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class ListenerURIHolder implements ConsulDiscoveryRegister.ConsulListener, URIHolder {

  private static final Logger logger = LoggerFactory.getLogger(ListenerURIHolder.class);

  private transient URI[] uris = new URI[0];

  private final AtomicInteger counter;

  private String consulName;

  private transient List<Endpoint> oldEndPoints;

  public ListenerURIHolder(String name) {
    this.consulName = Objects.requireNonNull(name);
    counter = new AtomicInteger(0);
  }


  @Override
  public void onUpdate(final List<Endpoint> endpoints) {
    if (CollectionUtils.isEmpty(endpoints)) {
      logger.warn("IDGenerator psm has no endpoints: {}", consulName);
      return;
    }
    if (oldEndPoints != null && CollectionUtils.isEqualCollection(oldEndPoints, endpoints)) {
      return;
    }
    logger.info("IDGenerator consulName:{} update {} endpoints", consulName, endpoints.size());

    this.oldEndPoints = endpoints;
    List<String> uriList = new ArrayList<>();

    for (Endpoint endpoint : endpoints) {
      uriList.add("http://" + getHost4URL(endpoint.getHost()) + ":" + endpoint.getPort());
    }

    URI[] tempUris = uriList.stream().map(URI::create).toArray(URI[]::new);
    uris = Arrays.stream(tempUris).filter(Objects::nonNull)
        .map(this::normalizeURI).toArray(URI[]::new);
  }

  private URI normalizeURI(URI uri) {
    String url = Objects.requireNonNull(uri).toString();
    if (!StringUtils.endsWith(url, "/")) {
      return URI.create(url + "/");
    } else {
      return uri;
    }
  }

  public static String getHost4URL(String originHost) {
    if (originHost.indexOf(':') >= 0 && !originHost.startsWith("[")) {
      return "[" + originHost + "]";
    }
    return originHost;
  }

  @Override
  public URI selectUri() {
    URI[] tempUris = uris;
    return tempUris[counter.getAndIncrement() % tempUris.length];
  }

}
