package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Getter
@AllArgsConstructor
public enum EnumCollectConfig implements BaseIntEnum {
    /**
     * 不需要收集
     */
    NO_NEED(1, "hide"),
    /**
     * 可填可不填
     */
    OPTIONAL(2, "optional"),
    /**
     * 必须搜集
     */
    REQUIRED(3, "required");

    private final Integer code;

    private final String name;

}
