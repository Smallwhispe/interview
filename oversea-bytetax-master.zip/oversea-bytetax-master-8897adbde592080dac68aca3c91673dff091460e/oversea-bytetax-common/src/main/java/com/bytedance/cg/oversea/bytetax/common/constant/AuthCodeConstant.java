package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * @author hanyuxiao
 * @date 2022/9/9
 **/
public class AuthCodeConstant {

    public static final String COMPANY_REGISTRATION_READ = "bytetax.company.read";

    public static final String COMPANY_REGISTRATION_WRITE = "bytetax.company.write";

    public static final String EXEMPTION_READ = "bytetax.exemption.read";

    public static final String EXEMPTION_DOWNLOAD = "bytetax.exemption.download";

    public static final String EXEMPTION_WRITE = "bytetax.exemption.write";

    public static final String TRANSACTIONS_READ = "bytetax.transactions.read";

    public static final String TRANSACTIONS_DOWNLOAD = "bytetax.transactions.download";

    public static final String RETURNS_DOWNLOAD = "bytetax.returns.download";

    public static final String RETURNS_WRITE = "bytetax.returns.write";

    public static final String RETURNS_READ = "bytetax.returns.read";

    public static final String CALCULATOR_READ = "bytetax.calculator.read";

    public static final String AUTHORITY_READ = "bytetax.authority.read";

    public static final String AUTHORITY_DOWNLOAD = "bytetax.authority.download";

    public static final String AUTHORITY_WRITE = "bytetax.authority.write";

    public static final String ITEM_READ = "bytetax.item.read";

    public static final String ITEM_DOWNLOAD = "bytetax.item.download";

    public static final String ITEM_WRITE = "bytetax.item.write";

    public static final String TAX_CODE_READ = "bytetax.category.read";

    public static final String TAX_CODE_DOWNLOAD = "bytetax.category.download";

    public static final String TAX_CODE_WRITE = "bytetax.category.write";

    public static final String RULE_READ = "bytetax.rule.read";

    public static final String RULE_DOWNLOAD = "bytetax.rule.download";

    public static final String RULE_WRITE = "bytetax.rule.write";

    public static final String BIZ_READ = "bytetax.biz.read";

    public static final String BIZ_DOWNLOAD = "bytetax.biz.download";

    public static final String BIZ_WRITE = "bytetax.biz.write";

    public static final String TAX_RATE_WAY_READ = "bytetax.way.read";

    public static final String TAX_RATE_WAY_DOWNLOAD = "bytetax.way.download";

    public static final String TAX_RATE_WAY_WRITE = "bytetax.way.write";

    public static final String BILL_TO_ACCOUNT_READ = "bytetax.account.read";

    public static final String BILL_TO_ACCOUNT_DOWNLOAD = "bytetax.account.download";

    public static final String BILL_TO_ACCOUNT_WRITE = "bytetax.account.write";

    public static final String TAX_NO_RULE_READ= "bytetax.taxnorule.read";

    public static final String TAX_NO_RULE_WRITE= "bytetax.taxnorule.write";

    public static final String TAX_NO_RULE_DOWNLOAD= "bytetax.taxnorule.download";

    public static final String TAX_NO_CONFIG_READ= "bytetax.taxnoconfig.read";

    public static final String TAX_NO_CONFIG_WRITE= "bytetax.taxnoconfig.write";

    public static final String TAX_NO_CONFIG_DOWNLOAD= "bytetax.taxnoconfig.download";


}
