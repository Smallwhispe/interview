package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;



@Getter
@AllArgsConstructor
public enum EnumTaxNoFormatRules implements BaseIntEnum {

//    /**
//     * 不能出现连续数值
//     */
//    NOT_CONTINUOUS_NUMBER(1, "not continuous number"),

    /**
     * 纯数值校验
     */
    ALL_NUMBER(2, "all numbers"),

//    /**
//     * 不能使用完全相同数值
//     */
//    NUMBER_NOT_ALL_THE_SAME(3, "numbers not all the same"),

    /**
     * Fonoa API
     */
    FONOA_API_SOURCE(4, "Fonoa API source")
    ;

    private final Integer code;
    private final String name;
}
