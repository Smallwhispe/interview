package com.bytedance.cg.oversea.bytetax.common.utils;

import com.bytedance.cg.oversea.bytetax.common.constant.ConstantValue;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.BaseEnum;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.BaseIntEnum;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.BaseIntStringEnum;
import com.bytedance.cg.oversea.bytetax.common.constant.enums.BaseStringEnum;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.thrift.TEnum;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author wangyong.1991
 * @version 创建时间：2020/12/17 2:47 PM
 */
public class EnumUtils {
    /**
     * 获取枚举值的code
     *
     * @param baseEnum
     * @return
     */
    public static Object getCode(BaseEnum baseEnum) {
        if (Objects.isNull(baseEnum)) {
            return null;
        }
        return baseEnum.getCode();
    }

    /**
     * 获取枚举值的code
     *
     * @param baseIntEnum
     * @return
     */
    public static Integer getCode(BaseIntEnum baseIntEnum) {
        if (Objects.isNull(baseIntEnum)) {
            return null;
        }
        return baseIntEnum.getCode();
    }

    /**
     * 获取枚举值的code
     *
     * @param baseIntEnum
     * @return
     */
    public static Integer getCode(BaseIntStringEnum baseIntEnum) {
        if (Objects.isNull(baseIntEnum)) {
            return null;
        }
        return baseIntEnum.getCode();
    }
    /**
     * 获取枚举值的code
     *
     * @param baseStringEnum
     * @return
     */
    public static String getCode(BaseStringEnum baseStringEnum) {
        if (Objects.isNull(baseStringEnum)) {
            return null;
        }
        return baseStringEnum.getCode();
    }

    /**
     * 获取枚举值的label
     *
     * @param baseEnum
     * @return
     */
    public static String getName(BaseEnum baseEnum) {
        if (Objects.isNull(baseEnum) || Objects.isNull(baseEnum.getName())) {
            return null;
        }
        return baseEnum.getName().toString();
    }

    /**
     * 枚举值 找到枚举类型
     *
     * @param enums
     * @param code
     * @return
     */
    public static <T extends BaseEnum> T getEnumByCode(T[] enums, Object code) {
        if (Objects.isNull(code) || Objects.isNull(enums)) {
            return null;
        }
        for (T e : enums) {
            if (code.equals(e.getCode())) {
                return e;
            }
        }
        return null;
    }

    public static <T extends BaseEnum> String getName(T[] enums, Object code) {
        T enumValue = getEnumByCode(enums, code);
        return getName(enumValue);
    }

    /**
     * 获取枚举值map
     *
     * @param enums
     * @return
     */
    public static List<Map<String, Object>> getEnumCodeNameList(BaseEnum[] enums) {
        List<Map<String, Object>> list = new ArrayList<>();
        if (Objects.isNull(enums)) {
            return list;
        }
        for (BaseEnum intEnum : enums) {
            list.add(buildCodeAndNameMap(intEnum.getCode(), getName(intEnum)));
        }
        return list;
    }

    /**
     * 构建id、name的map
     *
     * @param id
     * @param name
     * @return
     */
    public static Map<String, Object> buildCodeAndNameMap(Object id, Object name) {
        return buildMap(ConstantValue.CODE, id, ConstantValue.NAME, name);
    }

    /**
     * 统一构建map
     *
     * @param keyId
     * @param value
     * @param keyName
     * @param name
     * @return
     */
    public static Map<String, Object> buildMap(String keyId, Object value, String keyName, Object name) {
        Map<String, Object> map = new HashMap<>(2);
        map.put(keyId, value);
        map.put(keyName, name);
        return map;
    }

    /**
     * 校验code是否合法
     */
    public static boolean checkCodeValid(Integer code, BaseIntEnum[] enums) {
        if (Objects.isNull(enums) || Objects.isNull(code)) {
            return false;
        }
        for (BaseIntEnum intEnum : enums) {
            if (intEnum.getCode().equals(code)) {
                return true;
            }
        }
        return false;
    }

    public static <T extends BaseEnum> T getEnumByName(T[] enums, Object name) {
        if (Objects.isNull(name) || Objects.isNull(enums)) {
            return null;
        }
        for (T e : enums) {
            if (name.equals(e.getName())) {
                return e;
            }
        }
        return null;
    }

    /**
     * 获取枚举值的label
     *
     * @param baseEnum
     * @return
     */
    public static String getLabel(BaseEnum baseEnum) {
        if (Objects.isNull(baseEnum) || Objects.isNull(baseEnum.getName())) {
            return null;
        }
        return baseEnum.getName().toString();
    }

    public static boolean notMatch(BaseEnum origin, BaseEnum compare) {
        if (origin == null && compare == null) {
            return false;
        }

        if (origin != null && compare != null && origin.getCode().equals(compare.getCode())) {
            return false;
        }

        return true;
    }
    public static boolean match(BaseEnum origin, BaseEnum compare) {
        return !notMatch(origin, compare);
    }

    public static List<Map<String, Object>> getMapList(BaseEnum[] enums) {
        return Arrays.stream(enums)
                .map(e -> {
                    Map<String, Object> map = Maps.newHashMap();
                    map.put(ConstantValue.NAME, e.getName());
                    map.put(ConstantValue.VALUE, e.getCode());
                    return map;
                })
                .collect(Collectors.toList());
    }

    public static List<Map<String, Object>> getMapList(Map<Integer, String> param) {
        return param.keySet().stream()
                .map(e -> {
                    Map<String, Object> map = Maps.newHashMap();
                    map.put(ConstantValue.NAME, param.get(e));
                    map.put(ConstantValue.VALUE, e);
                    return map;
                })
                .collect(Collectors.toList());
    }

    public static List<Map<String, Object>> getIdAndNameMapList(BaseEnum[] enums) {
        return Arrays.stream(enums)
                .map(e -> {
                    Map<String, Object> map = Maps.newHashMap();
                    map.put(ConstantValue.ID, e.getCode());
                    map.put(ConstantValue.NAME, e.getName());
                    return map;
                })
                .collect(Collectors.toList());
    }


    public static <T extends BaseIntEnum> Integer convertAndGetCode(T[] enums, TEnum tEnum) {
        if (tEnum == null) {
            return null;
        }
        T enumValue = getEnumByCode(enums, tEnum.getValue());
        if (enumValue == null) {
            return null;
        }
        return enumValue.getCode();
    }

    public static <T extends BaseIntEnum> String convertAndGetName(T[] enums, TEnum tEnum) {
        if (tEnum == null) {
            return null;
        }
        T enumValue = getEnumByCode(enums, tEnum.getValue());
        if (enumValue == null) {
            return null;
        }
        return (String) enumValue.getName();
    }

    public static <T extends BaseIntEnum> String getCodeListString(List<T> enums) {
        List<Integer> codes = Lists.newArrayList();
        for (T e : enums) {
            codes.add(e.getCode());
        }
        return JsonUtil.writeValueAsString(codes);
    }

    public static <T extends BaseIntEnum> List<T> getEnumList(T[] enums, String codeListString) {
        List<Integer> codes = JsonUtil.readValue(codeListString, new TypeReference<List<Integer>>(){});
        List<T> ts = Lists.newArrayList();
        for (Integer code : codes) {
            ts.add(EnumUtils.getEnumByCode(enums, code));
        }
        return ts;
    }

    public static <T extends BaseIntEnum> List<T> getEnumList(T[] enums, List<Integer> codes) {
        List<T> ts = Lists.newArrayList();
        for (Integer code : codes) {
            ts.add(EnumUtils.getEnumByCode(enums, code));
        }
        return ts;
    }
}
