package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 税种类别 形成枚举 方便用户理解
 * 对应tax_category表的category字段
 */
@Getter
@AllArgsConstructor
public enum EnumTaxType implements BaseIntEnum {


    VAT(1, "VAT", EnumTaxClassify.TURNOVER),

    GST_HST(2, "GST/HST", EnumTaxClassify.TURNOVER),

    PST(3, "PST", EnumTaxClassify.TURNOVER),

    QST(4, "QST", EnumTaxClassify.TURNOVER),

    SALES_TAX(5, "Sales Tax", EnumTaxClassify.TURNOVER),

    TAX(6, "TAX", EnumTaxClassify.TURNOVER),

    JCT(7, "JCT", EnumTaxClassify.TURNOVER),

    DST(8, "DST", EnumTaxClassify.TURNOVER),

    IVA(9, "IVA", EnumTaxClassify.TURNOVER),

    INDONESIAN_PMSE_VAT(10, "Indonesian PMSE VAT", EnumTaxClassify.TURNOVER),

    VAT_CN(11, "增值税VAT", EnumTaxClassify.TURNOVER),

    GST(12, "GST", EnumTaxClassify.TURNOVER),

    CNPJ(13, "CNPJ", EnumTaxClassify.TURNOVER),

    WHT(14, "WHT", EnumTaxClassify.WITHHOLDING),

    CENTRAL_GST(15, "Central GST", EnumTaxClassify.TURNOVER),

    STATE_GST(16, "State GST", EnumTaxClassify.TURNOVER),

    INTEGRATED(17, "Integrated GST", EnumTaxClassify.TURNOVER),
   ;

    private final Integer code;
    private final String name;
    private final EnumTaxClassify classify;

    public static List<EnumTaxType> getRelatedTaxType(EnumTaxClassify classify) {
        return Arrays.stream(values()).filter(cur -> cur.getClassify().equals(classify)).collect(Collectors.toList());
    }

    public static boolean checkTaxTypeValid(String taxTypeName, EnumTaxClassify classify) {
        if (classify == null || StringUtils.isBlank(taxTypeName)) {
            return false;
        }
        return getRelatedTaxType(classify).stream().map(EnumTaxType::getName).collect(Collectors.toSet()).contains(taxTypeName);
    }

    public static EnumTaxType getTaxTypeByName(String name) {
        return Arrays.stream(values()).filter(cur -> cur.getName().equals(name)).findFirst().orElse(null);
    }
}
