package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 规则间关系类型
 * @author:
 * @date: 2020/9/3
 */
@Getter
@AllArgsConstructor
public enum EnumRelationType implements BaseIntEnum {

    AND(1, "且"),
    OR(2, "或");

    private Integer code;
    private String name;
}
