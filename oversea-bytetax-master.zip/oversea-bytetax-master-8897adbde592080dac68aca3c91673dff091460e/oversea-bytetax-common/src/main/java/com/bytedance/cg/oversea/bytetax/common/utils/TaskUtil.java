package com.bytedance.cg.oversea.bytetax.common.utils;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.joda.time.DateTime;

import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 4/17/23 4:23 PM
 */
public class TaskUtil {

    public static TaskTime getTaskTime (List<String> args, DateTime defaultStart, DateTime defaultEnd) {
        if (args == null) {
            return TaskTime.builder()
                    .startTime(defaultStart)
                    .endTime(defaultEnd).build();
        }
        DateTime startTime = DateUtil.transByPatten(args.get(0), DateUtil.TASK_PATTERN);
        DateTime endTime = DateUtil.transByPatten(args.get(1), DateUtil.TASK_PATTERN);
        return TaskTime.builder()
                .startTime(startTime)
                .endTime(endTime).build();
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TaskTime {
        private DateTime startTime;
        private DateTime endTime;
    }
}
