package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 税种匹配结果
 * @author:
 * @date:
 */
@Getter
@AllArgsConstructor
public enum EnumCategoryMatch implements BaseIntEnum {

    EMPTY(1, "空税种"),
    MATCH_ITEM(2, "匹配到商品"),
    MATCH_EMPTY(3, "匹配到空"),
    ;

    private Integer code;
    private String name;
}
