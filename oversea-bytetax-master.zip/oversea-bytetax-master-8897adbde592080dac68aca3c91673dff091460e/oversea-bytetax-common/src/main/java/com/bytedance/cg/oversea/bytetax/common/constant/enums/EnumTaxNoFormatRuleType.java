package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

/**
 * @Author: Cai Yuxin
 * @Date： 2023/08/14 3:17 PM
 */
@Getter
@AllArgsConstructor
public enum EnumTaxNoFormatRuleType implements BaseIntEnum {

    /**
     * 正则表达式校验规则
     */
    REGULAR_EXPRESSION(1, "RULE_TYPE_REGULAR_EXPRESSION"),

    /**
     * 数字不能连续
     */
    NO_CONTINUOUS_NUMBER(2, "RULE_TYPE_NO_CONTINUOUS_NUMBER"),

    /**
     * 数字不能完全相同
     */
    NUMBER_NOT_ALL_SAME(3, "RULE_TYPE_NUMBER_NOT_ALL_SAME"),

    /**
     * 数字不能逆序连续
     */
    NO_REVERSE_CONTINUOUS_NUMBER(4, "RULE_TYPE_NO_REVERSE_CONTINUOUS_NUMBER"),

    /**
     * 智利RUT税号特殊校验规则
     */
    CL_RUT(5, "RULE_TYPE_CH_RUT"),

    /**
     * 巴西CNPJ税号特殊校验规则
     */
    BR_CNPJ(6, "RULE_TYPE_BR_CNPJ"),

    /**
     * 巴西CPF税号特殊校验规则
     */
    BR_CPF(7, "RULE_TYPE_BR_CPF"),

    /**
     * 哥伦比亚IT税号特殊校验规则
     */
    CO_NIT(8, "RULE_TYPE_CO_NIT"),

    /**
     * 枚举类规则
     */
    ENUMS(9, "ENUMS"),

    /**
     * Fonoa格式校验
     */
    FONOA_API_SOURCE(10, "Fonoa API source"),
    ;

    private final Integer code;
    private final String name;

    public static final List<EnumTaxNoFormatRuleType> THIRD_PARTY = Lists.newArrayList(EnumTaxNoFormatRuleType.FONOA_API_SOURCE);

}
