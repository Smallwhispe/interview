package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 是否最新记录
 * @author:
 * @date:
 */
@Getter
@AllArgsConstructor
public enum EnumBizVariable implements BaseStringEnum {

    START_DATE("start_date", "开始日期"),
    ;

    private String code;
    private String name;
}
