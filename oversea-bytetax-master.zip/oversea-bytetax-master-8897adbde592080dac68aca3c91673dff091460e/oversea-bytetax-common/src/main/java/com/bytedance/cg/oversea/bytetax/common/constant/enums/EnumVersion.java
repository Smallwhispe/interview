package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2023/8/14
 **/
@Getter
@AllArgsConstructor
public enum EnumVersion implements BaseIntEnum {

    /**
     * Business 默认版本
     */
    DEFAULT_B(1, "DEFAULT_B"),

    /**
     * client/individual 默认版本
     */
    DEFAULT_C(2, "DEFAULT_C"),
    /**
     * client/individual 默认版本
     */
    DEFAULT_TEST(255, "DEFAULT_TEST"),
    ;

    private final Integer code;

    private final String name;

}
