package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang.StringUtils;

/**
 * 有无税号
 * @author:
 * @date:
 */
@Getter
@AllArgsConstructor
public enum EnumWithTaxNo implements BaseIntEnum {

    NOTFILTER(2, "Any"),
    WITH(1, "Yes"),
    WITHOUT(0, "No"),
    ;

    private Integer code;
    private String name;

    public static EnumWithTaxNo toEnumWithTaxNo(String taxNo) {
        return StringUtils.isBlank(taxNo) ? EnumWithTaxNo.WITHOUT : EnumWithTaxNo.WITH;
    }
}
