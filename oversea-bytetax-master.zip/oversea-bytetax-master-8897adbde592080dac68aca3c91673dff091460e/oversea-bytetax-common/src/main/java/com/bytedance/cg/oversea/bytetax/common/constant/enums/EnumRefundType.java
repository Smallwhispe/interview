package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * bytedance
 * 2023/3/29 9:11 下午
 */
@Getter
@AllArgsConstructor
public enum EnumRefundType implements BaseIntEnum{
    FULL(1, "full"),
    PARTIAL(2, "partial")
    ;

    private Integer code;
    private String name;
}
