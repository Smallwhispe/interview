package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author bytedance
 * 2022/7/5 2:38 下午
 */
@Getter
@AllArgsConstructor
public enum EnumTaxNoMatchResult implements BaseIntEnum {
    SERVER_PROBLEM(0, "服务器异常"),
    MATCH(1, "税号校验通过"),
    NOT_MATCH(2, "税号校验不通过"),
    NOT_SUPPORT_COUNTRY(3, "不支持国家");

    private Integer code;
    private String name;
}
