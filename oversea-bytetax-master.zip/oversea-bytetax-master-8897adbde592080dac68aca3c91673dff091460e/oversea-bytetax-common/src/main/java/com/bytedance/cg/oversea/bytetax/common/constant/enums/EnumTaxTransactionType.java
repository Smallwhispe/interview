package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2022/5/10
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxTransactionType implements BaseIntEnum {
    /**
     *  记录
     */
    RECORD(1, "transaction record"),
    /**
     *  计算
     */
    CALCULATE(2, "tax registered");

    private final Integer code;
    private final String name;
}
