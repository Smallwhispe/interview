package com.bytedance.cg.oversea.bytetax.common.dto;

import lombok.Data;
import org.apache.commons.collections4.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wangyong.1991
 * @version 创建时间：2020/12/18 6:17 PM
 */
@Data
public class PageDTO<T> {
    /**
     * 总数
     */
    private long total;

    /**
     * 数据列表
     */
    private List<T> data;

    public PageDTO(long total, List<T> data) {
        this.total = total;
        this.data = data;
    }

    public PageDTO() {
        this.total = 0;
        this.data = new ArrayList<>();
    }

    public PageDTO(long total) {
        this.total = total;
        this.data = new ArrayList<>();
    }

    public boolean isEmpty() {
        return CollectionUtils.isEmpty(data);
    }
}
