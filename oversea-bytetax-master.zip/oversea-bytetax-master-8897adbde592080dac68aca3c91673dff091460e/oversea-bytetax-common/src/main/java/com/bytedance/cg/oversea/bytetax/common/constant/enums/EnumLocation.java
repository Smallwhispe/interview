package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EnumLocation implements BaseIntEnum{
    REGISTER(1, "service"),
    OTHER(2, "goods"),
    ;
    private final Integer code;
    private final String name;
}
