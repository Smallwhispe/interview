package com.bytedance.cg.oversea.bytetax.common.utils;

import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;

public class NumberUtil {

    public static String getDecimalPart(BigDecimal bigDecimal){
        String[] split = bigDecimal.toString().split("\\.");
        if (split.length == 1) {
            return "0";
        }
        String replaced = split[1].replaceAll("0+$", "");
        return StringUtils.isBlank(replaced) ? "0" : replaced;
    }

    public static boolean doubleEquals(double d1, double d2){
        return BigDecimal.valueOf(d1).compareTo(BigDecimal.valueOf(d2)) == 0;
    }

    public static BigDecimal safeAdd(BigDecimal b1, BigDecimal b2) {
        BigDecimal sum = BigDecimal.ZERO;
        sum = sum.add(b1 == null ? BigDecimal.ZERO : b1);
        sum = sum.add(b2 == null ? BigDecimal.ZERO : b2);
        return sum;
    }

    public static BigDecimal safeDivide(BigDecimal b1, BigDecimal b2, int scale) {
        if (b2 == null || BigDecimal.ZERO.compareTo(b2) == 0) {
            return null;
        }
        BigDecimal res = b1 == null ? BigDecimal.ZERO : b1;
        return res.divide(b2, scale);
    }

    public static boolean safeCompareValueEqual(BigDecimal b1, BigDecimal b2) {
        if (b1 == null || b2 == null) {
            return false;
        }
        return b1.compareTo(b2) == 0;
    }

}
