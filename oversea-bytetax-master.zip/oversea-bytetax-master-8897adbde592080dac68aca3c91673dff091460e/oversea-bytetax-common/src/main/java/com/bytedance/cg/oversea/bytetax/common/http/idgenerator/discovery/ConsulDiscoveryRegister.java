package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery;

import com.orbitz.consul.model.lookup.Endpoint;

import java.util.List;

public interface ConsulDiscoveryRegister {

  boolean register(String psm, ConsulListener listener);

  interface ConsulListener {

    void onUpdate(List<Endpoint> endpoints);

  }

}
