package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author wangjian.2021
 * @date 2022/6/18
 * BizException code
 **/
@Getter
@AllArgsConstructor
public enum EnumBizExceptionCode implements BaseIntEnum {

    TAX_REPORTER_OUT_OF_LIMIT(-10, "税务报表数据超出限制");

    private Integer code;
    private String name;
}
