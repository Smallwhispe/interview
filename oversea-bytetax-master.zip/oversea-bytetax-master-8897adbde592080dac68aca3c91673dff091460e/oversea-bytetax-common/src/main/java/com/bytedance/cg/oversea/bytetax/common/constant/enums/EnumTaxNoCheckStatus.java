package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import com.google.common.collect.Lists;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;
import java.util.stream.Collectors;

@Getter
@AllArgsConstructor
public enum EnumTaxNoCheckStatus implements BaseIntEnum{

    /**
     *  本次请求失败，服务器异常
     */
    SERVER_PROBLEM(0, "server problem"),
    /**
     *  校验通过
     */
    PASS(1, "pass"),
    /**
     * 校验不通过
     */
    FAILURE(2, "failure"),
    /**
     * 当前API来源不支持该(国家，税号)当地数据库查询
     */
    API_SOURCE_NOT_SUPPORT(3, "api source not support"),
    /**
     * API校验进行中，请稍后查询
     */
    RUNNING(4, "running"),
    /**
     * 本次税号校验查询无效，因为事前没有发起税号校验请求
     */
    REQUEST_NOT_FOUND(5, "request not found"),
    /**
     * 不支持（国家，税种类型），找不到相关税号校验规则配置
     */
    RULE_NOT_FOUND(6, "rule not found"),
    /**
     * 不需要校验
     */
    NO_NEED_TO_VALIDATE(7, "no need to validate"),
    ;


    private final Integer code;
    private final String name;

    public static final List<EnumTaxNoCheckStatus> INVALID_CHECK_STATUS =
            Lists.newArrayList(EnumTaxNoCheckStatus.SERVER_PROBLEM, EnumTaxNoCheckStatus.API_SOURCE_NOT_SUPPORT);

    public static final List<EnumTaxNoCheckStatus> NO_NEED_VALIDATE_API = Lists.newArrayList(EnumTaxNoCheckStatus.SERVER_PROBLEM,
            EnumTaxNoCheckStatus.FAILURE);
    public static final List<EnumTaxNoCheckStatus> NO_NEED_MORE_VALIDATE = Lists.newArrayList(EnumTaxNoCheckStatus.SERVER_PROBLEM,
            EnumTaxNoCheckStatus.FAILURE);

    public static final List<EnumTaxNoCheckStatus> NEED_ONE_MORE_CHECK =
            Lists.newArrayList(EnumTaxNoCheckStatus.RUNNING, EnumTaxNoCheckStatus.SERVER_PROBLEM);

    public static final List<Integer> NEED_ONE_MORE_CHECK_CODE = NEED_ONE_MORE_CHECK.stream()
            .map(EnumTaxNoCheckStatus::getCode).collect(Collectors.toList());

    public static final List<EnumTaxNoCheckStatus> NEED_SEND_MESSAGE = Lists.newArrayList(EnumTaxNoCheckStatus.PASS, EnumTaxNoCheckStatus.FAILURE);

}
