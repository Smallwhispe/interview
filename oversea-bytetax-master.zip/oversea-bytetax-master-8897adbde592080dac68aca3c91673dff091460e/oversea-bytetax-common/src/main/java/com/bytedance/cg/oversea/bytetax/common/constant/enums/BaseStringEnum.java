package com.bytedance.cg.oversea.bytetax.common.constant.enums;

public interface BaseStringEnum extends BaseEnum {
    @Override
    String getCode();
}
