package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author 试算方式
 * @date 2022/5/10
 **/
@Getter
@AllArgsConstructor
public enum EnumCalculationLocation implements BaseIntEnum {
    /**
     *
     */
    REGISTER(1, "Register address"),
    /**
     *
     */
    OTHER(0, "other");

    private final Integer code;
    private final String name;
}
