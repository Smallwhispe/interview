package com.bytedance.cg.oversea.bytetax.common.utils;

import com.bytedance.cg.common.exception.BizException;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import com.bytedance.cg.credit.common.monitor.CgMetricsConstants;
import com.bytedance.cg.credit.common.monitor.CgMonitorMetricRecorder;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

/**
 * @author xiaoliufu
 * @version 1.0
 * @description: jackson common util
 * @created: 2020/1/9 10:36 AM
 **/
@Slf4j
public class JacksonUtil {

    public static String marshalToString(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = getObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }

    public static <T> T unmarshalWithExDeal(String json, Class<T> targetClass){
       return unmarshalWithObject(json, targetClass, getObjectMapper());
    }

    public static <T> T unmarshalWithObject(String json, Class<T> targetClass, ObjectMapper objectMapper){
        try {
            return getObjectMapper().readValue(json, targetClass);
        } catch (Exception e) {
            log.error("jackson deal error json:{}, class:{}", json, targetClass.toString(), e);
            CgMonitorMetricRecorder.exceptionOneMetrics("jackson_deal_error_json_class", e, CgMetricsConstants.ServiceType.COMMON);
            throw new RuntimeException(e);
        }
    }

    public static String marshalWithExDeal(Object obj) {
        try {
            ObjectMapper objectMapper = getObjectMapper();
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            log.error("jackson deal error obj:{}", obj, e);
            CgMonitorMetricRecorder.exceptionOneMetrics("jackson_deal_error_obj", e, CgMetricsConstants.ServiceType.COMMON);
            throw new BizException("jackson error", e);
        }
    }

    @SafeVarargs
    public static String marshalToString(Object obj, Pair<SerializationFeature, Boolean>... features) throws JsonProcessingException {
        ObjectMapper objectMapper = getObjectMapper();
        for (Pair<SerializationFeature, Boolean> featurePair : features) {
            objectMapper.configure(featurePair.getLeft(), featurePair.getRight());
        }

        return objectMapper.writeValueAsString(obj);
    }

    public static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setVisibility(PropertyAccessor.GETTER, JsonAutoDetect.Visibility.NONE);
        objectMapper.setVisibility(PropertyAccessor.SETTER, JsonAutoDetect.Visibility.NONE);
        objectMapper.setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        objectMapper.setVisibility(PropertyAccessor.IS_GETTER, JsonAutoDetect.Visibility.NONE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper;
    }


    public static <T> T unmarshalFromByte(byte[] bytes, Class<T> targetClass) throws IOException {
        return getObjectMapper().readValue(bytes, targetClass);
    }

    public static <T> T unmarshalFromByte(byte[] bytes, TypeReference<T> type) throws IOException {
        return getObjectMapper().readValue(bytes, type);
    }

    public static <T> T unmarshalFromString(String json, Class<T> targetClass) throws IOException {
        return getObjectMapper().readValue(json, targetClass);
    }

    public static <T> T unmarshalFromString(String json, TypeReference<T> type) throws IOException {
        return getObjectMapper().readValue(json, type);
    }
    public static <T> T unmarshalFromStringWithExDeal(String json, TypeReference<T> type) {
        try {
            return getObjectMapper().readValue(json, type);
        } catch (Exception e) {
            log.error("jackson deal error obj:{}", json, e);
            CgMonitorMetricRecorder.exceptionOneMetrics("jackson_deal_error_obj", e, CgMetricsConstants.ServiceType.COMMON);
            throw new RuntimeException("jackson error", e);
        }
    }

    public static <T> List<T> unmarshalFromString2List(String json, Class<T> targetClass) throws IOException {
        final ObjectMapper mapper = getObjectMapper();
        return mapper.readValue(json, mapper.getTypeFactory().constructCollectionType(List.class,
                targetClass));
    }

}
