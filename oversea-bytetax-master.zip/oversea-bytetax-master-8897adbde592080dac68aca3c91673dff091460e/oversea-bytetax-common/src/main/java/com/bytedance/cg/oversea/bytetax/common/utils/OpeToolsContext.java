package com.bytedance.cg.oversea.bytetax.common.utils;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.util.ArrayList;
import java.util.List;

/**
 * 用来手动监控程序中的各个节点
 * 后续可以通过注解自动添加
 * 可以追踪代码行
 * @author zhuxiaoqiang
 * @date 2020-12-29 10:50 下午
 */
public class OpeToolsContext {

    private static final ThreadLocal<List<Pair<String, Object>>> TRACE_INFO = new ThreadLocal<>();

    private static final ThreadLocal<Boolean> IN_TRACE = new ThreadLocal<>();

    public static void addTrace(Object tracer, String desc) {
        if (!isInTrace()) {
            return;
        }
        List<Pair<String, Object>> tracers = TRACE_INFO.get();
        if (tracers == null) {
            tracers = new ArrayList<>();
            TRACE_INFO.set(tracers);
        }
        tracers.add(new ImmutablePair<>(desc, tracer));
    }

    public static List<Pair<String, Object>> getTracers() {
        List<Pair<String, Object>> tracers = TRACE_INFO.get();
        return tracers != null ? tracers : new ArrayList<>();
    }

    public static boolean isInTrace() {
        Boolean trace = IN_TRACE.get();
        return trace != null ? trace : false;
    }

    public static void setInTrace(boolean trace) {
        IN_TRACE.set(trace);
    }

    public static void clear() {
        TRACE_INFO.remove();
        IN_TRACE.remove();
    }
}
