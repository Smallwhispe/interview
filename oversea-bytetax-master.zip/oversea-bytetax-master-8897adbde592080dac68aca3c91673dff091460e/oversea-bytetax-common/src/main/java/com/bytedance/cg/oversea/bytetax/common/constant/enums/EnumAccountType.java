package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 客户类别
 * 3M客户：内部客户
 * 非3M客户：外部客户
 */
@Getter
@AllArgsConstructor
public enum EnumAccountType implements BaseIntEnum {
    INTERNAL(0, "Internal"),

    EXTERNAL(1, "External"),
    ;

    private final Integer code;
    private final String name;
}
