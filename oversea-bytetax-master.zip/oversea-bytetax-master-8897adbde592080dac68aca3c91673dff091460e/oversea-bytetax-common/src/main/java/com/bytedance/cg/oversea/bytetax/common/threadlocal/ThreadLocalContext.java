package com.bytedance.cg.oversea.bytetax.common.threadlocal;

import java.util.HashMap;
import java.util.Map;

/**
 * @author wangjian.2021
 * @date 2022/9/13
 **/
public class ThreadLocalContext {


     private static final ThreadLocal<Map<String, Boolean>> TCC_GRAY_RES_THREAD_LOCAL = new ThreadLocal<>();

     public static Boolean getTccGrayResThreadLocalVal(String key) {
          Map<String, Boolean> valMap = TCC_GRAY_RES_THREAD_LOCAL.get();
          return valMap == null ? null : valMap.getOrDefault(key, null);
     }

     /**
      * 包访问权限，禁止外部调用
      * @param key
      * @param val
      * @return
      */
      static void setTccGrayResThreadLocalVal(String key, Boolean val) {
          Map<String, Boolean> valMap = TCC_GRAY_RES_THREAD_LOCAL.get();
          if (valMap == null) {
               valMap = new HashMap<>();
          }
          valMap.put(key, val);
          TCC_GRAY_RES_THREAD_LOCAL.set(valMap);
     }

    /**
     * 包访问权限，禁止外部调用
     */
    static void removeTccGrayResThreadLocalVal() {
        TCC_GRAY_RES_THREAD_LOCAL.remove();
     }



}
