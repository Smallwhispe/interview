package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * bytedance
 * 2022/7/20 9:01 下午
 * 代表当前操作是新增/更新/还是删除
 */
@Getter
@AllArgsConstructor
public enum EnumChangeType implements BaseIntEnum{
    CREATE(1, "create"),

    MODIFY(2, "modify"),

    DELETE(3, "delete");

    private final Integer code;
    private final String name;
}
