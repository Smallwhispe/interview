package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 税务报表生成维度
 * @author wangjian.2021
 * @date 2022/6/14
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxReporterGroupType implements BaseIntEnum {

    /**
     * 税务局维度
     */
    BY_TAX_ADMIN(1, "by tax authorities"),

    /**
     * 主体维度
     */
    BY_SUBJECT(2, "by legal entity");

    private final Integer code;
    private final String name;
}
