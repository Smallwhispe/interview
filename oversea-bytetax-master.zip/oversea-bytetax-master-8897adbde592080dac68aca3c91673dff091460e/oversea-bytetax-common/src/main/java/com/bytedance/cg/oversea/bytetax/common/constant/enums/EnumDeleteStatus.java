package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author: yangyl
 * @date: 2020/9/3
 */
@Getter
@AllArgsConstructor
public enum EnumDeleteStatus implements BaseIntEnum {

    ACTIVE(0, "生效"),
    DELETED(1, "删除");

    private Integer code;
    private String name;
}
