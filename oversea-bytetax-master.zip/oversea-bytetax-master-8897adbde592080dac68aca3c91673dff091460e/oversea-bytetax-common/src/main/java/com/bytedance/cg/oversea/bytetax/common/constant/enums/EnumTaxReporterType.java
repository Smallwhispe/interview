package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author hanyuxiao
 * @date 2022/5/31
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxReporterType implements BaseIntEnum {

    /**
     *  参与税务申报
     */
    GEN_REPORTER(1, "参与税务申报"),
    /**
     *  不参与税务申报
     */
    NO_NEED_GEN_REPORTER(2, "不参与税务申报");


    private final Integer code;
    private final String name;

    public static EnumTaxReporterType get(EnumTransactionCategory transactionCategory, boolean bizMatched) {
        if (bizMatched && transactionCategory.needTaxReport()) {
            return EnumTaxReporterType.GEN_REPORTER;
        }
        return EnumTaxReporterType.NO_NEED_GEN_REPORTER;

    }
}
