package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
/**
 * 税务身份
 */
public enum EnumTaxIdentity implements BaseIntEnum{


    /**
     *  个人
     */
    INDIVIDUAL(1, "individual"),
    /**
     *  企业
     */
    BUSINESS(2, "business"),
    /**
     *  不区分
     */
    BOTH(3, "both"),
    ;

    private final Integer code;
    private final String name;
}
