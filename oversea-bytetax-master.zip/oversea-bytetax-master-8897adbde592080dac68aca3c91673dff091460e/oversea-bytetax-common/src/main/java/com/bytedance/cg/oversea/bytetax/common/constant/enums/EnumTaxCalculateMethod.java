package com.bytedance.cg.oversea.bytetax.common.constant.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author wangjian.2021
 * @date 2022/4/29
 **/
@Getter
@AllArgsConstructor
public enum EnumTaxCalculateMethod implements BaseIntEnum {

    /**
     * 按相同税率聚合并计算(默认)
     */
    BY_TAX_RATE(1, "按相同税率聚合并计算"),
    /**
     * 按行计算
     */
    BY_ITEM_LINE(2, "按行计算");

    private final Integer code;
    private final String name;

    /**
     * 判断是否需要处理尾差
     * @param taxCalculateMethod
     * @return
     */
    public static boolean needHandleTailDiff(EnumTaxCalculateMethod taxCalculateMethod) {
        return taxCalculateMethod == null || BY_TAX_RATE.equals(taxCalculateMethod);
    }
}
