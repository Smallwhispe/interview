package com.bytedance.cg.oversea.bytetax.common.constant;

/**
 * @author wangjian.2021
 * @date 2022/6/24
 **/
public interface I18nConstants {

    /**
     * stand for Language "English"
     */
    String EN = "en";

    String NO_SEARCH_RESULTS = "Your search results are empty, please try other options.";

    String TRANSACTIONS_GENERATED = "[Transactions Table Generation] ";

    String RETURNS_GENERATED = "[Returns Table Generation] ";

    String TAX_CODE_GENERATED = "[Tax Code Table Generation] ";

    String RELATED_RULE_EXIST = "Before delete the tax code，" +
            "please check all tax rules related with this tax code have been deleted.";

    String RELATED_CATEGORY_EXIST = "Before delete the tax authority，" +
            "please check all tax categories related with this tax authority have been deleted.";

    String RELATED_SUBJECT_EXIST = "Before delete the tax authority，" +
            "please check all subjects related with this tax authority have been deleted.";

    String ONE_REGISTER_LOCATION = "Only one location can be registered!";

    String VALID_PERIOD = "Validity period must be continuous and non-repeatable.";

    String EARLY_END_TIME = "End time should not be earlier than start time!";

    String OUT_OF_PRECISION_LIMIT = "Out of tax rate precision limit.";

    String EXTENSION_REQUIRED = "File extension is required.";

    String EXCEL_FAILED = "Excel generation error!";

    String UPLOAD_FAILED = "Upload failed.";

    String SAVE_FAILED = "Save failed!";

    String UPDATE_FAILED = "Update failed!";

    String DELETE_FAILED = "Delete failed!";

    String REPEAT_VALUE = "Repeat value!";

    String EXISTING_ID = "Existing id!";

    String EXISTING_TAX_ADMIN = "Existing tax admin, same name and country";

    String EXISTING_BIZ = "Existing tax biz. Duplicate id and/or name!";

    String CHECK_INTERNAL_CUSTOMER_ID = "The account id is not internal account. Please check id again!";

    String WRONG_CURRENCY_SIZE = "Wrong currency size!";

    String WRONG_TAXCODES_SIZE = "Wrong taxCodes size!";

    String WRONG_PARAMS = "Wrong parameters!";

    String WRONG_GEO_ID = "Wrong geo id!";

    String WRONG_CITY_CODE = "Wrong city code!";

    String WRONG_CITY_ID = "Wrong city id!";

    String WRONG_SUBJECT_ID = "Wrong subject id:";

    String CANNOT_FIND_CODE = "Can't find code:";

    String CANNOT_FIND_TRANSACTION = "Can't find transaction!";

    String THRIFT_BAD_ANSWER = "Thrift bad answer:";

    String TOS_ERROR = "Tos error!";

    String NULL_TRANS_DETAIL = "Transaction detail is null!";

    String NULL_ID_ASSIGNED = "Ids of multiple items should be assigned!";

    String NULL_ITEM = "No corresponding items!";

    String CASE_DIFF_RESULT = "Following cases will be affected!";

    String DUPLICATE_CREATION = "duplicate creation";

    String PAGE_SIZE_PAGE_NUMBER_TOO_LARGE = "Page size and page number too large!";

    String ID_NOT_FOUND = "Id can not be found!";

    String KEYS_ONLY_IN_TAX_RULE = "Keys in Table tax_rule but in Table Case:";

    String FONOA_PRIORITY_REMINDER = "In API validation rule, Fonoa can only be the last priority!";

    String CHECK_RULE_DUPLICATES = " check rules duplicates! Please double check.";

    String ERR_TAX_TYPE_CLASSIFY_RELATION = "tax type and classify is invalid";

    String ERR_WHITELIST_TAX_CATEGORY_IS_EXIST = "This account has been set the WHT tax rate, you cannot create duplicate setting.";
    String ERR_WHITELIST_ID_INVALID = "Update ID is invalid!";
    String BUSINESS_COUNTRY_BIND_EFFECT_TIME_MISS ="Effective Time is required.";
    String BUSINESS_COUNTRY_BIND_MULTIPLE_EFFECTIVE_RECORDS ="Promote: Same Country same Effective Time with different subject.";
}
