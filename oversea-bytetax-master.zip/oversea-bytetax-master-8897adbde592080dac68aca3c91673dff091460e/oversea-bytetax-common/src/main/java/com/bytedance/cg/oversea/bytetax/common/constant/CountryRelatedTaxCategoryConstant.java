package com.bytedance.cg.oversea.bytetax.common.constant;


import com.bytedance.cg.oversea.bytetax.common.constant.enums.EnumTaxNoType;
import com.google.common.collect.Lists;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * bytedance
 * 2022/10/19 2:57 下午
 */
public class CountryRelatedTaxCategoryConstant {
    // geoId和相关联的税种类型的映射
    public static Map<Long, List<String>> COUNTRY_RELATED_TAX_CATEGORY_MAP = new HashMap<>();
     static {
         // 加拿大geoId
         COUNTRY_RELATED_TAX_CATEGORY_MAP.put(6251999L, Lists.newArrayList(EnumTaxNoType.GST_HST.getCode(), EnumTaxNoType.PST.getCode()));
     }
}
