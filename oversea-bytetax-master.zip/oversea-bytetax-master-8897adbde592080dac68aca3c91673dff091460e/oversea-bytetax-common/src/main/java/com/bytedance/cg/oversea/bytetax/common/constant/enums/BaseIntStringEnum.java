package com.bytedance.cg.oversea.bytetax.common.constant.enums;

public interface BaseIntStringEnum extends BaseEnum {
    @Override
    Integer getCode();

    @Override
    String getName();
}
