package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;

import java.security.MessageDigest;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class MD5UtilBitsUTTest {
  public static class MD5UtilMD5Lower32Test {

    @Test
    public void testMD5Lower32EmptyString() {
      assertEquals("d41d8cd98f00b204e9800998ecf8427e", MD5Util.mD5Lower32(""));
    }

    @Test
    public void testMD5Lower32Abc() {
      assertEquals("900150983cd24fb0d6963f7d28e17f72", MD5Util.mD5Lower32("abc"));
    }

    @Test
    public void testMD5Lower32QuickBrownFox() {
      assertEquals(
          "9e107d9d372bb6826bd81d3542a419d6",
          MD5Util.mD5Lower32("The quick brown fox jumps over the lazy dog"));
    }

    @Test
    public void testMD5Lower32NullInput() {
      assertEquals("", MD5Util.mD5Lower32(null));
    }
  }

  public static class MD5UtilMD5Upper32Test {

    @Test
    public void testMD5Upper32EmptyString() {
      assertEquals("D41D8CD98F00B204E9800998ECF8427E", MD5Util.MD5Upper32(""));
    }

    @Test
    public void testMD5Upper32ForAbc() {
      assertEquals("900150983CD24FB0D6963F7D28E17F72", MD5Util.MD5Upper32("abc"));
    }

    @Test
    public void testMD5Upper32ForQuickBrownFox() {
      assertEquals(
          "9E107D9D372BB6826BD81D3542A419D6",
          MD5Util.MD5Upper32("The quick brown fox jumps over the lazy dog"));
    }

    @Test
    public void testMD5Upper32NullInput() {
      assertEquals("", MD5Util.MD5Upper32(null));
    }

    @Test
    public void testMD5Upper32UTF8Chinese() {
      String input = "中国";
      String expected = computeMD5Upper32(input);
      assertEquals(expected, MD5Util.MD5Upper32(input));
    }

    private String computeMD5Upper32(String source) {
      try {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        md5.update(source.getBytes("UTF-8"));
        byte[] b = md5.digest();

        int i;
        StringBuffer buf = new StringBuffer("");

        for (int offset = 0; offset < b.length; offset++) {
          i = b[offset];
          if (i < 0) {
            i += 256;
          }
          if (i < 16) {
            buf.append("0");
          }
          buf.append(Integer.toHexString(i));
        }
        return buf.toString().toUpperCase();
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    }
  }
}
