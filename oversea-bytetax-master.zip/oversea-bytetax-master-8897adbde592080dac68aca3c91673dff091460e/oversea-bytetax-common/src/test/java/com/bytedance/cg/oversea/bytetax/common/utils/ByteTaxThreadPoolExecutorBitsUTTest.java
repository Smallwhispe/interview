package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.bytedance.cg.common.exception.BizException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ByteTaxThreadPoolExecutorBitsUTTest {
  public static class ByteTaxThreadPoolExecutorBatchSubmitAndGetTest {

    private ByteTaxThreadPoolExecutor executor;

    @Before
    public void setUp() {
      executor =
          new ByteTaxThreadPoolExecutor(
              2,
              4,
              60L,
              TimeUnit.SECONDS,
              new LinkedBlockingQueue<Runnable>(10),
              Executors.defaultThreadFactory(),
              new ThreadPoolExecutor.AbortPolicy());
    }

    @After
    public void tearDown() {
      if (executor != null) {
        executor.shutdownNow();
        try {
          executor.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
      }
    }

    @Test
    public void testBatchSubmitAndGetEmpty() {
      List<String> result =
          executor.batchSubmitAndGet(
              Collections.<Callable<String>>emptyList(), 1L, TimeUnit.SECONDS);
      assertEquals(0, result.size());
    }

    @Test
    public void testBatchSubmitAndGetNull() {
      List<String> result = executor.batchSubmitAndGet(null, 1L, TimeUnit.SECONDS);
      assertEquals(0, result.size());
    }

    @Test
    public void testBatchSubmitAndGetSuccess() {
      List<Callable<String>> callables =
          Arrays.asList(
              new Callable<String>() {
                @Override
                public String call() throws Exception {
                  return "a";
                }
              },
              null,
              new Callable<String>() {
                @Override
                public String call() throws Exception {
                  return null;
                }
              },
              new Callable<String>() {
                @Override
                public String call() throws Exception {
                  return "b";
                }
              });

      List<String> result = executor.batchSubmitAndGet(callables, 2L, TimeUnit.SECONDS);
      assertEquals(2, result.size());
      assertEquals("a", result.get(0));
      assertEquals("b", result.get(1));
    }

    @Test
    public void testBatchSubmitAndGetTimeout() {
      List<Callable<String>> callables =
          Collections.<Callable<String>>singletonList(
              new Callable<String>() {
                @Override
                public String call() throws Exception {
                  Thread.sleep(200);
                  return "slow";
                }
              });

      try {
        executor.batchSubmitAndGet(callables, 50L, TimeUnit.MILLISECONDS);
        fail("Expected BizException due to timeout");
      } catch (BizException e) {
        // expected
      }
    }

    @Test
    public void testBatchSubmitAndGetExecutionException() {
      List<Callable<String>> callables =
          Collections.<Callable<String>>singletonList(
              new Callable<String>() {
                @Override
                public String call() throws Exception {
                  throw new RuntimeException("boom");
                }
              });

      try {
        executor.batchSubmitAndGet(callables, 1L, TimeUnit.SECONDS);
        fail("Expected BizException due to execution exception");
      } catch (BizException e) {
        assertTrue(e.getMessage().contains("boom"));
      }
    }

    @Test
    public void testBatchSubmitAndGetInterrupted() {
      List<Callable<String>> callables =
          Collections.<Callable<String>>singletonList(
              new Callable<String>() {
                @Override
                public String call() throws Exception {
                  Thread.sleep(300);
                  return "ok";
                }
              });

      Thread.currentThread().interrupt();
      try {
        executor.batchSubmitAndGet(callables, 1L, TimeUnit.SECONDS);
        fail("Expected BizException due to interrupted thread");
      } catch (BizException e) {
        // expected
      } finally {
        // clear interrupted status to avoid affecting other tests
        Thread.interrupted();
      }
    }
  }
}
