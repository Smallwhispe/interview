package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

import com.bytedance.cg.common.exception.BizException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.awt.Point;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class JacksonUtilBitsUTTest {
  public static class JacksonUtilMarshalToStringH76eedTest {

    @Test
    public void testMarshalToStringBasic() throws Exception {
      SimpleBean bean = new SimpleBean("Alice", 30);
      String json = JacksonUtil.marshalToString(bean);
      assertEquals("{\"name\":\"Alice\",\"age\":30}", json);
    }

    @Test
    public void testMarshalToStringWithIndentOutput() throws Exception {
      SimpleBean bean = new SimpleBean("Bob", 25);
      String json =
          JacksonUtil.marshalToString(bean, Pair.of(SerializationFeature.INDENT_OUTPUT, true));
      assertTrue(json.contains("\n"));
      assertTrue(json.contains("\"name\""));
      assertTrue(json.contains("\"age\""));
    }

    @Test
    public void testMarshalToStringEmptyBeanWithFeatureFalse() throws Exception {
      EmptyBean empty = new EmptyBean();
      String json =
          JacksonUtil.marshalToString(
              empty, Pair.of(SerializationFeature.FAIL_ON_EMPTY_BEANS, false));
      assertEquals("{}", json);
    }

    @Test(expected = JsonProcessingException.class)
    public void testMarshalToStringEmptyBeanWithFeatureTrueThrows() throws Exception {
      EmptyBean empty = new EmptyBean();
      JacksonUtil.marshalToString(empty, Pair.of(SerializationFeature.FAIL_ON_EMPTY_BEANS, true));
    }

    class SimpleBean {
      private String name;
      private int age;

      SimpleBean(String name, int age) {
        this.name = name;
        this.age = age;
      }
    }

    class EmptyBean {
      // no fields
    }
  }

  public static class JacksonUtilUnmarshalFromStringWithExDealTest {

    @Test
    public void testUnmarshalFromStringWithExDeal_Map() {
      String json = "{\"name\":\"Alice\",\"age\":30}";
      Map<String, Object> result =
          JacksonUtil.unmarshalFromStringWithExDeal(
              json, new TypeReference<Map<String, Object>>() {});
      assertEquals("Alice", result.get("name"));
      assertEquals(30, ((Number) result.get("age")).intValue());
    }

    @Test
    public void testUnmarshalFromStringWithExDeal_ListOfMaps() {
      String json = "[{\"name\":\"Bob\",\"age\":25},{\"name\":\"Carol\",\"age\":40}]";
      List<Map<String, Object>> result =
          JacksonUtil.unmarshalFromStringWithExDeal(
              json, new TypeReference<List<Map<String, Object>>>() {});
      assertEquals(2, result.size());
      assertEquals("Bob", result.get(0).get("name"));
      assertEquals(25, ((Number) result.get(0).get("age")).intValue());
      assertEquals("Carol", result.get(1).get("name"));
      assertEquals(40, ((Number) result.get(1).get("age")).intValue());
    }

    @Test
    public void testUnmarshalFromStringWithExDeal_Exception() {
      String invalidJson = "not a json";
      try {
        JacksonUtil.unmarshalFromStringWithExDeal(
            invalidJson, new TypeReference<Map<String, Object>>() {});
        fail("Expected RuntimeException to be thrown");
      } catch (RuntimeException e) {
        assertEquals("jackson error", e.getMessage());
        assertNotNull(e.getCause());
      }
    }
  }

  public static class JacksonUtilMarshalWithExDealTest {

    // 非静态内部帮助类
    class SelfRef {
      public SelfRef self;
    }

    @Test
    public void testMarshalWithExDealSuccess() {
      String result = JacksonUtil.marshalWithExDeal("abc");
      assertEquals("\"abc\"", result);
    }

    @Test
    public void testMarshalWithExDealException() {
      SelfRef s = new SelfRef();
      s.self = s; // 自引用导致序列化异常
      try {
        JacksonUtil.marshalWithExDeal(s);
        fail("should throw BizException");
      } catch (BizException e) {
        assertEquals("jackson error", e.getMessage());
        assertNotNull(e.getCause());
      }
    }
  }

  public static class JacksonUtilUnmarshalWithObjectTest {

    @Test
    public void testUnmarshalWithObjectToMap() {
      String json = "{\"a\":1,\"b\":\"x\"}";
      ObjectMapper customMapper = new ObjectMapper();
      customMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

      Map result = JacksonUtil.unmarshalWithObject(json, Map.class, customMapper);

      assertNotNull(result);
      assertEquals(2, result.size());
      assertEquals(1, ((Number) result.get("a")).intValue());
      assertEquals("x", result.get("b"));
    }

    @Test
    public void testUnmarshalWithObjectIgnoresPassedMapperFeatures() {
      String json = "{\"x\":1,\"y\":2,\"z\":3}";
      ObjectMapper strictMapper = new ObjectMapper();
      strictMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);

      Point point = JacksonUtil.unmarshalWithObject(json, Point.class, strictMapper);

      assertNotNull(point);
      assertEquals(1, point.x);
      assertEquals(2, point.y);
    }

    @Test
    public void testUnmarshalWithObjectInvalidJsonThrowsRuntimeException() {
      String invalidJson = "{\"a\":1,\"b\":\"x\""; // 缺少右花括号
      ObjectMapper mapper = new ObjectMapper();

      try {
        JacksonUtil.unmarshalWithObject(invalidJson, Map.class, mapper);
        fail("Expected RuntimeException to be thrown");
      } catch (RuntimeException e) {
        assertNotNull(e.getCause());
      }
    }
  }

  public static class JacksonUtilMarshalToStringH167b0Test {

    class Person {
      private String name;
      private int age;

      Person(String name, int age) {
        this.name = name;
        this.age = age;
      }
    }

    class BeanWithGetterOnly {
      private int id;

      BeanWithGetterOnly(int id) {
        this.id = id;
      }

      public String getHidden() {
        return "shouldNotAppear";
      }
    }

    class ConflictingGetterBean {
      private String name;

      ConflictingGetterBean(String name) {
        this.name = name;
      }

      public String getName() {
        return "fromGetter";
      }
    }

    @Test
    public void testMarshalToStringSimpleFields() throws Exception {
      Person p = new Person("Alice", 30);
      String json = JacksonUtil.marshalToString(p);
      ObjectMapper mapper = new ObjectMapper();
      Map result = mapper.readValue(json, Map.class);
      assertEquals("Alice", result.get("name"));
      assertEquals(30, ((Number) result.get("age")).intValue());
    }

    @Test
    public void testMarshalToStringIgnoresGetterOnlyProperty() throws Exception {
      BeanWithGetterOnly b = new BeanWithGetterOnly(123);
      String json = JacksonUtil.marshalToString(b);
      ObjectMapper mapper = new ObjectMapper();
      Map result = mapper.readValue(json, Map.class);
      assertEquals(123, ((Number) result.get("id")).intValue());
      assertEquals(false, result.containsKey("hidden"));
    }

    @Test
    public void testMarshalToStringPrefersFieldOverGetter() throws Exception {
      ConflictingGetterBean bean = new ConflictingGetterBean("Alice");
      String json = JacksonUtil.marshalToString(bean);
      ObjectMapper mapper = new ObjectMapper();
      Map result = mapper.readValue(json, Map.class);
      assertEquals("Alice", result.get("name"));
    }

    @Test
    public void testMarshalToStringNull() throws Exception {
      String json = JacksonUtil.marshalToString(null);
      assertEquals("null", json);
    }
  }

  public static class JacksonUtilUnmarshalFromStringHe39daTest {

    @Test
    public void testUnmarshalFromStringToMap() throws Exception {
      String json = "{\"a\":1,\"b\":\"x\"}";
      Map<String, Object> result =
          JacksonUtil.unmarshalFromString(json, new TypeReference<Map<String, Object>>() {});
      assertEquals(2, result.size());
      assertEquals("x", result.get("b"));
      assertEquals(1, ((Number) result.get("a")).intValue());
    }

    @Test
    public void testUnmarshalFromStringToList() throws Exception {
      String json = "[1,2,3]";
      List<Integer> result =
          JacksonUtil.unmarshalFromString(json, new TypeReference<List<Integer>>() {});
      assertEquals(3, result.size());
      assertEquals(Integer.valueOf(1), result.get(0));
      assertEquals(Integer.valueOf(2), result.get(1));
      assertEquals(Integer.valueOf(3), result.get(2));
    }

    @Test(expected = IOException.class)
    public void testUnmarshalFromStringInvalidJsonThrowsIOException() throws Exception {
      String json = "{invalid json}";
      JacksonUtil.unmarshalFromString(json, new TypeReference<Map<String, Object>>() {});
    }
  }

  public static class JacksonUtilUnmarshalFromByteH4900bTest {

    @Test
    public void testUnmarshalFromByteSuccess() throws Exception {
      String json = "{\"name\":\"Alice\",\"age\":30}";
      byte[] bytes = json.getBytes(StandardCharsets.UTF_8);

      Map result = JacksonUtil.unmarshalFromByte(bytes, Map.class);

      assertEquals("Alice", result.get("name"));
      assertEquals(30, ((Number) result.get("age")).intValue());
    }

    @Test
    public void testUnmarshalFromByteWithExtraProperty() throws Exception {
      String json = "{\"name\":\"Bob\",\"age\":25,\"extra\":\"ignored\"}";
      byte[] bytes = json.getBytes(StandardCharsets.UTF_8);

      Map result = JacksonUtil.unmarshalFromByte(bytes, Map.class);

      assertEquals("Bob", result.get("name"));
      assertEquals(25, ((Number) result.get("age")).intValue());
      assertEquals("ignored", result.get("extra"));
    }

    @Test(expected = IOException.class)
    public void testUnmarshalFromByteInvalidJsonThrowsIOException() throws Exception {
      String invalid = "not a json";
      byte[] bytes = invalid.getBytes(StandardCharsets.UTF_8);

      JacksonUtil.unmarshalFromByte(bytes, Map.class);
    }
  }

  public static class JacksonUtilUnmarshalFromStringH34515Test {

    @Test
    public void testUnmarshalFromStringToMap() throws IOException {
      String json = "{\"name\":\"Alice\",\"age\":30}";
      Map result = JacksonUtil.unmarshalFromString(json, Map.class);
      assertEquals("Alice", result.get("name"));
      assertEquals(30, ((Number) result.get("age")).intValue());
    }

    @Test
    public void testUnmarshalFromStringToInteger() throws IOException {
      String json = "123";
      Integer result = JacksonUtil.unmarshalFromString(json, Integer.class);
      assertEquals(Integer.valueOf(123), result);
    }

    @Test
    public void testUnmarshalFromStringToBoolean() throws IOException {
      String json = "true";
      Boolean result = JacksonUtil.unmarshalFromString(json, Boolean.class);
      assertEquals(Boolean.TRUE, result);
    }

    @Test(expected = IOException.class)
    public void testUnmarshalFromStringInvalidJsonThrowsIOException() throws IOException {
      String invalidJson = "{\"name\":\"Alice\",\"age\":30";
      JacksonUtil.unmarshalFromString(invalidJson, Map.class);
    }

    @Test(expected = IOException.class)
    public void testUnmarshalFromStringEmptyStringThrowsIOException() throws IOException {
      String emptyJson = "";
      JacksonUtil.unmarshalFromString(emptyJson, Map.class);
    }
  }

  public static class JacksonUtilUnmarshalFromByteTypeReferenceUnmarshalFromByteH96002Test {

    @Test
    public void testUnmarshalFromByteToListMap() throws Exception {
      String json = "[{\"name\":\"Alice\",\"age\":30},{\"name\":\"Bob\",\"age\":25}]";
      byte[] bytes = json.getBytes(StandardCharsets.UTF_8);

      List<Map<String, Object>> users =
          JacksonUtil.unmarshalFromByte(bytes, new TypeReference<List<Map<String, Object>>>() {});
      assertEquals(2, users.size());
      assertEquals("Alice", users.get(0).get("name"));
      assertEquals(30, ((Number) users.get(0).get("age")).intValue());
      assertEquals("Bob", users.get(1).get("name"));
      assertEquals(25, ((Number) users.get(1).get("age")).intValue());
    }

    @Test
    public void testUnmarshalFromByteToMapGeneric() throws Exception {
      String json = "{\"a\":1,\"b\":2}";
      byte[] bytes = json.getBytes(StandardCharsets.UTF_8);

      Map<String, Integer> result =
          JacksonUtil.unmarshalFromByte(bytes, new TypeReference<Map<String, Integer>>() {});
      assertEquals(Integer.valueOf(1), result.get("a"));
      assertEquals(Integer.valueOf(2), result.get("b"));
      assertEquals(2, result.size());
    }

    @Test
    public void testUnmarshalFromByteInvalidJson() {
      byte[] bytes = "not-json".getBytes(StandardCharsets.UTF_8);
      try {
        JacksonUtil.unmarshalFromByte(bytes, new TypeReference<List<Map<String, Object>>>() {});
        fail("Expected IOException to be thrown");
      } catch (IOException e) {
        assertNotNull(e.getMessage());
      }
    }
  }
}
