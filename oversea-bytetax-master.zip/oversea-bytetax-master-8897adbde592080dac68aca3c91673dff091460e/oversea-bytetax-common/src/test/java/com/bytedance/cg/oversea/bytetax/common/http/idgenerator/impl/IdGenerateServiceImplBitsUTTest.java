package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client.IDGenerator;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.exception.IDGeneratorException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class IdGenerateServiceImplBitsUTTest {
  public static class IdGenerateServiceImplGetIdsTest {

    @Test
    public void testGetIds_WhenCntLessOrEqualMax_ShouldReturnIdsFromSingleCall() {
      int cnt = 5;
      List<Long> expected = buildSequentialList(1L, cnt);
      TestableIdGenerateServiceImpl service =
          new TestableIdGenerateServiceImpl().addBatch(cnt, expected);

      List<Long> result = service.getIds(cnt);

      assertEquals(cnt, result.size());
      assertEquals(expected, result);
      assertEquals(0, service.getPartIds50Calls);
      assertEquals(1, service.getPartIdsOtherCalls);
    }

    @Test
    public void testGetIds_WhenCntMoreThanMax_ShouldAggregateMultipleCalls() {
      int total = 120;

      List<Long> first50 = buildSequentialList(1L, 50);
      List<Long> second50 = buildSequentialList(51L, 50);
      List<Long> last20 = buildSequentialList(101L, 20);

      TestableIdGenerateServiceImpl service =
          new TestableIdGenerateServiceImpl()
              .addBatch(50, first50)
              .addBatch(50, second50)
              .addBatch(20, last20);

      List<Long> result = service.getIds(total);

      assertEquals(total, result.size());
      assertEquals(first50, result.subList(0, 50));
      assertEquals(second50, result.subList(50, 100));
      assertEquals(last20, result.subList(100, 120));
      assertEquals(2, service.getPartIds50Calls);
      assertEquals(1, service.getPartIdsOtherCalls);
    }

    @Test(expected = RuntimeException.class)
    public void testGetIds_WhenNotEnoughIdsReturned_ShouldThrow() {
      int cnt = 5;
      TestableIdGenerateServiceImpl service =
          new TestableIdGenerateServiceImpl().addBatch(cnt, new ArrayList<Long>());

      service.getIds(cnt);
    }

    @Test
    public void testGetIds_WhenCntIsZero_ShouldReturnEmptyList() {
      int cnt = 0;
      TestableIdGenerateServiceImpl service =
          new TestableIdGenerateServiceImpl().addBatch(cnt, new ArrayList<Long>());

      List<Long> result = service.getIds(cnt);

      assertEquals(0, result.size());
      assertEquals(0, service.getPartIds50Calls);
      assertEquals(1, service.getPartIdsOtherCalls);
    }

    private List<Long> buildSequentialList(long start, int count) {
      List<Long> list = new ArrayList<Long>(count);
      for (int i = 0; i < count; i++) {
        list.add(start + i);
      }
      return list;
    }

    // non-static inner helper class
    class TestableIdGenerateServiceImpl extends IdGenerateServiceImpl {
      final List<List<Long>> fiftyBatches = new ArrayList<List<Long>>();
      final List<Integer> otherCounts = new ArrayList<Integer>();
      final List<List<Long>> otherBatches = new ArrayList<List<Long>>();
      int getPartIds50Calls = 0;
      int getPartIdsOtherCalls = 0;

      TestableIdGenerateServiceImpl addBatch(int cnt, List<Long> returns) {
        if (cnt == 50) {
          fiftyBatches.add(returns);
        } else {
          otherCounts.add(cnt);
          otherBatches.add(returns);
        }
        return this;
      }

      @Override
      public List<Long> getPartIds(int cnt) {
        if (cnt == 50) {
          List<Long> ret = fiftyBatches.get(getPartIds50Calls);
          getPartIds50Calls++;
          return ret;
        } else {
          // assume order of cnt matches provided otherCounts
          List<Long> ret = otherBatches.get(getPartIdsOtherCalls);
          getPartIdsOtherCalls++;
          return ret;
        }
      }
    }
  }

  public static class IdGenerateServiceImplGetPartIdsTest {

    @Test
    public void testGetPartIds_Success() throws Exception {
      IdGenerateServiceImpl service = new IdGenerateServiceImpl();
      FakeIDGenerator okGen = new FakeIDGenerator(false);

      setIdGenerator(service, okGen);

      int cnt = 3;
      List<Long> result = service.getPartIds(cnt);

      List<Long> expected = new ArrayList<Long>();
      for (long i = 1; i <= cnt; i++) {
        expected.add(i);
      }
      assertEquals(expected, result);
    }

    @Test
    public void testGetPartIds_IDGeneratorExceptionWrapped() throws Exception {
      IdGenerateServiceImpl service = new IdGenerateServiceImpl();
      FakeIDGenerator badGen = new FakeIDGenerator(true);

      setIdGenerator(service, badGen);

      try {
        service.getPartIds(2);
        fail("Expected RuntimeException");
      } catch (RuntimeException e) {
        assertEquals("id generator bad answer", e.getMessage());
      }
    }

    private void setIdGenerator(IdGenerateServiceImpl service, IDGenerator gen) throws Exception {
      Field f = IdGenerateServiceImpl.class.getDeclaredField("idGenerator");
      f.setAccessible(true);
      f.set(service, gen);
    }

    class FakeIDGenerator implements IDGenerator {
      private final boolean throwEx;

      FakeIDGenerator(boolean throwEx) {
        this.throwEx = throwEx;
      }

      @Override
      public List<Long> genMulti(int count) throws IDGeneratorException {
        if (throwEx) {
          throw new IDGeneratorException("mock");
        }
        List<Long> list = new ArrayList<Long>();
        for (long i = 1; i <= count; i++) {
          list.add(i);
        }
        return list;
      }

      @Override
      public void close() throws IOException {
        // no-op
      }

      @Override
      public Long gen() throws IDGeneratorException, IDGeneratorException {
        if (throwEx) {
          throw new IDGeneratorException("mock");
        }
        return 1L;
      }
    }
  }

  public static class IdGenerateServiceImplGetIdTest {

    @Test
    public void testGetId_NullIdGenerator_throwsNullPointerException() {
      IdGenerateServiceImpl service = new IdGenerateServiceImpl();
      try {
        service.getId();
        fail("Expected NullPointerException to be thrown");
      } catch (NullPointerException e) {
        // expected
      }
    }
  }
}
