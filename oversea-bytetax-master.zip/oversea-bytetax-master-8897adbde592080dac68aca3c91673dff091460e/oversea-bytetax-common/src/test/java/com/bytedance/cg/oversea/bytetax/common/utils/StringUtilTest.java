package com.bytedance.cg.oversea.bytetax.common.utils;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class StringUtilTest {

    @Test
    public void testUnderLineToCamel() {
        assertEquals("hahXixiLala", StringUtil.underLineToCamel("hah_xixi_lala"));
    }
}
