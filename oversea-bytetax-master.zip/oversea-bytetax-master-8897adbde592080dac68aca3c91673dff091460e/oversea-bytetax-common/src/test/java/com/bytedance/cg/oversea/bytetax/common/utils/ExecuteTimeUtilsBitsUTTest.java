package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Method;
import org.aspectj.lang.annotation.Pointcut;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ExecuteTimeUtilsBitsUTTest {
  public static class ExecuteTimeUtilsServiceExecutionTimeLogTest {

    @Test
    public void testServiceExecutionTimeLogAnnotationValue() throws Exception {
      Method method = ExecuteTimeUtils.class.getDeclaredMethod("serviceExecutionTimeLog");
      Pointcut pointcut = method.getAnnotation(Pointcut.class);
      assertEquals(
          "@annotation(com.bytedance.cg.oversea.bytetax.common.utils.log.ExecuteTime)",
          pointcut.value());
    }

    @Test
    public void testServiceExecutionTimeLogInvoke() {
      ExecuteTimeUtils utils = new ExecuteTimeUtils();
      utils.serviceExecutionTimeLog();
    }
  }
}
