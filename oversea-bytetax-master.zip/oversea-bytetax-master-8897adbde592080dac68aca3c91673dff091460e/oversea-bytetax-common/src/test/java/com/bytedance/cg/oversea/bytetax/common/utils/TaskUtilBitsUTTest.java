package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class TaskUtilBitsUTTest {
  public static class TaskUtilGetTaskTimeTest {

    @Test
    public void testGetTaskTimeWhenArgsNull() {
      DateTime defaultStart = DateUtil.transByPatten("2020-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss");
      DateTime defaultEnd = DateUtil.transByPatten("2020-02-01 00:00:00", "yyyy-MM-dd HH:mm:ss");

      TaskUtil.TaskTime taskTime = TaskUtil.getTaskTime(null, defaultStart, defaultEnd);

      assertEquals(defaultStart, taskTime.getStartTime());
      assertEquals(defaultEnd, taskTime.getEndTime());
    }

    @Test
    public void testGetTaskTimeWhenArgsProvided() {
      String startArg = "2020010100";
      String endArg = "2020013123";

      TaskUtil.TaskTime taskTime =
          TaskUtil.getTaskTime(
              Arrays.asList(startArg, endArg),
              DateUtil.DEFAULT_DATETIME,
              DateUtil.NEW_DEFAULT_DATETIME);

      DateTime expectStart = DateUtil.transByPatten(startArg, DateUtil.TASK_PATTERN);
      DateTime expectEnd = DateUtil.transByPatten(endArg, DateUtil.TASK_PATTERN);

      assertEquals(expectStart, taskTime.getStartTime());
      assertEquals(expectEnd, taskTime.getEndTime());
    }
  }
}
