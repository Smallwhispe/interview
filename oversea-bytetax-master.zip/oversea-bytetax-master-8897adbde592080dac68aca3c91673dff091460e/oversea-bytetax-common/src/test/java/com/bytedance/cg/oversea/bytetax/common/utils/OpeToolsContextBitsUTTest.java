package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class OpeToolsContextBitsUTTest {
  public static class OpeToolsContextAddTraceTest {

    @After
    public void tearDown() {
      OpeToolsContext.clear();
    }

    @Test
    public void testAddTraceWhenNotInTrace() {
      OpeToolsContext.clear();
      OpeToolsContext.setInTrace(false);

      Object tracer = new Object();
      String desc = "not-added";
      OpeToolsContext.addTrace(tracer, desc);

      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(0, tracers.size());
      assertFalse(OpeToolsContext.isInTrace());
    }

    @Test
    public void testAddTraceWhenInTrace() {
      OpeToolsContext.clear();
      OpeToolsContext.setInTrace(true);

      Object tracer = new Object();
      String desc = "added";
      OpeToolsContext.addTrace(tracer, desc);

      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(1, tracers.size());
      Pair<String, Object> pair = tracers.get(0);
      assertEquals(desc, pair.getLeft());
      assertSame(tracer, pair.getRight());
      assertTrue(OpeToolsContext.isInTrace());
    }

    @Test
    public void testAddTraceMultiple() {
      OpeToolsContext.clear();
      OpeToolsContext.setInTrace(true);

      Object tracer1 = new Object();
      Object tracer2 = new Object();
      String desc1 = "first";
      String desc2 = "second";

      OpeToolsContext.addTrace(tracer1, desc1);
      OpeToolsContext.addTrace(tracer2, desc2);

      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(2, tracers.size());

      Pair<String, Object> p1 = tracers.get(0);
      assertEquals(desc1, p1.getLeft());
      assertSame(tracer1, p1.getRight());

      Pair<String, Object> p2 = tracers.get(1);
      assertEquals(desc2, p2.getLeft());
      assertSame(tracer2, p2.getRight());
    }

    @Test
    public void testAddTraceWithNulls() {
      OpeToolsContext.clear();
      OpeToolsContext.setInTrace(true);

      OpeToolsContext.addTrace(null, null);

      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(1, tracers.size());
      Pair<String, Object> pair = tracers.get(0);
      assertNull(pair.getLeft());
      assertNull(pair.getRight());
    }
  }

  public static class OpeToolsContextClearTest {

    @After
    public void tearDown() {
      OpeToolsContext.clear();
    }

    @Test
    public void testClearResetsContextInCurrentThread() {
      OpeToolsContext.clear();
      assertEquals(false, OpeToolsContext.isInTrace());
      assertEquals(0, OpeToolsContext.getTracers().size());

      OpeToolsContext.setInTrace(true);
      assertEquals(true, OpeToolsContext.isInTrace());
      OpeToolsContext.addTrace(new Object(), "t1");
      assertEquals(1, OpeToolsContext.getTracers().size());

      OpeToolsContext.clear();
      assertEquals(false, OpeToolsContext.isInTrace());
      assertEquals(0, OpeToolsContext.getTracers().size());
    }

    @Test
    public void testClearIsolationAcrossThreads() throws Exception {
      OpeToolsContext.clear();
      OpeToolsContext.setInTrace(true);
      OpeToolsContext.addTrace(new Object(), "main");
      assertEquals(1, OpeToolsContext.getTracers().size());

      final CountDownLatch workerReady = new CountDownLatch(1);
      final CountDownLatch mainCleared = new CountDownLatch(1);

      final AtomicInteger workerSizeBefore = new AtomicInteger(-1);
      final AtomicInteger workerSizeAfterMainClear = new AtomicInteger(-1);
      final AtomicInteger workerSizeAfterOwnClear = new AtomicInteger(-1);
      final AtomicBoolean workerIsInTraceAfterOwnClear = new AtomicBoolean(true);

      Thread worker =
          new Thread(
              new Runnable() {
                @Override
                public void run() {
                  try {
                    OpeToolsContext.setInTrace(true);
                    OpeToolsContext.addTrace(new Object(), "worker");
                    workerSizeBefore.set(OpeToolsContext.getTracers().size());
                    workerReady.countDown();

                    mainCleared.await();

                    workerSizeAfterMainClear.set(OpeToolsContext.getTracers().size());

                    OpeToolsContext.clear();

                    workerSizeAfterOwnClear.set(OpeToolsContext.getTracers().size());
                    workerIsInTraceAfterOwnClear.set(OpeToolsContext.isInTrace());
                  } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                  }
                }
              });

      worker.start();

      workerReady.await();

      OpeToolsContext.clear();
      assertEquals(false, OpeToolsContext.isInTrace());
      assertEquals(0, OpeToolsContext.getTracers().size());

      mainCleared.countDown();

      worker.join();

      assertEquals(1, workerSizeBefore.get());
      assertEquals(1, workerSizeAfterMainClear.get());
      assertEquals(0, workerSizeAfterOwnClear.get());
      assertEquals(false, workerIsInTraceAfterOwnClear.get());
    }
  }

  public static class OpeToolsContextSetInTraceTest {

    @After
    public void tearDown() {
      OpeToolsContext.clear();
    }

    @Test
    public void testSetInTraceTrueEnablesTracing() {
      OpeToolsContext.clear();
      assertFalse(OpeToolsContext.isInTrace());

      OpeToolsContext.setInTrace(true);
      assertTrue(OpeToolsContext.isInTrace());

      OpeToolsContext.addTrace("abc", "desc");
      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(1, tracers.size());
      assertEquals("desc", tracers.get(0).getLeft());
      assertEquals("abc", tracers.get(0).getRight());
    }

    @Test
    public void testSetInTraceFalseDisablesTracing() {
      OpeToolsContext.clear();

      OpeToolsContext.setInTrace(true);
      OpeToolsContext.addTrace("first", "d1");
      assertEquals(1, OpeToolsContext.getTracers().size());

      OpeToolsContext.setInTrace(false);
      assertFalse(OpeToolsContext.isInTrace());

      OpeToolsContext.addTrace("second", "d2");
      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(1, tracers.size());
      assertEquals("d1", tracers.get(0).getLeft());
      assertEquals("first", tracers.get(0).getRight());
    }

    @Test
    public void testClearResetsTraceState() {
      OpeToolsContext.setInTrace(true);
      OpeToolsContext.addTrace("obj", "desc");
      assertTrue(OpeToolsContext.isInTrace());
      assertEquals(1, OpeToolsContext.getTracers().size());

      OpeToolsContext.clear();

      assertFalse(OpeToolsContext.isInTrace());
      assertEquals(0, OpeToolsContext.getTracers().size());
    }

    @Test
    public void testThreadLocalIsolation() throws Exception {
      OpeToolsContext.clear();

      // 主线程开启trace并添加记录
      OpeToolsContext.setInTrace(true);
      OpeToolsContext.addTrace("main", "mdesc");
      assertTrue(OpeToolsContext.isInTrace());
      assertEquals(1, OpeToolsContext.getTracers().size());

      final AtomicBoolean childInitialTrace = new AtomicBoolean(true);
      final AtomicInteger childTracerSize = new AtomicInteger(-1);

      Thread t =
          new Thread(
              new Runnable() {
                @Override
                public void run() {
                  // 子线程初始应为不在trace中
                  childInitialTrace.set(OpeToolsContext.isInTrace());

                  // 子线程独立开启trace并添加记录
                  OpeToolsContext.setInTrace(true);
                  OpeToolsContext.addTrace("child", "cdesc");
                  childTracerSize.set(OpeToolsContext.getTracers().size());
                }
              });
      t.start();
      t.join();

      // 子线程初始状态与主线程的设置隔离
      assertFalse(childInitialTrace.get());

      // 子线程的tracers不影响主线程
      assertEquals(1, OpeToolsContext.getTracers().size());
      assertEquals("mdesc", OpeToolsContext.getTracers().get(0).getLeft());
      assertEquals("main", OpeToolsContext.getTracers().get(0).getRight());

      // 子线程独立维护自己的tracers
      assertEquals(1, childTracerSize.get());
    }
  }

  public static class OpeToolsContextGetTracersTest {

    @Before
    public void setUp() {
      OpeToolsContext.clear();
    }

    @After
    public void tearDown() {
      OpeToolsContext.clear();
    }

    @Test
    public void testGetTracersWhenNoTraceInfo() {
      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertNotNull(tracers);
      assertEquals(0, tracers.size());
    }

    @Test
    public void testGetTracersWhenInTraceButNoAddTrace() {
      OpeToolsContext.setInTrace(true);
      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertNotNull(tracers);
      assertEquals(0, tracers.size());
    }

    @Test
    public void testGetTracersAfterMutatingReturnedListWhenNoTraceInfo() {
      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      tracers.add(new ImmutablePair<String, Object>("desc", new Object()));
      List<Pair<String, Object>> next = OpeToolsContext.getTracers();
      assertEquals(0, next.size());
    }

    @Test
    public void testGetTracersWhenNotInTraceAddTraceIgnored() {
      OpeToolsContext.setInTrace(false);
      OpeToolsContext.addTrace(new Object(), "ignored");
      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertNotNull(tracers);
      assertEquals(0, tracers.size());
    }

    @Test
    public void testGetTracersWithSingleTrace() {
      OpeToolsContext.setInTrace(true);
      Object tracer = new Object();
      OpeToolsContext.addTrace(tracer, "hello");
      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(1, tracers.size());
      Pair<String, Object> pair = tracers.get(0);
      assertEquals("hello", pair.getLeft());
      assertEquals(tracer, pair.getRight());
    }

    @Test
    public void testGetTracersWithMultipleTracesOrderPreserved() {
      OpeToolsContext.setInTrace(true);
      Object t1 = new Object();
      Object t2 = new Object();
      OpeToolsContext.addTrace(t1, "a");
      OpeToolsContext.addTrace(t2, "b");

      List<Pair<String, Object>> tracers = OpeToolsContext.getTracers();
      assertEquals(2, tracers.size());

      Pair<String, Object> p1 = tracers.get(0);
      Pair<String, Object> p2 = tracers.get(1);

      assertEquals("a", p1.getLeft());
      assertEquals(t1, p1.getRight());
      assertEquals("b", p2.getLeft());
      assertEquals(t2, p2.getRight());
    }
  }

  public static class OpeToolsContextIsInTraceTest {

    @After
    public void tearDown() {
      OpeToolsContext.clear();
    }

    @Test
    public void testDefaultIsFalse() {
      OpeToolsContext.clear();
      assertEquals(false, OpeToolsContext.isInTrace());
    }

    @Test
    public void testSetTrueThenFalse() {
      OpeToolsContext.setInTrace(true);
      assertEquals(true, OpeToolsContext.isInTrace());

      OpeToolsContext.setInTrace(false);
      assertEquals(false, OpeToolsContext.isInTrace());
    }

    @Test
    public void testClearResets() {
      OpeToolsContext.setInTrace(true);
      OpeToolsContext.clear();
      assertEquals(false, OpeToolsContext.isInTrace());
    }

    @Test
    public void testThreadLocalIsolationBetweenThreads() throws Exception {
      OpeToolsContext.setInTrace(true);

      final CountDownLatch latch = new CountDownLatch(1);
      final AtomicBoolean childResult = new AtomicBoolean(true);

      Thread t =
          new Thread(
              new Runnable() {
                @Override
                public void run() {
                  childResult.set(OpeToolsContext.isInTrace());
                  latch.countDown();
                }
              });
      t.start();
      latch.await();

      assertEquals(false, childResult.get());
      assertEquals(true, OpeToolsContext.isInTrace());
    }

    @Test
    public void testThreadLocalIsolationMainNotAffectedByChildSet() throws Exception {
      OpeToolsContext.setInTrace(false);

      final CountDownLatch latch = new CountDownLatch(1);
      final AtomicBoolean childBefore = new AtomicBoolean();
      final AtomicBoolean childAfter = new AtomicBoolean();

      Thread t =
          new Thread(
              new Runnable() {
                @Override
                public void run() {
                  childBefore.set(OpeToolsContext.isInTrace());
                  OpeToolsContext.setInTrace(true);
                  childAfter.set(OpeToolsContext.isInTrace());
                  latch.countDown();
                }
              });
      t.start();
      latch.await();

      assertEquals(false, childBefore.get());
      assertEquals(true, childAfter.get());
      assertEquals(false, OpeToolsContext.isInTrace());
    }
  }
}
