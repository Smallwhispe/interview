package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class DateUtilBitsUTTest {
  public static class DateUtilFindDatesTest {

    @Test
    public void testFindDatesBeginEqualsEnd() throws Exception {
      GregorianCalendar begin = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      GregorianCalendar end = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      List<String> expect = Arrays.asList("2020-01-01 00:00:00");
      assertEquals(expect, DateUtil.findDates("D", begin.getTime(), end.getTime()));
    }

    @Test
    public void testFindDatesDaily() throws Exception {
      GregorianCalendar begin = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      GregorianCalendar end = new GregorianCalendar(2020, Calendar.JANUARY, 3, 0, 0, 0);
      List<String> expect =
          Arrays.asList("2020-01-01 00:00:00", "2020-01-02 00:00:00", "2020-01-03 00:00:00");
      assertEquals(expect, DateUtil.findDates("D", begin.getTime(), end.getTime()));
    }

    @Test
    public void testFindDatesHourly() throws Exception {
      GregorianCalendar begin = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      GregorianCalendar end = new GregorianCalendar(2020, Calendar.JANUARY, 1, 2, 0, 0);
      List<String> expect =
          Arrays.asList("2020-01-01 00:00:00", "2020-01-01 01:00:00", "2020-01-01 02:00:00");
      assertEquals(expect, DateUtil.findDates("H", begin.getTime(), end.getTime()));
    }

    @Test
    public void testFindDatesSecondly() throws Exception {
      GregorianCalendar begin = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      GregorianCalendar end = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 2);
      List<String> expect =
          Arrays.asList("2020-01-01 00:00:00", "2020-01-01 00:00:01", "2020-01-01 00:00:02");
      assertEquals(expect, DateUtil.findDates("N", begin.getTime(), end.getTime()));
    }

    @Test
    public void testFindDatesMonthly() throws Exception {
      GregorianCalendar begin = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      GregorianCalendar end = new GregorianCalendar(2020, Calendar.MARCH, 1, 0, 0, 0);
      List<String> expect =
          Arrays.asList("2020-01-01 00:00:00", "2020-02-01 00:00:00", "2020-03-01 00:00:00");
      assertEquals(expect, DateUtil.findDates("M", begin.getTime(), end.getTime()));
    }

    @Test
    public void testFindDatesEndBeforeBegin() throws Exception {
      GregorianCalendar begin = new GregorianCalendar(2020, Calendar.JANUARY, 2, 0, 0, 0);
      GregorianCalendar end = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      List<String> expect = Arrays.asList("2020-01-02 00:00:00");
      assertEquals(expect, DateUtil.findDates("D", begin.getTime(), end.getTime()));
    }
  }

  public static class DateUtilGetDayAfterTomorrowTest {

    @Test
    public void testGetDayAfterTomorrow() {
      Date result = DateUtil.getDayAfterTomorrow();

      Calendar cal = Calendar.getInstance();
      cal.setTime(result);
      assertEquals(0, cal.get(Calendar.HOUR_OF_DAY));
      assertEquals(0, cal.get(Calendar.MINUTE));
      assertEquals(0, cal.get(Calendar.SECOND));
      assertEquals(0, cal.get(Calendar.MILLISECOND));

      Calendar before = Calendar.getInstance();
      before.set(Calendar.SECOND, 0);
      before.set(Calendar.MILLISECOND, 0);
      before.set(Calendar.HOUR_OF_DAY, 0);
      before.set(Calendar.MINUTE, 0);
      before.add(Calendar.DAY_OF_MONTH, 2);
      Date expectedBefore = before.getTime();

      Calendar after = Calendar.getInstance();
      after.set(Calendar.SECOND, 0);
      after.set(Calendar.MILLISECOND, 0);
      after.set(Calendar.HOUR_OF_DAY, 0);
      after.set(Calendar.MINUTE, 0);
      after.add(Calendar.DAY_OF_MONTH, 2);
      Date expectedAfter = after.getTime();

      assertTrue(result.equals(expectedBefore) || result.equals(expectedAfter));
    }
  }

  public static class DateUtilStrToDateExtraStrToDateH59e71Test {

    @Test
    public void testStrToDateUtcZ() {
      assertEquals(
          new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(),
          DateUtil.strToDate("2020-01-01T00:00:00Z"));
    }

    @Test
    public void testStrToDateUtcWithMillis() {
      assertEquals(
          new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(),
          DateUtil.strToDate("2020-01-01T00:00:00.123Z"));
    }
  }

  public static class DateUtilTransByPattenTest {

    @Test
    public void testTransByPattenWithAlternatePattern() {
      assertEquals(
          new DateTime(2020, 1, 1, 0, 0, 0, 0),
          DateUtil.transByPatten("20200101000000", "yyyyMMddHHmmss"));
    }

    @Test
    public void testTransByPattenWithInvalidInputReturnsNow() {
      DateTime before = new DateTime();
      DateTime actual = DateUtil.transByPatten("invalid", "yyyy-MM-dd HH:mm:ss");
      DateTime after = new DateTime();
      assertTrue(
          actual.getMillis() >= before.getMillis() && actual.getMillis() <= after.getMillis());
    }

    @Test
    public void testTransByPattenWithDifferentTimeOfDay() {
      assertEquals(
          new DateTime(2020, 2, 3, 12, 34, 56, 0),
          DateUtil.transByPatten("2020-02-03 12:34:56", "yyyy-MM-dd HH:mm:ss"));
    }
  }

  public static class DateUtilTransStringTransH9225eTest {

    @Test
    public void testTransValid() {
      assertEquals(new DateTime(2020, 1, 1, 0, 0, 0, 0), DateUtil.trans("20200101"));
    }

    @Test
    public void testTransLeapDay() {
      assertEquals(new DateTime(2020, 2, 29, 0, 0, 0, 0), DateUtil.trans("20200229"));
    }

    @Test
    public void testTransInvalidFormatReturnsNow() {
      assertNotEquals(new DateTime(2020, 1, 1, 0, 0, 0, 0), DateUtil.trans("2020-01-01"));
    }

    @Test(expected = NullPointerException.class)
    public void testTransNullThrowsNPE() {
      DateUtil.trans((String) null);
    }
  }

  public static class DateUtilTrans3ArgsTransHf648bTest {

    @Test
    public void testTransWithDefaultToPattern() {
      Long expect = 20200101L;
      assertEquals(
          expect, DateUtil.trans("2020-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss", "yyyyMMdd"));
    }

    @Test
    public void testTransYearMonth() {
      Long expect = 202002L;
      assertEquals(expect, DateUtil.trans("2020-02-03", "yyyy-MM-dd", "yyyyMM"));
    }

    @Test(expected = NumberFormatException.class)
    public void testTransThrowsNumberFormatWhenToPatternNotNumeric() {
      DateUtil.trans("2020-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTransThrowsWhenFromPatternMismatch() {
      DateUtil.trans("2020-01-01", "yyyyMMdd", "yyyyMM");
    }
  }

  public static class DateUtilGetEarliestDateTimeTest {

    @Test
    public void testGetEarliestDateTimeMultiple() {
      DateTime dt1 = new DateTime(2020, 1, 1, 2, 0, 0, 0);
      DateTime dt2 = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      DateTime dt3 = new DateTime(2020, 1, 1, 1, 0, 0, 0);
      List<DateTime> input = Arrays.asList(dt1, dt2, dt3);
      assertEquals(dt2, DateUtil.getEarliestDateTime(input));
    }

    @Test
    public void testGetEarliestDateTimeWithNulls() {
      DateTime dt1 = new DateTime(2020, 1, 1, 2, 0, 0, 0);
      DateTime dt2 = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      List<DateTime> input = Arrays.asList(null, dt1, null, dt2);
      assertEquals(dt2, DateUtil.getEarliestDateTime(input));
    }

    @Test
    public void testGetEarliestDateTimeEmptyList() {
      List<DateTime> empty = Collections.emptyList();
      assertNull(DateUtil.getEarliestDateTime(empty));
    }

    @Test
    public void testGetEarliestDateTimeAllNulls() {
      List<DateTime> input = Arrays.asList((DateTime) null, (DateTime) null);
      assertNull(DateUtil.getEarliestDateTime(input));
    }

    @Test
    public void testGetEarliestDateTimeDuplicates() {
      DateTime dt1 = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      DateTime dt2 = new DateTime(2020, 1, 1, 1, 0, 0, 0);
      List<DateTime> input = Arrays.asList(dt2, dt1, dt1, dt2);
      assertEquals(dt1, DateUtil.getEarliestDateTime(input));
    }
  }

  public static class DateUtilLatestDateTimeGetLatestDateTimeTest {

    @Test
    public void testGetLatestDateTimeMultiple() {
      DateTime dt1 = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      DateTime dt2 = new DateTime(2020, 1, 5, 0, 0, 0, 0);
      DateTime dt3 = new DateTime(2019, 12, 31, 23, 59, 59, 0);
      assertEquals(dt2, DateUtil.getLatestDateTime(Arrays.asList(dt1, dt3, dt2)));
    }

    @Test
    public void testGetLatestDateTimeWithNulls() {
      DateTime dt1 = new DateTime(2020, 1, 1, 0, 0, 0, 0);
      DateTime dt2 = new DateTime(2020, 1, 2, 0, 0, 0, 0);
      assertEquals(dt2, DateUtil.getLatestDateTime(Arrays.asList(null, dt1, dt2, null)));
    }

    @Test
    public void testGetLatestDateTimeEmpty() {
      assertNull(DateUtil.getLatestDateTime(Arrays.asList()));
    }

    @Test
    public void testGetLatestDateTimeAllNulls() {
      assertNull(DateUtil.getLatestDateTime(Arrays.asList(null, null)));
    }

    @Test
    public void testGetLatestDateTimeDuplicates() {
      DateTime dt1 = new DateTime(2020, 1, 1, 1, 0, 0, 0);
      DateTime dt2 = new DateTime(2020, 1, 1, 1, 0, 0, 0);
      assertEquals(dt2, DateUtil.getLatestDateTime(Arrays.asList(dt1, dt2)));
    }

    @Test(expected = NullPointerException.class)
    public void testGetLatestDateTimeNullList() {
      DateUtil.getLatestDateTime(null);
    }
  }

  public static class DateUtilDate2LocalDateTimeTest {

    private TimeZone originDefault;

    @Before
    public void setUp() {
      originDefault = TimeZone.getDefault();
    }

    @After
    public void tearDown() {
      TimeZone.setDefault(originDefault);
    }

    @Test
    public void testDate2LocalDateTime_NullInput() {
      assertNull(DateUtil.date2LocalDateTime(null,ZoneId.systemDefault()));
    }

    @Test
    public void testDate2LocalDateTime_IgnoresProvidedZone() {
      GregorianCalendar utcCalendar = new GregorianCalendar();
      utcCalendar.clear();
      utcCalendar.set(2020, GregorianCalendar.JANUARY, 1, 0, 0, 0);

      LocalDateTime result =
          DateUtil.date2LocalDateTime(utcCalendar.getTime(), ZoneId.of("Asia/Shanghai"));

      assertEquals(LocalDateTime.of(2020, 1, 1, 0, 0, 0), result);
    }
  }

  public static class DateUtilStrToTimestampTest {

    @Test
    public void testStrToTimestampNull() {
      assertEquals(null, DateUtil.strToTimestamp(null));
    }

    @Test
    public void testStrToTimestampUtcWithMillis() {
      Long expect = 1577808000000L;
      assertEquals(expect, DateUtil.strToTimestamp("2020-01-01T00:00:00.123Z"));
    }

    @Test
    public void testStrToTimestampUtcNoMillis() {
      Long expect = 1577808000000L;
      assertEquals(expect, DateUtil.strToTimestamp("2020-01-01T00:00:00Z"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testStrToTimestampInvalid() {
      DateUtil.strToTimestamp("invalid-date");
    }
  }

  public static class DateUtilLocalDateTime2DateTest {

    @Test
    public void testLocalDateTime2DateUtc() {
      LocalDateTime localDateTime = LocalDateTime.of(2020, 1, 1, 0, 0, 0);
      long expectedMillis = localDateTime.atZone(ZoneOffset.UTC).toInstant().toEpochMilli();
      Date actual = DateUtil.localDateTime2Date(localDateTime, ZoneOffset.UTC);
      assertEquals(expectedMillis, actual.getTime());
    }

    @Test
    public void testLocalDateTime2DateWithOffset() {
      LocalDateTime localDateTime = LocalDateTime.of(2020, 1, 1, 0, 0, 0);
      ZoneOffset zoneOffset = ZoneOffset.ofHours(-5);
      long expectedMillis = localDateTime.atZone(zoneOffset).toInstant().toEpochMilli();
      Date actual = DateUtil.localDateTime2Date(localDateTime, zoneOffset);
      assertEquals(expectedMillis, actual.getTime());
    }

    @Test
    public void testLocalDateTime2DateNullLocalDateTime() {
      Date actual = DateUtil.localDateTime2Date(null, ZoneOffset.UTC);
      assertNull(actual);
    }

    @Test(expected = NullPointerException.class)
    public void testLocalDateTime2DateNullZoneId() {
      LocalDateTime localDateTime = LocalDateTime.of(2020, 1, 1, 0, 0, 0);
      DateUtil.localDateTime2Date(localDateTime, null);
    }
  }

  public static class DateUtilDateUTC02LocalDateTest {

    @Test
    public void testDateUTC02LocalDate_Null() {
      assertNull(DateUtil.dateUTC02LocalDate(null, 0));
    }

    @Test
    public void testDateUTC02LocalDate_ZeroOffset() {
      // 基准时间：2020-01-01 00:00:00
      assertEquals(
          new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(),
          DateUtil.dateUTC02LocalDate(
              new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testDateUTC02LocalDate_PositiveOffset() {
      // 基准时间：2020-01-01 00:00:00，加1小时
      assertEquals(
          new GregorianCalendar(2020, Calendar.JANUARY, 1, 1, 0, 0).getTime(),
          DateUtil.dateUTC02LocalDate(
              new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 3600));
    }

    @Test
    public void testDateUTC02LocalDate_NegativeOffset() {
      // 基准时间：2020-01-01 00:00:00，减1小时 -> 2019-12-31 23:00:00
      assertEquals(
          new GregorianCalendar(2019, Calendar.DECEMBER, 31, 23, 0, 0).getTime(),
          DateUtil.dateUTC02LocalDate(
              new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), -3600));
    }
  }

  public static class DateUtilDateLocal2UTC0Test {

    @Test
    public void testDateLocal2UTC0Null() {
      assertNull(DateUtil.dateLocal2UTC0(null, 0));
    }

    @Test
    public void testDateLocal2UTC0PositiveOffsetOneHour() {
      assertEquals(
          new GregorianCalendar(2019, Calendar.DECEMBER, 31, 23, 0, 0).getTime(),
          DateUtil.dateLocal2UTC0(
              new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0).getTime(), 3600));
    }

    @Test
    public void testDateLocal2UTC0NegativeOffsetOneHour() {
      assertEquals(
          new GregorianCalendar(2020, Calendar.JANUARY, 1, 1, 0, 0).getTime(),
          DateUtil.dateLocal2UTC0(
              new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0).getTime(), -3600));
    }

    @Test
    public void testDateLocal2UTC0CrossDayWithOneDayOffset() {
      assertEquals(
          new GregorianCalendar(2019, Calendar.DECEMBER, 31, 0, 0, 0).getTime(),
          DateUtil.dateLocal2UTC0(
              new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0).getTime(), 86400));
    }

    @Test
    public void testDateLocal2UTC0WithNewDefaultDate() {
      assertEquals(
          new GregorianCalendar(2998, Calendar.DECEMBER, 31, 23, 0, 0).getTime(),
          DateUtil.dateLocal2UTC0(DateUtil.NEW_DEFAULT_DATE, 3600));
    }
  }

  public static class DateUtilTransLongTransH526cfTest {

    @Test
    public void testTransLongValidDate() {
      assertEquals("1999-12-31", DateUtil.trans(19991231L));
    }

    @Test
    public void testTransLongNullInput() {
      assertEquals(null, DateUtil.trans((Long) null));
    }

    @Test
    public void testTransLongInvalidLength() {
      assertEquals(null, DateUtil.trans(202001L));
    }

    @Test
    public void testTransLongLenientParsing() {
      assertEquals("2020-03-01", DateUtil.trans(20200230L));
    }
  }

  public static class DateUtilTransH9225eTest {

    @Test
    public void testTransValid() {
      assertEquals(new DateTime(2020, 1, 1, 0, 0, 0, 0), DateUtil.trans("20200101"));
    }

    @Test
    public void testTransAnotherValid() {
      assertEquals(new DateTime(1999, 12, 31, 0, 0, 0, 0), DateUtil.trans("19991231"));
    }
  }

  public static class DateUtilDateUTC02LocalConsiderDefaultDateTest {

    @Test
    public void testReturnNullWhenDateIsNull() {
      assertEquals(null, DateUtil.dateUTC02LocalConsiderDefaultDate(null, 3600));
    }

    @Test
    public void testUseOffsetWhenNotDefaultDate() {
      // 2020-01-01 00:00:00 + 3600s = 2020-01-01 01:00:00
      assertEquals(
          "2020-01-01 01:00:00",
          DateUtil.dateUTC02LocalConsiderDefaultDate(
              new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 3600));
    }

    @Test
    public void testIgnoreOffsetWhenDefaultDate() {
      // 当日期为NEW_DEFAULT_DATE时，忽略传入的timeOffset，固定以0处理
      assertEquals(
          "2999-01-01 00:00:00",
          DateUtil.dateUTC02LocalConsiderDefaultDate(
              DateUtil.strToDate("2999-01-01 00:00:00"), 3600));
    }
  }

  public static class DateUtilDateLocal2UTC0ConsiderDefaultDateTest {

    @Test
    public void testDefaultDateReturnsUnchanged() {
      assertEquals(
          DateUtil.NEW_DEFAULT_DATE,
          DateUtil.dateLocal2UTC0ConsiderDefaultDate(DateUtil.NEW_DEFAULT_DATE, 3600));
    }

    @Test
    public void testNullDateReturnsNull() {
      assertEquals(null, DateUtil.dateLocal2UTC0ConsiderDefaultDate(null, 3600));
    }

    @Test
    public void testPositiveOffset() {
      Calendar input = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      Calendar expected = new GregorianCalendar(2019, Calendar.DECEMBER, 31, 23, 0, 0);
      assertEquals(
          expected.getTime(), DateUtil.dateLocal2UTC0ConsiderDefaultDate(input.getTime(), 3600));
    }

    @Test
    public void testNegativeOffset() {
      Calendar input = new GregorianCalendar(2020, Calendar.JANUARY, 1, 0, 0, 0);
      Calendar expected = new GregorianCalendar(2020, Calendar.JANUARY, 1, 1, 0, 0);
      assertEquals(
          expected.getTime(), DateUtil.dateLocal2UTC0ConsiderDefaultDate(input.getTime(), -3600));
    }
  }
}
