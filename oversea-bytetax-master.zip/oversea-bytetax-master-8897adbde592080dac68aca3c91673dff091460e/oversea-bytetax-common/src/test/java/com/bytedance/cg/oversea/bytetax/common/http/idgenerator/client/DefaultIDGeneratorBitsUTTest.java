package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.client;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.exception.IDGeneratorException;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.property.IdGeneratorProperties;
import com.bytedance.cg.oversea.bytetax.common.http.idgenerator.url.URIHolder;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class DefaultIDGeneratorBitsUTTest {
  public static class DefaultIDGeneratorGenMultiTest {

    private HttpServer server;
    private int port;
    private volatile String responseBody;
    private volatile int responseStatus;
    private DefaultIDGenerator idGenerator;

    @Before
    public void setUp() throws Exception {
      server = HttpServer.create(new InetSocketAddress(0), 0);
      port = server.getAddress().getPort();
      server.createContext("/gen", new TestHandler());
      server.setExecutor(null);
      server.start();

      URIHolder uriHolder =
          new URIHolder() {
            @Override
            public URI selectUri() {
              return URI.create("http://127.0.0.1:" + port + "/");
            }
          };

      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(200);
      properties.setConnectTimeout(200);
      properties.setSocketTimeout(200);
      properties.setMaxRetryCount(1);

      idGenerator =
          DefaultIDGenerator.builder()
              .setPsm("psm")
              .setNameSpace("ns")
              .setCounterSpace("cs")
              .setUriHolder(uriHolder)
              .setIdGeneratorProperties(properties)
              .build();

      responseStatus = 200;
      responseBody = "1,2,3";
    }

    @After
    public void tearDown() throws Exception {
      if (server != null) {
        server.stop(0);
      }
      if (idGenerator != null) {
        try {
          idGenerator.close();
        } catch (IOException e) {
          // ignore
        }
      }
    }

    @Test
    public void testGenMultiSuccess() throws Exception {
      responseStatus = 200;
      responseBody = "100,200,300";
      List<Long> result = idGenerator.genMulti(2);
      assertEquals(2, result.size());
      assertEquals(100L, result.get(0).longValue());
      assertEquals(200L, result.get(1).longValue());
    }

    @Test
    public void testGenMultiInvalidCountZero() throws Exception {
      try {
        idGenerator.genMulti(0);
      } catch (IDGeneratorException e) {
        assertEquals("count must betweeen (1, 100]. argument is illegal: 0", e.getMessage());
      }
    }

    @Test
    public void testGenMultiInvalidCountTooLarge() throws Exception {
      try {
        idGenerator.genMulti(101);
      } catch (IDGeneratorException e) {
        assertEquals("count must betweeen (1, 100]. argument is illegal: 101", e.getMessage());
      }
    }

    @Test
    public void testGenMultiStatusFail() throws Exception {
      responseStatus = 500;
      responseBody = "1,2";
      try {
        idGenerator.genMulti(2);
      } catch (IDGeneratorException e) {
        assertEquals("http response status is fail. status code:500", e.getMessage());
      }
    }

    @Test
    public void testGenMultiEmptyContent() throws Exception {
      responseStatus = 200;
      responseBody = "";
      try {
        idGenerator.genMulti(2);
      } catch (IDGeneratorException e) {
        assertEquals("IDGenerator response null exception", e.getMessage());
      }
    }

    @Test
    public void testGenMultiTrimToCount() throws Exception {
      responseStatus = 200;
      responseBody = "1,2,3,4,5";
      List<Long> result = idGenerator.genMulti(3);
      assertEquals(3, result.size());
      assertEquals(1L, result.get(0).longValue());
      assertEquals(2L, result.get(1).longValue());
      assertEquals(3L, result.get(2).longValue());
    }

    @Test
    public void testGenMultiIOException() throws Exception {
      URIHolder badHolder =
          new URIHolder() {
            @Override
            public URI selectUri() {
              // Unused port to trigger connection failure
              return URI.create("http://127.0.0.1:9/");
            }
          };
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(50);
      properties.setConnectTimeout(50);
      properties.setSocketTimeout(50);
      properties.setMaxRetryCount(1);

      DefaultIDGenerator badIdGenerator =
          DefaultIDGenerator.builder()
              .setPsm("psm")
              .setNameSpace("ns")
              .setCounterSpace("cs")
              .setUriHolder(badHolder)
              .setIdGeneratorProperties(properties)
              .build();

      try {
        badIdGenerator.genMulti(1);
      } catch (IDGeneratorException e) {
        assertEquals("IDGenerator io exception", e.getMessage());
      } finally {
        try {
          badIdGenerator.close();
        } catch (IOException e) {
          // ignore
        }
      }
    }

    class TestHandler implements HttpHandler {
      @Override
      public void handle(HttpExchange exchange) throws IOException {
        byte[] bytes = responseBody.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(responseStatus, bytes.length);
        OutputStream os = exchange.getResponseBody();
        os.write(bytes);
        os.close();
      }
    }
  }

  public static class DefaultIDGeneratorBuilderSetIdGeneratorPropertiesTest {

    @Test
    public void testSetIdGeneratorProperties_ReturnsSameInstanceAndChainable() {
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      IdGeneratorProperties props = new IdGeneratorProperties();
      props.setConnectTimeout(100);
      props.setSocketTimeout(200);
      props.setConnectionRequestTimeout(300);
      props.setMaxRetryCount(2);
      props.setIdGeneratorPsm("psm-id");

      DefaultIDGenerator.Builder returned = builder.setIdGeneratorProperties(props);
      assertSame(builder, returned);

      DefaultIDGenerator.Builder chained =
          returned.setPsm("psm").setCounterSpace("counter").setNameSpace("namespace");
      assertSame(builder, chained);
    }

    @Test
    public void testSetIdGeneratorProperties_NullReturnsSameInstance() {
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      DefaultIDGenerator.Builder returned = builder.setIdGeneratorProperties(null);
      assertSame(builder, returned);
    }
  }

  public static class DefaultIDGeneratorCloseTest {

    @Test
    public void testClose_NoException() throws IOException {
      // Setup builder with minimal valid configuration
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(200);
      properties.setConnectTimeout(200);
      properties.setSocketTimeout(200);
      properties.setMaxRetryCount(1);
      properties.setIdGeneratorPsm("psm");

      URIHolder uriHolder =
          new URIHolder() {
            @Override
            public URI selectUri() {
              return URI.create("http://localhost:8080/");
            }
          };

      DefaultIDGenerator idGenerator =
          DefaultIDGenerator.builder()
              .setPsm("test-psm")
              .setNameSpace("ns")
              .setCounterSpace("cs")
              .setUriHolder(uriHolder)
              .setIdGeneratorProperties(properties)
              .build();

      // Run the test
      idGenerator.close();

      // Verify: no exception thrown
      assertTrue(true);
    }
  }

  public static class DefaultIDGeneratorBuilderSetUriHolderTest {

    @Test
    public void testSetUriHolder_ReturnsSameBuilder() {
      DefaultIDGenerator.Builder builder = DefaultIDGenerator.builder();
      URIHolder uriHolder = new TestURIHolder();

      DefaultIDGenerator.Builder result = builder.setUriHolder(uriHolder);

      assertSame(builder, result);
    }

    @Test
    public void testSetUriHolder_ChainingAndBuild() throws IOException {
      DefaultIDGenerator.Builder builder = DefaultIDGenerator.builder();
      TestURIHolder testURIHolder = new TestURIHolder();

      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(
          IdGeneratorProperties.DEFAULT_CONNECTION_REQUEST_TIMEOUT);
      properties.setConnectTimeout(IdGeneratorProperties.DEFAULT_CONNECT_TIMEOUT);
      properties.setSocketTimeout(IdGeneratorProperties.DEFAULT_SOCKET_TIMEOUT);
      properties.setMaxRetryCount(IdGeneratorProperties.MAX_RETRY_COUNT);
      properties.setIdGeneratorPsm("service-psm");

      DefaultIDGenerator generator = null;
      try {
        generator =
            builder
                .setUriHolder(testURIHolder)
                .setPsm("client-psm")
                .setNameSpace("ns")
                .setCounterSpace("cs")
                .setIdGeneratorProperties(properties)
                .build();
        assertNotNull(generator);
      } finally {
        if (generator != null) {
          generator.close();
        }
      }
    }

    @Test
    public void testSetUriHolder_Null() {
      DefaultIDGenerator.Builder builder = DefaultIDGenerator.builder();

      DefaultIDGenerator.Builder result = builder.setUriHolder(null);

      assertSame(builder, result);
    }

    class TestURIHolder implements URIHolder {
      @Override
      public URI selectUri() {
        return URI.create("http://127.0.0.1");
      }
    }
  }

  public static class DefaultIDGeneratorBuilderSetPsmTest {

    @Test
    public void testSetPsmReturnsSameBuilder() {
      // Setup
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      // Run the test
      DefaultIDGenerator.Builder returned = builder.setPsm("service-psm");

      // Verify the results
      assertSame(builder, returned);
    }

    @Test
    public void testSetPsmWithNullIsChainable() {
      // Setup
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      // Run the test
      DefaultIDGenerator.Builder after =
          builder.setPsm(null).setNameSpace("ns").setCounterSpace("cs");

      // Verify the results
      assertSame(builder, after);
    }
  }

  public static class DefaultIDGeneratorBuilderSetNameSpaceTest {

    @Test
    public void testSetNameSpace_ReturnsSameBuilder() {
      // Setup
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      // Run
      DefaultIDGenerator.Builder returned = builder.setNameSpace("namespace");

      // Verify
      assertSame(builder, returned);
    }

    @Test
    public void testSetNameSpace_NullAndRepeatCalls_ReturnsSameBuilder() {
      // Setup
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      // Run & Verify: null value
      DefaultIDGenerator.Builder afterNull = builder.setNameSpace(null);
      assertSame(builder, afterNull);

      // Run & Verify: repeat setting
      DefaultIDGenerator.Builder afterRepeat = builder.setNameSpace("ns2");
      assertSame(builder, afterRepeat);
    }

    @Test
    public void testSetNameSpace_FluentChaining() {
      // Setup
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      // Run
      DefaultIDGenerator.Builder chained =
          builder.setNameSpace("ns").setPsm("psm").setCounterSpace("cs");

      // Verify
      assertSame(builder, chained);
    }
  }

  public static class DefaultIDGeneratorBuilderSetCounterSpaceTest {

    @Test
    public void testSetCounterSpace_ReturnsSameBuilder() {
      // given
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      // when
      DefaultIDGenerator.Builder returned = builder.setCounterSpace("test-counter-space");

      // then
      assertSame(builder, returned);
    }

    @Test
    public void testSetCounterSpace_Null_ReturnsSameBuilder() {
      // given
      DefaultIDGenerator.Builder builder = new DefaultIDGenerator.Builder();

      // when
      DefaultIDGenerator.Builder returned = builder.setCounterSpace(null);

      // then
      assertSame(builder, returned);
    }
  }

  public static class DefaultIDGeneratorBuilderBuildTest {

    // 非静态内部类，提供固定的URI
    class FixedURIHolder implements URIHolder {
      @Override
      public URI selectUri() {
        return URI.create("http://localhost/");
      }
    }

    private IdGeneratorProperties buildValidProperties() {
      IdGeneratorProperties props = new IdGeneratorProperties();
      props.setConnectionRequestTimeout(200);
      props.setConnectTimeout(200);
      props.setSocketTimeout(200);
      props.setMaxRetryCount(5);
      return props;
    }

    private DefaultIDGenerator.Builder buildBaseBuilder(IdGeneratorProperties props) {
      return DefaultIDGenerator.builder()
          .setNameSpace("ns")
          .setCounterSpace("cs")
          .setPsm("psm_service")
          .setUriHolder(new FixedURIHolder())
          .setIdGeneratorProperties(props);
    }

    @Test
    public void testBuild_Success() throws IOException {
      IdGeneratorProperties props = buildValidProperties();

      DefaultIDGenerator.Builder builder = buildBaseBuilder(props);
      DefaultIDGenerator generator = null;
      try {
        generator = builder.build();
        assertNotNull(generator);
      } finally {
        if (generator != null) {
          generator.close();
        }
      }
    }

    @Test
    public void testBuild_ConnectionRequestTimeoutInvalid() {
      IdGeneratorProperties props = buildValidProperties();
      props.setConnectionRequestTimeout(0);

      DefaultIDGenerator.Builder builder = buildBaseBuilder(props);
      try {
        builder.build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("connectionRequestTimeout below or equal zero.", e.getMessage());
      }
    }

    @Test
    public void testBuild_ConnectTimeoutInvalid() {
      IdGeneratorProperties props = buildValidProperties();
      props.setConnectTimeout(0);

      DefaultIDGenerator.Builder builder = buildBaseBuilder(props);
      try {
        builder.build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("connectTimeout below or equal zero.", e.getMessage());
      }
    }

    @Test
    public void testBuild_SocketTimeoutInvalid() {
      IdGeneratorProperties props = buildValidProperties();
      props.setSocketTimeout(0);

      DefaultIDGenerator.Builder builder = buildBaseBuilder(props);
      try {
        builder.build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("socketTimeout below or equal zero.", e.getMessage());
      }
    }

    @Test
    public void testBuild_MaxRetryCountInvalid() {
      IdGeneratorProperties props = buildValidProperties();
      props.setMaxRetryCount(0);

      DefaultIDGenerator.Builder builder = buildBaseBuilder(props);
      try {
        builder.build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("maxRetryCount below zero.", e.getMessage());
      }
    }
  }

  public static class DefaultIDGeneratorBuilderTest {

    // 简单的URIHolder实现，返回固定URI
    class FixedURIHolder implements URIHolder {
      private final URI base;

      FixedURIHolder(URI base) {
        this.base = base;
      }

      @Override
      public URI selectUri() {
        return base;
      }
    }

    @Test
    public void testBuilderReturnsNewInstance() {
      DefaultIDGenerator.Builder b1 = DefaultIDGenerator.builder();
      DefaultIDGenerator.Builder b2 = DefaultIDGenerator.builder();

      assertNotNull(b1);
      assertNotNull(b2);
      assertNotSame(b1, b2);
    }

    @Test
    public void testBuildSuccessWithValidProperties() {
      IdGeneratorProperties props = new IdGeneratorProperties();
      props.setConnectionRequestTimeout(200);
      props.setConnectTimeout(200);
      props.setSocketTimeout(200);
      props.setMaxRetryCount(1);
      props.setIdGeneratorPsm("psm-service");

      DefaultIDGenerator generator =
          DefaultIDGenerator.builder()
              .setUriHolder(new FixedURIHolder(URI.create("http://localhost:8080/")))
              .setNameSpace("ns")
              .setCounterSpace("cs")
              .setPsm("psm")
              .setIdGeneratorProperties(props)
              .build();

      assertNotNull(generator);
      try {
        generator.close();
      } catch (IOException e) {
        fail("close should not throw IOException");
      }
    }

    @Test
    public void testBuildThrowsOnInvalidConnectionRequestTimeout() {
      IdGeneratorProperties props = new IdGeneratorProperties();
      props.setConnectionRequestTimeout(0);
      props.setConnectTimeout(200);
      props.setSocketTimeout(200);
      props.setMaxRetryCount(1);
      props.setIdGeneratorPsm("psm-service");

      try {
        DefaultIDGenerator.builder()
            .setUriHolder(new FixedURIHolder(URI.create("http://localhost:8080/")))
            .setNameSpace("ns")
            .setCounterSpace("cs")
            .setPsm("psm")
            .setIdGeneratorProperties(props)
            .build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("connectionRequestTimeout below or equal zero.", e.getMessage());
      }
    }

    @Test
    public void testBuildThrowsOnInvalidConnectTimeout() {
      IdGeneratorProperties props = new IdGeneratorProperties();
      props.setConnectionRequestTimeout(200);
      props.setConnectTimeout(0);
      props.setSocketTimeout(200);
      props.setMaxRetryCount(1);
      props.setIdGeneratorPsm("psm-service");

      try {
        DefaultIDGenerator.builder()
            .setUriHolder(new FixedURIHolder(URI.create("http://localhost:8080/")))
            .setNameSpace("ns")
            .setCounterSpace("cs")
            .setPsm("psm")
            .setIdGeneratorProperties(props)
            .build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("connectTimeout below or equal zero.", e.getMessage());
      }
    }

    @Test
    public void testBuildThrowsOnInvalidSocketTimeout() {
      IdGeneratorProperties props = new IdGeneratorProperties();
      props.setConnectionRequestTimeout(200);
      props.setConnectTimeout(200);
      props.setSocketTimeout(0);
      props.setMaxRetryCount(1);
      props.setIdGeneratorPsm("psm-service");

      try {
        DefaultIDGenerator.builder()
            .setUriHolder(new FixedURIHolder(URI.create("http://localhost:8080/")))
            .setNameSpace("ns")
            .setCounterSpace("cs")
            .setPsm("psm")
            .setIdGeneratorProperties(props)
            .build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("socketTimeout below or equal zero.", e.getMessage());
      }
    }

    @Test
    public void testBuildThrowsOnInvalidMaxRetryCount() {
      IdGeneratorProperties props = new IdGeneratorProperties();
      props.setConnectionRequestTimeout(200);
      props.setConnectTimeout(200);
      props.setSocketTimeout(200);
      props.setMaxRetryCount(0);
      props.setIdGeneratorPsm("psm-service");

      try {
        DefaultIDGenerator.builder()
            .setUriHolder(new FixedURIHolder(URI.create("http://localhost:8080/")))
            .setNameSpace("ns")
            .setCounterSpace("cs")
            .setPsm("psm")
            .setIdGeneratorProperties(props)
            .build();
        fail("Expected IllegalArgumentException");
      } catch (IllegalArgumentException e) {
        assertEquals("maxRetryCount below zero.", e.getMessage());
      }
    }
  }

  public static class DefaultIDGeneratorGenTest {

    // simple URIHolder for tests
    class SimpleURIHolder implements URIHolder {
      private final URI base;

      SimpleURIHolder(URI base) {
        this.base = base;
      }

      @Override
      public URI selectUri() {
        return base;
      }
    }

    @Test
    public void testGen_ReturnsFirstId() throws Exception {
      HttpServer server = HttpServer.create(new InetSocketAddress(0), 0);
      server.createContext(
          "/gen",
          new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
              byte[] resp = "12345,67890".getBytes("UTF-8");
              exchange.sendResponseHeaders(200, resp.length);
              OutputStream os = exchange.getResponseBody();
              os.write(resp);
              os.close();
            }
          });
      server.start();

      int port = server.getAddress().getPort();
      URI baseUri = URI.create("http://127.0.0.1:" + port + "/");

      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(200);
      properties.setConnectTimeout(200);
      properties.setSocketTimeout(200);
      properties.setMaxRetryCount(3);

      DefaultIDGenerator generator = null;
      try {
        generator =
            DefaultIDGenerator.builder()
                .setIdGeneratorProperties(properties)
                .setUriHolder(new SimpleURIHolder(baseUri))
                .setPsm("psm")
                .setNameSpace("ns")
                .setCounterSpace("cs")
                .build();

        Long result = generator.gen();
        assertEquals(12345L, result.longValue());
      } finally {
        if (generator != null) {
          try {
            generator.close();
          } catch (IOException e) {
            // ignore
          }
        }
        server.stop(0);
      }
    }

    @Test(expected = IDGeneratorException.class)
    public void testGen_PropagatesExceptionFromGenMulti() throws Exception {
      HttpServer server = HttpServer.create(new InetSocketAddress(0), 0);
      server.createContext(
          "/gen",
          new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
              // respond with 500 to trigger retry and exception
              exchange.sendResponseHeaders(500, -1);
              exchange.close();
            }
          });
      server.start();

      int port = server.getAddress().getPort();
      URI baseUri = URI.create("http://127.0.0.1:" + port + "/");

      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(200);
      properties.setConnectTimeout(200);
      properties.setSocketTimeout(200);
      properties.setMaxRetryCount(1); // single attempt

      DefaultIDGenerator generator = null;
      try {
        generator =
            DefaultIDGenerator.builder()
                .setIdGeneratorProperties(properties)
                .setUriHolder(new SimpleURIHolder(baseUri))
                .setPsm("psm")
                .setNameSpace("ns")
                .setCounterSpace("cs")
                .build();

        generator.gen(); // should throw IDGeneratorException
      } finally {
        if (generator != null) {
          try {
            generator.close();
          } catch (IOException e) {
            // ignore
          }
        }
        server.stop(0);
      }
    }
  }
}
