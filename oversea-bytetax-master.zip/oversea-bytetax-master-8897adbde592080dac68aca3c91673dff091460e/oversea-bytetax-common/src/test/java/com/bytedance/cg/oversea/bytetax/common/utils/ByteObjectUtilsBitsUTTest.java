package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ByteObjectUtilsBitsUTTest {
  public static class ByteObjectUtilsLongEqualTest {

    @Test
    public void testLongEqual1() {
      assertTrue(ByteObjectUtils.longEqual(null, null));
    }

    @Test
    public void testLongEqual2() {
      assertTrue(ByteObjectUtils.longEqual(null, Long.valueOf(5L)));
    }

    @Test
    public void testLongEqual3() {
      assertTrue(ByteObjectUtils.longEqual(Long.valueOf(0L), null));
    }

    @Test
    public void testLongEqual4() {
      assertTrue(ByteObjectUtils.longEqual(Long.valueOf(0L), Long.valueOf(5L)));
    }

    @Test
    public void testLongEqual5() {
      assertFalse(ByteObjectUtils.longEqual(Long.valueOf(5L), null));
    }

    @Test
    public void testLongEqual6() {
      assertTrue(ByteObjectUtils.longEqual(Long.valueOf(5L), Long.valueOf(5L)));
    }

    @Test
    public void testLongEqual7() {
      assertFalse(ByteObjectUtils.longEqual(Long.valueOf(5L), Long.valueOf(6L)));
    }
  }
}
