package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.property;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class IdGeneratorPropertiesBitsUTTest {
  public static class IdGeneratorPropertiesSetIdGeneratorPsmTest {

    @Test
    public void testSetIdGeneratorPsm() {
      // given
      IdGeneratorProperties properties = new IdGeneratorProperties();
      String expected = "psm.service.id";

      // when
      properties.setIdGeneratorPsm(expected);

      // then
      assertEquals(expected, properties.getIdGeneratorPsm());
    }

    @Test
    public void testSetIdGeneratorPsm_Null() {
      // given
      IdGeneratorProperties properties = new IdGeneratorProperties();

      // when
      properties.setIdGeneratorPsm(null);

      // then
      assertNull(properties.getIdGeneratorPsm());
    }
  }

  public static class IdGeneratorPropertiesSetMaxRetryCountTest {

    @Test
    public void testDefaultMaxRetryCountIsFive() {
      // Setup
      IdGeneratorProperties properties = new IdGeneratorProperties();

      // Verify default value
      assertEquals(5, properties.getMaxRetryCount());
    }

    @Test
    public void testSetMaxRetryCount_PositiveValue() {
      // Setup
      IdGeneratorProperties properties = new IdGeneratorProperties();

      // Run
      properties.setMaxRetryCount(3);

      // Verify
      assertEquals(3, properties.getMaxRetryCount());
    }

    @Test
    public void testSetMaxRetryCount_NegativeValue() {
      // Setup
      IdGeneratorProperties properties = new IdGeneratorProperties();

      // Run
      properties.setMaxRetryCount(-1);

      // Verify
      assertEquals(-1, properties.getMaxRetryCount());
    }

    @Test
    public void testSetMaxRetryCount_IntegerMaxValue() {
      // Setup
      IdGeneratorProperties properties = new IdGeneratorProperties();

      // Run
      properties.setMaxRetryCount(Integer.MAX_VALUE);

      // Verify
      assertEquals(Integer.MAX_VALUE, properties.getMaxRetryCount());
    }
  }

  public static class IdGeneratorPropertiesSetSocketTimeoutTest {

    @Test
    public void testSetSocketTimeout_PositiveValue() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setSocketTimeout(500);
      assertEquals(500, properties.getSocketTimeout());
    }

    @Test
    public void testSetSocketTimeout_Zero() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setSocketTimeout(0);
      assertEquals(0, properties.getSocketTimeout());
    }

    @Test
    public void testSetSocketTimeout_NegativeValue() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setSocketTimeout(-1);
      assertEquals(-1, properties.getSocketTimeout());
    }

    @Test
    public void testSetSocketTimeout_MaxInt() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setSocketTimeout(Integer.MAX_VALUE);
      assertEquals(Integer.MAX_VALUE, properties.getSocketTimeout());
    }
  }

  public static class IdGeneratorPropertiesSetConnectTimeoutTest {

    @Test
    public void testSetConnectTimeout() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectTimeout(500);
      assertEquals(500, properties.getConnectTimeout());
    }

    @Test
    public void testSetConnectTimeoutZero() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectTimeout(0);
      assertEquals(0, properties.getConnectTimeout());
    }

    @Test
    public void testSetConnectTimeoutNegative() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectTimeout(-1);
      assertEquals(-1, properties.getConnectTimeout());
    }
  }

  public static class IdGeneratorPropertiesSetConnectionRequestTimeoutTest {

    @Test
    public void testSetConnectionRequestTimeout() {
      // Setup
      final IdGeneratorProperties properties = new IdGeneratorProperties();

      // Run the test
      properties.setConnectionRequestTimeout(350);

      // Verify the results
      assertEquals(350, properties.getConnectionRequestTimeout());
    }

    @Test
    public void testSetConnectionRequestTimeout_NegativeValue() {
      // Setup
      final IdGeneratorProperties properties = new IdGeneratorProperties();

      // Run the test
      properties.setConnectionRequestTimeout(-5);

      // Verify the results
      assertEquals(-5, properties.getConnectionRequestTimeout());
    }
  }

  public static class IdGeneratorPropertiesGetMaxRetryCountTest {

    @Test
    public void testGetMaxRetryCount_DefaultIsMaxConstant() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      assertEquals(IdGeneratorProperties.MAX_RETRY_COUNT, properties.getMaxRetryCount());
    }

    @Test
    public void testGetMaxRetryCount_AfterSet() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setMaxRetryCount(3);
      assertEquals(3, properties.getMaxRetryCount());
    }

    @Test
    public void testGetMaxRetryCount_UpdateValue() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setMaxRetryCount(2);
      properties.setMaxRetryCount(7);
      assertEquals(7, properties.getMaxRetryCount());
    }
  }

  public static class IdGeneratorPropertiesGetIdGeneratorPsmTest {

    @Test
    public void testGetIdGeneratorPsm_DefaultIsNull() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      assertEquals(null, properties.getIdGeneratorPsm());
    }

    @Test
    public void testGetIdGeneratorPsm_AfterSet() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setIdGeneratorPsm("psm-service-name");
      assertEquals("psm-service-name", properties.getIdGeneratorPsm());
    }
  }

  public static class IdGeneratorPropertiesGetSocketTimeoutTest {

    @Test
    public void testGetSocketTimeout_WithPositiveValue() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      int expected = 300;

      properties.setSocketTimeout(expected);
      int actual = properties.getSocketTimeout();

      assertEquals(expected, actual);
    }

    @Test
    public void testGetSocketTimeout_WithZeroValue() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      int expected = 0;

      properties.setSocketTimeout(expected);
      int actual = properties.getSocketTimeout();

      assertEquals(expected, actual);
    }
  }

  public static class IdGeneratorPropertiesGetConnectTimeoutTest {

    @Test
    public void testGetConnectTimeout_Default() {
      // Setup
      final IdGeneratorProperties properties = new IdGeneratorProperties();

      // Run the test
      final int result = properties.getConnectTimeout();

      // Verify the results
      assertEquals(200, result);
    }

    @Test
    public void testGetConnectTimeout_AfterSet() {
      // Setup
      final IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectTimeout(300);

      // Run the test
      final int result = properties.getConnectTimeout();

      // Verify the results
      assertEquals(300, result);
    }
  }

  public static class IdGeneratorPropertiesGetConnectionRequestTimeoutTest {

    @Test
    public void testGetConnectionRequestTimeout_AfterSet() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(150);
      assertEquals(150, properties.getConnectionRequestTimeout());
    }

    @Test
    public void testGetConnectionRequestTimeout_SetZero() {
      IdGeneratorProperties properties = new IdGeneratorProperties();
      properties.setConnectionRequestTimeout(0);
      assertEquals(0, properties.getConnectionRequestTimeout());
    }
  }
}
