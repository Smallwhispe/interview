package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.url;

import static org.junit.Assert.assertEquals;

import com.orbitz.consul.model.lookup.Endpoint;
import com.orbitz.consul.model.lookup.ImmutableEndpoint;
import java.util.Arrays;
import java.util.Collections;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ListenerURIHolderBitsUTTest {
  public static class ListenerURIHolderOnUpdateTest {

    @Test
    public void testOnUpdate_BuildsNormalizedUrisAndIPv6Brackets() {
      ListenerURIHolder holder = new ListenerURIHolder("id-generator");
      Endpoint ipv6Endpoint = ImmutableEndpoint.builder().host("2001:db8::1").port(8080).build();
      Endpoint normalEndpoint = ImmutableEndpoint.builder().host("example.com").port(80).build();

      holder.onUpdate(Arrays.asList(ipv6Endpoint, normalEndpoint));

      String first = holder.selectUri().toString();
      String second = holder.selectUri().toString();
      assertEquals("http://[2001:db8::1]:8080/", first);
      assertEquals("http://example.com:80/", second);
    }

    @Test
    public void testOnUpdate_EmptyEndpoints_NoChange() {
      ListenerURIHolder holder = new ListenerURIHolder("id-generator");
      Endpoint endpoint = ImmutableEndpoint.builder().host("host.com").port(8081).build();

      holder.onUpdate(Collections.singletonList(endpoint));
      String before = holder.selectUri().toString();

      holder.onUpdate(Collections.<Endpoint>emptyList());

      String after = holder.selectUri().toString();
      assertEquals("http://host.com:8081/", before);
      assertEquals("http://host.com:8081/", after);
    }

    @Test
    public void testOnUpdate_UpdateWithDifferentEndpoints_ChangesUris() {
      ListenerURIHolder holder = new ListenerURIHolder("id-generator");
      Endpoint e1 = ImmutableEndpoint.builder().host("a.com").port(1001).build();
      Endpoint e2 = ImmutableEndpoint.builder().host("b.com").port(1002).build();

      holder.onUpdate(Arrays.asList(e1, e2));
      holder.selectUri();
      holder.selectUri();

      Endpoint e3 = ImmutableEndpoint.builder().host("c.com").port(1003).build();
      holder.onUpdate(Collections.singletonList(e3));

      String selected = holder.selectUri().toString();
      assertEquals("http://c.com:1003/", selected);
    }
  }

  public static class ListenerURIHolderGetHost4URLTest {

    @Test
    public void testGetHost4URL_IPv6WithoutBrackets() {
      // Setup
      String originHost = "2001:db8::1";

      // Run
      String result = ListenerURIHolder.getHost4URL(originHost);

      // Verify
      assertEquals("[2001:db8::1]", result);
    }

    @Test
    public void testGetHost4URL_AlreadyBracketedIPv6() {
      // Setup
      String originHost = "[2001:db8::1]";

      // Run
      String result = ListenerURIHolder.getHost4URL(originHost);

      // Verify
      assertEquals("[2001:db8::1]", result);
    }

    @Test
    public void testGetHost4URL_NoColonHost() {
      // Setup
      String originHost = "example.com";

      // Run
      String result = ListenerURIHolder.getHost4URL(originHost);

      // Verify
      assertEquals("example.com", result);
    }

    @Test
    public void testGetHost4URL_ContainsColonNonIPv6Like() {
      // Setup
      String originHost = "abc:def";

      // Run
      String result = ListenerURIHolder.getHost4URL(originHost);

      // Verify
      assertEquals("[abc:def]", result);
    }

    @Test(expected = NullPointerException.class)
    public void testGetHost4URL_NullInput() {
      // Run
      ListenerURIHolder.getHost4URL(null);
    }

    // 非静态内部类占位，避免将来需要辅助逻辑时违反禁止静态内部类约束
    class Helper {}
  }
}
