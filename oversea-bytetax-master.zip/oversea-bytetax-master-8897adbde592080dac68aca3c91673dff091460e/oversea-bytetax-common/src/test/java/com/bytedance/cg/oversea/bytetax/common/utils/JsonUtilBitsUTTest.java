package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.bytedance.cg.common.exception.BizException;
import com.fasterxml.jackson.core.type.TypeReference;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class JsonUtilBitsUTTest {
  public static class JsonUtilUnmarshalArrayTest {

    @Test
    public void testUnmarshalArrayNull() {
      List<String> result = JsonUtil.unmarshalArray(null, String.class);
      assertNull(result);
    }

    @Test
    public void testUnmarshalArrayEmpty() {
      List<String> result = JsonUtil.unmarshalArray("", String.class);
      assertNull(result);
    }

    @Test
    public void testUnmarshalArrayValid() {
      String json = "[\"a\",\"b\",\"c\"]";
      List<String> result = JsonUtil.unmarshalArray(json, String.class);
      assertNotNull(result);
      assertEquals(3, result.size());
      assertEquals("a", result.get(0));
      assertEquals("b", result.get(1));
      assertEquals("c", result.get(2));
    }

    @Test
    public void testUnmarshalArrayValidObjectAsMap() {
      String json = "[{\"name\":\"Alice\",\"age\":30},{\"name\":\"Bob\",\"age\":25}]";
      List<Map> result = JsonUtil.unmarshalArray(json, Map.class);
      assertNotNull(result);
      assertEquals(2, result.size());
      assertEquals("Alice", result.get(0).get("name"));
      assertEquals(30, ((Number) result.get(0).get("age")).intValue());
      assertEquals("Bob", result.get(1).get("name"));
      assertEquals(25, ((Number) result.get(1).get("age")).intValue());
    }

    @Test
    public void testUnmarshalArrayInvalidJson() {
      String invalidJson = "[{\"name\":\"Alice\",\"age\":30},";
      try {
        JsonUtil.unmarshalArray(invalidJson, Map.class);
        fail("Expected BizException to be thrown");
      } catch (BizException e) {
        assertNotNull(e);
      }
    }
  }

  public static class JsonUtilUnmarshalArrayWithoutExceptionTest {

    @Test
    public void testNullInput() {
      List<Integer> result = JsonUtil.unmarshalArrayWithoutException(null, Integer.class);
      assertNull(result);
    }

    @Test
    public void testEmptyStringInput() {
      List<String> result = JsonUtil.unmarshalArrayWithoutException("", String.class);
      assertNull(result);
    }

    @Test
    public void testValidIntegerArray() {
      List<Integer> result = JsonUtil.unmarshalArrayWithoutException("[1,2,3]", Integer.class);
      assertEquals(Arrays.asList(1, 2, 3), result);
    }

    @Test
    public void testValidStringArray() {
      List<String> result =
          JsonUtil.unmarshalArrayWithoutException("[\"a\",\"b\",\"c\"]", String.class);
      assertEquals(Arrays.asList("a", "b", "c"), result);
    }

    @Test
    public void testInvalidJsonReturnsNull() {
      List<Integer> result = JsonUtil.unmarshalArrayWithoutException("not a json", Integer.class);
      assertNull(result);
    }

    @Test
    public void testEmptyArrayReturnsEmptyList() {
      List<Integer> result = JsonUtil.unmarshalArrayWithoutException("[]", Integer.class);
      assertNotNull(result);
      assertEquals(0, result.size());
    }
  }

  public static class JsonUtilReadValueHb0640Test {

    @Test
    public void testReadValue_NullJson_ReturnsNull() {
      Map<String, Object> result =
          JsonUtil.readValue(null, new TypeReference<Map<String, Object>>() {});
      assertNull(result);
    }

    @Test
    public void testReadValue_EmptyJson_ReturnsNull() {
      Map<String, Object> result =
          JsonUtil.readValue("", new TypeReference<Map<String, Object>>() {});
      assertNull(result);
    }

    @Test
    public void testReadValue_ValidMapJson_Success() {
      String json = "{\"a\":1,\"b\":\"x\"}";
      Map<String, Object> result =
          JsonUtil.readValue(json, new TypeReference<Map<String, Object>>() {});
      assertNotNull(result);
      assertEquals(2, result.size());
      assertEquals(1, ((Number) result.get("a")).intValue());
      assertEquals("x", result.get("b"));
    }

    @Test
    public void testReadValue_ValidListJson_Success() {
      String json = "[1,2,3]";
      List<Integer> result = JsonUtil.readValue(json, new TypeReference<List<Integer>>() {});
      assertNotNull(result);
      assertEquals(3, result.size());
      assertEquals(Integer.valueOf(1), result.get(0));
      assertEquals(Integer.valueOf(2), result.get(1));
      assertEquals(Integer.valueOf(3), result.get(2));
    }

    @Test
    public void testReadValue_InvalidJson_ThrowsBizException() {
      try {
        JsonUtil.readValue("not_json", new TypeReference<Map<String, Object>>() {});
        fail("Expected BizException to be thrown");
      } catch (BizException e) {
        assertEquals("json解析数据异常", e.getMessage());
      }
    }
  }

  public static class JsonUtilReadValueH0f24bTest {

    @Test
    public void testReadValueNullJson() {
      assertNull(JsonUtil.readValue(null, Map.class));
    }

    @Test
    public void testReadValueEmptyJson() {
      assertNull(JsonUtil.readValue("", Map.class));
    }

    @Test
    public void testReadValuePrimitiveInt() {
      Integer result = JsonUtil.readValue("1", Integer.class);
      assertEquals(Integer.valueOf(1), result);
    }

    @Test
    public void testReadValueMap() {
      Map result = JsonUtil.readValue("{\"a\":\"b\",\"n\":1}", Map.class);
      assertNotNull(result);
      assertEquals("b", result.get("a"));
      assertEquals(1, ((Number) result.get("n")).intValue());
    }

    @Test
    public void testReadValueInvalidJsonThrowsBizException() {
      try {
        JsonUtil.readValue("{\"a\":", Map.class);
        fail("Expected BizException to be thrown");
      } catch (BizException e) {
        assertEquals("json解析数据异常", e.getMessage());
      }
    }
  }

  public static class JsonUtilWriteValueAsStringTest {

    @Test
    public void testWriteValueAsStringNull() {
      assertNull(JsonUtil.writeValueAsString(null));
    }

    @Test
    public void testWriteValueAsStringSimple() {
      Map<String, Object> map = new HashMap<String, Object>();
      map.put("a", 1);
      assertEquals("{\"a\":1}", JsonUtil.writeValueAsString(map));
    }

    @Test
    public void testWriteValueAsStringException() {
      ThrowingBean bean = new ThrowingBean();
      String result = JsonUtil.writeValueAsString(bean);
      assertEquals("", result);
    }

    // 非静态内部类，getter抛出异常，触发JsonUtil异常分支
    class ThrowingBean {
      public String getValue() throws IOException {
        throw new IOException("boom");
      }
    }
  }

  public static class JsonUtilUnmarshalFromString2ListTest {

    @Test
    public void testUnmarshalFromString2List_Integer() {
      List<Integer> result = JsonUtil.unmarshalFromString2List("[1,2,3]", Integer.class);
      assertEquals(Arrays.asList(1, 2, 3), result);
    }

    @Test
    public void testUnmarshalFromString2List_String() {
      List<String> result = JsonUtil.unmarshalFromString2List("[\"a\",\"b\",\"c\"]", String.class);
      assertEquals(Arrays.asList("a", "b", "c"), result);
    }

    @Test
    public void testUnmarshalFromString2List_EmptyArray() {
      List<Integer> result = JsonUtil.unmarshalFromString2List("[]", Integer.class);
      assertEquals(0, result.size());
    }

    @Test
    public void testUnmarshalFromString2List_NullLiteral() {
      List<Integer> result = JsonUtil.unmarshalFromString2List("null", Integer.class);
      assertNull(result);
    }

    @Test(expected = RuntimeException.class)
    public void testUnmarshalFromString2List_InvalidJson() {
      JsonUtil.unmarshalFromString2List("not a json", Integer.class);
    }
  }
}
