package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.math.BigDecimal;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class NumberUtilBitsUTTest {
  public static class NumberUtilGetDecimalPartTest {

    @Test
    public void testGetDecimalPart_NoDecimal() {
      assertEquals("0", NumberUtil.getDecimalPart(new BigDecimal("123")));
    }

    @Test
    public void testGetDecimalPart_DecimalWithoutTrailingZeros() {
      assertEquals("456789", NumberUtil.getDecimalPart(new BigDecimal("123.456789")));
    }

    @Test
    public void testGetDecimalPart_DecimalWithTrailingZeros() {
      assertEquals("45", NumberUtil.getDecimalPart(new BigDecimal("123.4500")));
    }

    @Test
    public void testGetDecimalPart_AllZerosInDecimal() {
      assertEquals("0", NumberUtil.getDecimalPart(new BigDecimal("123.0000")));
    }

    @Test
    public void testGetDecimalPart_LeadingZerosKeptInDecimal() {
      assertEquals("0001", NumberUtil.getDecimalPart(new BigDecimal("0.0001000")));
    }

    @Test
    public void testGetDecimalPart_Zero() {
      assertEquals("0", NumberUtil.getDecimalPart(new BigDecimal("0")));
    }

    @Test
    public void testGetDecimalPart_ZeroPointZero() {
      assertEquals("0", NumberUtil.getDecimalPart(new BigDecimal("0.0")));
    }

    @Test
    public void testGetDecimalPart_NegativeNumber() {
      assertEquals("04", NumberUtil.getDecimalPart(new BigDecimal("-123.0400")));
    }

    @Test(expected = NullPointerException.class)
    public void testGetDecimalPart_Null() {
      NumberUtil.getDecimalPart(null);
    }
  }

  public static class NumberUtilSafeAddTest {

    @Test
    public void testSafeAddNormal() {
      BigDecimal b1 = new BigDecimal("1.23");
      BigDecimal b2 = new BigDecimal("4.56");
      BigDecimal result = NumberUtil.safeAdd(b1, b2);
      assertEquals(new BigDecimal("5.79"), result);
    }

    @Test
    public void testSafeAddNullFirst() {
      BigDecimal b2 = new BigDecimal("2.50");
      BigDecimal result = NumberUtil.safeAdd(null, b2);
      assertEquals(new BigDecimal("2.50"), result);
    }

    @Test
    public void testSafeAddNullSecond() {
      BigDecimal b1 = new BigDecimal("2.50");
      BigDecimal result = NumberUtil.safeAdd(b1, null);
      assertEquals(new BigDecimal("2.50"), result);
    }

    @Test
    public void testSafeAddBothNull() {
      BigDecimal result = NumberUtil.safeAdd(null, null);
      assertEquals(BigDecimal.ZERO, result);
    }

    @Test
    public void testSafeAddNegative() {
      BigDecimal b1 = new BigDecimal("-1");
      BigDecimal b2 = new BigDecimal("2");
      BigDecimal result = NumberUtil.safeAdd(b1, b2);
      assertEquals(new BigDecimal("1"), result);
    }

    @Test
    public void testSafeAddScalePreserved() {
      BigDecimal b1 = new BigDecimal("1.00");
      BigDecimal b2 = new BigDecimal("2.000");
      BigDecimal result = NumberUtil.safeAdd(b1, b2);
      assertEquals(new BigDecimal("3.000"), result);
    }
  }

  public static class NumberUtilSafeDivideTest {

    @Test
    public void testSafeDivide_DivisorNull() {
      BigDecimal result = NumberUtil.safeDivide(new BigDecimal("1.23"), null, 2);
      assertNull(result);
    }

    @Test
    public void testSafeDivide_DivisorZero() {
      BigDecimal result = NumberUtil.safeDivide(new BigDecimal("1.23"), BigDecimal.ZERO, 2);
      assertNull(result);
    }

    @Test
    public void testSafeDivide_DividendNull() {
      BigDecimal result = NumberUtil.safeDivide(null, new BigDecimal("2"), 2);
      assertEquals(BigDecimal.ZERO, result);
    }

    @Test
    public void testSafeDivide_TerminatingDivision() {
      BigDecimal result = NumberUtil.safeDivide(new BigDecimal("1"), new BigDecimal("2"), 2);
      assertEquals(new BigDecimal("1"), result);
    }

    @Test
    public void testSafeDivide_NonTerminatingDivision() {
      BigDecimal result = NumberUtil.safeDivide(new BigDecimal("1"), new BigDecimal("3"), 2);
      assertEquals(new BigDecimal("1"), result);
    }

    @Test
    public void testSafeDivide_NegativeResult() {
      BigDecimal result = NumberUtil.safeDivide(new BigDecimal("-1"), new BigDecimal("2"), 2);
      assertEquals(BigDecimal.ZERO, result);
    }
  }

  public static class NumberUtilSafeCompareValueEqualTest {

    @Test
    public void testSafeCompareValueEqual_BothNull() {
      assertEquals(false, NumberUtil.safeCompareValueEqual(null, null));
    }

    @Test
    public void testSafeCompareValueEqual_LeftNull() {
      assertEquals(false, NumberUtil.safeCompareValueEqual(null, BigDecimal.ZERO));
    }

    @Test
    public void testSafeCompareValueEqual_RightNull() {
      assertEquals(false, NumberUtil.safeCompareValueEqual(BigDecimal.ONE, null));
    }

    @Test
    public void testSafeCompareValueEqual_EqualSameScale() {
      assertEquals(
          true, NumberUtil.safeCompareValueEqual(new BigDecimal("1.23"), new BigDecimal("1.23")));
    }

    @Test
    public void testSafeCompareValueEqual_EqualDifferentScale() {
      assertEquals(
          true, NumberUtil.safeCompareValueEqual(new BigDecimal("1.230"), new BigDecimal("1.23")));
    }

    @Test
    public void testSafeCompareValueEqual_NotEqual() {
      assertEquals(
          false, NumberUtil.safeCompareValueEqual(new BigDecimal("1.23"), new BigDecimal("1.24")));
    }

    @Test
    public void testSafeCompareValueEqual_ZeroEqualDifferentScale() {
      assertEquals(true, NumberUtil.safeCompareValueEqual(BigDecimal.ZERO, new BigDecimal("0.00")));
    }

    @Test
    public void testSafeCompareValueEqual_NegativeEqualDifferentScale() {
      assertEquals(
          true, NumberUtil.safeCompareValueEqual(new BigDecimal("-10"), new BigDecimal("-10.0")));
    }
  }

  public static class NumberUtilDoubleEqualsTest {

    @Test
    public void testDoubleEqualsSameValues() {
      assertEquals(true, NumberUtil.doubleEquals(123.456, 123.456));
    }

    @Test
    public void testDoubleEqualsPositiveNegativeZero() {
      assertEquals(true, NumberUtil.doubleEquals(-0.0, 0.0));
    }

    @Test
    public void testDoubleEqualsFloatingPointNonEquality() {
      assertEquals(false, NumberUtil.doubleEquals(0.1 + 0.2, 0.3));
    }

    @Test
    public void testDoubleEqualsDifferentRepresentableValues() {
      double d1 = 1.0;
      double d2 = d1 + Math.ulp(d1);
      assertEquals(false, NumberUtil.doubleEquals(d1, d2));
    }

    @Test(expected = NumberFormatException.class)
    public void testDoubleEqualsNaNThrows() {
      NumberUtil.doubleEquals(Double.NaN, 0.0);
    }

    @Test(expected = NumberFormatException.class)
    public void testDoubleEqualsInfinityThrows() {
      NumberUtil.doubleEquals(Double.POSITIVE_INFINITY, 1.0);
    }
  }
}
