package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.bytedance.flow.control.FlowControlContainer;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import org.apache.thrift.TBase;
import org.apache.thrift.TException;
import org.apache.thrift.TFieldIdEnum;
import org.apache.thrift.protocol.TField;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.protocol.TStruct;
import org.apache.thrift.protocol.TType;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

@RunWith(Enclosed.class)
public class ThriftInvokerBitsUTTest {
  public static class ThriftInvokerToJSONStringTest {

    @Test
    public void testToJSONString_ThriftSerializerSuccess() {
      GoodThriftBase base = new GoodThriftBase("abc");
      String json = ThriftInvoker.toJSONString(base);
      assertTrue(json.contains("abc"));
      assertTrue(json.startsWith("{"));
    }

    @Test
    public void testToJSONString_ThriftSerializerFailsJacksonSuccess() {
      FailingThriftBase base = new FailingThriftBase("jackson");
      String json = ThriftInvoker.toJSONString(base);
      assertTrue(json.contains("\"name\":\"jackson\""));
      assertTrue(json.startsWith("{"));
    }

    @Test
    public void testToJSONString_BothSerializerFailReturnsEmpty() {
      SelfRefBase base = new SelfRefBase();
      String json = ThriftInvoker.toJSONString(base);
      assertEquals("", json);
    }

    class GoodThriftBase implements TBase<GoodThriftBase, GoodThriftBase.GoodThriftField> {
      public String value;

      GoodThriftBase(String value) {
        this.value = value;
      }

      @Override
      public void read(TProtocol iprot) throws TException {
        // not needed for tests
      }

      @Override
      public void write(TProtocol oprot) throws TException {
        oprot.writeStructBegin(new TStruct("GoodThriftBase"));
        oprot.writeFieldBegin(new TField("value", TType.STRING, (short) 1));
        oprot.writeString(value);
        oprot.writeFieldEnd();
        oprot.writeFieldStop();
        oprot.writeStructEnd();
      }

      @Override
      public GoodThriftBase deepCopy() {
        return new GoodThriftBase(this.value);
      }

      @Override
      public void clear() {
        this.value = null;
      }

      @Override
      public Object getFieldValue(GoodThriftField field) {
        if (field != null && "value".equals(field.getFieldName())) {
          return value;
        }
        return null;
      }

      @Override
      public void setFieldValue(GoodThriftField field, Object val) {
        if (field != null && "value".equals(field.getFieldName())) {
          this.value = (String) val;
        }
      }

      @Override
      public boolean isSet(GoodThriftField field) {
        if (field != null && "value".equals(field.getFieldName())) {
          return this.value != null;
        }
        return false;
      }

      @Override
      public GoodThriftField fieldForId(int fieldId) {
        if (fieldId == 1) {
          return new GoodThriftField((short) 1, "value");
        }
        return null;
      }

      @Override
      public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof GoodThriftBase)) return false;
        GoodThriftBase other = (GoodThriftBase) that;
        if (this.value == null) return other.value == null;
        return this.value.equals(other.value);
      }

      @Override
      public int compareTo(GoodThriftBase other) {
        if (other == null) return 1;
        if (this.value == null && other.value == null) return 0;
        if (this.value == null) return -1;
        if (other.value == null) return 1;
        return this.value.compareTo(other.value);
      }

      class GoodThriftField implements TFieldIdEnum {
        private final short id;
        private final String name;

        GoodThriftField(short id, String name) {
          this.id = id;
          this.name = name;
        }

        @Override
        public short getThriftFieldId() {
          return id;
        }

        @Override
        public String getFieldName() {
          return name;
        }
      }
    }

    class FailingThriftBase
        implements TBase<FailingThriftBase, FailingThriftBase.FailingThriftField> {
      public String name;

      FailingThriftBase(String name) {
        this.name = name;
      }

      @Override
      public void read(TProtocol iprot) throws TException {
        // not needed for tests
      }

      @Override
      public void write(TProtocol oprot) throws TException {
        throw new TException("intentional thrift write failure");
      }

      @Override
      public FailingThriftBase deepCopy() {
        return new FailingThriftBase(this.name);
      }

      @Override
      public void clear() {
        this.name = null;
      }

      @Override
      public Object getFieldValue(FailingThriftField field) {
        if (field != null && "name".equals(field.getFieldName())) {
          return name;
        }
        return null;
      }

      @Override
      public void setFieldValue(FailingThriftField field, Object val) {
        if (field != null && "name".equals(field.getFieldName())) {
          this.name = (String) val;
        }
      }

      @Override
      public boolean isSet(FailingThriftField field) {
        if (field != null && "name".equals(field.getFieldName())) {
          return this.name != null;
        }
        return false;
      }

      @Override
      public FailingThriftField fieldForId(int fieldId) {
        if (fieldId == 1) {
          return new FailingThriftField((short) 1, "name");
        }
        return null;
      }

      @Override
      public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof FailingThriftBase)) return false;
        FailingThriftBase other = (FailingThriftBase) that;
        if (this.name == null) return other.name == null;
        return this.name.equals(other.name);
      }

      @Override
      public int compareTo(FailingThriftBase other) {
        if (other == null) return 1;
        if (this.name == null && other.name == null) return 0;
        if (this.name == null) return -1;
        if (other.name == null) return 1;
        return this.name.compareTo(other.name);
      }

      class FailingThriftField implements TFieldIdEnum {
        private final short id;
        private final String name;

        FailingThriftField(short id, String name) {
          this.id = id;
          this.name = name;
        }

        @Override
        public short getThriftFieldId() {
          return id;
        }

        @Override
        public String getFieldName() {
          return name;
        }
      }
    }

    class SelfRefBase implements TBase<SelfRefBase, SelfRefBase.SelfRefField> {
      public SelfRefBase self;

      SelfRefBase() {
        this.self = this;
      }

      @Override
      public void read(TProtocol iprot) throws TException {
        // not needed for tests
      }

      @Override
      public void write(TProtocol oprot) throws TException {
        throw new TException("intentional thrift write failure");
      }

      @Override
      public SelfRefBase deepCopy() {
        SelfRefBase copy = new SelfRefBase();
        copy.self = copy;
        return copy;
      }

      @Override
      public void clear() {
        this.self = null;
      }

      @Override
      public Object getFieldValue(SelfRefField field) {
        if (field != null && "self".equals(field.getFieldName())) {
          return self;
        }
        return null;
      }

      @Override
      public void setFieldValue(SelfRefField field, Object val) {
        if (field != null && "self".equals(field.getFieldName())) {
          this.self = (SelfRefBase) val;
        }
      }

      @Override
      public boolean isSet(SelfRefField field) {
        if (field != null && "self".equals(field.getFieldName())) {
          return this.self != null;
        }
        return false;
      }

      @Override
      public SelfRefField fieldForId(int fieldId) {
        if (fieldId == 1) {
          return new SelfRefField((short) 1, "self");
        }
        return null;
      }

      @Override
      public boolean equals(Object that) {
        if (this == that) return true;
        if (!(that instanceof SelfRefBase)) return false;
        SelfRefBase other = (SelfRefBase) that;
        if (this.self == null) return other.self == null;
        return this.self == other.self;
      }

      @Override
      public int compareTo(SelfRefBase other) {
        return (this == other) ? 0 : 1;
      }

      class SelfRefField implements TFieldIdEnum {
        private final short id;
        private final String name;

        SelfRefField(short id, String name) {
          this.id = id;
          this.name = name;
        }

        @Override
        public short getThriftFieldId() {
          return id;
        }

        @Override
        public String getFieldName() {
          return name;
        }
      }
    }
  }

  public static class ThriftInvokerSetApplicationContextTest {

    @Test
    public void testSetApplicationContext_callsGetBean() {
      final boolean[] called = new boolean[1];

      ApplicationContext applicationContext =
          (ApplicationContext)
              Proxy.newProxyInstance(
                  ApplicationContext.class.getClassLoader(),
                  new Class[] {ApplicationContext.class},
                  new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) {
                      if ("getBean".equals(method.getName())
                          && args != null
                          && args.length == 1
                          && args[0] == FlowControlContainer.class) {
                        called[0] = true;
                        return null;
                      }
                      throw new UnsupportedOperationException(
                          "Unsupported method: " + method.getName());
                    }
                  });

      ThriftInvoker invoker = new ThriftInvoker();
      invoker.setApplicationContext(applicationContext);

      assertTrue(called[0]);
    }

    @Test(expected = BeansException.class)
    public void testSetApplicationContext_propagatesBeansException() {
      ApplicationContext applicationContext =
          (ApplicationContext)
              Proxy.newProxyInstance(
                  ApplicationContext.class.getClassLoader(),
                  new Class[] {ApplicationContext.class},
                  new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) {
                      if ("getBean".equals(method.getName())
                          && args != null
                          && args.length == 1
                          && args[0] == FlowControlContainer.class) {
                        throw new BeansException("getBean failed") {};
                      }
                      throw new UnsupportedOperationException(
                          "Unsupported method: " + method.getName());
                    }
                  });

      ThriftInvoker invoker = new ThriftInvoker();
      invoker.setApplicationContext(applicationContext);
    }
  }
}
