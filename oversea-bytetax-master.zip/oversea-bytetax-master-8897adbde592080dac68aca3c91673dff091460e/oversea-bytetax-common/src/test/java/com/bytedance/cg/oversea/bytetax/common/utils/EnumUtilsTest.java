package com.bytedance.cg.oversea.bytetax.common.utils;

import com.bytedance.cg.oversea.bytetax.common.constant.enums.*;
import org.apache.thrift.TEnum;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;

public class EnumUtilsTest {

    @Test
    public void testGetCode1() {
        // Setup
        final BaseEnum baseEnum = null;

        // Run the test
        final Object result = EnumUtils.getCode(baseEnum);

        // Verify the results
        assertNull(result);
    }

    @Test
    public void testGetCode2() {
        // Setup
        final BaseIntEnum baseIntEnum = EnumRelationType.AND;

        // Run the test
        final Integer result = EnumUtils.getCode(baseIntEnum);

        // Verify the results
        assertEquals(Integer.valueOf(1), result);
    }


    @Test
    public void testGetCode4() {
        // Setup
        final BaseStringEnum baseStringEnum = EnumBizVariable.START_DATE;

        // Run the test
        final String result = EnumUtils.getCode(baseStringEnum);

        // Verify the results
        assertEquals("start_date", result);
    }

    @Test
    public void testGetName1() {
        // Setup
        final BaseEnum baseEnum = null;

        // Run the test
        final String result = EnumUtils.getName(baseEnum);

        // Verify the results
        assertNull(result);
    }

    @Test
    public void testGetEnumByCode() {
        // Run the test
        final EnumAsyncTaskStatus result = EnumUtils.getEnumByCode(EnumAsyncTaskStatus.values(), 1);

        // Verify the results
        assertEquals(EnumAsyncTaskStatus.INIT, result);
    }

    @Test
    public void testGetName2() {

        // Run the test
        final String result = EnumUtils.getName(EnumBizVariable.values(), "start_date");

        // Verify the results
        assertEquals("开始日期", result);
    }

    @Test
    public void testCheckCodeValid() {

        // Run the test
        final boolean result = EnumUtils.checkCodeValid(1, EnumAsyncTaskStatus.values());

        // Verify the results
        assertTrue(result);
    }

    @Test
    public void testGetEnumByName() {
        // Run the test
        final EnumAsyncTaskStatus result = EnumUtils.getEnumByName(EnumAsyncTaskStatus.values(), "初始化");

        // Verify the results
        assertEquals(EnumAsyncTaskStatus.INIT, result);
    }

    @Test
    public void testGetLabel() {
        // Setup
        final BaseEnum baseEnum = EnumAsyncTaskStatus.CALCULATING;

        // Run the test
        final String result = EnumUtils.getLabel(baseEnum);

        // Verify the results
        assertEquals("计算中", result);
    }

    @Test
    public void testNotMatch() {
        // Setup
        final BaseEnum origin = null;
        final BaseEnum compare = null;

        // Run the test
        final boolean result = EnumUtils.notMatch(origin, compare);

        // Verify the results
        assertFalse(result);
    }

    @Test
    public void testMatch() {
        // Setup
        final BaseEnum origin = null;
        final BaseEnum compare = null;

        // Run the test
        final boolean result = EnumUtils.match(origin, compare);

        // Verify the results
        assertTrue(result);
    }


    @Test
    public void testGetCodeListString() {
        // Run the test
        final String result = EnumUtils.getCodeListString(Arrays.asList(EnumAsyncTaskStatus.values()));

        // Verify the results
        assertEquals("[1,2,3,4]", result);
    }
}
