package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class PageQueryUtilBitsUTTest {
  public static class PageQueryUtilFullQueryByPageIndexTest {

    @Test
    public void testFullQueryByPageIndex_singlePage() {
      Function<Integer, List<Integer>> func =
          pageIndex -> new ArrayList<>(Arrays.asList(pageIndex, pageIndex + 1));
      List<Integer> result = PageQueryUtil.fullQueryByPageIndex(func, 0, 5);
      assertEquals(Arrays.asList(0, 1), result);
    }

    @Test
    public void testFullQueryByPageIndex_multiPages() {
      Function<Integer, List<Integer>> func =
          pageIndex -> {
            if (pageIndex == 0) {
              return new ArrayList<>(Arrays.asList(0, 1, 2));
            } else if (pageIndex == 1) {
              return new ArrayList<>(Arrays.asList(10, 11, 12));
            } else {
              return new ArrayList<>(Arrays.asList(20));
            }
          };
      List<Integer> result = PageQueryUtil.fullQueryByPageIndex(func, 0, 3);
      assertEquals(Arrays.asList(0, 1, 2, 10, 11, 12, 20), result);
    }

    @Test
    public void testFullQueryByPageIndex_startIndexNonZero() {
      Function<Integer, List<Integer>> func =
          pageIndex -> {
            if (pageIndex == 5) {
              return new ArrayList<>(Arrays.asList(50, 51));
            } else if (pageIndex == 6) {
              return new ArrayList<>(Arrays.asList(60, 61));
            } else {
              return new ArrayList<>(Arrays.asList(70));
            }
          };
      List<Integer> result = PageQueryUtil.fullQueryByPageIndex(func, 5, 2);
      assertEquals(Arrays.asList(50, 51, 60, 61, 70), result);
    }

    @Test
    public void testFullQueryByPageIndex_emptyFirstPage() {
      final int[] calls = new int[] {0};
      Function<Integer, List<String>> func =
          pageIndex -> {
            calls[0]++;
            return new ArrayList<>();
          };
      List<String> result = PageQueryUtil.fullQueryByPageIndex(func, 1, 3);
      assertEquals(0, result.size());
      assertEquals(1, calls[0]);
    }

    @Test
    public void testFullQueryByPageIndex_exactPageSizeThenSmaller() {
      Function<Integer, List<String>> func =
          pageIndex -> {
            if (pageIndex == 0) {
              return new ArrayList<>(Arrays.asList("a", "b"));
            }
            return new ArrayList<>(Collections.singletonList("c"));
          };
      List<String> result = PageQueryUtil.fullQueryByPageIndex(func, 0, 2);
      assertEquals(Arrays.asList("a", "b", "c"), result);
    }
  }

  public static class PageQueryUtilQueryByPageTest {

    class TestItem {
      private final long id;

      TestItem(long id) {
        this.id = id;
      }

      long getId() {
        return id;
      }
    }

    class DataSource {
      private final List<TestItem> items;
      private final int pageSize;
      private final List<Long> calledOffsets = new ArrayList<>();

      DataSource(List<TestItem> items, int pageSize) {
        this.items = items;
        this.pageSize = pageSize;
      }

      List<TestItem> query(Long offset) {
        calledOffsets.add(offset);
        List<TestItem> res = new ArrayList<>();
        for (TestItem item : items) {
          if (item.getId() > offset) {
            res.add(item);
            if (res.size() == pageSize) {
              break;
            }
          }
        }
        return res;
      }

      List<Long> getCalledOffsets() {
        return calledOffsets;
      }
    }

    @Test
    public void testQueryByPage_MultiPages() {
      List<TestItem> all =
          Arrays.asList(
              new TestItem(1L),
              new TestItem(2L),
              new TestItem(3L),
              new TestItem(4L),
              new TestItem(5L),
              new TestItem(6L),
              new TestItem(7L));
      int limit = 3;
      DataSource ds = new DataSource(all, limit);

      List<TestItem> result =
          PageQueryUtil.queryByPage(
              new Function<Long, List<TestItem>>() {
                @Override
                public List<TestItem> apply(Long offset) {
                  return ds.query(offset);
                }
              },
              new Function<TestItem, Long>() {
                @Override
                public Long apply(TestItem r) {
                  return r.getId();
                }
              },
              limit);

      List<Long> ids = new ArrayList<>();
      for (TestItem item : result) {
        ids.add(item.getId());
      }
      assertEquals(Arrays.asList(1L, 2L, 3L, 4L, 5L, 6L, 7L), ids);
      assertEquals(Arrays.asList(0L, 3L, 6L), ds.getCalledOffsets());
    }

    @Test
    public void testQueryByPage_EmptyFirstPage() {
      List<TestItem> all = new ArrayList<>();
      int limit = 3;
      DataSource ds = new DataSource(all, limit);

      List<TestItem> result =
          PageQueryUtil.queryByPage(
              new Function<Long, List<TestItem>>() {
                @Override
                public List<TestItem> apply(Long offset) {
                  return ds.query(offset);
                }
              },
              new Function<TestItem, Long>() {
                @Override
                public Long apply(TestItem r) {
                  return r.getId();
                }
              },
              limit);

      assertEquals(0, result.size());
      assertEquals(Arrays.asList(0L), ds.getCalledOffsets());
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void testQueryByPage_QueryCountLimitZeroThrows() {
      List<TestItem> all = new ArrayList<>();
      int limit = 0;
      DataSource ds = new DataSource(all, 0);

      PageQueryUtil.queryByPage(
          new Function<Long, List<TestItem>>() {
            @Override
            public List<TestItem> apply(Long offset) {
              return ds.query(offset);
            }
          },
          new Function<TestItem, Long>() {
            @Override
            public Long apply(TestItem r) {
              return r.getId();
            }
          },
          limit);
    }

    @Test
    public void testQueryByPage_SinglePageExactLimit() {
      List<TestItem> all = Arrays.asList(new TestItem(1L), new TestItem(2L), new TestItem(3L));
      int limit = 3;
      DataSource ds = new DataSource(all, limit);

      List<TestItem> result =
          PageQueryUtil.queryByPage(
              new Function<Long, List<TestItem>>() {
                @Override
                public List<TestItem> apply(Long offset) {
                  return ds.query(offset);
                }
              },
              new Function<TestItem, Long>() {
                @Override
                public Long apply(TestItem r) {
                  return r.getId();
                }
              },
              limit);

      List<Long> ids = new ArrayList<>();
      for (TestItem item : result) {
        ids.add(item.getId());
      }
      assertEquals(Arrays.asList(1L, 2L, 3L), ids);
      assertEquals(Arrays.asList(0L, 3L), ds.getCalledOffsets());
    }
  }
}
