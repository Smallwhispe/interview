package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.*;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.*;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ExcelUtilBitsUTTest {
  public static class ExcelUtilToExcelMapToExcelHe7107Test {

    @Test
    public void testToExcelNullWhenDataMapEmpty() {
      Map<String, List<Object>> dataMap = new HashMap<String, List<Object>>();
      List<String> sheetNames = Arrays.asList("S1", "S2");
      byte[] bytes = ExcelUtil.toExcel(dataMap, sheetNames, Object.class);
      assertNull(bytes);
    }

    @Test
    public void testToExcelNullWhenSheetNamesEmpty() {
      Map<String, List<String>> dataMap = new HashMap<String, List<String>>();
      dataMap.put("S1", Arrays.asList("a", "b"));
      List<String> sheetNames = new ArrayList<String>();
      byte[] bytes = ExcelUtil.toExcel(dataMap, sheetNames, String.class);
      assertNull(bytes);
    }
  }

  public static class ExcelUtilReadTest {

    @Test
    public void testReadInvalidStream() throws Exception {
      InputStream is = new ByteArrayInputStream("not an excel".getBytes("UTF-8"));
      try {
        ExcelUtil.read(is, DummyModel.class);
        fail("Expected exception was not thrown");
      } catch (Exception e) {
        assertNotNull(e);
      }
    }

    @Test
    public void testReadNullInputStream() {
      try {
        ExcelUtil.read(null, DummyModel.class);
        fail("Expected exception was not thrown");
      } catch (Exception e) {
        assertNotNull(e);
      }
    }

    @Test
    public void testReadNullHeader() {
      InputStream is = new ByteArrayInputStream(new byte[0]);
      try {
        ExcelUtil.read(is, null);
        fail("Expected exception was not thrown");
      } catch (Exception e) {
        assertNotNull(e);
      }
    }

    class DummyModel {
      private String name;

      public DummyModel() {}

      public String getName() {
        return name;
      }

      public void setName(String name) {
        this.name = name;
      }
    }
  }

  public static class ExcelUtilReadFirstSheet2ModelTest {

    @Test
    public void testReadFirstSheet2ModelNullListener() {
      ByteArrayInputStream is = new ByteArrayInputStream(new byte[0]);
      try {
        ExcelUtil.readFirstSheet2Model(is, ExcelReadModel.class, null);
        fail("Expected exception but none thrown");
      } catch (Throwable e) {
        assertNotNull(e);
      }
    }

    @Test
    public void testReadFirstSheet2ModelNullClass() {
      ByteArrayInputStream is = new ByteArrayInputStream(new byte[0]);
      AnalysisEventListener<ExcelReadModel> listener =
          new AnalysisEventListener<ExcelReadModel>() {
            @Override
            public void invoke(ExcelReadModel data, AnalysisContext context) {}

            @Override
            public void doAfterAllAnalysed(AnalysisContext context) {}
          };
      try {
        ExcelUtil.readFirstSheet2Model(is, null, listener);
        fail("Expected exception but none thrown");
      } catch (Throwable e) {
        assertNotNull(e);
      }
    }

    @Test
    public void testReadFirstSheet2ModelNullInputStream() {
      AnalysisEventListener<ExcelReadModel> listener =
          new AnalysisEventListener<ExcelReadModel>() {
            @Override
            public void invoke(ExcelReadModel data, AnalysisContext context) {}

            @Override
            public void doAfterAllAnalysed(AnalysisContext context) {}
          };
      try {
        ExcelUtil.readFirstSheet2Model(null, ExcelReadModel.class, listener);
        fail("Expected exception but none thrown");
      } catch (Throwable e) {
        assertNotNull(e);
      }
    }

    class ExcelReadModel {
      private String name;
      private Integer age;

      public ExcelReadModel() {}

      public String getName() {
        return name;
      }

      public Integer getAge() {
        return age;
      }

      public void setName(String name) {
        this.name = name;
      }

      public void setAge(Integer age) {
        this.age = age;
      }
    }
  }
}
