package com.bytedance.cg.oversea.bytetax.common.utils;

import org.joda.time.DateTime;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.junit.Assert.assertEquals;

public class DateUtilTest {

    @Test
    public void testDecreaseDays() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.decreaseDays(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testTimeStampToDateUTC0() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.timeStampToDateUTC0(1577808000000L));
    }

    @Test
    public void testDateLocal2UTC0() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.dateLocal2UTC0(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testDateUTC02Local() {
        assertEquals("2020-01-01 00:00:00", DateUtil.dateUTC02Local(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testDateLocal2UTC0ConsiderDefaultDate() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.dateLocal2UTC0ConsiderDefaultDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testDateUTC02LocalConsiderDefaultDate() {
        assertEquals("2020-01-01 00:00:00", DateUtil.dateUTC02LocalConsiderDefaultDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testDateUTC02LocalDate() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.dateUTC02LocalDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testLocalDateTime2Date() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.localDateTime2Date(LocalDateTime.of(2019, 12, 31, 16, 0, 0), ZoneOffset.UTC));
    }

    @Test
    public void testDate2LocalDateTime() {
        assertEquals(LocalDateTime.of(2020, 1, 1, 0, 0, 0), DateUtil.date2LocalDateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), ZoneOffset.UTC));
    }

    @Test
    public void testDateToStr1() {
        assertEquals("2020-01-01 00:00:00", DateUtil.dateToStr(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime()));
    }

    @Test
    public void testDateToStr2() {
        assertEquals("2020-01-01 00:00:00", DateUtil.dateToStr(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), "yyyy-MM-dd HH:mm:ss"));
    }

    @Test
    public void testStrToDate1() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.strToDate("2020-01-01 00:00:00"));
    }

    @Test
    public void testStrToTimestamp() {
        Long expect = 1577808000000L;
        assertEquals(expect, DateUtil.strToTimestamp("2020-01-01 00:00:00"));
    }

    @Test
    public void testStrToDate2() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.strToDate("2020-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss"));
    }

    @Test
    public void testGetLatestDateTime() {
        assertEquals(new DateTime(2020, 1, 1, 1, 0, 0, 0), DateUtil.getLatestDateTime(Arrays.asList(new DateTime(2020, 1, 1, 1, 0, 0, 0))));
    }

    @Test
    public void testGetLatestDate() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.getLatestDate(Arrays.asList(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime())));
    }

    @Test
    public void testGetEarliestDateTime() {
        assertEquals(new DateTime(2020, 1, 1, 1, 0, 0, 0), DateUtil.getEarliestDateTime(Arrays.asList(new DateTime(2020, 1, 1, 1, 0, 0, 0))));
    }

    @Test
    public void testGetEarliestDate() {
        assertEquals(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), DateUtil.getEarliestDate(Arrays.asList(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime())));
    }

    @Test
    public void testStrToDateTime() {
        assertEquals(new DateTime(2020, 1, 1, 0, 0, 0, 0), DateUtil.strToDateTime("2020-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss"));
    }

    @Test
    public void testFindDates() throws Exception {
        assertEquals(Arrays.asList("2020-01-01 00:00:00"), DateUtil.findDates("dateType", new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime()));
    }

    @Test
    public void testFormatDateTime() {
        assertEquals("2020-01-01 00:00:00", DateUtil.formatDateTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime()));
    }

    @Test
    public void testOffsetDate() {
        assertEquals("2020-01-01 00:00:00", DateUtil.offsetDate(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0, 0));
    }

    @Test
    public void testGetMonthlyOffsetStartTime() {
        assertEquals("2020-01-01 00:00:00", DateUtil.getMonthlyOffsetStartTime(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), 0));
    }

    @Test
    public void testTrans1() {
        assertEquals("2020-01-01", DateUtil.trans(20200101L));
    }

    @Test
    public void testTrans2() {
        Long expect = 20200101L;
        assertEquals(expect, DateUtil.trans("2020-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss"));
    }


    @Test
    public void testTrans4() {
        assertEquals(new DateTime(2020, 1, 1, 0, 0, 0, 0), DateUtil.trans("20200101"));
    }

    @Test
    public void testTransByPatten() {
        assertEquals(new DateTime(2020, 1, 1, 0, 0, 0, 0), DateUtil.transByPatten("2020-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss"));
    }

    @Test
    public void testDiffDays() {
        assertEquals(new BigDecimal("0"), DateUtil.diffDays(new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime(), new GregorianCalendar(2020, Calendar.JANUARY, 1).getTime()));
    }

    @Test
    public void testGetSecondGap() {
        Long expect = 0L;
        assertEquals(expect, DateUtil.getSecondGap(new DateTime(2020, 1, 1, 1, 0, 0, 0), new DateTime(2020, 1, 1, 1, 0, 0, 0)));
    }

    @Test
    public void testToDateTime() {
        assertEquals(new DateTime(2020, 1, 1, 0, 0, 0, 0), DateUtil.toDateTime(1577808000000L));
    }
}
