package com.bytedance.cg.oversea.bytetax.common.threadlocal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ThreadLocalContextBitsUTTest {
  public static class ThreadLocalContextSetTccGrayResThreadLocalValTest {

    @After
    public void tearDown() {
      ThreadLocalContext.removeTccGrayResThreadLocalVal();
    }

    @Test
    public void testSetAndGetAndRemove() {
      ThreadLocalContext.removeTccGrayResThreadLocalVal();
      String key = "k1";

      // 初始应为null
      assertEquals(null, ThreadLocalContext.getTccGrayResThreadLocalVal(key));

      // 设置后应能取到值
      ThreadLocalContext.setTccGrayResThreadLocalVal(key, true);
      assertEquals(Boolean.TRUE, ThreadLocalContext.getTccGrayResThreadLocalVal(key));

      // 移除后应为null
      ThreadLocalContext.removeTccGrayResThreadLocalVal();
      assertEquals(null, ThreadLocalContext.getTccGrayResThreadLocalVal(key));
    }

    @Test
    public void testOverwriteValue() {
      ThreadLocalContext.removeTccGrayResThreadLocalVal();
      String key = "overwrite";

      ThreadLocalContext.setTccGrayResThreadLocalVal(key, true);
      assertEquals(Boolean.TRUE, ThreadLocalContext.getTccGrayResThreadLocalVal(key));

      ThreadLocalContext.setTccGrayResThreadLocalVal(key, false);
      assertEquals(Boolean.FALSE, ThreadLocalContext.getTccGrayResThreadLocalVal(key));
    }

    @Test
    public void testMultipleKeysAndThreadIsolation() throws InterruptedException {
      ThreadLocalContext.removeTccGrayResThreadLocalVal();

      String key1 = "alpha";
      String key2 = "beta";
      ThreadLocalContext.setTccGrayResThreadLocalVal(key1, true);
      ThreadLocalContext.setTccGrayResThreadLocalVal(key2, false);

      assertEquals(Boolean.TRUE, ThreadLocalContext.getTccGrayResThreadLocalVal(key1));
      assertEquals(Boolean.FALSE, ThreadLocalContext.getTccGrayResThreadLocalVal(key2));

      AtomicReference<Boolean> otherThreadBefore = new AtomicReference<Boolean>();
      AtomicReference<Boolean> otherThreadAfter = new AtomicReference<Boolean>();
      CountDownLatch latch = new CountDownLatch(1);

      Thread t =
          new Thread(
              new Runnable() {
                @Override
                public void run() {
                  // 其他线程初始应看不到主线程的ThreadLocal值
                  otherThreadBefore.set(ThreadLocalContext.getTccGrayResThreadLocalVal(key1));

                  // 在其他线程设置值
                  ThreadLocalContext.setTccGrayResThreadLocalVal(key1, false);
                  otherThreadAfter.set(ThreadLocalContext.getTccGrayResThreadLocalVal(key1));

                  ThreadLocalContext.removeTccGrayResThreadLocalVal();
                  latch.countDown();
                }
              });
      t.start();
      latch.await();

      // 其他线程在设置前应为null，设置后为false
      assertEquals(null, otherThreadBefore.get());
      assertEquals(Boolean.FALSE, otherThreadAfter.get());

      // 主线程的值不受其他线程影响
      assertEquals(Boolean.TRUE, ThreadLocalContext.getTccGrayResThreadLocalVal(key1));
      assertEquals(Boolean.FALSE, ThreadLocalContext.getTccGrayResThreadLocalVal(key2));
    }

    @Test
    public void testSetNullValue() {
      ThreadLocalContext.removeTccGrayResThreadLocalVal();

      String nullKey = "gamma";
      String nonNullKey = "delta";

      ThreadLocalContext.setTccGrayResThreadLocalVal(nullKey, null);
      ThreadLocalContext.setTccGrayResThreadLocalVal(nonNullKey, true);

      // 为null的值读取为null
      assertEquals(null, ThreadLocalContext.getTccGrayResThreadLocalVal(nullKey));
      // 非null值正常读取
      assertEquals(Boolean.TRUE, ThreadLocalContext.getTccGrayResThreadLocalVal(nonNullKey));
    }
  }

  public static class ThreadLocalContextRemoveTccGrayResThreadLocalValTest {

    @Test
    public void testRemoveTccGrayResThreadLocalVal_ClearCurrentThreadValue() {
      // Setup
      ThreadLocalContext.setTccGrayResThreadLocalVal("k1", Boolean.TRUE);
      assertEquals(Boolean.TRUE, ThreadLocalContext.getTccGrayResThreadLocalVal("k1"));

      // Run the test
      ThreadLocalContext.removeTccGrayResThreadLocalVal();

      // Verify the results
      assertEquals(null, ThreadLocalContext.getTccGrayResThreadLocalVal("k1"));
    }

    @Test
    public void testRemoveTccGrayResThreadLocalVal_WhenNoValueSet() {
      // Setup
      assertEquals(null, ThreadLocalContext.getTccGrayResThreadLocalVal("unset"));

      // Run the test
      ThreadLocalContext.removeTccGrayResThreadLocalVal();

      // Verify the results
      assertEquals(null, ThreadLocalContext.getTccGrayResThreadLocalVal("unset"));
    }

    @Test
    public void testRemoveTccGrayResThreadLocalVal_ShouldNotAffectOtherThread()
        throws InterruptedException {
      // Setup other thread and sync primitives
      final CountDownLatch otherThreadSet = new CountDownLatch(1);
      final CountDownLatch proceedCheck = new CountDownLatch(1);
      final AtomicReference<Boolean> otherThreadValueAfterMainRemove =
          new AtomicReference<Boolean>();

      Thread other =
          new Thread(
              new Runnable() {
                @Override
                public void run() {
                  ThreadLocalContext.setTccGrayResThreadLocalVal("kOther", Boolean.FALSE);
                  otherThreadSet.countDown();
                  try {
                    proceedCheck.await();
                  } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                  }
                  otherThreadValueAfterMainRemove.set(
                      ThreadLocalContext.getTccGrayResThreadLocalVal("kOther"));
                  ThreadLocalContext.removeTccGrayResThreadLocalVal();
                }
              });

      other.start();
      otherThreadSet.await(); // ensure other thread has set its value

      // Current thread sets and then removes its own value
      ThreadLocalContext.setTccGrayResThreadLocalVal("kMain", Boolean.TRUE);
      assertEquals(Boolean.TRUE, ThreadLocalContext.getTccGrayResThreadLocalVal("kMain"));

      ThreadLocalContext.removeTccGrayResThreadLocalVal();
      assertEquals(null, ThreadLocalContext.getTccGrayResThreadLocalVal("kMain"));

      // Allow other thread to check its value after main thread removal
      proceedCheck.countDown();
      other.join();

      // Verify other thread's value remains unaffected
      assertEquals(Boolean.FALSE, otherThreadValueAfterMainRemove.get());
    }
  }

  public static class ThreadLocalContextGetTccGrayResThreadLocalValTest {

    @Before
    public void setUp() {
      // ensure clean state before each test
      ThreadLocalContext.removeTccGrayResThreadLocalVal();
    }

    @After
    public void tearDown() {
      // clean up after each test
      ThreadLocalContext.removeTccGrayResThreadLocalVal();
    }

    @Test
    public void testGetWhenNoValueSet() {
      // Run
      Boolean result = ThreadLocalContext.getTccGrayResThreadLocalVal("any");

      // Verify
      assertNull(result);
    }

    @Test
    public void testGetAfterSetTrue() {
      // Setup
      ThreadLocalContext.setTccGrayResThreadLocalVal("k1", true);

      // Run
      Boolean result = ThreadLocalContext.getTccGrayResThreadLocalVal("k1");

      // Verify
      assertEquals(Boolean.TRUE, result);
    }

    @Test
    public void testGetAfterSetFalseAndUnknownKey() {
      // Setup
      ThreadLocalContext.setTccGrayResThreadLocalVal("k2", false);

      // Run
      Boolean existing = ThreadLocalContext.getTccGrayResThreadLocalVal("k2");
      Boolean unknown = ThreadLocalContext.getTccGrayResThreadLocalVal("unknown");

      // Verify
      assertEquals(Boolean.FALSE, existing);
      assertNull(unknown);
    }

    @Test
    public void testThreadIsolation() throws InterruptedException {
      // Setup in main thread
      ThreadLocalContext.setTccGrayResThreadLocalVal("shared", true);

      final AtomicReference<Boolean> childInitial = new AtomicReference<Boolean>();
      final AtomicReference<Boolean> childAfterSet = new AtomicReference<Boolean>();
      final CountDownLatch latch = new CountDownLatch(1);

      Thread t =
          new Thread(
              new Runnable() {
                @Override
                public void run() {
                  try {
                    // should not see parent's value
                    childInitial.set(ThreadLocalContext.getTccGrayResThreadLocalVal("shared"));

                    // set in child thread
                    ThreadLocalContext.setTccGrayResThreadLocalVal("shared", false);
                    childAfterSet.set(ThreadLocalContext.getTccGrayResThreadLocalVal("shared"));
                  } finally {
                    // clean up child thread
                    ThreadLocalContext.removeTccGrayResThreadLocalVal();
                    latch.countDown();
                  }
                }
              });
      t.start();
      latch.await();

      // Verify child thread observations
      assertNull(childInitial.get());
      assertEquals(Boolean.FALSE, childAfterSet.get());

      // Verify main thread value is unaffected
      Boolean mainAfterChild = ThreadLocalContext.getTccGrayResThreadLocalVal("shared");
      assertEquals(Boolean.TRUE, mainAfterChild);
    }
  }
}
