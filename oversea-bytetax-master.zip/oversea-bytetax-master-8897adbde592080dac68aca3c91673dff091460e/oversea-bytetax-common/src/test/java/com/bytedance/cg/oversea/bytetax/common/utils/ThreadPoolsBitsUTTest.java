package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import com.bytedance.cg.common.exception.BizException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ThreadPoolsBitsUTTest {
  public static class ThreadPoolsGetOrDefaultTest {

    @Test
    public void testGetOrDefaultFutureNull() {
      Supplier<String> supplier =
          new Supplier<String>() {
            @Override
            public String get() {
              return "default";
            }
          };

      String result = ThreadPools.getOrDefault(null, supplier);

      assertEquals("default", result);
    }

    @Test
    public void testGetOrDefaultFutureSuccess() {
      Future<String> future = CompletableFuture.completedFuture("value");
      Supplier<String> supplier =
          new Supplier<String>() {
            @Override
            public String get() {
              return "default";
            }
          };

      String result = ThreadPools.getOrDefault(future, supplier);

      assertEquals("value", result);
    }

    @Test
    public void testGetOrDefaultInterruptedException() {
      Future<String> future =
          new Future<String>() {
            @Override
            public boolean cancel(boolean mayInterruptIfRunning) {
              return false;
            }

            @Override
            public boolean isCancelled() {
              return false;
            }

            @Override
            public boolean isDone() {
              return false;
            }

            @Override
            public String get() throws InterruptedException {
              throw new InterruptedException("interrupt");
            }

            @Override
            public String get(long timeout, TimeUnit unit)
                throws InterruptedException, ExecutionException, TimeoutException {
              throw new InterruptedException("interrupt");
            }
          };

      Supplier<String> supplier =
          new Supplier<String>() {
            @Override
            public String get() {
              return "default";
            }
          };

      String result = ThreadPools.getOrDefault(future, supplier);

      assertEquals("default", result);
    }

    @Test
    public void testGetOrDefaultExecutionException() {
      CompletableFuture<String> future = new CompletableFuture<String>();
      future.completeExceptionally(new RuntimeException("cause"));

      Supplier<String> supplier =
          new Supplier<String>() {
            @Override
            public String get() {
              return "default";
            }
          };

      String result = ThreadPools.getOrDefault(future, supplier);

      assertEquals("default", result);
    }

    @Test
    public void testGetOrDefaultRejectedExecutionException() {
      Future<String> future =
          new Future<String>() {
            @Override
            public boolean cancel(boolean mayInterruptIfRunning) {
              return false;
            }

            @Override
            public boolean isCancelled() {
              return false;
            }

            @Override
            public boolean isDone() {
              return false;
            }

            @Override
            public String get() throws ExecutionException {
              throw new RejectedExecutionException("rejected");
            }

            @Override
            public String get(long timeout, TimeUnit unit)
                throws ExecutionException, InterruptedException, TimeoutException {
              throw new RejectedExecutionException("rejected");
            }
          };

      Supplier<String> supplier =
          new Supplier<String>() {
            @Override
            public String get() {
              return "default";
            }
          };

      String result = ThreadPools.getOrDefault(future, supplier);

      assertEquals("default", result);
    }
  }

  public static class ThreadPoolsSafeGetHf4d98Test {

    @Test
    public void testSafeGetReturnsValueWhenCompleted() {
      CompletableFuture<String> future = CompletableFuture.completedFuture("ok");
      String result = ThreadPools.safeGet(future);
      assertEquals("ok", result);
    }

    @Test
    public void testSafeGetReturnsNullOnTimeout() {
      CompletableFuture<String> future = new CompletableFuture<>();
      String result = ThreadPools.safeGet(future);
      assertNull(result);
    }

    @Test(expected = BizException.class)
    public void testSafeGetThrowsBizExceptionOnExecutionException() {
      CompletableFuture<String> future = new CompletableFuture<>();
      future.completeExceptionally(new RuntimeException("boom"));
      ThreadPools.safeGet(future);
    }

    @Test(expected = BizException.class)
    public void testSafeGetThrowsBizExceptionOnNullFuture() {
      Future<String> future = null;
      ThreadPools.safeGet(future);
    }
  }

  public static class ThreadPoolsSafeGetH77f90Test {

    @Test
    public void testSafeGetReturnValue() {
      CompletableFuture<String> future = CompletableFuture.completedFuture("ok");
      String result = ThreadPools.safeGet(future, 100);
      assertEquals("ok", result);
    }

    @Test
    public void testSafeGetTimeoutReturnNull() {
      CompletableFuture<String> future = new CompletableFuture<>();
      String result = ThreadPools.safeGet(future, 1);
      assertNull(result);
    }

    @Test
    public void testSafeGetExecutionExceptionWrapToBizException() {
      CompletableFuture<String> future = new CompletableFuture<>();
      future.completeExceptionally(new RuntimeException("boom"));
      try {
        ThreadPools.safeGet(future, 100);
        fail("BizException should be thrown");
      } catch (BizException e) {
        assertEquals("java.lang.RuntimeException: boom", e.getMessage());
      }
    }
  }
}
