package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.support.GenericApplicationContext;

@RunWith(Enclosed.class)
public class GetBeanUtilBitsUTTest {
  public static class GetBeanUtilGetBeanHa4763Test {

    @Test
    public void testGetBeanByName() {
      GenericApplicationContext context = new GenericApplicationContext();
      context.getBeanFactory().registerSingleton("testBean", "ok");
      context.refresh();

      GetBeanUtil util = new GetBeanUtil();
      util.setApplicationContext(context);

      assertEquals("ok", GetBeanUtil.getBean("testBean"));

      try {
        GetBeanUtil.getBean("missingBean");
        fail("Expected NoSuchBeanDefinitionException to be thrown");
      } catch (NoSuchBeanDefinitionException e) {
        assertEquals("missingBean", e.getBeanName());
      }
    }
  }
}
