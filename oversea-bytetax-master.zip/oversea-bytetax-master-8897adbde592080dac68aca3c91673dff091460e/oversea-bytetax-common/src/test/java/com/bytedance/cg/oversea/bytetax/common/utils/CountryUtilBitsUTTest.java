package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class CountryUtilBitsUTTest {
  public static class CountryUtilCheckIsCanadaTest {

    @Test
    public void testCheckIsCanadaTrue() {
      assertEquals(true, CountryUtil.checkIsCanada(6251999L));
    }

    @Test
    public void testCheckIsCanadaFalseWhenIdDifferent() {
      assertEquals(false, CountryUtil.checkIsCanada(6252000L));
    }

    @Test
    public void testCheckIsCanadaFalseWhenNull() {
      assertEquals(false, CountryUtil.checkIsCanada(null));
    }
  }
}
