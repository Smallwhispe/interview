package com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery;

import static org.junit.Assert.assertEquals;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ConsulDiscoveryRegisterImplBitsUTTest {
  public static class ConsulDiscoveryRegisterImplRegisterTest {

    @Test
    public void testRegister_ReturnsFalseWhenResolverIsNull_UsingReflection() throws Exception {
      Class<?> clazz =
          Class.forName(
              "com.bytedance.cg.oversea.bytetax.common.http.idgenerator.discovery.ConsulDiscoveryRegisterImpl");

      Constructor<?> targetCtor = null;
      for (Constructor<?> c : clazz.getConstructors()) {
        if (c.getParameterTypes().length == 1) {
          targetCtor = c;
          break;
        }
      }
      if (targetCtor == null) {
        Constructor<?>[] ctors = clazz.getConstructors();
        if (ctors.length > 0) {
          targetCtor = ctors[0];
        }
      }

      Object instance = targetCtor.newInstance(new Object[] {null});

      Method registerMethod = null;
      for (Method m : clazz.getMethods()) {
        if ("register".equals(m.getName())) {
          Class<?>[] pts = m.getParameterTypes();
          if (pts.length == 2 && pts[0] == String.class) {
            registerMethod = m;
            break;
          }
        }
      }

      Object result = registerMethod.invoke(instance, "psm-test", null);
      boolean boolResult = result instanceof Boolean ? ((Boolean) result) : false;

      assertEquals(false, boolResult);
    }
  }
}
