package com.bytedance.cg.oversea.bytetax.common.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.IOException;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HttpContext;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class HttpUtilBitsUTTest {
  public static class HttpUtilExecuteByEnvTest {

    class StubClient extends CloseableHttpClient {
      private final boolean throwIOException;

      StubClient(boolean throwIOException) {
        this.throwIOException = throwIOException;
      }

      @Override
      protected CloseableHttpResponse doExecute(
          HttpHost target, HttpRequest request, HttpContext context) throws IOException {
        if (throwIOException) {
          throw new IOException("io fail");
        }
        return null;
      }

      @Override
      public void close() throws IOException {
        // no-op
      }

      @Override
      public HttpParams getParams() {
        return null;
      }

      @Override
      public ClientConnectionManager getConnectionManager() {
        return null;
      }
    }

    @Test
    public void testExecuteByEnvDebugTrueReturnsNullResponse() throws Exception {
      CloseableHttpClient client = new StubClient(false);
      HttpUriRequest request = new HttpGet("http://example.com");

      CloseableHttpResponse result = HttpUtil.executeByEnv(client, request, "/test/path", true);

      assertEquals(null, result);
    }

    @Test
    public void testExecuteByEnvClientNotPublicNetThrowsRuntimeException() {
      CloseableHttpClient client = new StubClient(false);
      HttpUriRequest request = new HttpGet("http://example.com");

      try {
        HttpUtil.executeByEnv(client, request, "/test/path", false);
        fail("Expected RuntimeException");
      } catch (RuntimeException e) {
        assertEquals("http client type error", e.getMessage());
      } catch (IOException e) {
        fail("Did not expect IOException");
      }
    }

    @Test
    public void testExecuteByEnvDebugTrueThrowsIOException() throws Exception {
      CloseableHttpClient client = new StubClient(true);
      HttpUriRequest request = new HttpGet("http://example.com");

      try {
        HttpUtil.executeByEnv(client, request, "/test/path", true);
        fail("Expected IOException");
      } catch (IOException e) {
        assertEquals("io fail", e.getMessage());
      }
    }
  }
}
