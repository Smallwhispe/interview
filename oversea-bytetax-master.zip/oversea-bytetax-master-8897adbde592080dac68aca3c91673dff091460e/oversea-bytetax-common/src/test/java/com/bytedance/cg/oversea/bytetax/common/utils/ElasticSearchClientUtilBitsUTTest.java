package com.bytedance.cg.oversea.bytetax.common.utils;

import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

@RunWith(Enclosed.class)
public class ElasticSearchClientUtilBitsUTTest {
  public static class ElasticSearchClientUtilForConnectToNonSecurityClusterTest {

    @Test(expected = IllegalArgumentException.class)
    public void testForConnectToNonSecurityCluster_NullArgsThrowsIllegalArgumentException() {
      ElasticSearchClientUtil.forConnectToNonSecurityCluster(null, null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testForConnectToNonSecurityCluster_EmptyPsmThrowsIllegalArgumentException() {
      ElasticSearchClientUtil.forConnectToNonSecurityCluster("", "cluster");
    }

    @Test(expected = IllegalArgumentException.class)
    public void
        testForConnectToNonSecurityCluster_ValidInputButEnvironmentWithoutNodesThrowsIllegalArgumentException() {
      ElasticSearchClientUtil.forConnectToNonSecurityCluster("psmService", "clusterName");
    }
  }
}
